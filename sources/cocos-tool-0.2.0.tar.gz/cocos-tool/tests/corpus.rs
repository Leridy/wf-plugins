//! End-to-end corpus tests covering all Cocos Creator 3.x converters, strict JSON/UUID integrity,
//! manifest reconciliation, edit preservation, `--force` overwrite, and leftover cleanup.
mod common;

use common::Fake;
use plugin_protocols::lint::LintInput;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use wf_cocos_tool::{Input, Status, lint, sync};

const BASE64_KEYS: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";

fn sha256_hex(bytes: &[u8]) -> String {
    let mut out = String::with_capacity(64);
    for b in Sha256::digest(bytes) {
        out.push(HEX_CHARS[(b >> 4) as usize] as char);
        out.push(HEX_CHARS[(b & 0x0f) as usize] as char);
    }
    out
}

fn decompress_uuid(compressed: &str) -> Option<String> {
    let bytes = compressed.as_bytes();
    let (prefix_len, rest) = match bytes.len() {
        23 => (5usize, &bytes[5..]),
        22 => (2usize, &bytes[2..]),
        _ => return None,
    };
    if !bytes[..prefix_len].iter().all(u8::is_ascii_hexdigit) || !rest.len().is_multiple_of(2) {
        return None;
    }
    let mut hex = Vec::with_capacity(32);
    for &b in &bytes[..prefix_len] {
        hex.push(b.to_ascii_lowercase());
    }
    for pair in rest.chunks_exact(2) {
        let lhs = u8::try_from(BASE64_KEYS.iter().position(|&k| k == pair[0])?).ok()?;
        let rhs = u8::try_from(BASE64_KEYS.iter().position(|&k| k == pair[1])?).ok()?;
        hex.push(HEX_CHARS[(lhs >> 2) as usize]);
        hex.push(HEX_CHARS[(((lhs & 0x3) << 2) | (rhs >> 4)) as usize]);
        hex.push(HEX_CHARS[(rhs & 0xf) as usize]);
    }
    let s = String::from_utf8(hex).ok()?;
    Some(format!(
        "{}-{}-{}-{}-{}",
        &s[0..8],
        &s[8..12],
        &s[12..16],
        &s[16..20],
        &s[20..32]
    ))
}

fn is_builtin_type(ty: &str) -> bool {
    ty.starts_with("cc.")
        || ty.starts_with("sp.")
        || ty.starts_with("dragonBones.")
        || ty.starts_with("js.")
        || ty.starts_with("cce.")
}

fn record_meta_uuid(seen: &mut BTreeMap<String, String>, path: &str, raw: &str) -> String {
    let norm = raw.trim().to_ascii_lowercase();
    if let Some(prev) = seen.insert(norm.clone(), path.to_owned()) {
        panic!("{path}: duplicate UUID `{norm}` (already used in `{prev}`)");
    }
    norm
}

fn verify_strict_json_and_uuid_integrity(files: &BTreeMap<String, Vec<u8>>) {
    let mut seen_uuids = BTreeMap::new();
    let mut script_uuids = BTreeSet::new();

    for (path, bytes) in files {
        if !path.ends_with(".meta") {
            continue;
        }
        let target = path.strip_suffix(".meta").unwrap();
        let v: Value = serde_json::from_slice(bytes).unwrap_or_else(|e| panic!("{path}: invalid json: {e}"));
        let importer = v.get("importer").and_then(Value::as_str).unwrap_or_default();
        if importer != "directory" {
            let dir_prefix = format!("{target}/");
            let has_file = files.contains_key(target) || files.keys().any(|k| k.starts_with(&dir_prefix));
            assert!(has_file, "{path}: orphan .meta missing asset `{target}`");
        }
        let main_uuid = v
            .get("uuid")
            .and_then(Value::as_str)
            .unwrap_or_else(|| panic!("{path}: missing uuid"));
        let norm = record_meta_uuid(&mut seen_uuids, path, main_uuid);
        if matches!(importer, "typescript" | "javascript") {
            script_uuids.insert(norm);
        }
        if let Some(subs) = v.get("subMetas").and_then(Value::as_object) {
            for sub in subs.values() {
                if let Some(su) = sub.get("uuid").and_then(Value::as_str) {
                    record_meta_uuid(&mut seen_uuids, path, su);
                }
            }
        }
    }

    for path in files.keys() {
        let Some(ext) = path.rsplit('.').next() else {
            continue;
        };
        if path.starts_with("assets/wf/")
            && matches!(ext, "prefab" | "anim" | "mtl" | "tmx" | "glb" | "png" | "ts" | "effect")
        {
            assert!(
                files.contains_key(&format!("{path}.meta")),
                "{path}: missing .meta sidecar"
            );
        }
    }

    let uuids: BTreeSet<String> = seen_uuids.into_keys().collect();
    for (path, bytes) in files {
        let text = std::str::from_utf8(bytes).ok();
        if (path.ends_with(".ts") || path.ends_with(".effect"))
            && let Some(src) = text
            && let Some(first) = src.lines().next()
            && let Some((_, hash)) = first
                .strip_prefix("// wf cocos-export ")
                .and_then(|r| r.rsplit_once(" sha256="))
        {
            let body_start = src.find('\n').map_or(src.len(), |i| i + 1);
            assert_eq!(
                sha256_hex(src[body_start..].as_bytes()),
                hash.to_ascii_lowercase(),
                "{path}: stale slash-line stamp"
            );
        }

        if path.ends_with(".prefab")
            || path.ends_with(".anim")
            || path.ends_with(".mtl")
            || path.ends_with("wf-cocos.manifest.json")
        {
            let text = text.expect("utf8");
            assert!(
                !text.trim_start().starts_with("//"),
                "{path}: JSON asset must not start with comment"
            );
            let v: Value = serde_json::from_str(text).unwrap_or_else(|e| panic!("{path}: invalid json: {e}"));
            let arr_len = v.as_array().map(Vec::len);
            check_refs(path, &v, arr_len, &uuids, &script_uuids);
            if path.ends_with(".prefab") {
                verify_prefab_graph(path, v.as_array().expect("prefab must be JSON array"));
            } else if path.ends_with("wf-cocos.manifest.json") {
                verify_manifest(path, &v, files);
            }
        }
    }
}

fn check_refs(
    path: &str,
    v: &Value,
    arr_len: Option<usize>,
    uuids: &BTreeSet<String>,
    script_uuids: &BTreeSet<String>,
) {
    match v {
        Value::Array(items) => {
            for item in items {
                check_refs(path, item, arr_len, uuids, script_uuids);
            }
        }
        Value::Object(map) => {
            if let Some(id) = map.get("__id__").and_then(Value::as_i64)
                && let Some(len) = arr_len
            {
                assert!(id >= 0 && (id as usize) < len, "{path}: invalid __id__ {id} >= {len}");
            }
            if let Some(u) = map.get("__uuid__").and_then(Value::as_str) {
                assert!(uuids.contains(&u.to_ascii_lowercase()), "{path}: dangling __uuid__ {u}");
            }
            if let Some(ty) = map.get("__type__").and_then(Value::as_str)
                && !is_builtin_type(ty)
            {
                let decoded = decompress_uuid(ty)
                    .unwrap_or_else(|| panic!("{path}: invalid non-builtin __type__ compressed UUID `{ty}`"));
                assert!(
                    script_uuids.contains(&decoded),
                    "{path}: missing script .meta for `{ty}` (`{decoded}`)"
                );
            }
            for child in map.values() {
                check_refs(path, child, arr_len, uuids, script_uuids);
            }
        }
        _ => {}
    }
}

fn obj_type(slot: &Value) -> &str {
    slot.get("__type__").and_then(Value::as_str).unwrap_or_default()
}

fn id_of(obj: &Value, key: &str) -> Option<usize> {
    obj.get(key)
        .and_then(|v| v.get("__id__"))
        .and_then(Value::as_u64)
        .map(|n| usize::try_from(n).unwrap())
}

fn verify_prefab_graph(path: &str, arr: &[Value]) {
    assert_eq!(obj_type(&arr[0]), "cc.Prefab", "{path}: [0] must be cc.Prefab");
    assert_eq!(
        id_of(&arr[0], "data"),
        Some(1),
        "{path}: cc.Prefab.data must point to 1"
    );
    assert_eq!(obj_type(&arr[1]), "cc.Node", "{path}: [1] must be root cc.Node");

    for (idx, slot) in arr.iter().enumerate() {
        let ty = obj_type(slot);
        if ty == "cc.Node" {
            let pid = id_of(slot, "_prefab").unwrap_or_else(|| panic!("{path}: Node[{idx}] missing _prefab"));
            assert_eq!(obj_type(&arr[pid]), "cc.PrefabInfo", "{path}: Node[{idx}]._prefab type");
            if let Some(parent_id) = id_of(slot, "_parent") {
                assert_eq!(obj_type(&arr[parent_id]), "cc.Node");
                let parent_children = arr[parent_id]["_children"].as_array().unwrap();
                assert!(
                    parent_children.iter().any(|c| c["__id__"] == idx),
                    "{path}: Node[{idx}] missing from parent {parent_id} _children"
                );
            }
            for c in slot["_children"].as_array().unwrap() {
                let cid = usize::try_from(c["__id__"].as_u64().unwrap()).unwrap();
                assert_eq!(id_of(&arr[cid], "_parent"), Some(idx), "{path}: symmetric _parent");
            }
            for comp in slot["_components"].as_array().unwrap() {
                let cid = usize::try_from(comp["__id__"].as_u64().unwrap()).unwrap();
                assert_eq!(id_of(&arr[cid], "node"), Some(idx), "{path}: component owner link");
            }
        } else if !matches!(ty, "cc.Prefab" | "cc.PrefabInfo" | "cc.CompPrefabInfo") {
            let owner = id_of(slot, "node").unwrap_or_else(|| panic!("{path}: Component[{idx}] ({ty}) missing node"));
            assert_eq!(obj_type(&arr[owner]), "cc.Node");
            let comps = arr[owner]["_components"].as_array().unwrap();
            assert!(
                comps.iter().any(|c| c["__id__"] == idx),
                "{path}: Component[{idx}] ({ty}) missing from owner {owner}._components"
            );
            let cpid = id_of(slot, "__prefab").unwrap_or_else(|| panic!("{path}: Component[{idx}] missing __prefab"));
            assert_eq!(obj_type(&arr[cpid]), "cc.CompPrefabInfo");
            match ty {
                "cc.Button" => {
                    let tid = id_of(slot, "_target").unwrap();
                    assert_eq!(obj_type(&arr[tid]), "cc.Node");
                }
                "cc.Slider" => {
                    let hid = id_of(slot, "_handle").unwrap();
                    assert_eq!(obj_type(&arr[hid]), "cc.Node");
                }
                "cc.Toggle" => {
                    let cid = id_of(slot, "_checkMark").unwrap();
                    assert!(arr[cid].get("node").is_some());
                }
                "cc.ProgressBar" => {
                    let cid = id_of(slot, "_barSprite").unwrap();
                    assert!(arr[cid].get("node").is_some());
                }
                _ => {}
            }
        }
    }
}

fn verify_manifest(path: &str, v: &Value, files: &BTreeMap<String, Vec<u8>>) {
    assert_eq!(v["schema"].as_str(), Some("wf-cocos-manifest/1"), "{path}: schema");
    let entries = v["files"].as_object().unwrap();
    for (file, meta) in entries {
        let bytes = files
            .get(file)
            .unwrap_or_else(|| panic!("{path}: listed missing file `{file}`"));
        assert_eq!(
            sha256_hex(bytes),
            meta["sha256"].as_str().unwrap().to_ascii_lowercase(),
            "{path}: hash mismatch for `{file}`"
        );
    }
}

#[test]
fn all_ten_node_types_export_valid_strict_json_and_idempotent_rerun() {
    for case in [
        "real-frames",
        "real-source",
        "animation-strips",
        "animation-atlas",
        "real-ui-pieces",
        "ui-pieces",
        "ui-atlas",
        "ui-naming",
        "tilemap",
        "real-particles",
        "particle-builtin",
        "prop",
        "whole-map",
        "scrolling-scene",
        "scene3d-map",
        "model-3d",
    ] {
        let mut host = Fake::case(case);
        let plan = sync(&host, &Input::default()).unwrap_or_else(|e| panic!("{case}: {e:?}"));
        assert!(!plan.effects.is_empty(), "{case}: expected writes");
        assert!(
            plan.output.warnings.is_empty(),
            "{case}: unexpected warnings {:?}",
            plan.output.warnings
        );
        host.apply(plan.effects);
        verify_strict_json_and_uuid_integrity(&host.files);

        // Idempotent second run.
        let rerun = sync(&host, &Input::default()).unwrap();
        assert!(rerun.effects.is_empty(), "{case}: rerun should be empty");
        assert!(
            rerun.output.nodes.iter().all(|n| n.status == Status::Unchanged),
            "{case}"
        );
    }
}

#[test]
fn particle_whole_map_parallax_and_spatial_emit_shared_scripts_and_assets() {
    let mut host = Fake::case("whole-map");
    let plan = sync(&host, &Input::default()).unwrap();
    host.apply(plan.effects);
    assert!(host.files.contains_key("assets/wf/Scripts/WfWholeMapNav.ts"));
    assert!(host.files.contains_key("assets/wf/Scripts/WfYSortContainer.ts"));
    assert!(host.files.contains_key("assets/wf/Shaders/wf-whole-map-tile.effect"));
    assert!(host.files.contains_key("assets/wf/wf-cocos.manifest.json"));
    assert!(host.files.contains_key("assets/wf/whole-map/whole-map_Tile_0_0.mtl"));

    let mut host_px = Fake::case("scrolling-scene");
    let plan_px = sync(&host_px, &Input::default()).unwrap();
    host_px.apply(plan_px.effects);
    assert!(host_px.files.contains_key("assets/wf/Scripts/WfParallaxLayer.ts"));

    let mut host_fx = Fake::case("particle-builtin");
    let plan_fx = sync(&host_fx, &Input::default()).unwrap();
    host_fx.apply(plan_fx.effects);
    assert!(host_fx.files.contains_key("assets/wf/Scripts/WfParticleSim.ts"));
    assert!(host_fx.files.contains_key("assets/wf/Scripts/WfParticlePlayer.ts"));

    let mut host_3d = Fake::case("model-3d");
    let plan_3d = sync(&host_3d, &Input::default()).unwrap();
    host_3d.apply(plan_3d.effects);
    assert!(host_3d.files.contains_key("assets/wf/Scripts/WfSpatialMeta.ts"));
    assert!(host_3d.files.contains_key("assets/wf/model-3d/main.glb.meta"));
}

#[test]
fn user_edited_prefabs_and_scripts_are_kept_until_force() {
    let mut host = Fake::case("particle-builtin");
    let plan = sync(&host, &Input::default()).unwrap();
    let prefab_path = plan.output.nodes[0].main_prefab.clone().unwrap();
    host.apply(plan.effects);

    host.files
        .insert(prefab_path.clone(), b"[{\"custom\":true}]\n".to_vec());
    let script_path = "assets/wf/Scripts/WfParticlePlayer.ts";
    let mut script = host.files[script_path].clone();
    script.extend_from_slice(b"\n// custom edit\n");
    host.files.insert(script_path.into(), script);

    // Bump source node version or modify effect to trigger regeneration attempt.
    let kept = sync(&host, &Input::default()).unwrap();
    assert!(
        kept.output
            .warnings
            .iter()
            .any(|w| w.contains("Scripts/WfParticlePlayer.ts")),
        "{:?}",
        kept.output.warnings
    );
    assert!(!kept.output.warnings.is_empty());

    let forced = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    host.apply(forced.effects);
    let text = std::str::from_utf8(&host.files[&prefab_path]).unwrap();
    assert!(text.contains("cc.Prefab"));
}

#[test]
fn removing_a_synced_node_deletes_only_unedited_owned_files() {
    let mut host = Fake::case("particle-builtin");
    let plan = sync(&host, &Input::default()).unwrap();
    let prefab_path = plan.output.nodes[0].main_prefab.clone().unwrap();
    let meta_path = format!("{prefab_path}.meta");
    host.apply(plan.effects);

    // Edit prefab locally, leave .meta unedited, remove node from locks.
    host.files.insert(prefab_path.clone(), b"[{\"userKeep\":1}]\n".to_vec());
    host.locks.as_mut().unwrap().nodes.clear();

    let clean = sync(&host, &Input::default()).unwrap();
    host.apply(clean.effects);
    assert!(host.files.contains_key(&prefab_path), "edited prefab must stay");
    assert!(
        !host.files.contains_key(&meta_path),
        "unedited leftover .meta must be deleted"
    );
    assert!(clean.output.deleted.contains(&meta_path));
}

#[test]
fn missing_package_json_and_settings_fails() {
    let mut host = Fake::case("tilemap");
    host.files.remove("package.json");
    let err = sync(&host, &Input::default())
        .err()
        .expect("missing cocos root should fail");
    assert!(err.message.contains("Cocos"), "{}", err.message);
}

#[test]
fn checks_legacy_export_stamps_and_preserves_locally_edited_outputs() {
    let mut host = Fake::case("particle-builtin");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply(first.effects);
    let (script, bytes) = host
        .files
        .iter_mut()
        .find(|(_, bytes)| bytes.starts_with(b"// wf cocos-export "))
        .expect("a generated script with a legacy export stamp");
    let script = script.clone();
    bytes.extend_from_slice(b"\n// local edit\n");

    let findings = lint(&host, &LintInput::default());
    assert!(
        findings
            .diagnostics
            .iter()
            .any(|finding| { finding.file == script && finding.rule == "stale-wf-stamp" })
    );

    let rerun = sync(&host, &Input::default()).unwrap();
    assert!(!rerun.effects.iter().any(|effect| match effect {
        plugin_api::Effect::WriteFile { path, .. } | plugin_api::Effect::DeleteFile { path } => {
            *path == script
        }
        _ => false,
    }));
}
