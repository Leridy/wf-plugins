//! Corpus checks for every Cocos Creator 3.x lint rule, fix application,
//! and cross-validation against `wf-cocos-export` generated projects.
use globset::Glob;
use plugin_api::Failure;
use plugin_guest::{Host, HostError};
use plugin_protocols::lint::{Diagnostic, LintInput, Severity};
use std::collections::BTreeMap;

#[derive(Default)]
struct MemHost {
    files: BTreeMap<String, Vec<u8>>,
}

impl MemHost {
    fn from_str_pairs(pairs: &[(&str, &str)]) -> Self {
        Self {
            files: pairs
                .iter()
                .map(|(k, v)| ((*k).to_owned(), v.as_bytes().to_vec()))
                .collect(),
        }
    }

    fn apply_fixes(&mut self, diagnostics: &[Diagnostic]) {
        for d in diagnostics {
            let Some(fix) = &d.fix else { continue };
            for edit in &fix.edits {
                let bytes = self.files.get(&edit.file).expect("fix file exists");
                let mut text = String::from_utf8(bytes.clone()).unwrap();
                let s = edit.span.start as usize;
                let e = edit.span.end as usize;
                text.replace_range(s..e, &edit.text);
                self.files.insert(edit.file.clone(), text.into_bytes());
            }
        }
    }
}

impl Host for MemHost {
    fn list(&self, pattern: &str) -> Vec<String> {
        let matcher = Glob::new(pattern).unwrap().compile_matcher();
        self.files.keys().filter(|k| matcher.is_match(k)).cloned().collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.files
            .get(path)
            .cloned()
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }

    fn warn(&self, _: &str) {}
}

fn has_rule(diags: &[Diagnostic], rule: &str) -> bool {
    diags.iter().any(|d| d.rule == rule)
}

#[test]
fn catches_missing_orphan_duplicate_and_malformed_meta_issues() {
    let host = MemHost::from_str_pairs(&[
        ("package.json", "{}"),
        ("assets/Textures/Hero.png", "PNG"),
        (
            "assets/Textures/Ghost.png.meta",
            "{\"ver\":\"1.0.27\",\"importer\":\"image\",\"uuid\":\"aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa\"}",
        ),
        ("assets/Textures/DupA.png", "PNG"),
        (
            "assets/Textures/DupA.png.meta",
            "{\"uuid\":\"bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb\"}",
        ),
        ("assets/Textures/DupB.png", "PNG"),
        (
            "assets/Textures/DupB.png.meta",
            "{\"uuid\":\"bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb\"}",
        ),
        ("assets/Textures/BadMeta.png", "PNG"),
        ("assets/Textures/BadMeta.png.meta", "{broken"),
    ]);

    let out = wf_cocos_tool::lint(&host, &LintInput::default());
    assert!(has_rule(&out.diagnostics, "missing-meta"), "{:?}", out.diagnostics);
    assert!(has_rule(&out.diagnostics, "orphan-meta"), "{:?}", out.diagnostics);
    assert!(has_rule(&out.diagnostics, "duplicate-uuid"), "{:?}", out.diagnostics);
    assert!(has_rule(&out.diagnostics, "malformed-json"), "{:?}", out.diagnostics);
}

#[test]
fn catches_dangling_uuid_internal_id_and_missing_script_in_prefab() {
    let prefab = r#"[
  { "__type__": "cc.Prefab", "data": { "__id__": 1 } },
  { "__type__": "cc.Node", "_children": [{ "__id__": 99 }], "_components": [{ "__id__": 2 }, { "__id__": 3 }] },
  { "__type__": "cc.Sprite", "_spriteFrame": { "__uuid__": "deadbeef-dead-4ead-8ead-deadbeef0001@f9941" } },
  { "__type__": "99999InvalidCompressedId!" }
]"#;
    let host = MemHost::from_str_pairs(&[
        ("settings/v2/packages/project.json", "{}"),
        ("assets/Hero.prefab", prefab),
        (
            "assets/Hero.prefab.meta",
            "{\"uuid\":\"12345678-1234-4123-8123-123456789012\"}",
        ),
    ]);
    let out = wf_cocos_tool::lint(&host, &LintInput::default());
    assert!(
        has_rule(&out.diagnostics, "missing-internal-id"),
        "{:?}",
        out.diagnostics
    );
    assert!(has_rule(&out.diagnostics, "missing-uuid-ref"), "{:?}", out.diagnostics);
    assert!(has_rule(&out.diagnostics, "missing-script"), "{:?}", out.diagnostics);
    assert!(out.diagnostics.iter().all(|d| d.severity == Severity::Error));
}

#[test]
fn resource_case_mismatch_and_stale_stamp_apply_clean_fixes() {
    let ts_raw =
        "import { resources } from 'cc';\nresources.load('ui/button/spriteFrame');\nresources.load('Missing/Item');\n";
    let mut host = MemHost::from_str_pairs(&[
        ("package.json", "{}"),
        ("assets/Scripts/Loader.ts", ts_raw),
        (
            "assets/Scripts/Loader.ts.meta",
            "{\"uuid\":\"11111111-1111-4111-8111-111111111111\",\"importer\":\"typescript\"}",
        ),
        (
            "assets/Scripts/Gen.ts",
            "// wf cocos-export node1 v1 sha256=0000000000000000000000000000000000000000000000000000000000000000\nexport const x = 1;\n",
        ),
        (
            "assets/Scripts/Gen.ts.meta",
            "{\"uuid\":\"22222222-2222-4222-8222-222222222222\",\"importer\":\"typescript\"}",
        ),
        ("assets/resources/UI/Button.png", "PNG"),
        (
            "assets/resources/UI/Button.png.meta",
            "{\"uuid\":\"33333333-3333-4333-8333-333333333333\"}",
        ),
        (
            "assets/wf/wf-cocos.manifest.json",
            "{\"schema\":\"wf-cocos-manifest/1\",\"files\":{\"assets/Prefabs/Gen.prefab\":{\"owner\":\"n1\",\"version\":1,\"sha256\":\"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff\"}}}",
        ),
        ("assets/Prefabs/Gen.prefab", "[]"),
        (
            "assets/Prefabs/Gen.prefab.meta",
            "{\"uuid\":\"44444444-4444-4444-8444-444444444444\"}",
        ),
    ]);

    let out = wf_cocos_tool::lint(&host, &LintInput::default());
    assert!(has_rule(&out.diagnostics, "resource-path-case"));
    assert!(has_rule(&out.diagnostics, "missing-resource-path"));
    assert_eq!(out.diagnostics.iter().filter(|d| d.rule == "stale-wf-stamp").count(), 2);

    host.apply_fixes(&out.diagnostics);
    let fixed_loader = std::str::from_utf8(&host.files["assets/Scripts/Loader.ts"]).unwrap();
    assert!(
        fixed_loader.contains("resources.load('UI/Button/spriteFrame');"),
        "{fixed_loader}"
    );
    let fixed_gen = std::str::from_utf8(&host.files["assets/Scripts/Gen.ts"]).unwrap();
    assert_eq!(fixed_gen, "export const x = 1;\n");
}

#[test]
fn scopes_findings_to_requested_paths_without_breaking_cross_file_meta_index() {
    let host = MemHost::from_str_pairs(&[
        ("package.json", "{}"),
        ("assets/Sprites/Tex.png", "PNG"),
        (
            "assets/Sprites/Tex.png.meta",
            "{\"uuid\":\"11111111-1111-4111-8111-111111111111\"}",
        ),
        (
            "assets/Scenes/Main.scene",
            "[{\"__type__\":\"cc.SceneAsset\",\"scene\":{\"__id__\":1}},{\"__type__\":\"cc.Scene\"}]",
        ),
        (
            "assets/Scenes/Main.scene.meta",
            "{\"uuid\":\"22222222-2222-4222-8222-222222222222\"}",
        ),
        ("assets/Other/Broken.prefab", "{bad json"),
        (
            "assets/Other/Broken.prefab.meta",
            "{\"uuid\":\"33333333-3333-4333-8333-333333333333\"}",
        ),
    ]);
    let scoped = wf_cocos_tool::lint(
        &host,
        &LintInput {
            paths: vec!["assets/Scenes".into()],
        },
    );
    assert!(scoped.diagnostics.is_empty(), "{:?}", scoped.diagnostics);
}
