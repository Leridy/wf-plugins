//! Ensures syncing 30,000 animation frames stays fast and compact in memory.
mod common;

use common::Fake;
use plugin_api::platform::{Head, LockedRow, LocksOutput, NodeOutput, NodeRow, NodeState};
use std::collections::BTreeMap;
use wf_cocos_tool::{Input, sync};

#[test]
fn thirty_thousand_frames_fit_the_component_budget() {
    let mut host = Fake::default();
    host.files.insert("package.json".into(), b"{}".to_vec());
    // Construct a minimal valid 32x32 PNG IHDR header cleanly.
    let mut fake_png =
        Vec::from(&b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x20\x00\x00\x00\x20\x08\x06\x00\x00\x00"[..]);
    fake_png.extend_from_slice(&[0u8; 8]);
    host.files.insert("assets/wf/hero/atlas.png".into(), fake_png);

    let mut images = serde_json::Map::new();
    for i in 0..16 {
        images.insert(
            format!("f{i}"),
            serde_json::json!({
                "type": "atlas",
                "path": "atlas.png",
                "frame": { "x": i * 16, "y": 0, "w": 16, "h": 16 }
            }),
        );
    }
    let frames: Vec<_> = (0..30_000).map(|i| format!("f{}", i % 16)).collect();
    let durs: Vec<_> = (0..30_000).map(|_| 50.0).collect();
    let json = serde_json::json!({
        "images": images,
        "clips": [{
            "actionId": "run",
            "direction": "south",
            "loop": true,
            "anchor": { "x": 8, "y": 16 },
            "files": frames,
            "durationsMs": durs,
        }]
    });
    host.files.insert(
        "assets/wf/hero/animation.json".into(),
        serde_json::to_vec(&json).unwrap(),
    );

    let id = "11111111-1111-4111-8111-111111111111".to_owned();
    host.locks = Some(LocksOutput {
        directory: "assets/wf".into(),
        lock: "assets/wf/wf.lock.json".into(),
        nodes: vec![LockedRow {
            id: id.clone(),
            number: 1,
            path: "Hero".into(),
            version: 1,
            form: "frames".into(),
            files: vec!["hero/animation.json".into(), "hero/atlas.png".into()],
            head: Head::Current,
            head_version: Some(1),
        }],
    });
    host.nodes = vec![NodeOutput {
        node: NodeRow {
            id,
            number: 1,
            path: "Hero".into(),
            node_type: "frame_animation".into(),
            version: Some(1),
            state: NodeState::Current,
        },
        summary: String::new(),
        description: None,
        usage: String::new(),
        tags: Vec::new(),
        author: None,
        updated: "2026-11-16T00:00:00Z".into(),
        parts: Vec::new(),
        files: Vec::new(),
        unavailable: Vec::new(),
    }];
    let _unused: BTreeMap<String, Vec<u8>> = BTreeMap::new();
    let plan = sync(&host, &Input::default()).unwrap();
    assert!(!plan.effects.is_empty());
}
