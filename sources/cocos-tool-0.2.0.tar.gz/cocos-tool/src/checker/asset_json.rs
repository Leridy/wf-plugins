//! Checks `.prefab`, `.scene`, `.anim`, `.mtl` JSON for `malformed-json`,
//! `missing-uuid-ref`, `missing-internal-id`, and `missing-script`.
use super::{
    builtin::{is_builtin_type, is_builtin_uuid},
    message,
    meta::{MetaIndex, find_literal_span, line_col_span},
    project::{Layout, in_scope},
    uuid_codec::{decompress_uuid, normalize_uuid},
};
use plugin_guest::Host;
use plugin_protocols::lint::Diagnostic;
use serde_json::Value;
use std::str::from_utf8;

pub fn check_files(
    host: &dyn Host,
    layout: &Layout,
    meta: &MetaIndex,
    paths: &[String],
    checked: &mut Vec<String>,
    diagnostics: &mut Vec<Diagnostic>,
) {
    for path in &layout.jsons {
        if !in_scope(path, paths) {
            continue;
        }
        checked.push(path.clone());
        let Ok(bytes) = host.read(path) else {
            continue;
        };
        let Ok(text) = from_utf8(&bytes) else {
            diagnostics.push(message::error(
                "malformed-json",
                path,
                None,
                "Asset JSON file is not valid UTF-8.",
                None,
            ));
            continue;
        };
        let parsed: Value = match serde_json::from_str(text) {
            Ok(v) => v,
            Err(err) => {
                diagnostics.push(message::error(
                    "malformed-json",
                    path,
                    line_col_span(text, err.line(), err.column()),
                    format!("Malformed Cocos asset JSON: {err}"),
                    None,
                ));
                continue;
            }
        };

        let array_len = parsed.as_array().map(Vec::len);
        inspect_value(path, text, &parsed, array_len, meta, diagnostics);
    }
}

fn inspect_value(
    path: &str,
    text: &str,
    value: &Value,
    array_len: Option<usize>,
    meta: &MetaIndex,
    diagnostics: &mut Vec<Diagnostic>,
) {
    match value {
        Value::Array(items) => {
            for item in items {
                inspect_value(path, text, item, array_len, meta, diagnostics);
            }
        }
        Value::Object(map) => {
            if let Some(id_val) = map.get("__id__").and_then(Value::as_i64)
                && let Some(len) = array_len
            {
                let valid = usize::try_from(id_val).is_ok_and(|idx| idx < len);
                if !valid {
                    diagnostics.push(message::error(
                        "missing-internal-id",
                        path,
                        find_literal_span(text, &id_val.to_string()),
                        format!("Broken internal object reference `__id__: {id_val}` (array length is {len})."),
                        None,
                    ));
                }
            }

            if let Some(raw_uuid) = map.get("__uuid__").and_then(Value::as_str) {
                let norm = normalize_uuid(raw_uuid);
                if !is_builtin_uuid(&norm) && !meta.has_uuid(&norm) {
                    diagnostics.push(message::error(
                        "missing-uuid-ref",
                        path,
                        find_literal_span(text, raw_uuid),
                        format!("Missing asset UUID `{raw_uuid}` (no matching .meta entry in project)."),
                        None,
                    ));
                }
            }

            if let Some(ty) = map.get("__type__").and_then(Value::as_str)
                && !is_builtin_type(ty)
            {
                match decompress_uuid(ty) {
                    Some(script_uuid) if meta.script_uuids.contains(&script_uuid) => {}
                    Some(script_uuid) => diagnostics.push(message::error(
                        "missing-script",
                        path,
                        find_literal_span(text, ty),
                        format!(
                            "Component script type `{ty}` (UUID `{script_uuid}`) is missing or not a script .meta."
                        ),
                        None,
                    )),
                    None => diagnostics.push(message::error(
                        "missing-script",
                        path,
                        find_literal_span(text, ty),
                        format!("Unknown component class or invalid compressed script UUID `{ty}`."),
                        None,
                    )),
                }
            }

            for child in map.values() {
                inspect_value(path, text, child, array_len, meta, diagnostics);
            }
        }
        _ => {}
    }
}
