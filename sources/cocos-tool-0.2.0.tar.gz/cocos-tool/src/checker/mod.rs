//! Static Cocos Creator project checks.

mod asset_json;
mod builtin;
mod gather;
mod glob;
mod manifest_stamp;
mod message;
mod meta;
mod project;
mod rules;
#[cfg(test)]
mod testing;
mod ts_refs;
mod uuid_codec;

pub use gather::lint;
