//! Discovers Cocos Creator 3.x project roots and scopes path filters per project.
use super::glob;
use plugin_api::LIST_LIMIT;
use plugin_guest::Host;
use std::collections::BTreeSet;

pub struct Layout {
    pub root: String,
    pub assets: Vec<String>,
    pub metas: Vec<String>,
    pub jsons: Vec<String>,
    pub scripts: Vec<String>,
    pub manifests: Vec<String>,
    pub truncated: bool,
}

impl Layout {
    pub fn assets_prefix(&self) -> String {
        if self.root.is_empty() {
            "assets/".into()
        } else {
            format!("{}/assets/", self.root)
        }
    }
}

pub fn discover(host: &dyn Host, paths: &[String]) -> Vec<Layout> {
    let mut all_assets = Vec::new();
    let mut all_markers = Vec::new();
    let mut truncated = false;

    for pattern in ["assets/**", "*/assets/**", "*/*/assets/**"] {
        let hits = host.list(pattern);
        if hits.len() >= LIST_LIMIT {
            truncated = true;
        }
        all_assets.extend(hits);
    }
    for pattern in [
        "settings/**",
        "*/settings/**",
        "*/*/settings/**",
        "package.json",
        "*/package.json",
        "*/*/package.json",
        "project.json",
        "*/project.json",
        "*/*/project.json",
        "tsconfig.json",
        "*/tsconfig.json",
        "*/*/tsconfig.json",
    ] {
        let hits = host.list(pattern);
        if hits.len() >= LIST_LIMIT {
            truncated = true;
        }
        all_markers.extend(hits);
    }

    let mut roots = BTreeSet::new();
    for asset_path in &all_assets {
        if let Some(root) = extract_root(asset_path)
            && has_marker(root, &all_markers)
        {
            roots.insert(root.to_owned());
        }
    }

    let mut layouts = Vec::new();
    for root in roots {
        let prefix = if root.is_empty() {
            "assets/".to_owned()
        } else {
            format!("{root}/assets/")
        };
        if !paths.is_empty() && !paths_touch_root(paths, &root) {
            continue;
        }

        let mut assets = Vec::new();
        let mut metas = Vec::new();
        let mut jsons = Vec::new();
        let mut scripts = Vec::new();
        let mut manifests = Vec::new();

        for path in &all_assets {
            if !path.starts_with(&prefix) {
                continue;
            }
            let ext = path
                .rsplit_once('.')
                .map(|(_, e)| e.to_ascii_lowercase())
                .unwrap_or_default();
            if ext == "meta" {
                metas.push(path.clone());
            } else {
                assets.push(path.clone());
                let name = path.rsplit('/').next().unwrap_or(path).to_ascii_lowercase();
                if name == "wf-cocos.manifest.json" {
                    manifests.push(path.clone());
                } else if matches!(ext.as_str(), "prefab" | "scene" | "anim" | "mtl") {
                    jsons.push(path.clone());
                } else if matches!(ext.as_str(), "ts" | "js") {
                    scripts.push(path.clone());
                }
            }
        }
        assets.sort();
        assets.dedup();
        metas.sort();
        metas.dedup();
        jsons.sort();
        jsons.dedup();
        scripts.sort();
        scripts.dedup();
        manifests.sort();
        manifests.dedup();

        layouts.push(Layout {
            root,
            assets,
            metas,
            jsons,
            scripts,
            manifests,
            truncated,
        });
    }
    layouts
}

pub fn in_scope(path: &str, paths: &[String]) -> bool {
    if paths.is_empty() {
        return true;
    }
    paths.iter().any(|filter| {
        let norm = filter.trim_end_matches('/');
        if norm.is_empty() || norm == "." {
            return true;
        }
        path == norm || path.starts_with(&format!("{norm}/")) || glob::matches(norm, path)
    })
}

fn extract_root(asset_path: &str) -> Option<&str> {
    if asset_path.starts_with("assets/") {
        Some("")
    } else if let Some((prefix, _)) = asset_path.split_once("/assets/") {
        Some(prefix)
    } else {
        None
    }
}

fn has_marker(root: &str, markers: &[String]) -> bool {
    let prefix = if root.is_empty() {
        String::new()
    } else {
        format!("{root}/")
    };
    markers.iter().any(|m| {
        m.starts_with(&format!("{prefix}settings/"))
            || m == &format!("{prefix}package.json")
            || m == &format!("{prefix}project.json")
            || m == &format!("{prefix}tsconfig.json")
    })
}

fn paths_touch_root(paths: &[String], root: &str) -> bool {
    if root.is_empty() {
        return true;
    }
    let prefix = format!("{root}/");
    paths.iter().any(|p| {
        let n = p.trim_end_matches('/');
        n == root || n.starts_with(&prefix) || root.starts_with(&format!("{n}/"))
    })
}
