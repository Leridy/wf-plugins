//! Top-level `wf.lint/1` entrypoint across all discovered Cocos Creator 3.x projects.
use super::{project, rules};
use plugin_guest::Host;
use plugin_protocols::lint::{LintInput, LintOutput};

pub fn lint(host: &dyn Host, input: &LintInput) -> LintOutput {
    let layouts = project::discover(host, &input.paths);
    let mut checked = Vec::new();
    let mut diagnostics = Vec::new();
    for layout in &layouts {
        rules::check_project(host, layout, &input.paths, &mut checked, &mut diagnostics);
    }
    checked.sort();
    checked.dedup();
    LintOutput { checked, diagnostics }
}
