//! CocosTool capability descriptions.
use crate::types::{Input, Output};
use plugin_api::{Capability, Description, Example, Risk};
use plugin_protocols::lint::{LintInput, LintOutput, PROTOCOL};
use schemars::schema_for;

pub const SYNC: &str = "sync";
pub const LINT: &str = "lint";

pub fn description() -> Description {
    Description {
        capabilities: vec![Capability {
            op: SYNC.into(),
            summary: "Convert exported WeaveForge assets into Cocos Creator 3.x .meta, Prefabs, AnimationClips, and runtimes".into(),
            when: "The project is a Cocos Creator 3.x workspace and ready wf exports should become native Cocos assets, prefabs, clips, or maps.".into(),
            risk: Risk::Write,
            input: serde_json::to_value(schema_for!(Input)).expect("input schema"),
            output: Some(serde_json::to_value(schema_for!(Output)).expect("output schema")),
            examples: vec![
                Example {
                    args: "sync".into(),
                    note: "Convert every exported node in the workspace mirror into Cocos assets and prefabs.".into(),
                },
                Example {
                    args: "sync --nodes #12 --force".into(),
                    note: "Re-export node #12 and overwrite locally modified generated files.".into(),
                },
            ],
            implements: None,
        }, Capability {
            op: LINT.into(),
            summary: "Check Cocos Creator 3.x .meta UUIDs, .prefab/.scene/.anim/.mtl references, scripts, and wf stamps".into(),
            when: "Check a Cocos Creator 3.x project before committing or opening it in the editor.".into(),
            risk: Risk::Read,
            input: serde_json::to_value(schema_for!(LintInput)).expect("schema"),
            output: Some(serde_json::to_value(schema_for!(LintOutput)).expect("schema")),
            examples: vec![
                Example {
                    args: "lint".into(),
                    note: "Check every Cocos Creator 3.x asset and script in the project.".into(),
                },
                Example {
                    args: "lint --paths assets/scenes".into(),
                    note: "Restrict diagnostics to assets/scenes while still indexing all project .meta files.".into(),
                },
            ],
            implements: Some(PROTOCOL.into()),
        }],
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sync_is_write_and_lint_is_read_with_strict_typed_input() {
        let desc = description();
        assert_eq!(desc.capabilities.len(), 2);
        let cap = &desc.capabilities[0];
        assert_eq!(cap.op, "sync");
        assert_eq!(cap.risk, Risk::Write);
        assert!(cap.output.is_some());
        let lint = &desc.capabilities[1];
        assert_eq!(lint.op, LINT);
        assert_eq!(lint.risk, Risk::Read);
        assert_eq!(lint.implements.as_deref(), Some(PROTOCOL));
        assert_eq!(cap.input["additionalProperties"], serde_json::Value::Bool(false));
    }
}
