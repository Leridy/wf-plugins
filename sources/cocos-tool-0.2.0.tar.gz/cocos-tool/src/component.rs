//! The frozen WIT boundary; all work is performed through the testable Host.
use crate::{
    Input,
    describe::{self, LINT, SYNC},
    lint, sync,
};
use plugin_api::{Effect as Planned, Failure};
use plugin_guest::{
    HostError, Wit,
    bindings::{
        Error, Guest, Outcome, export,
        wf::plugin::types::{Effect, FileWrite, Verdict},
    },
};

struct Plugin;

impl Guest for Plugin {
    fn describe() -> Vec<u8> {
        plugin_guest::describe(&describe::description())
    }

    fn call(op: String, input: Vec<u8>) -> Result<Outcome, Error> {
        match op.as_str() {
            SYNC => sync_outcome(&input),
            LINT => plugin_guest::lint(LINT, &op, &input, |input| Ok(lint(&Wit, input))),
            _ => Err(HostError::new(Failure::NotFound, "unknown CocosTool operation").into()),
        }
    }
}

fn sync_outcome(input: &[u8]) -> Result<Outcome, Error> {
    let input: Input =
        serde_json::from_slice(input).map_err(|e| HostError::new(Failure::InvalidInput, e.to_string()))?;
    let plan = sync(&Wit, &input)?;
    let output = serde_json::to_vec(&plan.output).map_err(|e| HostError::new(Failure::Internal, e.to_string()))?;
    let effects = plan
        .effects
        .into_iter()
        .map(|effect| match effect {
            Planned::WriteFile { path, bytes, overwrite } => {
                Ok(Effect::WriteFile(FileWrite { path, bytes, overwrite }))
            }
            Planned::DeleteFile { path } => Ok(Effect::DeleteFile(path)),
            _ => Err(HostError::new(Failure::Internal, "unexpected effect")),
        })
        .collect::<Result<Vec<_>, _>>()?;
    Ok(Outcome {
        output,
        effects,
        verdict: Verdict::Ok,
        hints: Vec::new(),
    })
}

export!(Plugin);
