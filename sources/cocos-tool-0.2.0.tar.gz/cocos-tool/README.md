# CocosTool

CocosTool is the official WeaveForge plugin for Cocos Creator 3.x. It combines
project checks and native asset export in a single WebAssembly package. The
catalog display name is **CocosTool** and the CLI and package ID is `cocos-tool`.

```sh
wf plugin install cocos-tool
wf cocos-tool lint
wf lint
wf cocos-tool sync --dry-run
wf cocos-tool sync
```

The check reads project assets, metadata, scripts, and WeaveForge export
stamps. It works without a local workspace mirror or a Cocos Creator
installation. The exporter converts assets in a local WeaveForge mirror and
keeps the existing Cocos export manifest and ownership stamps.

## Upgrade from the former plugins

- Change `wf cocos lint` to `wf cocos-tool lint` and
  `wf cocos-export sync` to `wf cocos-tool sync`.
- In `wf-plugins.toml`, change `cocos/<rule>` settings to `cocos-tool/<rule>`.
- For a shared project, save the new plugin with `wf plugin install cocos-tool --save`.
  Remove the two superseded plugin declarations and lock entries using the
  migration steps in the
  [publication guide](https://github.com/Leridy/wf-plugins/blob/main/examples/cocos-tool/README.md).

The former [Cocos project checker](https://gitlab.xqhuyu.cn/996-ugc/wf-plugins/cocos)
is retained as a source reference. This repository maintains both operations.

## Build

Check out the official `plugin-kit` next to this repository.

```sh
cargo test --locked
cargo build --release --locked --target wasm32-wasip2
```
