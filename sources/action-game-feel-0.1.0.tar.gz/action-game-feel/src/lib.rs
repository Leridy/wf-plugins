wit_bindgen::generate!({ path: "wit", world: "provider" });

use wf::plugin::types::{Failure, Verdict};

struct Plugin;

impl Guest for Plugin {
    fn describe() -> Vec<u8> {
        serde_json::to_vec(&serde_json::json!({
            "capabilities": [{
                "op": "guide",
                "summary": "Read the action game feel guide",
                "when": "Diagnose or improve action game responsiveness and feedback.",
                "risk": "read",
                "input": {"type": "object", "properties": {}},
                "examples": [{"args": "guide", "note": "read the guide"}]
            }]
        }))
        .expect("description serializes")
    }

    fn call(op: String, _input: Vec<u8>) -> Result<Outcome, Error> {
        if op != "guide" {
            return Err(Error {
                kind: Failure::NotFound,
                message: format!("unknown op `{op}`"),
                param: None,
            });
        }

        Ok(Outcome {
            output: serde_json::to_vec(&serde_json::json!({
                "guide": include_str!("../skills/guide.md")
            }))
            .expect("guide serializes"),
            effects: Vec::new(),
            verdict: Verdict::Ok,
            hints: Vec::new(),
        })
    }
}

export!(Plugin);
