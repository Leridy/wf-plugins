# 动作游戏手感

独立的 WeaveForge 插件，提供动作响应、战斗节奏、跳跃容错、打击反馈和实机对照指南。技能内容参考用户收藏视频的页面说明和章节摘要。

安装或链接插件后，使用 `wf skill show action-game-feel/guide --all` 或 `wf action-game-feel guide` 读取指南。插件不声明工程文件读取权限。

构建和检查：`cargo build --release --target wasm32-wasip2`，然后运行 `wf plugin test .` 和 `wf plugin pack .`。
