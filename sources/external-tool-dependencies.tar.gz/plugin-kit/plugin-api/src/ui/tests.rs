use super::{Bind, CellKind, NodeTypeKey, ProjectNeed, Renderer, Selection, When, is_plain};
use crate::{ConfigValue, Manifest};

fn manifest(ui: &str) -> String {
    format!(
        "[plugin]\nname = \"demo\"\nversion = \"0.1.0\"\nsummary = \"s\"\napi = \"{}\"\ncomponent = \"demo.wasm\"\n{ui}",
        crate::API
    )
}

const EXPORT: &str = r#"
[[ui.actions]]
id = "export-godot"
label = { en = "Export as Godot resources", zh = "导出为 Godot 资源" }
op = "sync"
place = "node-menu"
when = { node_types = ["frame_animation", "ui"], selection = "any", project = "mirror" }
input.nodes = "selection"
input.force = { value = true }

[[ui.views]]
op = "sync"
title = { en = "Godot export" }
from = "table"
renderer = { type = "table", columns = [
  { label = { en = "Node" }, kind = "node" },
  { label = { en = "Status" }, kind = "status" },
] }
"#;

fn refused(ui: &str, needle: &str) {
    let error = Manifest::parse(&manifest(ui)).expect_err(ui).0;
    assert!(error.contains(needle), "{error}");
}

#[test]
fn the_toml_reads_as_typed_actions_and_views() {
    let manifest = Manifest::parse(&manifest(EXPORT)).unwrap();
    let action = &manifest.ui.actions[0];
    assert_eq!(action.when.node_types, [NodeTypeKey::FrameAnimation, NodeTypeKey::Ui]);
    assert_eq!(action.when.project, ProjectNeed::Mirror);
    assert_eq!(action.input["nodes"], Bind::Selection);
    assert_eq!(action.input["force"], Bind::Value(ConfigValue::Bool(true)));
    let view = &manifest.ui.views[0];
    assert_eq!(view.from.as_deref(), Some("table"));
    let Renderer::Table { columns } = &view.renderer else {
        panic!("a table");
    };
    assert_eq!(columns[0].kind, CellKind::Node);
    let again = Manifest::parse(&toml::to_string(&manifest).unwrap()).unwrap();
    assert_eq!(again.ui, manifest.ui);
}

#[test]
fn declarations_that_cannot_work_are_refused() {
    let action = |extra: &str| {
        format!("[[ui.actions]]\nid = \"go\"\nlabel = {{ en = \"Go\" }}\nop = \"sync\"\nplace = \"node-menu\"\n{extra}")
    };
    refused(&action("input.node = \"node\"\n"), "selection = \"one\"");
    refused(&action("when = { node_types = [\"ui\", \"ui\"] }\n"), "twice");
    refused(&action("when = { node_types = [\"sprite\"] }\n"), "sprite");
    refused(
        "[[ui.actions]]\nid = \"go\"\nlabel = { en = \"Go\" }\nop = \"lint\"\nplace = \"panel\"\ninput.paths = \"selection\"\n",
        "panel action",
    );
    refused(
        "[[ui.actions]]\nid = \"go\"\nlabel = { en = \"Go\" }\nop = \"lint\"\nplace = \"panel\"\nwhen = { selection = \"one\" }\n",
        "panel action",
    );
    refused(
        "[[ui.actions]]\nid = \"go\"\nlabel = { en = \"Go\u{202E}\" }\nop = \"lint\"\nplace = \"panel\"\n",
        "label.en",
    );
    refused(
        &format!(
            "[[ui.actions]]\nid = \"go\"\nlabel = {{ en = \"{}\" }}\nop = \"lint\"\nplace = \"panel\"\n",
            "x".repeat(33)
        ),
        "1 to 32",
    );
    refused(&format!("{}{}", action(""), action("")), "declared once");
    refused(
        "[[ui.views]]\nop = \"sync\"\ntitle = { en = \"A\" }\nrenderer = { type = \"findings\" }\n[[ui.views]]\nop = \"sync\"\ntitle = { en = \"B\" }\nrenderer = { type = \"key-values\" }\n",
        "one view per op",
    );
    refused(
        "[[ui.views]]\nop = \"sync\"\ntitle = { en = \"A\" }\nrenderer = { type = \"table\", columns = [] }\n",
        "1 to 8",
    );
    refused(
        "[[ui.views]]\nop = \"sync\"\ntitle = { en = \"A\" }\nfrom = \"Table\"\nrenderer = { type = \"images\" }\n",
        "top-level output field",
    );
}

#[test]
fn when_admits_types_directories_and_counts() {
    let any = When::default();
    assert!(any.admits(Some(NodeTypeKey::Music)));
    assert!(!any.admits(None));
    let directories = When {
        directories: true,
        ..When::default()
    };
    assert!(directories.admits(None));
    assert!(!directories.admits(Some(NodeTypeKey::Ui)));
    let typed = When {
        node_types: vec![NodeTypeKey::Ui],
        directories: true,
        selection: Selection::One,
        project: ProjectNeed::Open,
    };
    assert!(typed.admits(Some(NodeTypeKey::Ui)) && typed.admits(None));
    assert!(!typed.admits(Some(NodeTypeKey::Music)));
    assert!(typed.takes(1) && !typed.takes(2) && !typed.takes(0));
    assert!(any.takes(200) && !any.takes(201));
}

#[test]
fn plain_text_has_no_controls_bidi_or_zero_width_characters() {
    assert!(is_plain("导出为 Godot 资源"));
    for bad in ["a\nb", "a\u{200B}b", "a\u{2067}b", "a\u{FEFF}", "a\u{7}"] {
        assert!(!is_plain(bad), "{bad:?}");
    }
}
