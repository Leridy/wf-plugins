//! A call's result as the host sees it, converted from the WIT types.
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct Span {
    pub start: u32,
    pub end: u32,
}

/// A side effect a plugin asks the host to perform; paths are project-relative.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "kind", rename_all = "kebab-case")]
pub enum Effect {
    WriteFile {
        path: String,
        #[serde(skip)]
        bytes: Vec<u8>,
        overwrite: bool,
    },
    EditFile {
        path: String,
        span: Span,
        text: String,
    },
    DeleteFile {
        path: String,
    },
    Exec {
        tool: String,
        args: Vec<String>,
        reason: String,
    },
    Invoke {
        method: String,
    },
}

impl Effect {
    /// The file this effect touches, if it touches one.
    pub fn path(&self) -> Option<&str> {
        match self {
            Self::WriteFile { path, .. } | Self::EditFile { path, .. } | Self::DeleteFile { path } => Some(path),
            Self::Exec { .. } | Self::Invoke { .. } => None,
        }
    }
}

#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub enum Verdict {
    #[default]
    Ok,
    Findings,
}

/// A follow-up command a plugin suggests: arguments after the executable.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct Hint {
    pub args: Vec<String>,
    pub reason: String,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct Outcome {
    pub output: Value,
    pub effects: Vec<Effect>,
    pub verdict: Verdict,
    pub hints: Vec<Hint>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum Failure {
    InvalidInput,
    NotFound,
    Unsupported,
    Internal,
}

/// An error a plugin reports; `param` names the offending input field.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct PluginError {
    pub kind: Failure,
    pub message: String,
    pub param: Option<String>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Level {
    Debug,
    Info,
    Warn,
    Error,
}
