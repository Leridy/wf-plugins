//! `NodeTypeKey`: every node type of the Nodes tree, as the Server stores it,
//! the mirror lists it and a plugin manifest names it. One type for the
//! Server and the plugin crates alike. Vendored from WeaveForge's
//! `foundation::node_type`; keep the two in step.

use serde::{Deserialize, Serialize};
use std::fmt;

macro_rules! node_types {
    ($($(#[$variant_meta:meta])* $variant:ident = $text:literal),+ $(,)?) => {
        /// A node type of the Nodes tree.
        #[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
        #[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "NodeTypeKey"))]
        #[derive(schemars::JsonSchema)]
        pub enum NodeTypeKey {
            $($(#[$variant_meta])* #[serde(rename = $text)] $variant),+
        }

        impl NodeTypeKey {
            /// Every node type, in declaration order.
            pub const ALL: [Self; [$($text),+].len()] = [$(Self::$variant),+];

            pub const fn as_str(self) -> &'static str {
                match self {
                    $(Self::$variant => $text),+
                }
            }

            pub fn parse(text: &str) -> Option<Self> {
                match text {
                    $($text => Some(Self::$variant),)+
                    _ => None,
                }
            }
        }
    };
}

node_types! {
    Image = "image",
    CharacterArt = "character_art",
    FrameAnimation = "frame_animation",
    SkeletalAnimation = "skeletal_animation",
    CharacterEffect = "character_effect",
    ParticleEffect = "particle_effect",
    ScrollingScene = "scrolling_scene",
    Tilemap = "tilemap",
    Prop = "prop",
    Ui = "ui",
    Icon = "icon",
    WordArt = "word_art",
    Music = "music",
    SoundEffect = "sound_effect",
    Tts = "tts",
    Video = "video",
    Text = "text",
    Reference = "reference",
    Table = "table",
    Model3d = "model_3d",
    Scene3dMap = "scene3d_map",
    WholeMap = "whole_map",
    #[default]
    Unclassified = "unclassified",
}

impl NodeTypeKey {
    /// The node type a stored row or catalog entry names; a key no node type
    /// has reads as unclassified.
    pub fn stored(key: &str) -> Self {
        Self::parse(key).unwrap_or(Self::Unclassified)
    }
}

impl fmt::Display for NodeTypeKey {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.as_str())
    }
}
