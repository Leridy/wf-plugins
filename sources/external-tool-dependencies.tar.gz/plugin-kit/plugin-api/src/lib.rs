//! The contract between `wf` and its plugins: the WIT world a plugin component
//! implements, its manifest, the capabilities it describes and the outcome it
//! returns. Pure data, no runtime; `plugin-host` runs components against it.
mod config;
mod description;
mod icon;
mod manifest;
mod node_type;
mod outcome;
mod package;
pub mod platform;
mod process;
mod protocol;
mod schema;
mod tool;
mod tool_discovery;
mod tool_version;
pub mod ui;

pub use config::{
    CONFIG_LIMIT, ConfigError, ConfigField, ConfigKind, ConfigOption, ConfigValue, ConfigValues, check_fields,
    effective, is_config_key,
};
pub use description::{Capability, Description, Example, Risk};
pub use icon::{ICON_ENTRY, ICON_LIMIT, ICON_SIDES, ICONS_DIRECTORY, IconError, IconRef, check_icon, icon_file};
pub use manifest::{
    Contribution, MANIFEST_FILE, Manifest, ManifestError, PLATFORM_READ_TARGET, Permissions, PlatformAccess,
    PluginInfo, SKILL_TOPIC_LIMIT, SkillTopic, call_target, exec_target, is_name,
};
/// The node types `[ui]` actions and template slots name.
pub use node_type::NodeTypeKey;
pub use outcome::{Effect, Failure, Hint, Level, Outcome, PluginError, Span, Verdict};
pub use package::{
    CAPABILITIES_ENTRY, COMPONENT_ENTRY, FILES_ENTRY, FILES_SCHEMA, FileEntry, Files, INDEX_SCHEMA, Index, IndexEntry,
    IndexOp, IndexVersion, MANIFEST_ENTRY, OFFICIAL_INDEX, OFFICIAL_INDEX_PATH, Origin, PACKAGE_EXTENSION,
    SIGNATURE_EXTENSION, SIGNATURE_SCHEMA, SKILLS_DIRECTORY, Signature, Signer, UI_ASSETS_DIRECTORY, fingerprint,
    package_file,
};
pub use process::{
    CALL_TIMEOUT, CALL_TIMEOUT_LIMIT, MCP_SCHEMA_LIMIT, MCP_SUMMARY_LIMIT, MCP_TOOL_COUNT, MCP_TOOLS_ENTRY,
    MCP_TOOLS_LIMIT, MCP_TOOLS_SCHEMA, MCP_WHEN_LIMIT, McpSnapshot, McpTool, Process, ProcessKind, ServerName, Target,
    ToolHints, empty_input,
};
pub use protocol::Protocol;
pub use schema::{DESCRIPTION_SCHEMA_FILE, MANIFEST_SCHEMA_FILE, description_schema, manifest_schema};
pub use tool::{Detect, EXEC_TAIL_LIMIT, ExecResult, ExecStatus, ToolDecl};
pub use tool_discovery::{RegistryHint, RegistryHive, RegistryView};
pub use tool_version::{VersionCheck, VersionExtract, VersionStream};

/// The WIT package new plugin components target; also its API version.
/// 0.1.1 adds `host.call` (platform read methods), 0.1.2 `host.call-plugin`,
/// 0.1.3 `host.config` (the plugin's settings in the project),
/// 0.1.4 `host.tool-available` and `host.cleanup-after-exec`.
pub const API: &str = "wf:plugin@0.1.4";
/// The first API; its components keep loading, without `host.call`.
pub const API_0_1_0: &str = "wf:plugin@0.1.0";
/// Adds `host.call`; its components keep loading, without `host.call-plugin`.
pub const API_0_1_1: &str = "wf:plugin@0.1.1";
/// Adds `host.call-plugin`; its components keep loading, without `host.config`.
pub const API_0_1_2: &str = "wf:plugin@0.1.2";
/// Adds `host.config`; its components keep loading, without 0.1.4 host helpers.
pub const API_0_1_3: &str = "wf:plugin@0.1.3";
/// Every API a manifest may name: one minor series, so the host links components of each.
pub const APIS: [&str; 5] = [API_0_1_0, API_0_1_1, API_0_1_2, API_0_1_3, API];
/// Most paths one `host.list-files` returns; a listing that long may be cut short.
pub const LIST_LIMIT: usize = 10_000;
/// The WIT source, written into scaffolded plugin projects.
pub const WIT: &str = include_str!("../wit/plugin.wit");
