//! The JSON Schemas of what a plugin author writes: `wf-plugin.toml` and what
//! `describe()` returns. `wf plugin new` writes them into the project so
//! editors and Agents can validate before building.
use crate::{Description, Manifest};
use schemars::{JsonSchema, schema_for};

/// Where a scaffolded project keeps the manifest schema.
pub const MANIFEST_SCHEMA_FILE: &str = "schemas/wf-plugin.schema.json";
/// Where a scaffolded project keeps the description schema.
pub const DESCRIPTION_SCHEMA_FILE: &str = "schemas/description.schema.json";

/// The schema of `wf-plugin.toml`, pretty-printed.
pub fn manifest_schema() -> String {
    render::<Manifest>()
}

/// The schema of the JSON `describe()` returns, pretty-printed.
pub fn description_schema() -> String {
    render::<Description>()
}

fn render<T: JsonSchema>() -> String {
    let mut text = serde_json::to_string_pretty(&schema_for!(T)).expect("a schema serializes");
    text.push('\n');
    text
}

#[cfg(test)]
mod tests {
    use super::{description_schema, manifest_schema};
    use serde_json::Value;

    fn parse(text: &str) -> Value {
        serde_json::from_str(text).unwrap()
    }

    #[test]
    fn schemas_forbid_unknown_fields_and_describe_the_author_facing_keys() {
        let manifest = parse(&manifest_schema());
        assert_eq!(manifest["additionalProperties"], false);
        assert_eq!(manifest["$defs"]["PluginInfo"]["additionalProperties"], false);
        for key in ["name", "version", "summary", "api", "component"] {
            assert!(manifest["$defs"]["PluginInfo"]["properties"][key].is_object(), "{key}");
        }
        let description = parse(&description_schema());
        assert_eq!(description["$defs"]["Capability"]["additionalProperties"], false);
        let risks = description["$defs"]["Risk"]["oneOf"].as_array().unwrap();
        assert_eq!(risks.len(), 3);
        assert_eq!(
            description["$defs"]["Capability"]["properties"]["input"]["type"],
            "object"
        );
    }
}
