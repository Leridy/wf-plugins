//! A plugin's settings: the fields it declares under `[[config]]` in
//! `wf-plugin.toml` (readable without running plugin code) and the values a
//! project keeps for it in `<cli>-plugins.toml`. The kinds are a closed typed
//! set, not JSON Schema: the client draws its form from them and the runtime
//! checks values against them. There is no secret kind (plugins have no network).
use schemars::JsonSchema;
use serde::{Deserialize, Serialize, Serializer};
use std::collections::{BTreeMap, BTreeSet};

/// The values a project sets for one plugin, by [`ConfigField::key`].
pub type ConfigValues = BTreeMap<String, ConfigValue>;

/// One setting a plugin declares.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct ConfigField {
    /// Lowercase letters, digits and `_`, starting with a letter; unique within
    /// the plugin. The key the plugin reads it by.
    pub key: String,
    /// What the form labels it.
    pub label: String,
    /// One or two sentences under the field: what it changes.
    #[serde(default)]
    pub description: String,
    pub kind: ConfigKind,
    /// The value a project that sets none gets; without one the key is absent.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub default: Option<ConfigValue>,
}

/// What a setting holds, written `kind = { type = "number", min = 1 }`.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(tag = "type", rename_all = "snake_case", deny_unknown_fields)]
pub enum ConfigKind {
    /// A string; one line unless `multiline`, at most `max_len` characters.
    Text {
        #[serde(default)]
        multiline: bool,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        max_len: Option<u32>,
    },
    /// A number within `min`..=`max`; a whole number when `integer`.
    Number {
        #[serde(default, skip_serializing_if = "Option::is_none")]
        min: Option<f64>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        max: Option<f64>,
        #[serde(default)]
        integer: bool,
    },
    Bool,
    /// One of `options`, stored as its `value`.
    Choice {
        options: Vec<ConfigOption>,
    },
    /// A project-relative path with `/` separators, matching `glob` when set.
    ProjectPath {
        #[serde(default, skip_serializing_if = "Option::is_none")]
        glob: Option<String>,
    },
}

/// One entry of a [`ConfigKind::Choice`].
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct ConfigOption {
    /// What is stored and what the plugin reads.
    pub value: String,
    /// What the form shows.
    pub label: String,
}

/// One setting's value. A number with no fraction is written as an integer,
/// so a plugin may read an `integer` field into an integer type.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(untagged)]
pub enum ConfigValue {
    Bool(bool),
    #[serde(serialize_with = "number")]
    Number(f64),
    Text(String),
}

/// Largest integer an `f64` holds exactly.
const EXACT: f64 = 9_007_199_254_740_992.0;

#[expect(clippy::trivially_copy_pass_by_ref, reason = "serde's serialize_with signature")]
fn number<S: Serializer>(value: &f64, serializer: S) -> Result<S::Ok, S::Error> {
    if value.fract() == 0.0 && value.abs() <= EXACT {
        serializer.serialize_i64(*value as i64)
    } else {
        serializer.serialize_f64(*value)
    }
}

/// Most fields one plugin may declare.
pub const CONFIG_LIMIT: usize = 64;

/// Why a declaration or a value is refused: the field's key and a sentence
/// for the person filling the form (or the author writing the manifest).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ConfigError {
    pub key: String,
    pub message: String,
}

impl ConfigError {
    fn new(key: &str, message: impl Into<String>) -> Self {
        Self {
            key: key.to_owned(),
            message: message.into(),
        }
    }
}

impl ConfigField {
    /// Whether `value` fits this field. A [`ConfigKind::ProjectPath`] is checked
    /// for its shape here; the runtime matches its `glob`.
    pub fn check(&self, value: &ConfigValue) -> Result<(), String> {
        match (&self.kind, value) {
            (ConfigKind::Text { multiline, max_len }, ConfigValue::Text(text)) => {
                if !multiline && text.contains(['\n', '\r']) {
                    return Err("must be one line".into());
                }
                if text.chars().any(|c| c.is_control() && c != '\n' && c != '\t') {
                    return Err("must not hold control characters".into());
                }
                match max_len {
                    Some(max) if text.chars().count() > *max as usize => {
                        Err(format!("must be at most {max} characters"))
                    }
                    _ => Ok(()),
                }
            }
            (ConfigKind::Number { min, max, integer }, ConfigValue::Number(number)) => {
                if !number.is_finite() {
                    return Err("must be a number".into());
                }
                if *integer && number.fract() != 0.0 {
                    return Err("must be a whole number".into());
                }
                if let Some(min) = min.filter(|min| number < min) {
                    return Err(format!("must be at least {}", shown(min)));
                }
                match max.filter(|max| number > max) {
                    Some(max) => Err(format!("must be at most {}", shown(max))),
                    None => Ok(()),
                }
            }
            (ConfigKind::Bool, ConfigValue::Bool(_)) => Ok(()),
            (ConfigKind::Choice { options }, ConfigValue::Text(text)) => {
                if options.iter().any(|option| option.value == *text) {
                    Ok(())
                } else {
                    let values: Vec<&str> = options.iter().map(|option| option.value.as_str()).collect();
                    Err(format!("must be one of {}", values.join(", ")))
                }
            }
            (ConfigKind::ProjectPath { .. }, ConfigValue::Text(path)) => {
                if relative(path) {
                    Ok(())
                } else {
                    Err("must be a path inside the project, with `/` between names".into())
                }
            }
            (kind, _) => Err(format!("must be {}", kind.expected())),
        }
    }

    /// Whether the field itself is well declared, its default included.
    fn check_declaration(&self) -> Result<(), String> {
        if self.label.trim().is_empty() {
            return Err("needs a label".into());
        }
        match &self.kind {
            ConfigKind::Text { max_len: Some(0), .. } => return Err("max_len must be at least 1".into()),
            ConfigKind::Number { min, max, integer } => {
                let bounds = [min, max].into_iter().flatten();
                if bounds
                    .clone()
                    .any(|bound| !bound.is_finite() || (*integer && bound.fract() != 0.0))
                {
                    return Err("min and max must be finite numbers, whole when integer".into());
                }
                if let (Some(min), Some(max)) = (min, max)
                    && min > max
                {
                    return Err("min must not exceed max".into());
                }
            }
            ConfigKind::Choice { options } => {
                if options.is_empty() {
                    return Err("a choice needs options".into());
                }
                let mut seen = BTreeSet::new();
                for option in options {
                    if option.value.is_empty() || !seen.insert(option.value.as_str()) {
                        return Err(format!("option `{}` must be non-empty and listed once", option.value));
                    }
                }
            }
            ConfigKind::ProjectPath { glob: Some(glob) }
                if glob.starts_with('/') || glob.split('/').any(|p| p == "..") =>
            {
                return Err(format!("glob `{glob}` must stay inside the project"));
            }
            ConfigKind::Text { .. } | ConfigKind::Bool | ConfigKind::ProjectPath { .. } => {}
        }
        match &self.default {
            Some(value) => self.check(value).map_err(|reason| format!("default {reason}")),
            None => Ok(()),
        }
    }
}

impl ConfigKind {
    /// The kind of value it takes, for a message.
    const fn expected(&self) -> &'static str {
        match self {
            Self::Text { .. } => "text",
            Self::Number { .. } => "a number",
            Self::Bool => "true or false",
            Self::Choice { .. } => "one of its options",
            Self::ProjectPath { .. } => "a project path",
        }
    }
}

/// A number as a person writes it: no `.0` on a whole one.
fn shown(number: f64) -> String {
    if number.fract() == 0.0 && number.abs() <= EXACT {
        format!("{}", number as i64)
    } else {
        number.to_string()
    }
}

/// A non-empty `/`-separated path of plain names that stays inside the project.
fn relative(path: &str) -> bool {
    !path.is_empty()
        && !path.contains('\\')
        && path
            .split('/')
            .all(|part| !part.is_empty() && part != "." && part != ".." && !part.chars().any(char::is_control))
}

/// Lowercase letters, digits and `_`, starting with a letter: a key every
/// language reads as a field name.
pub fn is_config_key(key: &str) -> bool {
    key.len() <= 64
        && key.starts_with(|c: char| c.is_ascii_lowercase())
        && key
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '_')
}

/// Checks a manifest's `[[config]]`: named keys, each once, well-declared fields.
pub fn check_fields(fields: &[ConfigField]) -> Result<(), ConfigError> {
    if fields.len() > CONFIG_LIMIT {
        return Err(ConfigError::new(
            "",
            format!("declares more than {CONFIG_LIMIT} fields"),
        ));
    }
    let mut seen = BTreeSet::new();
    for field in fields {
        if !is_config_key(&field.key) {
            return Err(ConfigError::new(
                &field.key,
                "must be lowercase letters, digits and `_`, starting with a letter",
            ));
        }
        if !seen.insert(field.key.as_str()) {
            return Err(ConfigError::new(&field.key, "is declared twice"));
        }
        field
            .check_declaration()
            .map_err(|message| ConfigError::new(&field.key, message))?;
    }
    Ok(())
}

/// What a plugin reads: `set` checked against `fields` (an unknown key is an
/// error), with each unset field's default filled in.
pub fn effective(fields: &[ConfigField], set: &ConfigValues) -> Result<ConfigValues, ConfigError> {
    if let Some(key) = set.keys().find(|key| !fields.iter().any(|field| field.key == **key)) {
        return Err(ConfigError::new(key, "is not a setting of this plugin"));
    }
    let mut values = ConfigValues::new();
    for field in fields {
        let value = match set.get(&field.key) {
            Some(value) => {
                field
                    .check(value)
                    .map_err(|message| ConfigError::new(&field.key, message))?;
                value
            }
            None => match &field.default {
                Some(value) => value,
                None => continue,
            },
        };
        values.insert(field.key.clone(), value.clone());
    }
    Ok(values)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn field(key: &str, kind: ConfigKind, default: Option<ConfigValue>) -> ConfigField {
        ConfigField {
            key: key.into(),
            label: key.into(),
            description: String::new(),
            kind,
            default,
        }
    }

    fn fields() -> Vec<ConfigField> {
        vec![
            field(
                "limit",
                ConfigKind::Number {
                    min: Some(1.0),
                    max: Some(400.0),
                    integer: true,
                },
                Some(ConfigValue::Number(100.0)),
            ),
            field(
                "style",
                ConfigKind::Choice {
                    options: ["tabs", "spaces"]
                        .map(|value| ConfigOption {
                            value: value.into(),
                            label: value.into(),
                        })
                        .into(),
                },
                None,
            ),
            field(
                "title",
                ConfigKind::Text {
                    multiline: false,
                    max_len: Some(5),
                },
                None,
            ),
            field("scene", ConfigKind::ProjectPath { glob: None }, None),
            field("strict", ConfigKind::Bool, Some(ConfigValue::Bool(false))),
        ]
    }

    fn set(values: &[(&str, ConfigValue)]) -> ConfigValues {
        values
            .iter()
            .map(|(key, value)| ((*key).to_owned(), value.clone()))
            .collect()
    }

    #[test]
    fn defaults_fill_unset_fields_and_a_field_without_one_stays_absent() {
        let values = effective(&fields(), &set(&[("style", ConfigValue::Text("tabs".into()))])).unwrap();
        assert_eq!(
            values,
            set(&[
                ("limit", ConfigValue::Number(100.0)),
                ("strict", ConfigValue::Bool(false)),
                ("style", ConfigValue::Text("tabs".into())),
            ])
        );
        // A whole number reaches the plugin as an integer.
        assert_eq!(
            serde_json::to_string(&values).unwrap(),
            r#"{"limit":100,"strict":false,"style":"tabs"}"#
        );
    }

    #[test]
    fn form_invalid_values_name_their_field() {
        let text = |value: &str| ConfigValue::Text(value.into());
        for (key, value, message) in [
            ("limit", ConfigValue::Number(0.0), "must be at least 1"),
            ("limit", ConfigValue::Number(401.0), "must be at most 400"),
            ("limit", ConfigValue::Number(1.5), "must be a whole number"),
            ("limit", text("100"), "must be a number"),
            ("style", text("both"), "must be one of tabs, spaces"),
            ("title", text("a\nb"), "must be one line"),
            ("title", text("toolong"), "must be at most 5 characters"),
            (
                "scene",
                text("../x.tscn"),
                "must be a path inside the project, with `/` between names",
            ),
            (
                "scene",
                text("/etc/x"),
                "must be a path inside the project, with `/` between names",
            ),
            ("strict", text("yes"), "must be true or false"),
            ("colour", text("red"), "is not a setting of this plugin"),
        ] {
            let error = effective(&fields(), &set(&[(key, value)])).unwrap_err();
            assert_eq!(
                error,
                ConfigError {
                    key: key.into(),
                    message: message.into()
                }
            );
        }
    }

    #[test]
    fn values_read_from_toml_keep_their_kind() {
        #[derive(Deserialize)]
        struct Table {
            values: ConfigValues,
        }
        let table: Table =
            toml::from_str("[values]\nlimit = 7\nratio = 0.5\nstrict = true\nstyle = \"tabs\"\n").unwrap();
        assert_eq!(
            table.values,
            set(&[
                ("limit", ConfigValue::Number(7.0)),
                ("ratio", ConfigValue::Number(0.5)),
                ("strict", ConfigValue::Bool(true)),
                ("style", ConfigValue::Text("tabs".into())),
            ])
        );
        assert_eq!(
            toml::to_string(&table.values).unwrap(),
            "limit = 7\nratio = 0.5\nstrict = true\nstyle = \"tabs\"\n"
        );
    }
}
