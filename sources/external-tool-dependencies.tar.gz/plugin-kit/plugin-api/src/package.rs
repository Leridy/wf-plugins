//! Plugin packages, their signatures and the indexes that list them
//! (cli-plugins-distribution.md §11.2). Shared by `pack`, `install`, `sign` and `search`.
use crate::{Capability, IconRef, Risk, Target};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fmt::Write;

/// A package file is `<name>-<version>.wfplugin`.
pub const PACKAGE_EXTENSION: &str = "wfplugin";
/// A package's detached signature is `<package>.sig`.
pub const SIGNATURE_EXTENSION: &str = "sig";

/// Entries of a package.
pub const MANIFEST_ENTRY: &str = "wf-plugin.toml";
pub const COMPONENT_ENTRY: &str = "plugin.wasm";
pub const CAPABILITIES_ENTRY: &str = "capabilities.json";
pub const FILES_ENTRY: &str = "files.json";
/// `[[skills]]` topics are stored as `skills/<topic>.md`.
pub const SKILLS_DIRECTORY: &str = "skills";
/// The `[ui] assets` directory is stored as `ui-assets/`, its files as they were.
pub const UI_ASSETS_DIRECTORY: &str = "ui-assets";

pub const FILES_SCHEMA: &str = "wf-plugin-files/1";
/// Version 2 adds each version's `icon` and describes its `ops` (summary and
/// risk); an index of another schema is refused, never read in part.
pub const INDEX_SCHEMA: &str = "wf-plugin-index/2";
/// The name of the index every server serves; its packages may use the
/// reserved `official` namespace.
pub const OFFICIAL_INDEX: &str = "official";
/// Where a server serves the official index, below its origin; its packages are
/// addressed relative to it (`<name>/<file>`).
pub const OFFICIAL_INDEX_PATH: &str = "/releases/plugins/index.json";

/// `files.json`: every other entry of the package with its hash and size.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Files {
    pub schema: String,
    pub files: Vec<FileEntry>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct FileEntry {
    /// `/`-separated, relative to the package root.
    pub path: String,
    /// Lowercase hex.
    pub sha256: String,
    pub size: u64,
}

/// `index.json`, official or third-party; signed next to it as `index.json.sig`.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub struct Index {
    pub schema: String,
    pub name: String,
    pub plugins: Vec<IndexEntry>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub struct IndexEntry {
    pub name: String,
    pub summary: String,
    pub versions: Vec<IndexVersion>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub struct IndexVersion {
    pub version: String,
    /// The WIT package the component targets, e.g. `wf:plugin@0.1.0`.
    pub api: String,
    /// The CLI versions it supports, as a semver requirement.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cli: Option<String>,
    /// Where the package is downloaded from (HTTPS).
    pub url: String,
    /// sha256 of the package bytes, lowercase hex.
    pub sha256: String,
    #[cfg_attr(feature = "ts", ts(type = "number"))]
    pub size: u64,
    /// Fingerprint of the key that signed the package; absent when unsigned.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub signer: Option<String>,
    /// The permissions the package asks for, as confirmations list them.
    #[serde(default)]
    pub permissions: Vec<String>,
    /// What the version's capabilities do, as its package describes them.
    #[serde(default)]
    pub ops: Vec<IndexOp>,
    /// The package's icon, published beside the index as
    /// `icons/<sha256>.png`; absent when the plugin has none.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub icon: Option<IconRef>,
    /// Protocols implemented by this version's capabilities.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub protocols: Vec<String>,
    /// The platform a process plugin's package runs on, one entry per
    /// target; `None` for a component or data-only package, which runs anywhere.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub target: Option<Target>,
}

impl IndexVersion {
    /// Whether this package runs on `host` (this build's [`Target::host`]).
    pub fn runs_on(&self, host: Option<Target>) -> bool {
        self.target.is_none_or(|target| Some(target) == host)
    }
}

/// One capability of a listed version, so a catalog shows what a plugin does
/// and how far it reaches before it is installed.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub struct IndexOp {
    /// Run as `<cli> <plugin> <op>`.
    pub op: String,
    /// The capability's one-line summary.
    pub summary: String,
    /// Its declared lower bound; a call may still raise it.
    pub risk: Risk,
}

impl From<&Capability> for IndexOp {
    fn from(capability: &Capability) -> Self {
        Self {
            op: capability.op.clone(),
            summary: capability.summary.clone(),
            risk: capability.risk,
        }
    }
}

pub const SIGNATURE_SCHEMA: &str = "wf-plugin-signature/1";

/// `<package>.sig`: an Ed25519 signature over the package's sha256 (32 bytes)
/// and the public key it verifies with, so a first install can show the
/// signer's fingerprint for confirmation.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Signature {
    pub schema: String,
    /// Raw 32-byte Ed25519 public key, lowercase hex.
    pub public_key: String,
    /// The 64-byte signature, lowercase hex.
    pub value: String,
}

/// Where an installed package came from.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub enum Origin {
    File { path: String },
    Url { url: String },
    Index { name: String },
}

/// Who vouches for a package, as installs confirm and the registry records it.
#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub enum Signer {
    Unsigned,
    /// A signature verified against `fingerprint`'s key; `official` when that
    /// key is the release key.
    Verified {
        fingerprint: String,
        official: bool,
    },
}

/// The fingerprint of an Ed25519 public key: the first 16 hex characters of
/// its sha256.
pub fn fingerprint(public_key: &[u8]) -> String {
    hex(&Sha256::digest(public_key)[..8])
}

/// Lowercase hex of `bytes`.
pub(crate) fn hex(bytes: &[u8]) -> String {
    bytes.iter().fold(String::new(), |mut hex, byte| {
        let _ = write!(hex, "{byte:02x}");
        hex
    })
}

/// The package name `pack` writes and `install` expects.
pub fn package_file(name: &str, version: &str) -> String {
    format!("{name}-{version}.{PACKAGE_EXTENSION}")
}

#[cfg(test)]
mod tests {
    use super::IndexVersion;

    #[test]
    fn protocols_default_to_empty_are_omitted_when_empty_and_round_trip() {
        let mut version = IndexVersion {
            version: "1.0.0".into(),
            api: crate::API.into(),
            cli: None,
            url: "https://example.test/plugin.zip".into(),
            sha256: "ab".repeat(32),
            size: 12,
            signer: None,
            permissions: Vec::new(),
            ops: Vec::new(),
            icon: None,
            protocols: Vec::new(),
            target: None,
        };
        let encoded = serde_json::to_string(&version).unwrap();
        assert!(!encoded.contains("protocols"));
        assert_eq!(serde_json::from_str::<IndexVersion>(&encoded).unwrap(), version);
        version.protocols = vec!["wf.lint/1".into()];
        let encoded = serde_json::to_string(&version).unwrap();
        assert_eq!(serde_json::from_str::<IndexVersion>(&encoded).unwrap(), version);
    }
}
