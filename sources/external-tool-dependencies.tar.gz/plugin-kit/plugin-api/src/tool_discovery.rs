//! Declarative Windows installation locations, never commands or registry writes.
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(rename_all = "UPPERCASE")]
pub enum RegistryHive {
    Hkcu,
    Hklm,
}

#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(rename_all = "snake_case")]
pub enum RegistryView {
    #[default]
    Both,
    Native,
    X86,
    X64,
}

#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct RegistryHint {
    pub hive: RegistryHive,
    /// Under Software; an optional wildcard is allowed only in the final key segment.
    pub key: String,
    /// Empty reads the key's default value. Only string values are read.
    #[serde(default)]
    pub value: String,
    /// When the value is an installation directory, append this relative executable path.
    #[serde(default)]
    pub executable: Option<String>,
    #[serde(default)]
    pub view: RegistryView,
}

impl RegistryHint {
    pub fn check(&self) -> Result<(), String> {
        let key = self.key.replace('/', "\\");
        let segments: Vec<_> = key.split('\\').collect();
        if key.len() > 512
            || segments.len() < 3
            || !segments[0].eq_ignore_ascii_case("software")
            || segments
                .iter()
                .any(|s| s.is_empty() || *s == "." || *s == ".." || s.chars().any(char::is_control))
            || segments[..segments.len() - 1].iter().any(|s| s.contains(['*', '?']))
        {
            return Err(
                "registry.key must name a bounded Software subtree; only its final segment may contain wildcards"
                    .into(),
            );
        }
        // No arbitrary sensitive registry extraction: discovery reads installation locations only.
        if ![
            "",
            "installlocation",
            "installpath",
            "installdir",
            "path",
            "executablepath",
        ]
        .contains(&self.value.to_ascii_lowercase().as_str())
        {
            return Err("registry.value must be an installation path (never UninstallString or commands)".into());
        }
        if let Some(path) = &self.executable
            && (path.is_empty()
                || path.len() > 512
                || path.contains(':')
                || path.starts_with(['/', '\\'])
                || path.split(['/', '\\']).any(|s| {
                    s.is_empty() || s == "." || s == ".." || s.contains(['*', '?']) || s.chars().any(char::is_control)
                }))
        {
            return Err("registry.executable must be a plain relative file path".into());
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn registry_reads_are_scoped_to_installation_paths() {
        let mut hint = RegistryHint {
            hive: RegistryHive::Hkcu,
            key: r"Software\Microsoft\Windows\CurrentVersion\Uninstall\Example*".into(),
            value: "InstallLocation".into(),
            executable: Some("bin/editor.exe".into()),
            view: RegistryView::Both,
        };
        assert!(hint.check().is_ok());
        hint.value = "UninstallString".into();
        assert!(hint.check().is_err());
        hint.value = String::new();
        hint.key = r"Software\*\Editor".into();
        assert!(hint.check().is_err());
        hint.key = r"Software\Vendor\Editor".into();
        hint.executable = Some("../runner.exe".into());
        assert!(hint.check().is_err());
    }
}
