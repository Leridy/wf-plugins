//! `[ui]`: what a plugin adds to the client, as data. Actions put a button in
//! a fixed place (the node menu, the plugins panel) that runs one capability
//! with an input built from where it was pressed; views name the fixed
//! renderer a capability's output is drawn with. Nothing in it runs or is
//! parsed as markup: the client draws it with its own components.
//!
//! [`Ui::check`] checks the declarations on their own; whether they fit the
//! capabilities (the op exists, the bound fields have the right kind) is the
//! runtime's check, which needs the plugin's description.
use std::collections::{BTreeMap, BTreeSet};

use crate::NodeTypeKey;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

use crate::manifest::inside;
use crate::{ConfigValue, ManifestError, is_config_key, is_name};

/// Most actions one plugin declares.
pub const ACTION_LIMIT: usize = 16;
/// Most views one plugin declares.
pub const VIEW_LIMIT: usize = 8;
/// Most columns a table view has.
pub const COLUMN_LIMIT: usize = 8;
/// Most characters of an action's label, per language.
pub const LABEL_LIMIT: usize = 32;
/// Most characters of a view's or a column's title, per language.
pub const TITLE_LIMIT: usize = 48;
/// Most nodes one node-menu action runs on.
pub const SELECTION_LIMIT: usize = 200;
/// Most files the `[ui] assets` directory holds.
pub const ASSET_LIMIT: usize = 64;
/// Most bytes of one of them.
pub const ASSET_BYTES: u64 = 4 << 20;
/// Most bytes of all of them.
pub const ASSETS_BYTES: u64 = 16 << 20;
/// Most characters of an input field's name.
const FIELD_LIMIT: usize = 64;

/// `[ui]`: what the plugin adds to the client. Data only: the client draws it
/// with its own components; nothing in it runs or is parsed as markup.
#[derive(Clone, Debug, Default, Deserialize, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Ui {
    /// Buttons that run a capability (`[[ui.actions]]`), at most 16.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub actions: Vec<Action>,
    /// How capabilities' outputs are shown (`[[ui.views]]`), at most 8, one per op.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub views: Vec<View>,
    /// A directory inside the plugin of pictures an `images` view shows as
    /// `{ "package": "<path inside it>" }`: PNG, JPEG or WebP only, at most 64
    /// files of 4 MiB and 16 MiB in all, no symbolic links. Packed as it is.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub assets: Option<String>,
}

/// A button that runs one capability with an input built from where it was pressed.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Action {
    /// Lowercase words joined by `-`, unique within the plugin.
    pub id: String,
    /// What the button says, at most 32 characters per language.
    pub label: Text,
    /// The capability it runs: one of the plugin's, a template's included.
    pub op: String,
    pub place: Place,
    /// When a node-menu action is offered.
    #[serde(default)]
    pub when: When,
    /// Input field → where its value comes from. Unbound optional fields take
    /// the capability's defaults; every required field must be bound.
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub input: BTreeMap<String, Bind>,
}

/// Where an action's button is.
#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiPlace"))]
#[serde(rename_all = "kebab-case")]
pub enum Place {
    /// The node context menu of the explorer and the canvas (one group per plugin).
    NodeMenu,
    /// A row under the plugin in the plugins view (installed list and its features tab).
    Panel,
}

/// When a node-menu action is offered. Typed conditions, no expressions.
#[derive(Clone, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiWhen"))]
#[serde(deny_unknown_fields)]
pub struct When {
    /// The item types it applies to; empty = every item type (or, with
    /// `directories`, directories only).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub node_types: Vec<NodeTypeKey>,
    /// Directory nodes too.
    #[serde(default)]
    pub directories: bool,
    #[serde(default)]
    pub selection: Selection,
    #[serde(default)]
    pub project: ProjectNeed,
}

impl When {
    /// Whether a selected node may be among the action's: `None` is a
    /// directory, `Some` an item of that type.
    pub fn admits(&self, node: Option<NodeTypeKey>) -> bool {
        match node {
            None => self.directories,
            Some(_) if self.node_types.is_empty() => !self.directories,
            Some(node_type) => self.node_types.contains(&node_type),
        }
    }

    /// Whether `count` selected nodes are a selection the action takes.
    pub fn takes(&self, count: usize) -> bool {
        match self.selection {
            Selection::One => count == 1,
            Selection::Any => (1..=SELECTION_LIMIT).contains(&count),
        }
    }

    fn is_default(&self) -> bool {
        *self == Self::default()
    }
}

/// How many nodes a node-menu action runs on.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiSelection"))]
#[serde(rename_all = "kebab-case")]
pub enum Selection {
    /// Exactly one.
    One,
    /// One or more, at most [`SELECTION_LIMIT`].
    #[default]
    Any,
}

/// The project folder an action needs.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiProjectNeed"))]
#[serde(rename_all = "kebab-case")]
pub enum ProjectNeed {
    /// A project folder is chosen in the plugins view (the Workspace's Agent folder).
    #[default]
    Open,
    /// …and it mirrors this Workspace (its mirror's workspace id is this one).
    Mirror,
}

/// Where an input field's value comes from. TOML: `"selection"`, `"node"`, `{ value = … }`.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case", deny_unknown_fields)]
pub enum Bind {
    /// The selected nodes' addresses (`wf://<id>`), in selection order: an array-of-strings field.
    Selection,
    /// The one selected node's address: a string field; needs `selection = "one"`.
    Node,
    /// A constant, as a plugin setting's value.
    Value(ConfigValue),
}

/// A capability's output shown by a fixed renderer in the client.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiView"))]
#[serde(deny_unknown_fields)]
pub struct View {
    /// The capability whose output it shows; at most one view per op.
    pub op: String,
    /// At most 48 characters per language.
    pub title: Text,
    /// The top-level output field holding the data; the whole output when absent.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub from: Option<String>,
    pub renderer: Renderer,
}

/// The fixed renderers, each with its data type.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiRenderer"))]
#[serde(tag = "type", rename_all = "kebab-case", deny_unknown_fields)]
pub enum Renderer {
    /// Rows of cells under these columns (1..=8); data: `plugin_protocols::ui::TableData`.
    Table { columns: Vec<Column> },
    /// Diagnostics by file; data: `plugin_protocols::lint::LintOutput`.
    Findings,
    /// Labelled values; data: `plugin_protocols::ui::KeyValuesData`.
    KeyValues,
    /// Pictures from the project or the plugin's package; data: `plugin_protocols::ui::ImagesData`.
    Images,
}

/// A table column: its header and the kind of every cell under it.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiColumn"))]
#[serde(deny_unknown_fields)]
pub struct Column {
    pub label: Text,
    pub kind: CellKind,
}

/// What a table cell holds.
#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiCellKind"))]
#[serde(rename_all = "kebab-case")]
pub enum CellKind {
    Text,
    Number,
    Status,
    Path,
    Node,
}

/// Plugin text in each app language; `en` is required and the fallback.
/// Mirrors `@weaveforge/i18n` `supportedLanguages` (a test keeps them equal).
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "PluginText"))]
#[serde(deny_unknown_fields)]
pub struct Text {
    pub en: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub zh: Option<String>,
}

impl Text {
    /// Every language's text, `en` first.
    fn each(&self) -> impl Iterator<Item = (&'static str, &str)> {
        [("en", Some(self.en.as_str())), ("zh", self.zh.as_deref())]
            .into_iter()
            .filter_map(|(language, text)| text.map(|text| (language, text)))
    }

    /// Each language's text is plain, non-empty and at most `limit` characters.
    fn check(&self, what: &str, limit: usize) -> Result<(), ManifestError> {
        for (language, text) in self.each() {
            let count = text.chars().count();
            if text.trim().is_empty() || count > limit || !is_plain(text) {
                return Err(ManifestError(format!(
                    "{what}.{language} must be one line of 1 to {limit} characters without control, bidirectional or zero-width characters."
                )));
            }
        }
        Ok(())
    }
}

/// Text the client may show as is: no control characters (line breaks
/// included), bidirectional controls or zero-width characters, checked one
/// character at a time.
pub fn is_plain(text: &str) -> bool {
    !text.chars().any(|c| {
        c.is_control()
            || matches!(
                c,
                '\u{061C}'
                    | '\u{200B}'..='\u{200F}'
                    | '\u{202A}'..='\u{202E}'
                    | '\u{2060}'..='\u{2064}'
                    | '\u{2066}'..='\u{2069}'
                    | '\u{FEFF}'
            )
    })
}

impl Ui {
    pub fn is_empty(&self) -> bool {
        self.actions.is_empty() && self.views.is_empty() && self.assets.is_none()
    }

    /// The declarations on their own: names, text, limits and the rules of
    /// each place. Whether they fit the capabilities is the runtime's check.
    pub fn check(&self) -> Result<(), ManifestError> {
        if let Some(assets) = &self.assets
            && (!inside(assets) || assets.contains('\\'))
        {
            return Err(ManifestError(format!(
                "ui.assets `{assets}` must be a relative `/`-separated directory inside the plugin."
            )));
        }
        if self.actions.len() > ACTION_LIMIT {
            return Err(ManifestError(format!(
                "ui.actions declares {}; at most {ACTION_LIMIT}.",
                self.actions.len()
            )));
        }
        if self.views.len() > VIEW_LIMIT {
            return Err(ManifestError(format!(
                "ui.views declares {}; at most {VIEW_LIMIT}.",
                self.views.len()
            )));
        }
        let mut ids = BTreeSet::new();
        for action in &self.actions {
            if !is_name(&action.id) || !ids.insert(action.id.as_str()) {
                return Err(ManifestError(format!(
                    "ui.actions id `{}` must be declared once: lowercase words joined by `-`.",
                    action.id
                )));
            }
            action.check()?;
        }
        let mut ops = BTreeSet::new();
        for view in &self.views {
            if !is_name(&view.op) || !ops.insert(view.op.as_str()) {
                return Err(ManifestError(format!(
                    "ui.views op `{}` must name a capability, with one view per op.",
                    view.op
                )));
            }
            view.check()?;
        }
        Ok(())
    }
}

impl Action {
    fn check(&self) -> Result<(), ManifestError> {
        let at = |rest: &str| ManifestError(format!("ui.actions `{}` {rest}", self.id));
        self.label
            .check(&format!("ui.actions `{}` label", self.id), LABEL_LIMIT)?;
        if !is_name(&self.op) {
            return Err(at(&format!(
                "op `{}` must name a capability: lowercase words joined by `-`.",
                self.op
            )));
        }
        let mut types = BTreeSet::new();
        if let Some(twice) = self.when.node_types.iter().find(|t| !types.insert(**t)) {
            return Err(at(&format!("when.node_types lists `{twice}` twice.")));
        }
        for (field, bind) in &self.input {
            if field.is_empty() || field.chars().count() > FIELD_LIMIT || !is_plain(field) {
                return Err(at(&format!(
                    "input field `{field}` must be a capability's input field name."
                )));
            }
            match bind {
                Bind::Selection | Bind::Node if self.place == Place::Panel => {
                    return Err(at(&format!(
                        "input.{field} binds the selection, which a panel action does not have."
                    )));
                }
                Bind::Node if self.when.selection != Selection::One => {
                    return Err(at(&format!("input.{field} = \"node\" needs when.selection = \"one\".")));
                }
                Bind::Value(ConfigValue::Number(number)) if !number.is_finite() => {
                    return Err(at(&format!("input.{field} must be a finite number.")));
                }
                _ => {}
            }
        }
        if self.place == Place::Panel && !self.when.is_default() {
            return Err(at(
                "is a panel action: it takes no `when`, which is for node-menu actions.",
            ));
        }
        Ok(())
    }
}

impl View {
    fn check(&self) -> Result<(), ManifestError> {
        let what = format!("ui.views `{}`", self.op);
        self.title.check(&format!("{what} title"), TITLE_LIMIT)?;
        if let Some(from) = &self.from
            && !is_config_key(from)
        {
            return Err(ManifestError(format!(
                "{what} from `{from}` must be a top-level output field: lowercase letters, digits and `_`."
            )));
        }
        if let Renderer::Table { columns } = &self.renderer {
            if !(1..=COLUMN_LIMIT).contains(&columns.len()) {
                return Err(ManifestError(format!(
                    "{what} declares {} table columns; 1 to {COLUMN_LIMIT}.",
                    columns.len()
                )));
            }
            for column in columns {
                column.label.check(&format!("{what} column label"), TITLE_LIMIT)?;
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests;
