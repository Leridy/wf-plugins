//! A plugin's icon: one square PNG named by `[plugin] icon`, packed as
//! [`ICON_ENTRY`] and published beside its index as `icons/<sha256>.png`, so a
//! catalog shows it before anything is installed. PNG only: a scriptable
//! format (SVG) would need sanitising wherever it is shown.
use crate::package::hex;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fmt;

/// The package entry holding the icon.
pub const ICON_ENTRY: &str = "icon.png";
/// Below an index's directory: icons by content, `icons/<sha256>.png`.
pub const ICONS_DIRECTORY: &str = "icons";
/// Most bytes an icon may have.
pub const ICON_LIMIT: usize = 64 << 10;
/// The side lengths an icon may have, in pixels; it is square.
pub const ICON_SIDES: [u32; 2] = [128, 256];

/// An icon by content: what a signed index lists and the client caches.
#[derive(Clone, Debug, Deserialize, Eq, Hash, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub struct IconRef {
    /// sha256 of the PNG bytes, lowercase hex.
    pub sha256: String,
    /// Its length in bytes, at most [`ICON_LIMIT`].
    pub size: u32,
}

/// The file an icon is published and cached as.
pub fn icon_file(sha256: &str) -> String {
    format!("{sha256}.png")
}

/// Why bytes are not a usable icon, phrased for the plugin author.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IconError(pub String);

impl fmt::Display for IconError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

const PNG_SIGNATURE: [u8; 8] = [0x89, b'P', b'N', b'G', b'\r', b'\n', 0x1a, b'\n'];

/// Checks `bytes` as an icon from its header: a PNG of at most
/// [`ICON_LIMIT`] bytes whose first chunk (`IHDR`) gives a square of one of
/// [`ICON_SIDES`]; returns its reference.
pub fn check_icon(bytes: &[u8]) -> Result<IconRef, IconError> {
    if bytes.len() > ICON_LIMIT {
        return Err(IconError(format!(
            "is {} bytes; an icon may have at most {} KiB",
            bytes.len(),
            ICON_LIMIT >> 10
        )));
    }
    // Signature, then the IHDR chunk: length 13, type, width, height.
    let header = bytes.get(..24).filter(|header| {
        header[..8] == PNG_SIGNATURE && header[8..12] == 13_u32.to_be_bytes() && &header[12..16] == b"IHDR"
    });
    let Some(header) = header else {
        return Err(IconError("is not a PNG image".into()));
    };
    let side = |at: usize| u32::from_be_bytes([header[at], header[at + 1], header[at + 2], header[at + 3]]);
    let (width, height) = (side(16), side(20));
    if width != height || !ICON_SIDES.contains(&width) {
        return Err(IconError(format!(
            "is {width}x{height} pixels; an icon is square, {} or {} pixels",
            ICON_SIDES[0], ICON_SIDES[1]
        )));
    }
    Ok(IconRef {
        sha256: hex(&Sha256::digest(bytes)),
        // At most ICON_LIMIT, checked above.
        size: bytes.len() as u32,
    })
}

#[cfg(test)]
mod tests {
    use super::{ICON_LIMIT, IconError, check_icon};

    /// A PNG header claiming `width`x`height`, padded to `size` bytes.
    fn png(width: u32, height: u32, size: usize) -> Vec<u8> {
        let mut bytes = vec![0x89, b'P', b'N', b'G', b'\r', b'\n', 0x1a, b'\n'];
        bytes.extend(13_u32.to_be_bytes());
        bytes.extend(b"IHDR");
        bytes.extend(width.to_be_bytes());
        bytes.extend(height.to_be_bytes());
        bytes.resize(size, 0);
        bytes
    }

    fn refused(bytes: &[u8]) -> String {
        check_icon(bytes).map(drop).unwrap_err().to_string()
    }

    #[test]
    fn square_pngs_of_128_or_256_pixels_within_64_kib_are_icons() {
        for side in [128, 256] {
            let icon = check_icon(&png(side, side, 900)).unwrap();
            assert_eq!(icon.size, 900);
            assert_eq!(icon.sha256.len(), 64);
        }
        assert!(check_icon(&png(128, 128, ICON_LIMIT)).is_ok());
    }

    #[test]
    fn too_large_not_png_or_not_square_is_refused() {
        assert!(refused(&png(128, 128, ICON_LIMIT + 1)).contains("at most 64 KiB"));
        assert!(refused(b"<svg xmlns='http://www.w3.org/2000/svg'/>").contains("not a PNG"));
        let mut gif = png(128, 128, 100);
        gif[1..4].copy_from_slice(b"GIF");
        assert_eq!(check_icon(&gif), Err(IconError("is not a PNG image".into())));
        assert!(refused(&png(128, 64, 100)).contains("128x64"));
        assert!(refused(&png(512, 512, 100)).contains("512x512"));
        assert!(refused(&png(128, 128, 20)).contains("not a PNG"));
    }
}
