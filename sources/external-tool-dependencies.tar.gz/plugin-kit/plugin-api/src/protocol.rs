//! The official plugin protocols by id. A capability names one in
//! `implements`; a manifest contributes data in one under `[[contributes]]`.
//! The types each protocol carries live in `plugin-protocols`.
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

/// An official protocol, written as its id `<name>/<major>`; an unknown id
/// is an error wherever one is read.
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, JsonSchema, Ord, PartialEq, PartialOrd, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "PluginProtocol"))]
pub enum Protocol {
    /// Check project files and report diagnostics; implemented by capabilities.
    #[serde(rename = "wf.lint/1")]
    Lint,
    /// A project template; contributed as data and run by the runtime itself.
    #[serde(rename = "wf.template/1")]
    Template,
}

impl Protocol {
    pub const ALL: [Self; 2] = [Self::Lint, Self::Template];

    pub const fn id(self) -> &'static str {
        match self {
            Self::Lint => "wf.lint/1",
            Self::Template => "wf.template/1",
        }
    }

    pub fn parse(id: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|protocol| protocol.id() == id)
    }

    pub const fn summary(self) -> &'static str {
        match self {
            Self::Lint => "Check project files and report diagnostics, optionally with fixes.",
            Self::Template => "Create a project from a template's files, then run its declared tools.",
        }
    }

    /// Whether a manifest contributes it as data (`[[contributes]]`) rather
    /// than a component's capability implementing it.
    pub const fn is_data(self) -> bool {
        match self {
            Self::Lint => false,
            Self::Template => true,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::Protocol;

    #[test]
    fn ids_round_trip_and_unknown_ids_are_none() {
        for protocol in Protocol::ALL {
            assert_eq!(Protocol::parse(protocol.id()), Some(protocol));
            let written = serde_json::to_string(&protocol).unwrap();
            assert_eq!(written, format!("\"{}\"", protocol.id()));
        }
        assert_eq!(Protocol::parse("wf.lint/2"), None);
        assert_eq!(Protocol::parse("wf.lint"), None);
    }
}
