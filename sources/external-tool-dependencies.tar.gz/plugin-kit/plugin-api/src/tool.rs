//! External programs a plugin may run through `effect.exec`: the `[[tools]]`
//! a manifest declares, how the runtime finds one on this machine, and what
//! a run of one reports. The runtime resolves a tool name to an absolute path
//! from its own tool table, never through a shell; the `detect` hints only
//! suggest candidates the person confirms once.
use crate::{RegistryHint, VersionCheck};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

/// Most bytes of a run's standard output and error an [`ExecResult`] keeps: the end.
pub const EXEC_TAIL_LIMIT: usize = 8 << 10;

/// One `[[tools]]` entry: a mandatory dependency of the whole plugin, named
/// in `permissions.exec`. All entries must be ready before any operation runs.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct ToolDecl {
    /// Lowercase letters, digits and `-`, starting with a letter; unique
    /// within the plugin. The name `exec` requests and the tool table use.
    pub name: String,
    /// What the program is, in a few words (`Godot editor`); shown beside its path.
    pub summary: String,
    /// Where it is usually installed; hints only, never run without the person's confirmation.
    #[serde(default)]
    pub detect: Detect,
    /// Optional, explicitly approved version query and compatibility requirements.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub version: Option<VersionCheck>,
}

/// Where to look for a tool. Plain paths with `*` and `?` wildcards, no shell
/// syntax: nothing here is expanded by a shell or run as a command.
#[derive(Clone, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct Detect {
    /// Absolute paths on macOS, or under the home directory as `~/…`
    /// (`/Applications/Godot*.app/Contents/MacOS/Godot`).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub macos: Vec<String>,
    /// Paths on Windows starting with a drive (`C:/`) or one environment
    /// variable (`%ProgramFiles%/Godot*/Godot*.exe`); `/` or `\` separate.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub windows: Vec<String>,
    /// Program names looked up on `PATH` on every system (`godot`, `godot4`).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub path: Vec<String>,
    /// Bounded, read-only Windows registry discovery; ignored on other platforms.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub registry: Vec<RegistryHint>,
}

impl Detect {
    /// The first entry that is not a plain hint, with why.
    pub fn check(&self) -> Result<(), String> {
        if self.macos.len() + self.windows.len() + self.path.len() + self.registry.len() > 32 {
            return Err("at most 32 discovery rules are allowed per tool".into());
        }
        for hint in &self.registry {
            hint.check()?;
        }
        for entry in &self.macos {
            check_macos(entry).map_err(|reason| format!("detect.macos `{entry}` {reason}"))?;
        }
        for entry in &self.windows {
            check_windows(entry).map_err(|reason| format!("detect.windows `{entry}` {reason}"))?;
        }
        for entry in &self.path {
            if entry.is_empty()
                || entry.starts_with('.')
                || !entry
                    .chars()
                    .all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-' | '+'))
            {
                return Err(format!(
                    "detect.path `{entry}` must be a program name: letters, digits, `.`, `_`, `-` and `+`."
                ));
            }
        }
        Ok(())
    }
}

/// Characters a path hint may hold besides its separators: no quoting,
/// substitution, redirection or command separators.
fn plain(c: char) -> bool {
    c.is_ascii_alphanumeric() || matches!(c, ' ' | '.' | '_' | '-' | '+' | '*' | '?' | '(' | ')')
}

fn check_segments<'a>(segments: impl Iterator<Item = &'a str>) -> Result<(), &'static str> {
    for segment in segments {
        if segment == ".." {
            return Err("must not contain `..`.");
        }
        if !segment.chars().all(plain) {
            return Err(
                "may hold only letters, digits, spaces, `.`, `_`, `-`, `+`, `(`, `)` and the wildcards `*` and `?`.",
            );
        }
    }
    Ok(())
}

fn check_macos(entry: &str) -> Result<(), &'static str> {
    let Some(rest) = entry.strip_prefix('/').or_else(|| entry.strip_prefix("~/")) else {
        return Err("must be an absolute path or start with `~/`.");
    };
    check_segments(rest.split('/'))
}

fn check_windows(entry: &str) -> Result<(), &'static str> {
    let rest = if let Some(variable) = entry.strip_prefix('%') {
        let Some((name, rest)) = variable.split_once('%') else {
            return Err("must close its environment variable with `%`.");
        };
        if name.is_empty()
            || !name
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | '(' | ')'))
        {
            return Err("must name an environment variable of letters, digits, `_`, `(` and `)`.");
        }
        rest
    } else {
        let mut chars = entry.chars();
        match (chars.next(), chars.next()) {
            (Some(drive), Some(':')) if drive.is_ascii_alphabetic() => &entry[2..],
            _ => return Err("must start with a drive (`C:/`) or an environment variable (`%ProgramFiles%/`)."),
        }
    };
    let Some(rest) = rest.strip_prefix(['/', '\\']) else {
        return Err("must continue with `/` or `\\` after its drive or variable.");
    };
    check_segments(rest.split(['/', '\\']))
}

/// One external program run by `effect.exec` or a template's `post` step.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub struct ExecResult {
    /// The tool's name as the manifest declares it.
    pub tool: String,
    /// The absolute path that ran, from the tool table.
    pub path: PathBuf,
    /// The arguments as given, without a shell.
    pub args: Vec<String>,
    pub status: ExecStatus,
    /// The end of its standard output, at most [`EXEC_TAIL_LIMIT`] bytes, lossy UTF-8.
    pub stdout_tail: String,
    /// The end of its standard error, likewise.
    pub stderr_tail: String,
}

impl ExecResult {
    /// It exited with status 0; anything else stops the steps after it.
    pub const fn succeeded(&self) -> bool {
        matches!(self.status, ExecStatus::Exited { code: 0 })
    }
}

/// How a run ended.
#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(tag = "state", rename_all = "snake_case")]
pub enum ExecStatus {
    /// It exited by itself with `code`.
    Exited { code: i32 },
    /// The system ended it (a signal) without an exit code.
    Killed,
    /// It ran past the time limit and was stopped with its process tree.
    TimedOut,
    /// The call was cancelled while it ran; it was stopped with its process tree.
    Cancelled,
}

#[cfg(test)]
mod tests {
    use super::Detect;

    fn detect(macos: &[&str], windows: &[&str], path: &[&str]) -> Detect {
        let owned = |entries: &[&str]| entries.iter().map(|&entry| entry.to_owned()).collect();
        Detect {
            registry: Vec::new(),
            macos: owned(macos),
            windows: owned(windows),
            path: owned(path),
        }
    }

    #[test]
    fn plain_path_hints_pass() {
        let hints = detect(
            &[
                "/Applications/Godot*.app/Contents/MacOS/Godot",
                "~/Applications/Godot?.app",
            ],
            &[
                "%ProgramFiles%/Godot*/Godot*.exe",
                "%LOCALAPPDATA%\\Godot*\\Godot*.exe",
                "%ProgramFiles(x86)%/Godot/godot.exe",
                "C:/Program Files (x86)/Godot/godot.exe",
            ],
            &["godot", "godot4", "godot.exe"],
        );
        assert_eq!(hints.check(), Ok(()));
    }

    #[test]
    fn shell_syntax_and_escapes_are_refused() {
        for (hints, fragment) in [
            (detect(&["Applications/Godot"], &[], &[]), "absolute path"),
            (detect(&["/Applications/$HOME/Godot"], &[], &[]), "may hold only"),
            (detect(&["/Applications/`id`"], &[], &[]), "may hold only"),
            (detect(&["/a;rm -rf /"], &[], &[]), "may hold only"),
            (detect(&["/Applications/../etc/x"], &[], &[]), "`..`"),
            (detect(&[], &["Godot/godot.exe"], &[]), "start with a drive"),
            (detect(&[], &["%ProgramFiles/godot.exe"], &[]), "close its environment"),
            (detect(&[], &["%A B%/godot.exe"], &[]), "environment variable of"),
            (detect(&[], &["%ProgramFiles%godot.exe"], &[]), "continue with"),
            (detect(&[], &["C:/a|b.exe"], &[]), "may hold only"),
            (detect(&[], &[], &["god ot"]), "program name"),
            (detect(&[], &[], &["bin/godot"]), "program name"),
            (detect(&[], &[], &[".godot"]), "program name"),
        ] {
            let error = hints.check().unwrap_err();
            assert!(error.contains(fragment), "{hints:?}: {error}");
        }
    }
}
