//! Plugin-owned version queries and parsing. The host owns execution policy.
use crate::is_name;
use regex::RegexBuilder;
use schemars::JsonSchema;
use semver::VersionReq;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(rename_all = "snake_case")]
pub enum VersionStream {
    #[default]
    Stdout,
    Stderr,
}

#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(tag = "kind", rename_all = "snake_case", deny_unknown_fields)]
pub enum VersionExtract {
    /// The entire trimmed output is a semantic version (two components imply patch zero).
    Text,
    /// A named `version` capture. Preserve prerelease suffixes, or reject prereleases explicitly.
    Regex { pattern: String },
    /// An RFC 6901 pointer to a string in the command's JSON output.
    JsonPointer { pointer: String },
}

#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct VersionCheck {
    pub args: Vec<String>,
    #[serde(default)]
    pub stream: VersionStream,
    pub extract: VersionExtract,
    pub require: String,
    // Version eligibility only, not proof that a service or feature runs successfully.
    #[serde(default)]
    pub features: BTreeMap<String, String>,
}

impl VersionCheck {
    pub fn check(&self) -> Result<(), String> {
        // A deliberately small positive vocabulary, not a blacklist of dangerous shell syntax.
        // Even these flags require the person's explicit approval: flags cannot make native code safe.
        if self.args.is_empty()
            || self.args.len() > 4
            || !self
                .args
                .iter()
                .any(|s| matches!(s.as_str(), "--version" | "-version" | "-V" | "version"))
            || self.args.iter().any(|s| {
                !matches!(
                    s.as_str(),
                    "--version" | "-version" | "-V" | "version" | "--json" | "--format=json" | "--headless"
                )
            })
        {
            return Err("version.args allows only a version query (--version, -version, -V or version) with --json, --format=json or --headless; scripts, projects and other operations are not checks".into());
        }
        if self.require.len() > 256 || VersionReq::parse(&self.require).is_err() {
            return Err("version.require must be a semantic version range".into());
        }
        if self.features.len() > 16
            || self
                .features
                .iter()
                .any(|(name, range)| !is_name(name) || range.len() > 256 || VersionReq::parse(range).is_err())
        {
            return Err("version.features must contain at most 16 named semantic version ranges".into());
        }
        match &self.extract {
            VersionExtract::Regex { pattern } => {
                if pattern.len() > 2048 {
                    return Err("version regex is too large".into());
                }
                let regex = RegexBuilder::new(pattern)
                    .size_limit(256 * 1024)
                    .build()
                    .map_err(|e| format!("invalid version regex: {e}"))?;
                if !regex.capture_names().any(|name| name == Some("version")) {
                    return Err("version regex requires a named `version` capture".into());
                }
            }
            VersionExtract::JsonPointer { pointer }
                if pointer.len() > 256 || (!pointer.is_empty() && !pointer.starts_with('/')) =>
            {
                return Err("version JSON pointer must be empty or start with /".into());
            }
            _ => {}
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn query(args: &[&str]) -> VersionCheck {
        VersionCheck {
            args: args.iter().map(|s| (*s).into()).collect(),
            stream: VersionStream::Stdout,
            extract: VersionExtract::Text,
            require: ">=4.3.0, <5.0.0".into(),
            features: BTreeMap::new(),
        }
    }
    #[test]
    fn queries_cannot_be_used_as_script_or_install_commands() {
        assert!(query(&["--headless", "--version"]).check().is_ok());
        assert!(query(&["version", "--json"]).check().is_ok());
        assert!(query(&["-version"]).check().is_ok());
        for args in [
            &["--version", "--script", "payload.gd"][..],
            &["-c", "echo 4.3.0"],
            &["install"],
            &["-version", "-executeMethod", "Payload.Run"],
            &["-version", "-projectPath", "/tmp/project"],
            &["--version", ";rm"],
            &["--version", "--path=/tmp/project"],
            &["--headless"],
        ] {
            assert!(query(args).check().is_err(), "{args:?}");
        }
    }
    #[test]
    fn parser_and_ranges_are_validated_before_installation() {
        let mut check = query(&["--version"]);
        check.extract = VersionExtract::Regex {
            pattern: "([0-9.]+)".into(),
        };
        assert!(check.check().is_err());
        check.extract = VersionExtract::Regex {
            pattern: r"(?P<version>\d+\.\d+)".into(),
        };
        assert!(check.check().is_ok());
        check.require = "four or newer".into();
        assert!(check.check().is_err());
    }
}
