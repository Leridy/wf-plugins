//! Process plugins (M5b): a native program the runtime starts and talks to
//! as a stdio MCP server. The manifest's `[process]` names one binary per
//! [`Target`]; the package carries the server's tools as a signed snapshot
//! ([`McpSnapshot`], `mcp-tools.json`) taken when it was packed, so listings,
//! `describe`, confirmations and the catalog show every tool and its risk
//! without starting native code. The process is not sandboxed: a manifest
//! with `[process]` asks for no permissions, settings or programs, since
//! none of those boundaries would hold for it.
use crate::{Capability, Manifest, ManifestError, Risk, is_name, manifest::inside, package::hex};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fmt::Write,
};

/// The signed tool snapshot inside a process plugin's package.
pub const MCP_TOOLS_ENTRY: &str = "mcp-tools.json";
pub const MCP_TOOLS_SCHEMA: &str = "wf-mcp-tools/1";
/// Most bytes of `mcp-tools.json`.
pub const MCP_TOOLS_LIMIT: usize = 1 << 20;
/// Most tools one snapshot may hold.
pub const MCP_TOOL_COUNT: usize = 64;
/// Most bytes of one tool's input or output schema, as compact JSON.
pub const MCP_SCHEMA_LIMIT: usize = 64 << 10;
/// Most bytes of a tool's summary and of its `when`.
pub const MCP_SUMMARY_LIMIT: usize = 200;
pub const MCP_WHEN_LIMIT: usize = 2000;
/// The default and largest `call_timeout`, in seconds.
pub const CALL_TIMEOUT: u32 = 300;
pub const CALL_TIMEOUT_LIMIT: u32 = 1800;
/// Most `args` entries, and most bytes of one.
const ARG_COUNT: usize = 32;
const ARG_LIMIT: usize = 1 << 10;
/// Deepest a tool's schema may nest.
const SCHEMA_DEPTH: usize = 32;

/// `[process]`: how the runtime starts the plugin's program.
#[derive(Clone, Debug, Deserialize, Serialize, JsonSchema, Eq, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct Process {
    /// The protocol the program speaks; only `mcp-stdio`.
    pub kind: ProcessKind,
    /// One program per target, at least one: `bin/<target>/…` inside the
    /// plugin; a `windows-x64` one ends in `.exe`.
    pub binary: BTreeMap<Target, String>,
    /// Passed to the program as they are, without a shell; at most 32, each
    /// at most 1 KiB.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub args: Vec<String>,
    /// Seconds one tool call may take, 1 to 1800; 300 when left out.
    #[serde(default = "default_call_timeout")]
    pub call_timeout: u32,
}

const fn default_call_timeout() -> u32 {
    CALL_TIMEOUT
}

impl Process {
    /// The one target a package's manifest names: `pack` keeps only the
    /// program it packs; `None` while it names several.
    pub fn packed_target(&self) -> Option<Target> {
        match self.binary.keys().collect::<Vec<_>>().as_slice() {
            [target] => Some(**target),
            _ => None,
        }
    }

    /// The program for `target`, relative to the plugin directory.
    pub fn binary(&self, target: Target) -> Option<&str> {
        self.binary.get(&target).map(String::as_str)
    }
}

#[derive(Clone, Copy, Debug, Deserialize, Serialize, JsonSchema, Eq, PartialEq)]
#[serde(rename_all = "kebab-case")]
pub enum ProcessKind {
    /// The Model Context Protocol over standard input and output, one JSON
    /// message per line.
    McpStdio,
}

/// A platform a process plugin ships a program for: the client's release
/// targets, named as its release files are.
#[derive(Clone, Copy, Debug, Deserialize, Serialize, JsonSchema, Eq, PartialEq, Ord, PartialOrd, Hash)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "PluginTarget"))]
#[serde(rename_all = "kebab-case")]
pub enum Target {
    MacosArm64,
    WindowsX64,
}

impl Target {
    pub const ALL: [Self; 2] = [Self::MacosArm64, Self::WindowsX64];

    /// The target this build runs on; `None` where process plugins are not
    /// supported.
    pub const fn host() -> Option<Self> {
        if cfg!(all(target_os = "macos", target_arch = "aarch64")) {
            Some(Self::MacosArm64)
        } else if cfg!(all(target_os = "windows", target_arch = "x86_64")) {
            Some(Self::WindowsX64)
        } else {
            None
        }
    }

    pub const fn id(self) -> &'static str {
        match self {
            Self::MacosArm64 => "macos-arm64",
            Self::WindowsX64 => "windows-x64",
        }
    }

    pub fn parse(id: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|target| target.id() == id)
    }
}

/// The checks of `[process]` that `Manifest::check` runs; the one entry point.
pub fn check(manifest: &Manifest) -> Result<(), ManifestError> {
    let Some(process) = &manifest.process else {
        return Ok(());
    };
    let error = |message: String| Err(ManifestError(message));
    if manifest.plugin.component.is_some() {
        return error(
            "plugin.component and [process] exclude each other: a plugin is a component or a program.".into(),
        );
    }
    let unused = [
        (!manifest.contributes.is_empty(), "contributes"),
        (!manifest.config.is_empty(), "config"),
        (!manifest.tools.is_empty(), "tools"),
        (!manifest.permissions.is_empty(), "permissions"),
    ];
    if let Some((_, key)) = unused.into_iter().find(|(set, _)| *set) {
        return error(format!(
            "{key} cannot be used with [process]: the program runs outside the sandbox, so no grant would bound it."
        ));
    }
    if process.binary.is_empty() {
        return error("process.binary needs a program for at least one target (`macos-arm64`, `windows-x64`).".into());
    }
    for (target, path) in &process.binary {
        let id = target.id();
        let directory = format!("bin/{id}/");
        if !inside(path) || path.contains('\\') || !path.starts_with(&directory) || path.len() == directory.len() {
            return error(format!(
                "process.binary.{id} `{path}` must be a `/`-separated path inside the plugin under `{directory}`."
            ));
        }
        if *target == Target::WindowsX64 && !path.to_ascii_lowercase().ends_with(".exe") {
            return error(format!("process.binary.{id} `{path}` must end in `.exe`."));
        }
    }
    if process.args.len() > ARG_COUNT {
        return error(format!("process.args holds at most {ARG_COUNT} entries."));
    }
    if let Some(arg) = process
        .args
        .iter()
        .find(|arg| arg.len() > ARG_LIMIT || arg.contains('\0'))
    {
        return error(format!(
            "process.args `{}` must be at most 1 KiB, without NUL.",
            arg.chars().take(40).collect::<String>()
        ));
    }
    if !(1..=CALL_TIMEOUT_LIMIT).contains(&process.call_timeout) {
        return error(format!(
            "process.call_timeout must be between 1 and {CALL_TIMEOUT_LIMIT} seconds."
        ));
    }
    Ok(())
}

/// `mcp-tools.json`: the server's tools as `pack` listed them, signed with
/// the package. The runtime still lists the tools each time it starts the
/// program, only to compare: a tool whose name or [`McpTool::sha256`]
/// differs is refused, one the snapshot lacks is ignored.
#[derive(Clone, Debug, Deserialize, Serialize, Eq, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct McpSnapshot {
    /// [`MCP_TOOLS_SCHEMA`].
    pub schema: String,
    /// The MCP protocol version the server answered with.
    pub protocol: String,
    pub server: ServerName,
    pub tools: Vec<McpTool>,
}

impl McpSnapshot {
    pub fn tool(&self, op: &str) -> Option<&McpTool> {
        self.tools.iter().find(|tool| tool.op == op)
    }

    /// One capability per tool, as `describe` and the catalog list them.
    pub fn capabilities(&self) -> Vec<Capability> {
        self.tools.iter().map(McpTool::capability).collect()
    }

    /// The structural rules `pack` and every install check: the schema, 1 to
    /// 64 tools, each op a name (not `help`) and each op and tool once, every
    /// digest the tool's own, object input schemas, and each schema within
    /// its size and nesting limits. Whether an input schema makes flags is
    /// the runtime's check (`plugin_commands::input::check`).
    pub fn check(&self) -> Result<(), String> {
        if self.schema != MCP_TOOLS_SCHEMA {
            return Err(format!("{MCP_TOOLS_ENTRY} must have the schema {MCP_TOOLS_SCHEMA}."));
        }
        if self.tools.is_empty() || self.tools.len() > MCP_TOOL_COUNT {
            return Err(format!("the server must list 1 to {MCP_TOOL_COUNT} tools."));
        }
        let mut ops = BTreeSet::new();
        let mut names = BTreeSet::new();
        for tool in &self.tools {
            let named = format!("tool `{}` (op `{}`)", tool.tool, tool.op);
            if !is_name(&tool.op) || tool.op == "help" {
                return Err(format!(
                    "{named} needs an op of lowercase words joined by `-`, not `help`."
                ));
            }
            if !ops.insert(tool.op.as_str()) || !names.insert(tool.tool.as_str()) {
                return Err(format!("{named} is listed twice, or two tools make the same op."));
            }
            if !tool.sealed() {
                return Err(format!("{named} does not match its sha256."));
            }
            if tool.input.get("type").and_then(Value::as_str) != Some("object") {
                return Err(format!("{named} needs an object input schema."));
            }
            for (schema, what) in [(Some(&tool.input), "input"), (tool.output.as_ref(), "output")] {
                let Some(schema) = schema else { continue };
                if schema.to_string().len() > MCP_SCHEMA_LIMIT || depth(schema) > SCHEMA_DEPTH {
                    return Err(format!(
                        "{named} has an {what} schema over 64 KiB or nested deeper than {SCHEMA_DEPTH}."
                    ));
                }
            }
        }
        Ok(())
    }
}

/// How deep a value nests: a scalar is 0, `{}` and `[]` are 1.
fn depth(value: &Value) -> usize {
    match value {
        Value::Object(map) => 1 + map.values().map(depth).max().unwrap_or(0),
        Value::Array(items) => 1 + items.iter().map(depth).max().unwrap_or(0),
        _ => 0,
    }
}

/// The server as it named itself (`serverInfo`; plugin text).
#[derive(Clone, Debug, Deserialize, Serialize, Eq, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct ServerName {
    pub name: String,
    pub version: String,
}

/// One MCP tool as a capability `<plugin> <op>`.
#[derive(Clone, Debug, Deserialize, Serialize, Eq, PartialEq)]
#[serde(deny_unknown_fields)]
pub struct McpTool {
    /// The capability name, from the tool's: kebab-case, not `help`.
    pub op: String,
    /// The tool's MCP name, which calls use.
    pub tool: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub title: Option<String>,
    #[serde(default)]
    pub description: String,
    /// The tool's `inputSchema` (an object schema).
    pub input: Value,
    /// Its `outputSchema`, when it declares one.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub output: Option<Value>,
    pub hints: ToolHints,
    /// [`McpTool::digest`] of the tool: what the runtime compares with the
    /// running server's `tools/list`.
    pub sha256: String,
}

impl McpTool {
    /// The canonical digest of what binds a call: the tool's name, its input
    /// and output schemas and its hints (object keys sorted, compact).
    pub fn digest(tool: &str, input: &Value, output: Option<&Value>, hints: ToolHints) -> String {
        let mut text = String::new();
        canonical(&Value::String(tool.to_owned()), &mut text);
        text.push('\n');
        canonical(input, &mut text);
        text.push('\n');
        canonical(output.unwrap_or(&Value::Null), &mut text);
        let _ = write!(
            text,
            "\n{}{}{}{}",
            u8::from(hints.read_only),
            u8::from(hints.destructive),
            u8::from(hints.idempotent),
            u8::from(hints.open_world)
        );
        hex(&Sha256::digest(text.as_bytes()))
    }

    /// Whether `sha256` is this tool's own digest.
    pub fn sealed(&self) -> bool {
        self.sha256 == Self::digest(&self.tool, &self.input, self.output.as_ref(), self.hints)
    }

    /// Only a tool its signed snapshot marks read-only is `Read`; every other
    /// one is high-risk: the program changes what it likes, unseen.
    pub const fn risk(&self) -> Risk {
        if self.hints.read_only {
            Risk::Read
        } else {
            Risk::HighRisk
        }
    }

    /// The capability the tool is: its title, else its description's first
    /// line, as the summary, and the rest of the description as `when`.
    pub fn capability(&self) -> Capability {
        let description = self.description.trim();
        let (first, rest) = description.split_once('\n').unwrap_or((description, ""));
        let summary = match self.title.as_deref().map(str::trim) {
            Some(title) if !title.is_empty() => title,
            _ => first,
        };
        let when = if self.title.as_deref().is_some_and(|t| !t.trim().is_empty()) {
            description
        } else {
            rest.trim()
        };
        Capability {
            op: self.op.clone(),
            summary: clipped(summary, MCP_SUMMARY_LIMIT),
            when: clipped(when, MCP_WHEN_LIMIT),
            risk: self.risk(),
            input: self.input.clone(),
            output: self.output.clone(),
            examples: Vec::new(),
            implements: None,
        }
    }
}

/// A tool's annotations as the runtime trusts them: only from the signed
/// snapshot. Absent hints take the MCP defaults ([`ToolHints::default`]).
#[derive(Clone, Copy, Debug, Deserialize, Serialize, Eq, PartialEq, Hash)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(rename_all = "camelCase")]
#[expect(clippy::struct_excessive_bools, reason = "the four independent MCP tool annotations")]
pub struct ToolHints {
    /// It changes nothing (`readOnlyHint`).
    pub read_only: bool,
    /// It may delete or overwrite (`destructiveHint`); shown, does not change the risk.
    pub destructive: bool,
    /// Repeating it changes nothing more (`idempotentHint`).
    pub idempotent: bool,
    /// It reaches beyond the machine (`openWorldHint`); shown, does not change the risk.
    pub open_world: bool,
}

impl Default for ToolHints {
    /// The MCP specification's defaults for a tool without annotations.
    fn default() -> Self {
        Self {
            read_only: false,
            destructive: true,
            idempotent: false,
            open_world: true,
        }
    }
}

impl ToolHints {
    /// The hints of a tool's annotations, each absent one at its default.
    pub fn of(
        read_only: Option<bool>,
        destructive: Option<bool>,
        idempotent: Option<bool>,
        open_world: Option<bool>,
    ) -> Self {
        let default = Self::default();
        Self {
            read_only: read_only.unwrap_or(default.read_only),
            destructive: destructive.unwrap_or(default.destructive),
            idempotent: idempotent.unwrap_or(default.idempotent),
            open_world: open_world.unwrap_or(default.open_world),
        }
    }
}

/// `text` without control characters, at most `limit` bytes on a character boundary.
fn clipped(text: &str, limit: usize) -> String {
    let mut clean = String::with_capacity(text.len().min(limit));
    for c in text.chars() {
        let c = if c.is_control() { ' ' } else { c };
        if clean.len() + c.len_utf8() > limit {
            break;
        }
        clean.push(c);
    }
    clean
}

/// Compact JSON with every object's keys sorted, so a digest does not depend
/// on the order a server wrote them in.
fn canonical(value: &Value, out: &mut String) {
    match value {
        Value::Object(map) => {
            out.push('{');
            let mut keys: Vec<&String> = map.keys().collect();
            keys.sort();
            for (index, key) in keys.into_iter().enumerate() {
                if index > 0 {
                    out.push(',');
                }
                canonical(&Value::String(key.clone()), out);
                out.push(':');
                canonical(&map[key.as_str()], out);
            }
            out.push('}');
        }
        Value::Array(items) => {
            out.push('[');
            for (index, item) in items.iter().enumerate() {
                if index > 0 {
                    out.push(',');
                }
                canonical(item, out);
            }
            out.push(']');
        }
        scalar => out.push_str(&scalar.to_string()),
    }
}

/// An empty object schema, for a tool that takes no input.
pub fn empty_input() -> Value {
    Value::Object(Map::from_iter([("type".to_owned(), Value::String("object".into()))]))
}

#[cfg(test)]
mod tests {
    use super::{MCP_TOOLS_SCHEMA, McpSnapshot, McpTool, ServerName, Target, ToolHints, empty_input};
    use crate::{Manifest, Risk};
    use serde_json::{Map, Value};

    const PROCESS: &str = "[process]\nkind = \"mcp-stdio\"\nbinary.macos-arm64 = \"bin/macos-arm64/notes\"\nbinary.windows-x64 = \"bin/windows-x64/notes.exe\"\n";

    fn manifest(extra: &str) -> String {
        format!(
            "[plugin]\nname = \"notes\"\nversion = \"0.1.0\"\nsummary = \"s\"\napi = \"{}\"\n{extra}",
            crate::API
        )
    }

    #[test]
    fn a_process_plugin_names_a_program_per_target_and_asks_for_nothing() {
        let parsed = Manifest::parse(&manifest(PROCESS)).unwrap();
        let process = parsed.process.unwrap();
        assert_eq!(process.call_timeout, super::CALL_TIMEOUT);
        assert_eq!(process.binary(Target::MacosArm64), Some("bin/macos-arm64/notes"));
        for (extra, fragment) in [
            (
                format!("{PROCESS}[permissions]\nread = [\"**\"]\n"),
                "permissions cannot",
            ),
            (
                format!("{PROCESS}[[contributes]]\nprotocol = \"wf.template/1\"\ndata = \"t/a\"\n"),
                "contributes cannot",
            ),
            (
                PROCESS.replace("[process]", "[process]\ncall_timeout = 0"),
                "call_timeout",
            ),
            (
                PROCESS.replace("bin/windows-x64/notes.exe", "bin/windows-x64/notes"),
                "`.exe`",
            ),
            (
                PROCESS.replace("bin/macos-arm64/notes", "bin/windows-x64/notes"),
                "under `bin/macos-arm64/`",
            ),
            (
                PROCESS.replace("bin/macos-arm64/notes", "bin/macos-arm64/../../x"),
                "inside the plugin",
            ),
            (
                "[process]\nkind = \"mcp-stdio\"\nbinary = {}\n".to_owned(),
                "at least one target",
            ),
            (PROCESS.replace("mcp-stdio", "mcp-http"), "unknown variant"),
            (PROCESS.replace("macos-arm64 =", "linux-x64 ="), "unknown variant"),
        ] {
            let error = Manifest::parse(&manifest(&extra)).unwrap_err().to_string();
            assert!(error.contains(fragment), "{extra}: {error}");
        }
        let both = manifest(PROCESS).replace("[plugin]\n", "[plugin]\ncomponent = \"a.wasm\"\n");
        let error = Manifest::parse(&both).unwrap_err().to_string();
        assert!(error.contains("exclude each other"), "{error}");
    }

    #[test]
    fn the_digest_ignores_key_order_and_covers_schemas_and_hints() {
        let schema = |keys: &[(&str, &str)]| {
            Value::Object(Map::from_iter(
                keys.iter()
                    .map(|(key, value)| ((*key).to_owned(), Value::String((*value).to_owned()))),
            ))
        };
        let hints = ToolHints::default();
        let ab = McpTool::digest("add", &schema(&[("a", "1"), ("b", "2")]), None, hints);
        let ba = McpTool::digest("add", &schema(&[("b", "2"), ("a", "1")]), None, hints);
        assert_eq!(ab, ba);
        let read_only = ToolHints {
            read_only: true,
            ..hints
        };
        for other in [
            McpTool::digest("add2", &schema(&[("a", "1"), ("b", "2")]), None, hints),
            McpTool::digest("add", &schema(&[("a", "1")]), None, hints),
            McpTool::digest("add", &schema(&[("a", "1"), ("b", "2")]), Some(&empty_input()), hints),
            McpTool::digest("add", &schema(&[("a", "1"), ("b", "2")]), None, read_only),
        ] {
            assert_ne!(ab, other);
        }
    }

    #[test]
    fn only_a_read_only_tool_reads_and_its_text_is_clipped() {
        let mut tool = McpTool {
            op: "find-todos".into(),
            tool: "find_todos".into(),
            title: None,
            description: "Find TODOs\u{7}\nScans text files for TODO and FIXME.".into(),
            input: empty_input(),
            output: None,
            hints: ToolHints::of(Some(true), None, None, Some(false)),
            sha256: String::new(),
        };
        tool.sha256 = McpTool::digest(&tool.tool, &tool.input, None, tool.hints);
        assert!(tool.sealed());
        let capability = tool.capability();
        assert_eq!(capability.risk, Risk::Read);
        assert_eq!(capability.summary, "Find TODOs ");
        assert_eq!(capability.when, "Scans text files for TODO and FIXME.");
        tool.hints = ToolHints::default();
        assert!(!tool.sealed());
        assert_eq!(tool.risk(), Risk::HighRisk);
        tool.title = Some("é".repeat(150));
        assert_eq!(tool.capability().summary.len(), 200);
    }

    fn tool(op: &str, name: &str) -> McpTool {
        let hints = ToolHints::default();
        McpTool {
            op: op.into(),
            tool: name.into(),
            title: None,
            description: String::new(),
            input: empty_input(),
            output: None,
            hints,
            sha256: McpTool::digest(name, &empty_input(), None, hints),
        }
    }

    #[test]
    fn a_snapshot_lists_sealed_named_tools_once() {
        let snapshot = |tools: Vec<McpTool>| McpSnapshot {
            schema: MCP_TOOLS_SCHEMA.into(),
            protocol: "2025-06-18".into(),
            server: ServerName {
                name: "notes".into(),
                version: "0.1.0".into(),
            },
            tools,
        };
        assert_eq!(snapshot(vec![tool("add-note", "add_note")]).check(), Ok(()));
        let mut forged = tool("add-note", "add_note");
        forged.hints.read_only = true;
        let mut scalar = tool("add-note", "add_note");
        scalar.input = Value::String("x".into());
        scalar.sha256 = McpTool::digest("add_note", &scalar.input, None, scalar.hints);
        for (tools, fragment) in [
            (Vec::new(), "1 to 64"),
            (vec![tool("help", "help")], "not `help`"),
            (vec![tool("Add", "Add")], "not `help`"),
            (vec![tool("a", "a"), tool("a", "b")], "twice"),
            (vec![forged], "sha256"),
            (vec![scalar], "object input"),
        ] {
            let error = snapshot(tools).check().unwrap_err();
            assert!(error.contains(fragment), "{error}");
        }
    }
}
