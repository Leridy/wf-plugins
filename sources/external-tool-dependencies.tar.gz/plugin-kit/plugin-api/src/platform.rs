//! The platform's read methods a plugin reaches through `host.call` (API
//! 0.1.1) once the user granted `platform = "read"`: their names and the
//! input and output each takes and returns as UTF-8 JSON. They read the local
//! mirror at the project root only: no network and no credential.
use schemars::{JsonSchema, Schema, schema_for};
use serde::{Deserialize, Serialize};

/// A platform method by its `call` name.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Method {
    MirrorNodes,
    MirrorNode,
    MirrorLocks,
}

impl Method {
    pub const ALL: [Self; 3] = [Self::MirrorNodes, Self::MirrorNode, Self::MirrorLocks];

    pub const fn name(self) -> &'static str {
        match self {
            Self::MirrorNodes => "wf.mirror.nodes",
            Self::MirrorNode => "wf.mirror.node",
            Self::MirrorLocks => "wf.mirror.locks",
        }
    }

    pub fn parse(name: &str) -> Option<Self> {
        Self::ALL.into_iter().find(|method| method.name() == name)
    }

    pub const fn summary(self) -> &'static str {
        match self {
            Self::MirrorNodes => "List mirrored nodes, filtered by path glob and node type.",
            Self::MirrorNode => "One node by address (#N, path or wf://id): its card summary and files.",
            Self::MirrorLocks => "The nodes an export directory locked, and whether HEAD moved since.",
        }
    }

    pub fn input_schema(self) -> Schema {
        match self {
            Self::MirrorNodes => schema_for!(NodesInput),
            Self::MirrorNode => schema_for!(NodeInput),
            Self::MirrorLocks => schema_for!(LocksInput),
        }
    }

    pub fn output_schema(self) -> Schema {
        match self {
            Self::MirrorNodes => schema_for!(NodesOutput),
            Self::MirrorNode => schema_for!(NodeOutput),
            Self::MirrorLocks => schema_for!(LocksOutput),
        }
    }
}

/// Every method with its summary and schemas, as one pretty-printed JSON
/// document for authors who do not build against this crate.
pub fn methods_schema() -> String {
    #[derive(Serialize)]
    struct Entry {
        method: &'static str,
        summary: &'static str,
        input: Schema,
        output: Schema,
    }
    let entries: Vec<Entry> = Method::ALL
        .into_iter()
        .map(|method| Entry {
            method: method.name(),
            summary: method.summary(),
            input: method.input_schema(),
            output: method.output_schema(),
        })
        .collect();
    let mut text = serde_json::to_string_pretty(&entries).expect("schemas serialize");
    text.push('\n');
    text
}

/// `wf.mirror.nodes`: every current node when no filter is given.
#[derive(Clone, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct NodesInput {
    /// A glob over node paths: `*` stays within a segment, `**` crosses them.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub path: Option<String>,
    /// Only nodes of this type (`image`, `frame_animation`, …; `directory` for directories).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub node_type: Option<String>,
    /// Also list nodes the fetched history deleted, as `state: deleted`.
    #[serde(default)]
    pub deleted: bool,
}

#[derive(Clone, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct NodesOutput {
    /// By path, then number.
    pub nodes: Vec<NodeRow>,
}

/// A node as listings show it.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "MirrorNodeRow"))]
pub struct NodeRow {
    /// The node's stable UUID; `wf://<id>` addresses it.
    pub id: String,
    /// The short number; `#<number>` addresses it.
    #[cfg_attr(feature = "ts", ts(type = "number"))]
    pub number: u64,
    /// The `/`-separated display path (user data).
    pub path: String,
    /// The node type, or `directory`.
    pub node_type: String,
    /// The current version; absent for a directory.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    #[cfg_attr(feature = "ts", ts(type = "number | null"))]
    pub version: Option<u64>,
    pub state: NodeState,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "MirrorNodeState"))]
#[serde(rename_all = "snake_case")]
pub enum NodeState {
    /// Shared and published at HEAD.
    Current,
    /// At HEAD, but its latest version is a draft.
    Draft,
    /// Listed at HEAD but no longer shared: its files are unavailable.
    Withdrawn,
    /// Deleted in the fetched history; `version` is the last one it had.
    Deleted,
}

/// `wf.mirror.node`.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct NodeInput {
    /// `#<number>`, a node path or `wf://<id>`; the current version only (no `@revision` or `:part`).
    pub address: String,
}

/// One node's card summary and files.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct NodeOutput {
    pub node: NodeRow,
    /// One line saying what the node holds (user data); empty when unavailable.
    pub summary: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    /// How to use the node in a game (user data); empty when unavailable.
    pub usage: String,
    pub tags: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub author: Option<String>,
    /// When the current version was made (RFC 3339).
    pub updated: String,
    pub parts: Vec<PartRow>,
    pub files: Vec<FileRow>,
    /// Card facts the mirror does not hold for this node.
    pub unavailable: Vec<String>,
}

#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct PartRow {
    pub path: String,
    pub count: u64,
}

/// A file of the current version.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct FileRow {
    /// Relative to the node (user data).
    pub path: String,
    pub role: String,
    pub purpose: String,
    pub content_type: String,
    pub bytes: u64,
    /// The content hash (sha256, hex).
    pub hash: String,
}

/// `wf.mirror.locks`.
#[derive(Clone, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct LocksInput {
    /// A project-relative export directory; the project's configured one when absent.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub directory: Option<String>,
}

#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct LocksOutput {
    /// The export directory read, project-relative.
    pub directory: String,
    /// The export lock file, project-relative: the plugin reads it, and points
    /// spans into it, by this path rather than by a name it assumes.
    pub lock: String,
    pub nodes: Vec<LockedRow>,
}

/// A node as the export lock recorded it.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct LockedRow {
    pub id: String,
    pub number: u64,
    /// The node path when exported (user data).
    pub path: String,
    /// The exported version.
    pub version: u64,
    /// The form exported.
    pub form: String,
    /// Exported files, relative to the export directory.
    pub files: Vec<String>,
    pub head: Head,
    /// The node's version at HEAD; absent when HEAD no longer has it.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub head_version: Option<u64>,
}

/// How HEAD relates to what was exported.
#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Head {
    /// HEAD has the exported version at the exported path.
    Current,
    /// HEAD has another version or path: exporting again would change files.
    Moved,
    /// HEAD no longer has the node.
    Removed,
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::Value;

    #[test]
    fn methods_round_trip_their_names_and_publish_strict_input_schemas() {
        for method in Method::ALL {
            assert_eq!(Method::parse(method.name()), Some(method));
            let input = serde_json::to_value(method.input_schema()).unwrap();
            assert_eq!(input["additionalProperties"], false, "{}", method.name());
            assert_eq!(input["type"], "object");
        }
        assert_eq!(Method::parse("wf.mirror"), None);
        let document: Value = serde_json::from_str(&methods_schema()).unwrap();
        let names: Vec<&str> = document
            .as_array()
            .unwrap()
            .iter()
            .map(|entry| entry["method"].as_str().unwrap())
            .collect();
        assert_eq!(names, ["wf.mirror.nodes", "wf.mirror.node", "wf.mirror.locks"]);
    }

    #[test]
    fn inputs_default_their_filters_and_refuse_unknown_keys() {
        assert_eq!(serde_json::from_str::<NodesInput>("{}").unwrap(), NodesInput::default());
        assert!(serde_json::from_str::<NodesInput>(r#"{"pth": "a/**"}"#).is_err());
        assert!(serde_json::from_str::<NodeInput>("{}").is_err());
        assert_eq!(serde_json::from_str::<LocksInput>("{}").unwrap(), LocksInput::default());
    }
}
