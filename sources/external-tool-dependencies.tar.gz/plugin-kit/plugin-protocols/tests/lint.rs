use plugin_protocols::lint::{LintInput, LintOutput, Severity};

#[test]
fn missing_fields_default_and_unknown_fields_are_ignored() {
    assert_eq!(serde_json::from_str::<LintInput>("{}").unwrap(), LintInput::default());
    let output: LintOutput = serde_json::from_str(
        r#"{"checked": ["a.gd"], "later": 1, "diagnostics": [
            {"rule": "r", "severity": "error", "message": "m", "file": "a.gd", "hint": "x"}]}"#,
    )
    .unwrap();
    assert_eq!(output.checked, ["a.gd"]);
    assert_eq!(output.diagnostics[0].severity, Severity::Error);
    assert!(output.diagnostics[0].span.is_none());
}

#[test]
fn severities_order_from_info_to_error() {
    assert!(Severity::Info < Severity::Warning && Severity::Warning < Severity::Error);
}
