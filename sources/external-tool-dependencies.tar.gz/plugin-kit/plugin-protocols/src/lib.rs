//! The official plugin protocols: the input and output types a capability that
//! `implements` one takes and returns, shared by its implementations and the
//! orchestration command that consumes it, and the data a plugin contributes
//! to one (`[[contributes]]`). A protocol id is `<name>/<major>`: within a
//! major version only optional fields are added, so outputs ignore unknown
//! fields and inputs default the ones they lack.
pub mod lint;
pub mod template;
pub mod ui;

/// The protocols by id; the manifest names them too, so `plugin-api` owns the enum.
pub use plugin_api::Protocol;
