//! `wf.template/1`: a project template a plugin contributes as data. Each
//! `[[contributes]]` entry of this protocol is a directory holding
//! [`TEMPLATE_FILE`] and a [`FILES_DIRECTORY`] tree; the runtime turns it into
//! the plugin's capability named after the directory, whose input is
//! [`DIR_PARAM`] plus the template's `params` and whose output is a
//! [`TemplateReport`]. No plugin code runs: the runtime writes the files,
//! replacing `{{key}}` in text files with the params, then runs the `post`
//! steps through `effect.exec`.
use std::collections::{BTreeMap, BTreeSet};
use std::fmt;
use std::path::PathBuf;

use plugin_api::platform::NodeRow;
use plugin_api::{ConfigField, ExecResult, NodeTypeKey, Protocol, check_fields, is_name};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

pub const PROTOCOL: &str = Protocol::Template.id();
/// The template's description inside its contributed directory.
pub const TEMPLATE_FILE: &str = "template.toml";
/// The file tree written into the target directory, beside [`TEMPLATE_FILE`].
pub const FILES_DIRECTORY: &str = "files";
/// The input every template capability takes besides its params: the target directory.
pub const DIR_PARAM: &str = "dir";

/// `template.toml`.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct Template {
    /// One line saying what the template creates; the capability's summary.
    pub summary: String,
    /// When an Agent should pick it; the capability's `when`. Defaults to a
    /// sentence built from `summary` and `engine`.
    #[serde(default, skip_serializing_if = "String::is_empty")]
    pub when: String,
    /// The engine and version the project is for (`godot@4.3`); shown and
    /// filtered on, never interpreted by the runtime.
    pub engine: String,
    /// What the person fills in, in the same shape as a plugin's settings;
    /// `{{key}}` in text files is replaced by the value.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub params: Vec<ConfigField>,
    /// Programs to run after the files are written, in order; any failure
    /// stops the rest.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub post: Vec<PostStep>,
    /// The places in the project a workspace asset can fill, by name.
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub assets: BTreeMap<String, AssetSlot>,
}

/// One program a template runs once its files are written.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct PostStep {
    /// A tool in the plugin's `permissions.exec`.
    pub tool: String,
    /// The arguments as given, without a shell; it runs in the target directory.
    #[serde(default)]
    pub args: Vec<String>,
    /// Why it runs, shown in the plan and the approval.
    pub reason: String,
}

/// A place in the generated project a workspace asset can fill.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(deny_unknown_fields)]
pub struct AssetSlot {
    /// The node type that fits: `frame_animation`, `tilemap`, `ui`.
    pub node_type: NodeTypeKey,
    /// The states or parts the slot needs (`idle`, `run`, `jump`).
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub states: Vec<String>,
    /// What the slot is for, in a sentence.
    pub summary: String,
}

/// What running a template returns: its capability's output.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub struct TemplateReport {
    /// The target directory, absolute.
    pub root: PathBuf,
    /// What the target directory held when the run was planned.
    pub target: TargetState,
    /// The files written (planned, on a dry run), relative to `root`, `/`-separated.
    pub files: Vec<String>,
    /// The `post` steps that ran, in order; a failed one is the last.
    pub post: Vec<ExecResult>,
    pub slots: Vec<SlotStatus>,
}

/// A template's target directory when its run was planned. `New` and
/// `Empty` make it the project, trusted for that run.
#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(rename_all = "camelCase")]
pub enum TargetState {
    /// It did not exist; the run creates it.
    New,
    Empty,
    /// It held files: it sits in the project found from it, and a file the
    /// template writes over one there is high-risk.
    NonEmpty,
}

/// A template capability's form, typed, as a client draws it instead of
/// reading the input's JSON Schema.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(rename_all = "camelCase")]
pub struct TemplateForm {
    /// The capability's op: the template's name.
    pub op: String,
    pub summary: String,
    /// The engine and version the project is for (`godot@4.7`).
    pub engine: String,
    /// The input key of the target directory: [`DIR_PARAM`].
    pub dir: String,
    /// Its params, in order; each is an input of its key.
    pub params: Vec<ConfigField>,
    /// The programs it runs after writing the files, in order.
    pub post: Vec<PostStep>,
    /// Its asset slots, by name.
    pub assets: BTreeMap<String, AssetSlot>,
}

impl TemplateForm {
    /// The form of `template`, contributed under the name `op`.
    pub fn of(op: &str, template: &Template) -> Self {
        Self {
            op: op.to_owned(),
            summary: template.summary.clone(),
            engine: template.engine.clone(),
            dir: DIR_PARAM.to_owned(),
            params: template.params.clone(),
            post: template.post.clone(),
            assets: template.assets.clone(),
        }
    }
}

/// An asset slot and the workspace nodes that could fill it.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
pub struct SlotStatus {
    pub name: String,
    pub slot: AssetSlot,
    /// The mirrored nodes of the slot's type; `None` when the target
    /// directory is not inside a mirror.
    pub matched: Option<Vec<NodeRow>>,
}

/// Why a template cannot be used, phrased for its author.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TemplateError(pub String);

impl fmt::Display for TemplateError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

impl Template {
    /// Reads `template.toml` and checks it against the plugin's `permissions.exec`.
    pub fn parse(text: &str, exec: &[String]) -> Result<Self, TemplateError> {
        let template: Self =
            toml::from_str(text).map_err(|error| TemplateError(format!("{TEMPLATE_FILE}: {}", error.message())))?;
        template.check(exec)?;
        Ok(template)
    }

    /// Whether the template is usable by a plugin that may run `exec`.
    pub fn check(&self, exec: &[String]) -> Result<(), TemplateError> {
        let fail = |message: String| Err(TemplateError(message));
        if !one_line(&self.summary) {
            return fail("summary must be one non-empty line.".into());
        }
        if !self.when.is_empty() && !one_line(&self.when) {
            return fail("when must be one line.".into());
        }
        if !one_line(&self.engine) {
            return fail("engine must be one non-empty line, such as `godot@4.3`.".into());
        }
        check_fields(&self.params).map_err(|error| {
            TemplateError(if error.key.is_empty() {
                format!("params {}.", error.message)
            } else {
                format!("params `{}` {}.", error.key, error.message)
            })
        })?;
        if self.params.iter().any(|field| field.key == DIR_PARAM) {
            return fail(format!("params `{DIR_PARAM}` is reserved for the target directory."));
        }
        for step in &self.post {
            if !exec.contains(&step.tool) {
                return fail(format!(
                    "post tool `{}` must be in the plugin's permissions.exec.",
                    step.tool
                ));
            }
            if !one_line(&step.reason) {
                return fail(format!("post `{}` needs a one-line reason.", step.tool));
            }
            if step.args.iter().any(|arg| arg.chars().any(char::is_control)) {
                return fail(format!(
                    "post `{}` arguments must not hold control characters.",
                    step.tool
                ));
            }
        }
        for (name, slot) in &self.assets {
            if !is_name(name) {
                return fail(format!("assets `{name}` must be lowercase words joined by `-`."));
            }
            let lowercase = |text: &str| {
                text.starts_with(|c: char| c.is_ascii_lowercase())
                    && text
                        .chars()
                        .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '_')
            };
            let mut states = BTreeSet::new();
            if let Some(state) = slot
                .states
                .iter()
                .find(|state| !lowercase(state) || !states.insert(*state))
            {
                return fail(format!(
                    "assets `{name}` state `{state}` must be lowercase letters, digits and `_`, listed once."
                ));
            }
            if !one_line(&slot.summary) {
                return fail(format!("assets `{name}` needs a one-line summary."));
            }
        }
        Ok(())
    }
}

fn one_line(text: &str) -> bool {
    !text.trim().is_empty() && !text.chars().any(char::is_control)
}

#[cfg(test)]
mod tests {
    use std::collections::BTreeMap;

    use plugin_api::{ConfigField, ConfigKind, ConfigValue, NodeTypeKey};

    use super::{AssetSlot, PostStep, Template};

    fn template() -> Template {
        Template {
            summary: "A 2D platformer".into(),
            when: String::new(),
            engine: "godot@4.3".into(),
            params: vec![ConfigField {
                key: "resolution".into(),
                label: "Resolution".into(),
                description: String::new(),
                kind: ConfigKind::Text {
                    multiline: false,
                    max_len: Some(16),
                },
                default: Some(ConfigValue::Text("320x180".into())),
            }],
            post: vec![PostStep {
                tool: "godot".into(),
                args: vec!["--headless".into(), "--import".into()],
                reason: "Import the project's resources".into(),
            }],
            assets: BTreeMap::from([(
                "player".to_owned(),
                AssetSlot {
                    node_type: NodeTypeKey::FrameAnimation,
                    states: vec!["idle".into(), "run".into(), "jump".into()],
                    summary: "The player character".into(),
                },
            )]),
        }
    }

    fn godot() -> Vec<String> {
        vec!["godot".to_owned()]
    }

    #[test]
    fn a_template_whose_steps_use_granted_tools_passes() {
        assert_eq!(template().check(&godot()), Ok(()));
    }

    /// A change that breaks a valid template, and a fragment of the error it causes.
    type Breakage = (fn(&mut Template), &'static str);

    #[test]
    fn undeclared_tools_reserved_params_and_bad_slots_are_refused() {
        let cases: [Breakage; 8] = [
            (|t| t.summary = " ".into(), "summary"),
            (|t| t.engine = "godot\n4".into(), "engine"),
            (|t| t.post[0].tool = "blender".into(), "permissions.exec"),
            (|t| t.post[0].reason = String::new(), "reason"),
            (|t| t.post[0].args.push("a\0b".into()), "control characters"),
            (|t| t.params[0].key = "dir".into(), "reserved"),
            (
                |t| t.params[0].default = Some(ConfigValue::Bool(true)),
                "params `resolution`",
            ),
            (
                |t| t.assets.get_mut("player").unwrap().states.push("idle".into()),
                "listed once",
            ),
        ];
        for (change, fragment) in cases {
            let mut broken = template();
            change(&mut broken);
            let error = broken.check(&godot()).unwrap_err().to_string();
            assert!(error.contains(fragment), "{fragment}: {error}");
        }
        let mut renamed = template();
        renamed.assets = BTreeMap::from([("Player".to_owned(), template().assets["player"].clone())]);
        assert!(
            renamed
                .check(&godot())
                .unwrap_err()
                .to_string()
                .contains("assets `Player`")
        );
    }

    #[test]
    fn the_file_parses_into_the_type_and_misspelled_keys_fail() {
        let text = "summary = \"A 2D platformer\"\nengine = \"godot@4.3\"\n\
            [[params]]\nkey = \"resolution\"\nlabel = \"Resolution\"\nkind = { type = \"text\", max_len = 16 }\ndefault = \"320x180\"\n\
            [[post]]\ntool = \"godot\"\nargs = [\"--headless\", \"--import\"]\nreason = \"Import the project's resources\"\n\
            [assets.player]\nnode_type = \"frame_animation\"\nstates = [\"idle\", \"run\", \"jump\"]\nsummary = \"The player character\"\n";
        assert_eq!(Template::parse(text, &godot()), Ok(template()));
        let error = Template::parse(&text.replace("engine", "engin"), &godot()).unwrap_err();
        assert!(error.to_string().contains("engin"), "{error}");
    }
}
