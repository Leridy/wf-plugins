//! The data of the client's fixed renderers (`[ui.views]` in the manifest): a
//! capability whose output a view shows returns these types, whole or under
//! the view's `from` field. Findings reuse `lint::LintOutput`. Within a major
//! version only optional fields are added.
//!
//! The runtime reads an output into these types at the edge, cuts tables and
//! findings to their limits and checks the rest with the `check` methods
//! here; data that fails only costs the view (shown as a problem with the raw
//! output), never the run.
use plugin_api::ui::{CellKind, is_plain};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

/// Most table rows shown; the rest are counted, not shown.
pub const TABLE_ROW_LIMIT: usize = 500;
/// Most findings shown; the rest are counted, not shown.
pub const FINDING_LIMIT: usize = 1000;
/// Most labelled values.
pub const KEY_VALUE_LIMIT: usize = 64;
/// Most pictures.
pub const IMAGE_LIMIT: usize = 32;
/// Most bytes of one picture.
pub const IMAGE_BYTES: u64 = 4 << 20;
/// Longest side of one picture, in pixels.
pub const IMAGE_SIDE: u32 = 4096;
/// Most bytes of every picture of one result.
pub const IMAGES_BYTES: u64 = 24 << 20;
/// Most characters of a text cell.
pub const CELL_TEXT_LIMIT: usize = 200;
/// Most characters of a status.
pub const STATUS_TEXT_LIMIT: usize = 24;
/// Most characters of a value's label.
pub const LABEL_LIMIT: usize = 40;
/// Most characters of a picture's caption.
pub const CAPTION_LIMIT: usize = 80;

/// `renderer = { type = "table" }`: each row has exactly the declared
/// columns, every cell of the column's kind.
#[derive(Clone, Debug, Default, Deserialize, JsonSchema, PartialEq, Serialize)]
pub struct TableData {
    pub rows: Vec<Vec<Cell>>,
}

/// One value, tagged with its kind: `{ "text": "…" }`, `{ "number": 3 }`,
/// `{ "status": { "tone": "ok", "text": "done" } }`, `{ "path": "a/b.tscn" }`,
/// `{ "node": "wf://<uuid>" }`.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiCell"))]
#[serde(rename_all = "kebab-case", deny_unknown_fields)]
pub enum Cell {
    /// One line, at most 200 characters.
    Text(String),
    /// Finite.
    Number(f64),
    Status(Status),
    /// Project-relative, `/`-separated, inside the project; empty means no path.
    Path(String),
    /// `wf://<uuid>`; the page links it when the node is in this Workspace.
    Node(String),
}

/// A short state word and its tone.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiStatus"))]
#[serde(deny_unknown_fields)]
pub struct Status {
    pub tone: Tone,
    /// At most 24 characters.
    pub text: String,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiTone"))]
#[serde(rename_all = "kebab-case")]
pub enum Tone {
    Neutral,
    Ok,
    Warn,
    Error,
}

/// `renderer = { type = "key-values" }`: at most 64 labelled values.
#[derive(Clone, Debug, Default, Deserialize, JsonSchema, PartialEq, Serialize)]
pub struct KeyValuesData {
    pub items: Vec<KeyValue>,
}

#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "UiKeyValue"))]
#[serde(deny_unknown_fields)]
pub struct KeyValue {
    /// At most 40 characters.
    pub label: String,
    pub value: Cell,
}

/// `renderer = { type = "images" }`: at most 32 pictures.
#[derive(Clone, Debug, Default, Deserialize, JsonSchema, PartialEq, Serialize)]
pub struct ImagesData {
    pub items: Vec<ImageItem>,
}

#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ImageItem {
    pub source: ImageSource,
    /// At most 80 characters.
    #[serde(default)]
    pub caption: String,
}

/// Where a picture is: never a URL.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case", deny_unknown_fields)]
pub enum ImageSource {
    /// A file in the run's project (within `permissions.read`).
    Project(String),
    /// A file in the plugin's `[ui] assets` directory, relative to it.
    Package(String),
}

/// Why view data cannot be shown: where in it, and why.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Fault {
    /// `rows[3][1]`, `items[2].label`.
    pub at: String,
    pub reason: String,
}

impl Fault {
    fn new(at: impl Into<String>, reason: impl Into<String>) -> Self {
        Self {
            at: at.into(),
            reason: reason.into(),
        }
    }
}

impl Cell {
    pub const fn kind(&self) -> CellKind {
        match self {
            Self::Text(_) => CellKind::Text,
            Self::Number(_) => CellKind::Number,
            Self::Status(_) => CellKind::Status,
            Self::Path(_) => CellKind::Path,
            Self::Node(_) => CellKind::Node,
        }
    }

    /// The value fits its kind's rules.
    pub fn check(&self) -> Result<(), String> {
        match self {
            Self::Text(text) => short(text, CELL_TEXT_LIMIT),
            Self::Number(number) if number.is_finite() => Ok(()),
            Self::Number(_) => Err("is not a finite number".into()),
            Self::Status(status) => short(&status.text, STATUS_TEXT_LIMIT),
            Self::Path(path) if path.is_empty() || is_relative(path) => Ok(()),
            Self::Path(_) => Err("is not a project-relative `/`-separated path".into()),
            Self::Node(node) if is_node(node) => Ok(()),
            Self::Node(_) => Err("is not a node address `wf://<uuid>`".into()),
        }
    }
}

impl TableData {
    /// Every row has the columns' kinds, in order, and every cell fits.
    pub fn check(&self, columns: &[CellKind]) -> Result<(), Fault> {
        for (r, row) in self.rows.iter().enumerate() {
            if row.len() != columns.len() {
                return Err(Fault::new(
                    format!("rows[{r}]"),
                    format!("has {} cells; the view declares {} columns", row.len(), columns.len()),
                ));
            }
            for (c, (cell, kind)) in row.iter().zip(columns).enumerate() {
                let at = format!("rows[{r}][{c}]");
                if cell.kind() != *kind {
                    return Err(Fault::new(
                        at,
                        format!("is a {:?} cell in a {kind:?} column", cell.kind()),
                    ));
                }
                cell.check().map_err(|reason| Fault::new(at, reason))?;
            }
        }
        Ok(())
    }
}

impl KeyValuesData {
    pub fn check(&self) -> Result<(), Fault> {
        if self.items.len() > KEY_VALUE_LIMIT {
            return Err(Fault::new(
                "items",
                format!("holds {} values; at most {KEY_VALUE_LIMIT}", self.items.len()),
            ));
        }
        for (i, item) in self.items.iter().enumerate() {
            short(&item.label, LABEL_LIMIT).map_err(|reason| Fault::new(format!("items[{i}].label"), reason))?;
            item.value
                .check()
                .map_err(|reason| Fault::new(format!("items[{i}].value"), reason))?;
        }
        Ok(())
    }
}

impl ImagesData {
    /// The count, captions and path shapes; the files themselves are the runtime's to read.
    pub fn check(&self) -> Result<(), Fault> {
        if self.items.len() > IMAGE_LIMIT {
            return Err(Fault::new(
                "items",
                format!("holds {} pictures; at most {IMAGE_LIMIT}", self.items.len()),
            ));
        }
        for (i, item) in self.items.iter().enumerate() {
            if !item.caption.is_empty() {
                short(&item.caption, CAPTION_LIMIT)
                    .map_err(|reason| Fault::new(format!("items[{i}].caption"), reason))?;
            }
            let (ImageSource::Project(path) | ImageSource::Package(path)) = &item.source;
            if !is_relative(path) {
                return Err(Fault::new(
                    format!("items[{i}].source"),
                    "is not a relative `/`-separated path inside its root",
                ));
            }
        }
        Ok(())
    }
}

/// One plain line of 1..=`limit` characters.
fn short(text: &str, limit: usize) -> Result<(), String> {
    if text.trim().is_empty() || text.chars().count() > limit {
        Err(format!("must be 1 to {limit} characters"))
    } else if !is_plain(text) {
        Err("holds control, bidirectional or zero-width characters".into())
    } else {
        Ok(())
    }
}

/// A non-empty relative path of plain, `/`-separated segments without `.` or `..`.
pub fn is_relative(path: &str) -> bool {
    !path.is_empty()
        && is_plain(path)
        && !path.contains('\\')
        && path
            .split('/')
            .all(|segment| !segment.is_empty() && segment != "." && segment != "..")
        && !path.contains(':')
}

/// `wf://` and a hyphenated UUID.
fn is_node(address: &str) -> bool {
    address.strip_prefix("wf://").is_some_and(|id| {
        id.len() == 36
            && id.char_indices().all(|(i, c)| {
                if matches!(i, 8 | 13 | 18 | 23) {
                    c == '-'
                } else {
                    c.is_ascii_hexdigit()
                }
            })
    })
}

#[cfg(test)]
mod tests {
    use super::{Cell, CellKind, ImageItem, ImageSource, ImagesData, KeyValue, KeyValuesData, Status, TableData, Tone};

    const NODE: &str = "wf://0b6e3f9e-6c43-4c55-9d43-8b1d1f0b9a11";

    fn row() -> Vec<Cell> {
        vec![
            Cell::Node(NODE.into()),
            Cell::Status(Status {
                tone: Tone::Ok,
                text: "written".into(),
            }),
            Cell::Number(4.0),
            Cell::Path("scenes/player.tscn".into()),
        ]
    }

    const COLUMNS: [CellKind; 4] = [CellKind::Node, CellKind::Status, CellKind::Number, CellKind::Path];

    #[test]
    fn cells_read_as_tagged_values() {
        let cells: Vec<Cell> = serde_json::from_str(
            r#"[{"node":"wf://0b6e3f9e-6c43-4c55-9d43-8b1d1f0b9a11"},{"status":{"tone":"ok","text":"written"}},{"number":4},{"path":"scenes/player.tscn"}]"#,
        )
        .unwrap();
        assert_eq!(cells, row());
    }

    #[test]
    fn tables_must_match_their_columns() {
        let table = TableData { rows: vec![row()] };
        assert_eq!(table.check(&COLUMNS), Ok(()));
        let short = TableData {
            rows: vec![row()[..3].to_vec()],
        };
        assert_eq!(short.check(&COLUMNS).unwrap_err().at, "rows[0]");
        let mut swapped = row();
        swapped.swap(2, 3);
        assert_eq!(
            TableData { rows: vec![swapped] }.check(&COLUMNS).unwrap_err().at,
            "rows[0][2]"
        );
        let mut escaping = row();
        escaping[3] = Cell::Path("../secret".into());
        assert_eq!(
            TableData { rows: vec![escaping] }.check(&COLUMNS).unwrap_err().at,
            "rows[0][3]"
        );
        let mut bad_node = row();
        bad_node[0] = Cell::Node("https://example.com".into());
        assert!(TableData { rows: vec![bad_node] }.check(&COLUMNS).is_err());
    }

    #[test]
    fn an_absent_path_is_blank_but_present_paths_stay_inside_the_project() {
        let mut cells = row();
        cells[3] = Cell::Path(String::new());
        assert_eq!(TableData { rows: vec![cells] }.check(&COLUMNS), Ok(()));
        assert!(!super::is_relative(""));
        for path in [
            "../secret",
            "/secret",
            "a/../secret",
            "a\\secret",
            "file:secret",
            "a//b",
        ] {
            assert!(Cell::Path(path.into()).check().is_err(), "{path}");
        }
        assert!(
            ImagesData {
                items: vec![ImageItem {
                    source: ImageSource::Project(String::new()),
                    caption: String::new(),
                }],
            }
            .check()
            .is_err()
        );
    }

    #[test]
    fn values_and_pictures_keep_their_limits() {
        let value = |label: &str| KeyValue {
            label: label.into(),
            value: Cell::Text("x".into()),
        };
        assert!(
            KeyValuesData {
                items: vec![value("Files")]
            }
            .check()
            .is_ok()
        );
        assert_eq!(
            KeyValuesData {
                items: vec![value(&"l".repeat(41))]
            }
            .check()
            .unwrap_err()
            .at,
            "items[0].label"
        );
        let picture = |source: ImageSource| ImageItem {
            source,
            caption: String::new(),
        };
        assert!(
            ImagesData {
                items: vec![picture(ImageSource::Package("icons/a.png".into()))]
            }
            .check()
            .is_ok()
        );
        for bad in ["/etc/passwd", "a/../b", "C:/x.png", "https://x/y.png"] {
            assert!(
                ImagesData {
                    items: vec![picture(ImageSource::Project(bad.into()))]
                }
                .check()
                .is_err(),
                "{bad}"
            );
        }
    }
}
