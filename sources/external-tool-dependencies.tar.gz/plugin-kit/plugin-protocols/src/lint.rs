//! `wf.lint/1`: check project files and report diagnostics. An implementation
//! only reads and returns data, never effects; a fix is a diagnostic's set of
//! edits, which the lint command turns into file edits when asked to fix. The
//! command qualifies each rule with the plugin name (`assets/stale-asset`),
//! applies the project's rule levels, adds line and column from the span and
//! decides the exit status.
use plugin_api::Protocol;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

pub const PROTOCOL: &str = Protocol::Lint.id();

/// What the lint command sends.
#[derive(Clone, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct LintInput {
    /// Project-relative files or directories (`/`-separated, no `..`) to
    /// check; empty means the whole project. Report diagnostics only for files
    /// under them. A path that matches no file reports nothing; it is not an error.
    #[serde(default)]
    pub paths: Vec<String>,
}

/// What an implementation returns as its output.
#[derive(Clone, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct LintOutput {
    /// Every file this implementation examined, project-relative. The command
    /// reports the files no implementation examined.
    #[serde(default)]
    pub checked: Vec<String>,
    #[serde(default)]
    pub diagnostics: Vec<Diagnostic>,
}

/// One problem in one file.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct Diagnostic {
    /// The rule, without the plugin name: lowercase words joined by `-`.
    pub rule: String,
    /// The rule's default level; the project may change it or turn the rule off.
    pub severity: Severity,
    /// One or two sentences saying what is wrong and how to fix it.
    pub message: String,
    /// The project-relative file the problem is in.
    pub file: String,
    /// Where in `file`; absent when the problem concerns the whole file.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub span: Option<Span>,
    /// Edits that fix the problem; applied only by `lint --fix`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub fix: Option<Fix>,
}

#[derive(Deserialize, JsonSchema, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS))]
#[serde(rename_all = "snake_case")]
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum Severity {
    Info,
    Warning,
    /// Makes the lint command exit with findings (6) unless fixed.
    Error,
}

/// Byte offsets into a file's UTF-8 text, end exclusive; both on character boundaries.
#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct Span {
    pub start: u32,
    pub end: u32,
}

#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct Fix {
    /// What applying the fix does, in a few words.
    pub summary: String,
    /// Non-overlapping edits; a fix applies all of them or none.
    pub edits: Vec<TextEdit>,
}

/// Replace `span` of `file` with `text`.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct TextEdit {
    pub file: String,
    pub span: Span,
    pub text: String,
}
