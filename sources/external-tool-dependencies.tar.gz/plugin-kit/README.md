# plugin-kit

WeaveForge 插件组件（WebAssembly，`wasm32-wasip2`）共用的 Rust 库，从 WeaveForge 仓库拷出：

| crate | 内容 |
| --- | --- |
| `plugin-api` | 插件 API 的纯数据：`wf-plugin.toml` 清单、描述、`Failure`/`Effect`、平台行、UI 声明、WIT（`plugin-api/wit/plugin.wit`） |
| `plugin-protocols` | 官方协议的输入输出类型：`wf.lint/1`、`wf.template/1`、UI 数据 |
| `plugin-guest` | 组件这一侧：WIT 绑定、`Host` trait、`wf.lint/1` provider 的胶水、测试用计数分配器（`testing` feature） |

使用它的插件（`assets`、`gdscript`、`godot`、`godot-export`）用路径依赖引用，所以本仓库要和插件仓库克隆在同一个目录下：

```toml
plugin-api = { path = "../plugin-kit/plugin-api" }
plugin-guest = { path = "../plugin-kit/plugin-guest" }
plugin-protocols = { path = "../plugin-kit/plugin-protocols" }
```

## 与 WeaveForge 同步

源头是 WeaveForge 的 `crates/plugin-api`、`crates/plugin-protocols`（运行时仍在用）和原来的 `crates/plugin-guest`；
`plugin-api/src/node_type.rs` 拷自 `crates/foundation/src/node_type.rs`（去掉数据库列）。
WeaveForge 改了这些 crate 或 WIT 时，把改动同步到这里，再在各插件仓库重新构建、升版本、发布。
与原文的差别只有：不依赖 `foundation`；去掉了检查 WeaveForge 前端语言列表的测试。

## 检查

```sh
cargo test
cargo clippy --all-targets
cargo build --target wasm32-wasip2 -p plugin-guest
```

## 发布插件

签名包发布在 git 插件仓库 <https://github.com/Leridy/wf-plugins>，在 WeaveForge 仓库里运行：

```sh
bun scripts/release/plugin-repo.ts --repo <wf-plugins 检出> --plugins <插件目录>...
```

## External program declarations

The manifest API now includes `tools.version` (fixed query, extraction,
requirement and feature ranges) and read-only `tools.detect.registry` rules.
This matches the already published `godot-export 0.5.0` source archive.
Use that plugin for Godot and `unity-export` for Unity Editor examples.

Declare only software the plugin actually executes. Each tool is a required
plugin-wide dependency: installation is allowed without it, but execution and
previews remain blocked until the client confirms a compatible default.
Discovery is passive; the client owns version-query execution and authorization.
Normal export/import execution remains a separately approved high-risk action.
Static lint, file-only exporters and data-only templates without executable
post steps must not acquire unrelated editor dependencies.
