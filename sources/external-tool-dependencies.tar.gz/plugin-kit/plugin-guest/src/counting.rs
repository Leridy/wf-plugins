//! A global allocator that counts live bytes, for the plugins' memory tests:
//! a plugin runs in a WebAssembly store with a memory limit, and a test on the
//! host target measures what a run allocates there at most. Install it in the
//! test binary:
//!
//! ```ignore
//! #[global_allocator]
//! static ALLOCATOR: Counting = Counting;
//! ```
#![allow(unsafe_code, reason = "a counting allocator wraps the system one")]

use std::{
    alloc::{GlobalAlloc, Layout, System},
    sync::atomic::{AtomicUsize, Ordering::Relaxed},
};

pub struct Counting;

static CURRENT: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);

impl Counting {
    /// Runs `f`; returns its result and the most it held allocated at once
    /// above what was allocated when it started. Measurements running at the
    /// same time mix their peaks, so a test measures one after another.
    pub fn peak<T>(f: impl FnOnce() -> T) -> (T, usize) {
        let base = CURRENT.load(Relaxed);
        PEAK.store(base, Relaxed);
        let result = f();
        (result, PEAK.load(Relaxed).saturating_sub(base))
    }
}

// SAFETY: every call is passed to the system allocator unchanged.
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let now = CURRENT.fetch_add(layout.size(), Relaxed) + layout.size();
        PEAK.fetch_max(now, Relaxed);
        unsafe { System.alloc(layout) }
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        CURRENT.fetch_sub(layout.size(), Relaxed);
        unsafe { System.dealloc(pointer, layout) }
    }

    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let now = if size >= layout.size() {
            CURRENT.fetch_add(size - layout.size(), Relaxed) + size - layout.size()
        } else {
            CURRENT.fetch_sub(layout.size() - size, Relaxed) - (layout.size() - size)
        };
        PEAK.fetch_max(now, Relaxed);
        unsafe { System.realloc(pointer, layout, size) }
    }
}
