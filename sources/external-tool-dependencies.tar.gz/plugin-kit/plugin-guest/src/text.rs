//! Untrusted text (paths, ids, node names from project files or the platform)
//! inside a message: on one line, unable to close the backticks around it, and
//! at most `limit` characters long, so it cannot forge or flood the output.

/// `text` in backticks, on one line, cut to `limit` characters with `...`.
pub fn quoted(text: &str, limit: usize) -> String {
    let mut flat: String = text
        .chars()
        .map(|c| match c {
            '`' => '\'',
            c if c.is_control() || matches!(c, '\u{2028}' | '\u{2029}') => ' ',
            c => c,
        })
        .take(limit)
        .collect();
    if text.chars().nth(limit).is_some() {
        flat.push_str("...");
    }
    format!("`{flat}`")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn text_stays_on_one_line_inside_its_backticks_and_is_cut() {
        assert_eq!(quoted("a`b\nc\u{2028}d\u{2029}e\u{7}f", 100), "`a'b c d e f`");
        assert_eq!(quoted("héllo", 5), "`héllo`");
        assert_eq!(quoted("héllo!", 5), "`héllo...`");
        assert_eq!(quoted("", 0), "``");
    }
}
