//! The WIT's failure kinds, converted to and from `plugin_api`'s.
use crate::bindings::Failure;
use plugin_api::Failure as ApiFailure;

impl From<Failure> for ApiFailure {
    fn from(kind: Failure) -> Self {
        match kind {
            Failure::InvalidInput => Self::InvalidInput,
            Failure::NotFound => Self::NotFound,
            Failure::Unsupported => Self::Unsupported,
            Failure::Internal => Self::Internal,
        }
    }
}

impl From<ApiFailure> for Failure {
    fn from(kind: ApiFailure) -> Self {
        match kind {
            ApiFailure::InvalidInput => Self::InvalidInput,
            ApiFailure::NotFound => Self::NotFound,
            ApiFailure::Unsupported => Self::Unsupported,
            ApiFailure::Internal => Self::Internal,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn failure_kinds_map_one_to_one() {
        for kind in [
            ApiFailure::InvalidInput,
            ApiFailure::NotFound,
            ApiFailure::Unsupported,
            ApiFailure::Internal,
        ] {
            assert_eq!(ApiFailure::from(Failure::from(kind)), kind);
        }
    }
}
