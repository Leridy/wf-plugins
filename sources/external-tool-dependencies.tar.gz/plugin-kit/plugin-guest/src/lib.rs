//! The guest side of the plugin API, shared by the official plugins: the
//! bindings of the canonical WIT (`crates/plugin-api/wit`), the host's imports
//! behind the [`Host`] and [`Platform`] traits so checks run against fakes in
//! tests, the plugin's settings ([`config`]), the `wf.lint/1` provider glue,
//! and the quoting of untrusted text in messages. A plugin implements
//! [`bindings::Guest`] and calls [`bindings::export!`] in its component module.
pub mod bindings;
mod config;
#[cfg(feature = "testing")]
pub mod counting;
mod failure;
mod host;
mod provider;
mod text;

pub use config::{config, settings};
pub use host::{Host, HostError, Platform, Wit};
pub use provider::{describe, lint};
pub use text::quoted;
