//! The plugin's settings in the project (`host.config`, API 0.1.3): the
//! `[[config]]` keys its manifest declares, already checked by the host, with
//! defaults filled in and a key with neither absent. A plugin reads them into
//! its own struct (an `integer` number reads into an integer type).
use crate::{HostError, bindings::wf::plugin::host as imports};
use plugin_api::Failure;
use serde::de::DeserializeOwned;

/// The plugin's settings, read into `T`. Give `T` an `Option` (or a serde
/// default) for each field the manifest declares without a default.
pub fn config<T: DeserializeOwned>() -> Result<T, HostError> {
    settings(&imports::config())
}

/// [`config`] from the bytes `host.config` returned, for tests.
pub fn settings<T: DeserializeOwned>(bytes: &[u8]) -> Result<T, HostError> {
    serde_json::from_slice(bytes).map_err(|error| {
        HostError::new(
            Failure::Internal,
            format!("the plugin's settings do not match its [[config]]: {error}"),
        )
    })
}

#[cfg(test)]
mod tests {
    use super::settings;
    use serde::Deserialize;

    #[derive(Debug, Deserialize, PartialEq)]
    struct Settings {
        limit: u32,
        style: Option<String>,
        strict: bool,
    }

    #[test]
    fn settings_read_into_the_plugins_struct() {
        let read: Settings = settings(br#"{"limit":100,"strict":true}"#).unwrap();
        assert_eq!(
            read,
            Settings {
                limit: 100,
                style: None,
                strict: true
            }
        );
        let error = settings::<Settings>(br#"{"limit":"x","strict":true}"#).unwrap_err();
        assert!(error.message.contains("[[config]]"), "{}", error.message);
    }
}
