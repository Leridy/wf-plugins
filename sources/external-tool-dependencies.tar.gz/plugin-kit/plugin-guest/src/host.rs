//! What a plugin asks of its host, as traits, so the checks run against a fake
//! or the disk in tests and against the WIT imports in the component.
use crate::bindings::{Error, Level, wf::plugin::host as imports};
use plugin_api::{Failure, LIST_LIMIT};

/// A host refusal: the kind says what the caller can do about it.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HostError {
    pub kind: Failure,
    pub message: String,
}

impl HostError {
    pub fn new(kind: Failure, message: impl Into<String>) -> Self {
        Self {
            kind,
            message: message.into(),
        }
    }

    pub fn not_found(&self) -> bool {
        self.kind == Failure::NotFound
    }
}

impl From<Error> for HostError {
    fn from(error: Error) -> Self {
        Self::new(error.kind.into(), error.message)
    }
}

impl From<HostError> for Error {
    fn from(error: HostError) -> Self {
        Self {
            kind: error.kind.into(),
            message: error.message,
            param: None,
        }
    }
}

/// The project's files and the person running the command.
pub trait Host {
    /// Readable project-relative files matching `glob`, sorted; at most
    /// [`Host::list_limit`]. A glob without wildcards names one path, which
    /// makes the listing a cheap check that the file exists.
    fn list(&self, glob: &str) -> Vec<String>;
    /// A readable project-relative file.
    fn read(&self, path: &str) -> Result<Vec<u8>, HostError>;
    /// A message for the person running the command (stderr).
    fn warn(&self, message: &str);

    /// How many paths a listing holds at most; one of that length is cut short.
    fn list_limit(&self) -> usize {
        LIST_LIMIT
    }

    /// Whether external `tool` (in `permissions.exec` and granted) resolves to
    /// an executable path in the host's external tool table.
    fn tool_available(&self, _tool: &str) -> bool {
        false
    }

    /// Registers a project-relative path for host removal after `exec` runs.
    fn cleanup_after_exec(&self, _path: &str) -> Result<(), HostError> {
        Ok(())
    }
}

/// A host that also answers the platform's read methods (`host.call`), for a
/// plugin granted `platform = "read"`.
pub trait Platform: Host {
    /// A platform read method (`wf.mirror.locks`): JSON in, JSON out.
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, HostError>;
}

/// The component's host: the WIT imports.
pub struct Wit;

impl Host for Wit {
    fn list(&self, glob: &str) -> Vec<String> {
        imports::list_files(glob)
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        imports::read_file(path).map_err(HostError::from)
    }

    fn warn(&self, message: &str) {
        imports::log(Level::Warn, message);
    }

    fn tool_available(&self, tool: &str) -> bool {
        imports::tool_available(tool)
    }

    fn cleanup_after_exec(&self, path: &str) -> Result<(), HostError> {
        imports::cleanup_after_exec(path).map_err(HostError::from)
    }
}

impl Platform for Wit {
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, HostError> {
        imports::call(method, input).map_err(HostError::from)
    }
}
