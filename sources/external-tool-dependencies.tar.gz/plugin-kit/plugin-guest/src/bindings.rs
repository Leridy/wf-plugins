//! The `provider` world of the canonical WIT, generated once for every
//! official plugin.
#![allow(unsafe_code, clippy::all, clippy::pedantic, reason = "wit-bindgen's generated glue")]

wit_bindgen::generate!({
    path: "../plugin-api/wit",
    world: "provider",
    pub_export_macro: true,
    default_bindings_module: "plugin_guest::bindings",
});

pub use wf::plugin::types::{Failure, Level, Verdict};
