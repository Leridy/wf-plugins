//! The two exports of a plugin whose one op implements `wf.lint/1`: its
//! description, and the call that checks the op, reads the input and turns
//! the output into an outcome.
use crate::{
    HostError,
    bindings::{Error, Failure, Outcome, Verdict},
};
use plugin_api::Description;
use plugin_protocols::lint::{LintInput, LintOutput, Severity};

/// What `describe` returns.
pub fn describe(description: &Description) -> Vec<u8> {
    serde_json::to_vec(description).expect("a description serializes")
}

/// What `call` returns for a plugin whose only op, `own`, implements
/// `wf.lint/1` through `run`.
pub fn lint(
    own: &str,
    op: &str,
    input: &[u8],
    run: impl FnOnce(&LintInput) -> Result<LintOutput, HostError>,
) -> Result<Outcome, Error> {
    if op != own {
        return Err(Error {
            kind: Failure::NotFound,
            message: format!("unknown op `{}`; this plugin has `{own}`", op.escape_debug()),
            param: None,
        });
    }
    let input: LintInput = serde_json::from_slice(input).map_err(|e| Error {
        kind: Failure::InvalidInput,
        message: e.to_string(),
        param: None,
    })?;
    let output = run(&input)?;
    // The `lint` command decides from the project's rule levels; run directly, the defaults do.
    let verdict = if output.diagnostics.iter().any(|d| d.severity == Severity::Error) {
        Verdict::Findings
    } else {
        Verdict::Ok
    };
    let output = serde_json::to_vec(&output).map_err(|e| Error {
        kind: Failure::Internal,
        message: e.to_string(),
        param: None,
    })?;
    Ok(Outcome {
        output,
        effects: Vec::new(),
        verdict,
        hints: Vec::new(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use plugin_protocols::lint::Diagnostic;

    fn finding(severity: Severity) -> LintOutput {
        LintOutput {
            checked: vec!["a.gd".to_owned()],
            diagnostics: vec![Diagnostic {
                rule: "rule".to_owned(),
                severity,
                message: "message".to_owned(),
                file: "a.gd".to_owned(),
                span: None,
                fix: None,
            }],
        }
    }

    #[test]
    fn a_lint_call_checks_the_op_and_input_and_judges_by_severity() {
        let unknown = lint("lint", "fix", b"{}", |_| unreachable!()).unwrap_err();
        assert_eq!(
            (unknown.kind, unknown.message.as_str()),
            (Failure::NotFound, "unknown op `fix`; this plugin has `lint`")
        );
        let invalid = lint("lint", "lint", b"[", |_| unreachable!()).unwrap_err();
        assert_eq!(invalid.kind, Failure::InvalidInput);
        let error = lint("lint", "lint", b"{}", |_| Ok(finding(Severity::Error))).unwrap();
        assert_eq!(error.verdict, Verdict::Findings);
        let warning = lint("lint", "lint", b"{}", |_| Ok(finding(Severity::Warning))).unwrap();
        assert_eq!(warning.verdict, Verdict::Ok);
        let refused = lint("lint", "lint", b"{}", |_| {
            Err(HostError::new(plugin_api::Failure::Unsupported, "no grant"))
        })
        .unwrap_err();
        assert_eq!(
            (refused.kind, refused.message.as_str()),
            (Failure::Unsupported, "no grant")
        );
    }
}
