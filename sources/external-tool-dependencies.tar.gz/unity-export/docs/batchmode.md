# Unity Editor dependency and batchmode export

Requires a stable Unity **6 Editor** (`>=6000.0.0, <7000.0.0`), not Unity Hub.
Alpha, beta and release-candidate editors are rejected. The existing export
pipeline and its fixtures target Unity 6; older editors are not supported.

Install or update the plugin, choose an Editor in the environment setup card,
then **Confirm and configure**. The client discovers installations, checks the
chosen editor with `-version`, and selects a compatible default. This query does
not open or import a project. A Unity license is still required for export;
passing the version query does not verify licensing or project packages.

Discovery checks common Unity Hub editor directories, PATH, and Windows App
Paths entries in both user/machine hives and registry views. Registry hints are
optional; for a custom installation, browse to `Unity.exe` or `Unity.app`.
Do not select Unity Hub. Changing the default affects other Unity-dependent
plugins. Changed binaries or check definitions require a new check.

From a synced Unity project whose export directory is inside `Assets/`:

```sh
wf unity-export sync --dry-run
wf unity-export sync
```

Sync plans file writes and an external-program effect. After approval, the
runtime runs the selected editor with `-batchmode -quit -nographics`, the project
path, and the bundled `WeaveForge.Editor.WfSyncRunner.Run` method. It never uses
a shell or a plugin-supplied executable path. The host cleans temporary runner
files after execution. A dry run starts no editor. Close this project in Unity
before export; an existing `Temp/UnityLockfile` blocks the operation.

Batchmode executes project code and may import assets. It remains a high-risk
operation subject to the client's normal approval policy. Environment setup
does not approve future exports. The `batchmode` feature flag only reports
version eligibility, not a successful project import or an MCP service.

Non-zero exit, cancellation or timeout fails the operation. Review Unity output
when an import fails; licensing, missing packages and project compile errors
cannot be fixed by selecting a compatible version alone.

This release requires the current development client with external-tool version
checks and registry discovery, plus plugin API 0.1.4. No unreleased client
version is invented in `plugin.cli`.
