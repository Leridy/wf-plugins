# unity-export

Official WeaveForge CLI plugin (`wf unity-export sync [NODE…]`) that converts exported WeaveForge assets and domain sidecars inside a Unity project's `Assets/` folder into native Unity assets, sprite `.meta` settings, animations, UGUI prefabs, tilemaps, prop prefabs, and deterministic particle effect players.

## Requirements

- Stable Unity 6 Editor (`>=6000.0.0, <7000.0.0`), configured and version-checked in the client.
- The development client with external-tool discovery/version support and plugin API 0.1.4.
- See [environment setup and batchmode](docs/batchmode.md) for discovery, approval and troubleshooting.

- A Unity project containing `ProjectSettings/ProjectVersion.txt` above the export directory, with the export directory inside `Assets/`.
- Supported Unity packages for the corresponding node types:
  - `com.unity.ugui` for `ui` prefabs
  - `com.unity.2d.tilemap` (`UnityEngine.TilemapModule`) for `tilemap` prefabs and `Tile` assets
  - `com.unity.modules.physics2d` for `tilemap` and `prop` 2D colliders

## Conversions

| Node type | Required `wf export` form | Generated Unity outputs |
| --- | --- | --- |
| `frame_animation`, `character_effect` | `frames`, `strips`, `atlas` | `.png.meta` (Single pivot / Multiple sliced spritesheet), `.anim` (`AnimationClip`), `.controller` (`AnimatorController`), `<Name>.prefab` (`SpriteRenderer` + `Animator`) |
| `ui` | `pieces`, `atlas` | `.png.meta` (with 9-slice `spriteBorder`), per-widget UGUI `<Widget>.prefab` (`Button`, `Toggle`, `Slider` progress bar/slider, `Image`) |
| `tilemap` | `source` | `.png.meta` (tile-aligned `spriteMode: 2`, Point filter, `PPU = tileWidth`), `tiles/*.asset` (`Tile`), `<Name>.prefab` (`Grid`, `Tilemap` ground layers, Y-sorted `Scene` sprites, `PolygonCollider2D` obstacles, `EdgeCollider2D` walkable bounds, `Spawn`) |
| `particle_effect` | `source` | Shared `Scripts/WfParticlePlayer.cs` + `Shaders/WfParticleUnlit.shader` (Built-in + URP compatible), `<Name>.prefab` (`WfParticlePlayer` matching editor `simulation.ts` 1:1 in 2D & 3D) |
| `prop` | `pieces`, `atlas` | `.png.meta` (`PPU = pixelsPerTile`, normalized anchor pivot), per-object `<Object>.prefab` (`SpriteRenderer`, state `PolygonCollider2D`, optional transition `.anim` + `.controller`) |

## Build and test

```sh
cargo test
cargo clippy --target wasm32-wasip2
cargo build --release --target wasm32-wasip2
```
