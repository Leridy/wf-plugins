//! Integration corpus tests validating CLI manifest planning, shared C#/shader emission, all domain types, and reconciliation lifecycle.
mod common;

use common::Fake;
use plugin_api::Effect;
use serde_json::{Value, json};
use std::collections::BTreeMap;
use wf_unity_export::{Element, Input, Plan, Status, sync};

fn manifest_task(plan: &Plan) -> Value {
    let bytes = plan
        .effects
        .iter()
        .find_map(|e| match e {
            Effect::WriteFile { path, bytes, .. } if path == "Assets/WfTmpSync/manifest.json" => Some(bytes),
            _ => None,
        })
        .expect("Assets/WfTmpSync/manifest.json written");
    let manifest: Value = serde_json::from_slice(bytes).expect("valid manifest json");
    assert_eq!(manifest["tasks"].as_array().unwrap().len(), 1);
    manifest["tasks"][0].clone()
}

fn corpus_with_ugui(name: &str, with_ugui: bool) -> (Plan, Value, BTreeMap<String, Vec<u8>>) {
    let mut host = Fake::case(name);
    if with_ugui {
        host.files.insert(
            "Packages/manifest.json".into(),
            br#"{"dependencies":{"com.unity.ugui":"2.6.0"}}"#.to_vec(),
        );
    }
    let plan = sync(&host, &Input::default()).unwrap();
    let written: BTreeMap<_, _> = plan
        .effects
        .iter()
        .filter_map(|e| match e {
            Effect::WriteFile { path, bytes, .. } => Some((path.clone(), bytes.clone())),
            _ => None,
        })
        .collect();
    assert!(written.contains_key("Assets/WfTmpSync/WfSyncRunner.cs"), "{name}");
    assert!(written.contains_key("Assets/WfTmpSync/WfSyncWorld.cs"), "{name}");
    assert!(written.contains_key("Assets/WfTmpSync/manifest.json"), "{name}");
    assert!(
        plan.effects
            .iter()
            .any(|e| matches!(e, Effect::Exec { tool, .. } if tool == "unity")),
        "{name}: expected Unity CLI Exec"
    );
    assert_eq!(plan.output.nodes[0].status, Status::Written, "{name}");

    let task = manifest_task(&plan);
    host.apply_cli(&plan.output, plan.effects.clone());
    let rerun = sync(&host, &Input::default()).unwrap();
    assert!(rerun.effects.is_empty(), "{name}: expected 0 effects on rerun");
    assert_eq!(rerun.output.nodes[0].status, Status::Unchanged, "{name}");
    (plan, task, written)
}

fn corpus(name: &str) -> (Plan, Value, BTreeMap<String, Vec<u8>>) {
    corpus_with_ugui(name, false)
}

#[test]
fn frame_animation_and_character_effect_variants_plan_cli_cleanly() {
    let (frames_plan, frames_task, _) = corpus("real-frames");
    let textures = frames_task["textures"].as_array().unwrap();
    let down_left = textures
        .iter()
        .find(|t| t["assetPath"] == "Assets/wf/hero/spriteActions-1/down_left/01.png")
        .unwrap();
    let down = textures
        .iter()
        .find(|t| t["assetPath"] == "Assets/wf/hero/spriteActions-1/down/01.png")
        .unwrap();
    assert_eq!(down_left["slices"][0]["pivotX"], 0.5);
    assert_eq!(down_left["slices"][0]["pivotY"], 0.0);
    assert_ne!(down["slices"][0]["pivotX"], 0.5);
    assert_eq!(frames_task["animPrefabs"][0]["assetPath"], "Assets/wf/hero/Hero.prefab");
    assert_eq!(
        frames_task["controllers"][0]["assetPath"],
        "Assets/wf/hero/Hero.controller"
    );
    assert!(!frames_task["clips"].as_array().unwrap().is_empty());
    assert_eq!(
        frames_plan.output.nodes[0].main_prefab.as_deref(),
        Some("Assets/wf/hero/Hero.prefab")
    );

    let (_, source_task, _) = corpus("real-source");
    let (_, strips_task, _) = corpus("animation-strips");
    let (_, atlas_task, _) = corpus("animation-atlas");
    assert_eq!(source_task["animPrefabs"][0]["assetPath"], "Assets/wf/hero/Hero.prefab");
    assert_eq!(strips_task["textures"][0]["multiple"], true);
    assert_eq!(atlas_task["textures"][0]["multiple"], true);
}

#[test]
fn ui_kits_plan_ugui_prefabs_when_installed_and_report_unsupported_widget_notes() {
    let (real_ui, real_task, _) = corpus_with_ugui("real-ui-pieces", true);
    assert_eq!(
        real_ui.output.nodes[0].elements,
        vec![
            Element {
                name: "待选订单行".into(),
                prefab: Some("Assets/wf/hero/待选订单行.prefab".into()),
            },
            Element {
                name: "主操作按钮".into(),
                prefab: Some("Assets/wf/hero/主操作按钮.prefab".into()),
            },
            Element {
                name: "体力条".into(),
                prefab: Some("Assets/wf/hero/体力条.prefab".into()),
            },
        ]
    );
    let btn = real_task["uiPrefabs"]
        .as_array()
        .unwrap()
        .iter()
        .find(|u| u["assetPath"] == "Assets/wf/hero/主操作按钮.prefab")
        .unwrap();
    assert_eq!(btn["kind"], "press");

    for case in ["ui-pieces", "ui-atlas"] {
        let (plan, task, _) = corpus_with_ugui(case, true);
        for kind in ["switch", "ring", "stick", "parts", "states"] {
            assert!(
                plan.output.nodes[0]
                    .reasons
                    .iter()
                    .any(|r| r.contains(&format!("{kind} has no UGUI widget prefab template"))),
                "{case}: missing note for {kind}"
            );
        }
        let ui_prefabs = task["uiPrefabs"].as_array().unwrap();
        let find_kind = |path: &str| {
            ui_prefabs.iter().find(|u| u["assetPath"] == path).unwrap()["kind"]
                .as_str()
                .unwrap()
                .to_owned()
        };
        assert_eq!(find_kind("Assets/wf/hero/Play_Button.prefab"), "press");
        assert_eq!(find_kind("Assets/wf/hero/PlayButton2.prefab"), "flip");
        assert_eq!(find_kind("Assets/wf/hero/play-button.prefab"), "bar");
        assert_eq!(find_kind("Assets/wf/hero/slide.prefab"), "slide");
    }

    let (naming_plan, naming_task, _) = corpus_with_ugui("ui-naming", true);
    assert_eq!(naming_plan.output.nodes[0].elements.len(), 10);
    let paths: Vec<&str> = naming_task["uiPrefabs"]
        .as_array()
        .unwrap()
        .iter()
        .map(|u| u["assetPath"].as_str().unwrap())
        .collect();
    assert!(paths.contains(&"Assets/wf/hero/主按钮.prefab"));
    assert!(paths.contains(&"Assets/wf/hero/主按钮_2.prefab"));
}

#[test]
fn tilemap_plans_ortho_and_isometric_grids_tiles_collisions_and_spawn() {
    let (_, task, _) = corpus("tilemap");
    let prefab = &task["tilemapPrefabs"][0];
    assert_eq!(prefab["assetPath"], "Assets/wf/meadow/Meadow.prefab");
    assert_eq!(prefab["isometric"], false);
    assert_eq!(prefab["hasSpawn"], true);
    assert!(!prefab["obstacles"].as_array().unwrap().is_empty());
    assert!(!prefab["walkable"].as_array().unwrap().is_empty());
    assert_eq!(task["textures"][0]["filterMode"], 0);
    assert!(!task["tileAssets"].as_array().unwrap().is_empty());

    let mut iso_host = Fake::case("tilemap");
    let mut map: Value = serde_json::from_slice(&iso_host.files["Assets/wf/meadow/tilemap.json"]).unwrap();
    map["orientation"] = "isometric".into();
    map["tileWidth"] = json!(64);
    map["tileHeight"] = json!(32);
    iso_host.files.insert(
        "Assets/wf/meadow/tilemap.json".into(),
        serde_json::to_vec(&map).unwrap(),
    );
    let iso_plan = sync(&iso_host, &Input::default()).unwrap();
    let iso_task = manifest_task(&iso_plan);
    assert_eq!(iso_task["tilemapPrefabs"][0]["isometric"], true);
    assert_eq!(iso_task["tilemapPrefabs"][0]["cellHeight"], 0.5);
}

#[test]
fn particles_export_shared_runtime_without_spatial_gpu_warnings() {
    let (_, real_task, real_files) = corpus("real-particles");
    assert!(real_files.contains_key("Assets/wf/Scripts/WfParticlePlayer.cs"));
    assert!(real_files.contains_key("Assets/wf/Shaders/WfParticleUnlit.shader"));
    assert_eq!(
        real_task["particlePrefabs"][0]["assetPath"],
        "Assets/wf/01a1bf2d-3bef-71b1-8253-91dd23916069/粒子_敌军传送门.prefab"
    );
    assert_eq!(real_task["particlePrefabs"][0]["planar"], true);

    let (builtin_plan, builtin_task, _) = corpus("particle-builtin");
    let reasons = &builtin_plan.output.nodes[0].reasons;
    assert!(reasons.iter().any(|r| r.contains("Unused smoke")));
    assert!(!reasons.iter().any(|r| r.contains("Spatial") || r.contains("planar")));
    assert_eq!(
        builtin_task["particlePrefabs"][0]["assetPath"],
        "Assets/wf/fx/sparks/Sparks.prefab"
    );
    assert_eq!(builtin_task["particlePrefabs"][0]["planar"], false);
}

#[test]
fn props_plan_prefabs_colliders_transitions_and_multi_state_notes() {
    let (plan, task, _) = corpus("prop");
    assert_eq!(
        plan.output.nodes[0].elements,
        vec![
            Element {
                name: "Wooden Barrel".into(),
                prefab: Some("Assets/wf/props/Wooden_Barrel.prefab".into()),
            },
            Element {
                name: "Treasure Chest".into(),
                prefab: Some("Assets/wf/props/Treasure_Chest.prefab".into()),
            },
        ]
    );
    let barrel = &task["propPrefabs"][0];
    assert_eq!(barrel["ctrlAssetPath"], "");
    assert!(!barrel["rootPolys"].as_array().unwrap().is_empty());
    let chest = &task["propPrefabs"][1];
    assert_ne!(chest["ctrlAssetPath"], "");
    assert_eq!(chest["stateColliders"].as_array().unwrap().len(), 2);
    let barrel_tex = task["textures"]
        .as_array()
        .unwrap()
        .iter()
        .find(|t| t["assetPath"] == "Assets/wf/props/objects/barrel.png")
        .unwrap();
    assert_eq!(barrel_tex["ppu"], 32.0);

    let mut host = Fake::case("prop");
    let mut props: Value = serde_json::from_slice(&host.files["Assets/wf/props/props.json"]).unwrap();
    props["objects"][1]["animations"] = json!([]);
    host.files
        .insert("Assets/wf/props/props.json".into(), serde_json::to_vec(&props).unwrap());
    let plan2 = sync(&host, &Input::default()).unwrap();
    assert!(
        plan2.output.nodes[0]
            .reasons
            .iter()
            .any(|r| r.contains("no transition animations"))
    );
}

#[test]
fn edited_and_commentless_files_are_kept_until_force() {
    let mut host = Fake::case("real-frames");
    let plan = sync(&host, &Input::default()).unwrap();
    let files: Vec<String> = plan.output.nodes[0].files.iter().map(|f| f.path.clone()).collect();
    host.apply_cli(&plan.output, plan.effects);
    host.files
        .get_mut(&files[0])
        .unwrap()
        .extend_from_slice(b"# user edit\n");
    let second = String::from_utf8(host.files[&files[1]].clone()).unwrap();
    let stripped = second.trim_end_matches('\n').rsplit_once('\n').unwrap().0.to_owned() + "\n";
    host.files.insert(files[1].clone(), stripped.into_bytes());

    let kept = sync(&host, &Input::default()).unwrap();
    assert_eq!(kept.output.nodes[0].status, Status::Kept);
    assert!(kept.effects.iter().all(|e| !matches!(e, Effect::Exec { .. })));

    let forced = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    assert_eq!(forced.output.nodes[0].status, Status::Updated);
    let task = manifest_task(&forced);
    assert!(task["textures"].as_array().unwrap().iter().any(|t| t["write"] == true));
}

#[test]
fn new_version_is_an_overwrite_even_when_spec_is_identical() {
    let mut host = Fake::case("real-source");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply_cli(&first.output, first.effects);
    host.locks.as_mut().unwrap().nodes[0].version += 1;
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Updated);
    let task = manifest_task(&plan);
    assert_eq!(task["animPrefabs"][0]["write"], true);
}

#[test]
fn layout_changes_and_particle_removal_delete_only_unedited_leftovers() {
    let mut host = Fake::case("real-source");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply_cli(&first.output, first.effects);
    host.files.insert(
        "Assets/wf/hero/CustomHelper.cs".into(),
        b"public class CustomHelper {}\n".to_vec(),
    );
    host.locks.as_mut().unwrap().nodes[0].path = "Actors/Renamed".into();
    let plan = sync(&host, &Input::default()).unwrap();
    assert!(plan.output.deleted.iter().any(|p| p.ends_with("Hero.prefab")));
    assert!(plan.output.deleted.iter().any(|p| p.ends_with("Hero.controller")));
    host.apply_cli(&plan.output, plan.effects);
    assert!(host.files.contains_key("Assets/wf/hero/CustomHelper.cs"));

    let mut phost = Fake::case("particle-builtin");
    let pfirst = sync(&phost, &Input::default()).unwrap();
    phost.apply_cli(&pfirst.output, pfirst.effects);
    assert!(phost.files.contains_key("Assets/wf/Scripts/WfParticlePlayer.cs"));
    phost.locks.as_mut().unwrap().nodes.clear();
    let clean = sync(&phost, &Input::default()).unwrap();
    assert!(
        clean
            .output
            .deleted
            .contains(&"Assets/wf/Scripts/WfParticlePlayer.cs".to_owned())
    );
    assert!(
        clean
            .output
            .deleted
            .contains(&"Assets/wf/Shaders/WfParticleUnlit.shader".to_owned())
    );
    phost.apply(clean.effects);
    assert!(!phost.files.contains_key("Assets/wf/Scripts/WfParticlePlayer.cs"));
}

#[test]
fn selection_accepts_all_three_address_forms_and_keeps_shared_runtime_untouched() {
    let mut host = Fake::case("real-source");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply_cli(&first.output, first.effects);
    let mut phost = Fake::case("particle-builtin");
    let pfirst = sync(&phost, &Input::default()).unwrap();
    phost.apply_cli(&pfirst.output, pfirst.effects);
    let runtime_script = phost.files["Assets/wf/Scripts/WfParticlePlayer.cs"].clone();
    host.files
        .insert("Assets/wf/Scripts/WfParticlePlayer.cs".into(), runtime_script);

    for address in ["#75", "Actors/Hero", "wf://11111111-1111-4111-8111-111111111111"] {
        let plan = sync(
            &host,
            &Input {
                nodes: vec![address.into()],
                ..Input::default()
            },
        )
        .unwrap();
        assert!(plan.effects.is_empty());
        assert!(plan.output.deleted.is_empty());
        assert_eq!(plan.output.nodes.len(), 1);
    }
    assert!(
        sync(
            &host,
            &Input {
                nodes: vec!["#999".into()],
                ..Input::default()
            }
        )
        .is_err()
    );
}

#[test]
fn missing_project_version_assets_sidecar_or_corrupt_png_fails() {
    for path in [
        "ProjectSettings/ProjectVersion.txt",
        "Assets/wf/hero/animation.json",
        "Assets/wf/hero/spriteActions-1/source/01.png",
    ] {
        let mut host = Fake::case("real-source");
        assert!(host.files.remove(path).is_some(), "{path}");
        assert!(sync(&host, &Input::default()).is_err(), "{path}");
    }
    let mut bad_png = Fake::case("real-source");
    bad_png.files.insert(
        "Assets/wf/hero/spriteActions-1/source/01.png".into(),
        b"not-a-png".to_vec(),
    );
    assert!(sync(&bad_png, &Input::default()).is_err());

    let mut missing_tex = Fake::case("particle-builtin");
    assert!(
        missing_tex
            .files
            .remove("Assets/wf/fx/sparks/particle-texture-spark.png")
            .is_some()
    );
    assert!(sync(&missing_tex, &Input::default()).is_err());
}

#[test]
fn unsupported_node_types_skip_without_effects() {
    let mut host = Fake::case("real-source");
    for kind in [
        "word_art",
        "music",
        "sound_effect",
        "voice",
        "tts",
        "video",
        "character_art",
        "skeletal_animation",
    ] {
        host.nodes[0].node.node_type = kind.into();
        let plan = sync(&host, &Input::default()).unwrap();
        assert_eq!(plan.output.nodes[0].status, Status::Skipped, "{kind}");
        assert!(!plan.output.nodes[0].reasons.is_empty(), "{kind}");
        assert!(plan.effects.is_empty(), "{kind}");
    }
}

#[test]
fn whole_map_plans_masked_tile_shader_mat_nav_and_colliders() {
    let (_, task, written) = corpus("whole-map");
    assert!(written.contains_key("Assets/wf/Shaders/WfWholeMapTile.shader"));
    assert!(written.contains_key("Assets/wf/Scripts/WfWholeMapNav.cs"));
    assert_eq!(
        task["materials"][0]["assetPath"],
        "Assets/wf/whole-map/Town_Tile_0_0.mat"
    );
    let prefab = &task["wholeMapPrefabs"][0];
    assert_eq!(prefab["assetPath"], "Assets/wf/whole-map/Town.prefab");
    assert!(!prefab["navRects"].as_array().unwrap().is_empty());
    assert!(!prefab["colliders"].as_array().unwrap().is_empty());
}

#[test]
fn scrolling_scene_plans_parallax_layer_script_and_level_prefab() {
    let (_, task, written) = corpus("scrolling-scene");
    assert!(written.contains_key("Assets/wf/Scripts/WfParallaxLayer.cs"));
    let prefab = &task["parallaxPrefabs"][0];
    assert_eq!(prefab["assetPath"], "Assets/wf/scrolling-scene/Forest.prefab");
    assert_eq!(prefab["backdrop"]["speed"], 0.1);
    assert!(!prefab["levelBoxes"].as_array().unwrap().is_empty());
    assert!(!prefab["levelMarkers"].as_array().unwrap().is_empty());
}

#[test]
fn scene3d_map_and_model_3d_plan_3d_colliders_roles_sockets_and_clips() {
    let (s3d_plan, s3d_task, s3d_written) = corpus("scene3d-map");
    assert!(
        s3d_plan.output.nodes[0]
            .reasons
            .iter()
            .any(|r| r.contains("Blocked doors")),
        "{:?}",
        s3d_plan.output.nodes[0].reasons
    );
    assert!(s3d_written.contains_key("Assets/wf/Scripts/WfSpatialMeta.cs"));
    let s3d_prefab = &s3d_task["scene3dPrefabs"][0];
    assert_eq!(s3d_prefab["assetPath"], "Assets/wf/scene3d-map/Citadel.prefab");
    assert!(!s3d_prefab["colliders"].as_array().unwrap().is_empty());
    assert!(
        s3d_prefab["roles"]
            .as_array()
            .unwrap()
            .iter()
            .any(|r| r["id"] == "gate_1" && r["blocked"] == true)
    );

    let (_, m3d_task, _) = corpus("model-3d");
    let m3d_prefab = &m3d_task["model3dPrefabs"][0];
    assert_eq!(m3d_prefab["assetPath"], "Assets/wf/model-3d/Knight.prefab");
    assert_eq!(m3d_prefab["capsuleCollider"], true);
    assert!(
        m3d_prefab["sockets"]
            .as_array()
            .unwrap()
            .iter()
            .any(|s| s["name"] == "Socket_HandR")
    );
    assert!(
        m3d_prefab["clips"]
            .as_array()
            .unwrap()
            .iter()
            .any(|c| c["loops"] == true)
    );
}

#[test]
fn an_entirely_skipped_kit_still_lists_its_elements_without_a_prefab() {
    let mut host = Fake::case("ui-pieces");
    host.files.insert(
        "Assets/wf/hero/ui.json".into(),
        r#"{
            "images": {}, "elements": [
                {"name": "面板", "kind": "panel", "size": {"width": 8, "height": 8}, "states": [], "widget": {"type": "states"}}
            ]
        }"#
        .as_bytes()
        .to_vec(),
    );
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Skipped);
    assert_eq!(
        plan.output.nodes[0].elements,
        [Element {
            name: "面板".into(),
            prefab: None
        }]
    );
    assert!(plan.effects.is_empty());
}
