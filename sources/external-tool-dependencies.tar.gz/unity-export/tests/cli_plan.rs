//! Tests Unity CLI-only routing, lockfile rejection, UGUI manifest detection,
//! idempotent `src=` stamps, temp script cleanup, and real Unity batchmode round-trips.
#![allow(clippy::panic)]
mod common;

use common::Fake;
use plugin_api::Effect;
use plugin_guest::{Host, HostError, Platform};
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    cell::RefCell,
    collections::BTreeMap,
    fmt::Write,
    fs,
    path::{Path, PathBuf},
    process::{self, Command},
};
use wf_unity_export::{Input, Status, sync};

fn stamp_with_src(id: &str, version: u64, body: &str, src_hash: &str) -> Vec<u8> {
    let body = if body.ends_with('\n') {
        body.to_owned()
    } else {
        format!("{body}\n")
    };
    let digest = Sha256::digest(body.as_bytes());
    let mut hex = String::with_capacity(64);
    for b in digest {
        write!(hex, "{b:02x}").expect("write");
    }
    format!("{body}# wf unity-export {id} v{version} sha256={hex} src={src_hash}\n").into_bytes()
}

fn find_write<'a>(effects: &'a [Effect], target_path: &str) -> &'a [u8] {
    effects
        .iter()
        .find_map(|e| match e {
            Effect::WriteFile { path, bytes, .. } if path == target_path => Some(bytes.as_slice()),
            _ => None,
        })
        .unwrap_or_else(|| panic!("missing WriteFile for {target_path}"))
}

#[test]
fn auto_mode_plans_unity_cli_and_cleanup_then_reruns_unchanged() {
    let mut host = Fake::case("real-frames");
    host.tools.insert("unity".into());

    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Written);
    let generated_paths: Vec<String> = plan.output.nodes[0].files.iter().map(|f| f.path.clone()).collect();
    assert!(!generated_paths.is_empty());

    let writes: Vec<&str> = plan
        .effects
        .iter()
        .filter_map(|e| match e {
            Effect::WriteFile { path, .. } => Some(path.as_str()),
            _ => None,
        })
        .collect();
    assert!(writes.contains(&"Assets/wf/wf-bindings.json"));
    assert!(writes.contains(&"Assets/WfTmpSync/WfSyncRunner.cs"));
    assert!(writes.contains(&"Assets/WfTmpSync/WfSyncWorld.cs"));
    assert!(writes.contains(&"Assets/WfTmpSync/manifest.json"));

    let execs: Vec<(&str, &[String])> = plan
        .effects
        .iter()
        .filter_map(|e| match e {
            Effect::Exec { tool, args, .. } => Some((tool.as_str(), args.as_slice())),
            _ => None,
        })
        .collect();
    assert_eq!(execs.len(), 1);
    assert_eq!(execs[0].0, "unity");
    assert!(execs[0].1.contains(&"-batchmode".to_owned()));
    assert!(execs[0].1.contains(&"-executeMethod".to_owned()));
    assert!(execs[0].1.contains(&"WeaveForge.Editor.WfSyncRunner.Run".to_owned()));

    assert_eq!(
        host.cleanup.borrow().as_slice(),
        &[
            "Assets/WfTmpSync/WfSyncRunner.cs",
            "Assets/WfTmpSync/WfSyncRunner.cs.meta",
            "Assets/WfTmpSync/WfSyncWorld.cs",
            "Assets/WfTmpSync/WfSyncWorld.cs.meta",
            "Assets/WfTmpSync/manifest.json",
            "Assets/WfTmpSync/manifest.json.meta",
            "Assets/WfTmpSync.meta",
        ]
    );

    let manifest: Value = serde_json::from_slice(find_write(&plan.effects, "Assets/WfTmpSync/manifest.json")).unwrap();
    let task = &manifest["tasks"][0];
    let src_hash = task["srcHash"].as_str().unwrap();
    let id = task["id"].as_str().unwrap();
    let version = task["version"].as_u64().unwrap();

    host.apply(plan.effects);
    assert!(!host.files.contains_key("Assets/WfTmpSync/WfSyncRunner.cs"));
    assert!(!host.files.contains_key("Assets/WfTmpSync/manifest.json"));

    for p in generated_paths {
        host.files
            .insert(p, stamp_with_src(id, version, "fileFormatVersion: 2\n", src_hash));
    }
    host.cleanup.borrow_mut().clear();

    let rerun = sync(&host, &Input::default()).unwrap();
    assert_eq!(rerun.output.nodes[0].status, Status::Unchanged);
    assert!(rerun.effects.is_empty());
    assert!(host.cleanup.borrow().is_empty());
}

#[test]
fn ui_kit_detects_com_unity_ugui_in_packages_manifest() {
    let mut host = Fake::case("ui-pieces");

    let no_ugui = sync(&host, &Input::default()).unwrap();
    let m0: Value = serde_json::from_slice(find_write(&no_ugui.effects, "Assets/WfTmpSync/manifest.json")).unwrap();
    assert!(m0["tasks"][0]["uiPrefabs"].as_array().unwrap().is_empty());
    assert!(
        no_ugui.output.nodes[0]
            .reasons
            .iter()
            .any(|r| r.contains("com.unity.ugui"))
    );
    assert!(
        !no_ugui
            .effects
            .iter()
            .any(|e| matches!(e, Effect::WriteFile { path, .. } if path.ends_with(".prefab")))
    );

    host.files.insert(
        "Packages/manifest.json".into(),
        br#"{"dependencies":{"com.unity.ugui":"2.6.0"}}"#.to_vec(),
    );
    let with_ugui = sync(&host, &Input::default()).unwrap();
    let m1: Value = serde_json::from_slice(find_write(&with_ugui.effects, "Assets/WfTmpSync/manifest.json")).unwrap();
    assert!(!m1["tasks"][0]["uiPrefabs"].as_array().unwrap().is_empty());
    assert!(
        !with_ugui
            .effects
            .iter()
            .any(|e| matches!(e, Effect::WriteFile { path, .. } if path.ends_with(".prefab")))
    );
}

#[test]
fn sync_errors_when_unity_lockfile_present_and_plans_cli_without_tool_hint() {
    let mut host = Fake::case("real-frames");
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Written);
    assert!(
        plan.effects
            .iter()
            .any(|e| matches!(e, Effect::Exec { tool, .. } if tool == "unity"))
    );
    assert!(!host.cleanup.borrow().is_empty());

    host.files.insert("Temp/UnityLockfile".into(), Vec::new());
    let err = sync(&host, &Input::default()).unwrap_err();
    assert!(err.message.contains("Temp/UnityLockfile"));
}

#[test]
fn cli_mode_preserves_user_edits_when_unforced() {
    let mut host = Fake::case("real-frames");
    host.tools.insert("unity".into());

    let first = sync(&host, &Input::default()).unwrap();
    let files: Vec<String> = first.output.nodes[0].files.iter().map(|f| f.path.clone()).collect();
    let prefab_path = files
        .iter()
        .find(|p| p.ends_with(".prefab"))
        .cloned()
        .expect("prefab path");
    let manifest: Value = serde_json::from_slice(find_write(&first.effects, "Assets/WfTmpSync/manifest.json")).unwrap();
    let task = &manifest["tasks"][0];
    let src_hash = task["srcHash"].as_str().unwrap();
    let id = task["id"].as_str().unwrap();
    let version = task["version"].as_u64().unwrap();

    host.apply(first.effects);
    for p in &files {
        if *p == prefab_path {
            host.files.insert(p.clone(), b"%YAML 1.1\n# user edit\n".to_vec());
        } else {
            host.files.insert(
                p.clone(),
                stamp_with_src(id, version, "fileFormatVersion: 2\n", src_hash),
            );
        }
    }

    let next = sync(&host, &Input::default()).unwrap();
    assert_eq!(next.output.nodes[0].status, Status::Kept);
    assert!(next.effects.iter().all(|e| !matches!(e, Effect::Exec { .. })));

    let forced = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    let m2: Value = serde_json::from_slice(find_write(&forced.effects, "Assets/WfTmpSync/manifest.json")).unwrap();
    assert_eq!(m2["tasks"][0]["animPrefabs"][0]["write"], true);
    assert_eq!(m2["tasks"][0]["textures"][0]["write"], false);
}

struct TempDir(PathBuf);
impl TempDir {
    fn new(name: &str) -> Self {
        let dir = std::env::temp_dir().join(format!("wf_unity_e2e_{}_{name}", process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        Self(dir)
    }
}
impl Drop for TempDir {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

struct DiskHost<'a> {
    root: &'a Path,
    base: &'a Fake,
    cleanup: RefCell<Vec<String>>,
    warnings: RefCell<Vec<String>>,
}
impl Host for DiskHost<'_> {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = globset::Glob::new(glob).unwrap().compile_matcher();
        common::files(self.root)
            .into_keys()
            .filter(|p| matcher.is_match(p))
            .collect()
    }
    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        fs::read(self.root.join(path)).map_err(|_| HostError::new(plugin_api::Failure::NotFound, path))
    }
    fn warn(&self, msg: &str) {
        self.warnings.borrow_mut().push(msg.to_owned());
    }
    fn tool_available(&self, tool: &str) -> bool {
        tool == "unity"
    }
    fn cleanup_after_exec(&self, path: &str) -> Result<(), HostError> {
        self.cleanup.borrow_mut().push(path.to_owned());
        Ok(())
    }
}
impl Platform for DiskHost<'_> {
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, HostError> {
        self.base.call(method, input)
    }
}

fn seed_case_project(root: &Path, base: &Fake, manifest_json: Option<&[u8]>) {
    let assets = root.join("Assets");
    if assets.exists() {
        fs::remove_dir_all(&assets).unwrap();
    }
    let tmp = root.join("Temp");
    if tmp.exists() {
        fs::remove_dir_all(&tmp).unwrap();
    }
    for (rel, bytes) in &base.files {
        let full = root.join(rel);
        fs::create_dir_all(full.parent().unwrap()).unwrap();
        fs::write(full, bytes).unwrap();
    }
    let pkg = root.join("Packages/manifest.json");
    if let Some(json) = manifest_json {
        fs::create_dir_all(pkg.parent().unwrap()).unwrap();
        fs::write(pkg, json).unwrap();
    } else if root.join("Packages").exists() {
        let _ = fs::remove_dir_all(root.join("Packages"));
    }
}

fn run_disk_sync(unity: &Path, root: &Path, base: &Fake, label: &str) {
    let disk = DiskHost {
        root,
        base,
        cleanup: RefCell::new(Vec::new()),
        warnings: RefCell::new(Vec::new()),
    };

    let plan = sync(&disk, &Input::default()).unwrap_or_else(|e| panic!("{label}: sync failed: {}", e.message));
    assert_eq!(plan.output.nodes[0].status, Status::Written, "{label}");

    let mut execs = Vec::new();
    for effect in plan.effects {
        match effect {
            Effect::WriteFile { path, bytes, .. } => {
                let full = root.join(&path);
                fs::create_dir_all(full.parent().unwrap()).unwrap();
                fs::write(full, bytes).unwrap();
            }
            Effect::DeleteFile { path } => {
                let _ = fs::remove_file(root.join(path));
            }
            Effect::Exec { args, .. } => execs.push(args),
            _ => panic!("unexpected effect in {label}"),
        }
    }
    for args in execs {
        let out = Command::new(unity).args(&args).current_dir(root).output().unwrap();
        assert!(
            out.status.success(),
            "{label}: Unity {:?} failed:\nstdout:\n{}\nstderr:\n{}",
            args,
            String::from_utf8_lossy(&out.stdout),
            String::from_utf8_lossy(&out.stderr),
        );
    }

    for rel in disk.cleanup.borrow_mut().drain(..) {
        let _ = fs::remove_file(root.join(rel));
    }
    let _ = fs::remove_dir(root.join("Assets/WfTmpSync"));
    assert!(
        !root.join("Assets/WfTmpSync").exists(),
        "{label}: WfTmpSync dir left behind"
    );
    assert!(
        !root.join("Assets/WfTmpSync.meta").exists(),
        "{label}: WfTmpSync.meta left behind"
    );

    for f in &plan.output.nodes[0].files {
        assert!(root.join(&f.path).is_file(), "{label}: missing generated {}", f.path);
    }

    let rerun = sync(&disk, &Input::default()).unwrap();
    assert_eq!(rerun.output.nodes[0].status, Status::Unchanged, "{label} rerun");
    assert!(rerun.effects.is_empty(), "{label} rerun must have 0 effects");
}

#[test]
#[ignore = "requires UNITY_EDITOR_BIN and a licensed Unity 6 Editor"]
fn configured_unity_editor_exports_source_fixture() {
    let unity = PathBuf::from(std::env::var_os("UNITY_EDITOR_BIN").expect("set UNITY_EDITOR_BIN"));
    assert!(unity.is_file(), "missing Unity Editor at {}", unity.display());
    let project = TempDir::new("configured-editor");
    let base = Fake::case("real-source");
    seed_case_project(
        &project.0,
        &base,
        Some(br#"{"dependencies":{"com.unity.modules.jsonserialize":"1.0.0"}}"#),
    );
    run_disk_sync(&unity, &project.0, &base, "configured-editor");
}

#[test]
#[ignore = "requires local Unity 6 binary"]
fn real_unity_cli_round_trips_fixture_corpus() {
    let unity = Path::new("/Applications/Unity/Hub/Editor/6000.6.7f1/Unity.app/Contents/MacOS/Unity");
    assert!(unity.is_file(), "missing Unity binary at {}", unity.display());

    // First verify WfSyncRunner compiles & succeeds even with only jsonserialize enabled (no physics/tilemap/ugui).
    let stripped = TempDir::new("stripped");
    let src_base = Fake::case("real-source");
    seed_case_project(
        &stripped.0,
        &src_base,
        Some(br#"{"dependencies":{"com.unity.modules.jsonserialize":"1.0.0"}}"#),
    );
    run_disk_sync(unity, &stripped.0, &src_base, "real-source-stripped");

    // Then run every node kind with Unity's default built-in engine modules.
    let minimal = TempDir::new("minimal");
    let cases = [
        "real-source",
        "real-frames",
        "animation-atlas",
        "ui-pieces",
        "tilemap",
        "prop",
        "real-particles",
        "whole-map",
        "scrolling-scene",
        "model-3d",
        "scene3d-map",
    ];
    for name in cases {
        let base = Fake::case(name);
        seed_case_project(&minimal.0, &base, None);
        run_disk_sync(unity, &minimal.0, &base, name);
    }

    let ugui = TempDir::new("ugui");
    let ui_base = Fake::case("ui-pieces");
    let ugui_manifest = br#"{"dependencies":{"com.unity.ugui":"2.6.0","com.unity.modules.jsonserialize":"1.0.0"}}"#;
    seed_case_project(&ugui.0, &ui_base, Some(ugui_manifest));
    run_disk_sync(unity, &ugui.0, &ui_base, "ui-pieces-ugui");

    let empty_check: BTreeMap<String, Vec<u8>> = common::files(&ugui.0);
    assert!(
        empty_check.keys().any(|k| k.ends_with(".prefab")),
        "UGUI run must produce .prefab files"
    );
}
