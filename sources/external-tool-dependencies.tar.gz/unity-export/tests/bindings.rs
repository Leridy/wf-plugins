//! End-to-end integration test for `icon` (`icons.json`), `image` (`source`), alpha `visualBounds`/`bodyBounds`, and `wf-bindings.json` + `WfBindings.cs` sync/lifecycle.
mod common;

use common::Fake;
use miniz_oxide::deflate::compress_to_vec_zlib;
use serde_json::{Value, json};
use std::str::from_utf8;
use wf_unity_export::{Input, Status, sync};

fn padded_rgba_png(w: u32, h: u32, rx: u32, ry: u32, rw: u32, rh: u32) -> Vec<u8> {
    let mut raw = Vec::new();
    for y in 0..h {
        raw.push(0);
        for x in 0..w {
            let opaque = x >= rx && x < rx + rw && y >= ry && y < ry + rh;
            raw.extend_from_slice(if opaque { &[255, 255, 255, 255] } else { &[0, 0, 0, 0] });
        }
    }
    let idat = compress_to_vec_zlib(&raw, 6);
    let mut png = Vec::from(*b"\x89PNG\r\n\x1a\n");
    let mut ihdr = Vec::new();
    ihdr.extend_from_slice(&w.to_be_bytes());
    ihdr.extend_from_slice(&h.to_be_bytes());
    ihdr.extend_from_slice(&[8, 6, 0, 0, 0]);
    for (kind, data) in [(b"IHDR", ihdr.as_slice()), (b"IDAT", idat.as_slice()), (b"IEND", b"")] {
        png.extend_from_slice(&(data.len() as u32).to_be_bytes());
        png.extend_from_slice(kind);
        png.extend_from_slice(data);
        png.extend_from_slice(&0u32.to_be_bytes());
    }
    png
}

#[test]
fn icons_images_alpha_visual_bounds_and_wf_bindings_work_end_to_end() {
    let mut host = Fake::case("prop");
    let id_prop = host.locks.as_ref().unwrap().nodes[0].id.clone();
    let id_icon = "bbbb0001-0000-4000-8000-000000000001".to_owned();
    let id_img = "bbbb0002-0000-4000-8000-000000000002".to_owned();

    // Update prop object #1 to floating `center` semantics with padded PNG (`16x16` containing `8x6` at `(4, 2)`).
    let mut props: Value = serde_json::from_slice(&host.files["Assets/wf/props/props.json"]).unwrap();
    props["objects"][0]["anchorKind"] = json!("center");
    props["objects"][0]["canvas"] = json!({"width": 16, "height": 16});
    props["objects"][0]["anchor"] = json!({"x": 8, "y": 14});
    host.files
        .insert("Assets/wf/props/props.json".into(), serde_json::to_vec(&props).unwrap());
    host.files.insert(
        "Assets/wf/props/objects/barrel.png".into(),
        padded_rgba_png(16, 16, 4, 2, 8, 6),
    );

    // Add an `icon` node (`icons.json`) and a standalone `image` node under `Assets/Resources/...` (`source`).
    host.files.insert(
        "Assets/wf/icons/icons.json".into(),
        serde_json::to_vec(&json!({
            "images": { "sword": { "type": "atlas", "path": "sheet.png", "frame": { "x": 0, "y": 0, "w": 32, "h": 32 } } },
            "elements": [{
                "name": "Sword",
                "kind": "item-icon",
                "size": { "width": 32, "height": 32 },
                "widget": { "type": "states" },
                "states": [{
                    "name": "rest",
                    "role": "rest",
                    "file": "sword",
                    "slice": { "mode": "fixed", "borders": { "top": 0, "right": 0, "bottom": 0, "left": 0 } }
                }]
            }]
        }))
        .unwrap(),
    );
    host.files.insert(
        "Assets/wf/icons/sheet.png".into(),
        padded_rgba_png(64, 32, 6, 4, 20, 24),
    );
    host.files.insert(
        "Assets/wf/Resources/bg/SpaceBg.png".into(),
        padded_rgba_png(32, 16, 8, 2, 16, 12),
    );

    let base_lock = host.locks.as_ref().unwrap().nodes[0].clone();
    let base_node = host.nodes[0].clone();
    let locks = host.locks.as_mut().unwrap();
    for (id, num, path, kind, form, files) in [
        (
            id_icon.clone(),
            11,
            "UI/Icons",
            "icon",
            "atlas",
            vec!["icons/icons.json", "icons/sheet.png"],
        ),
        (
            id_img.clone(),
            12,
            "Art/SpaceBg",
            "image",
            "source",
            vec!["Resources/bg/SpaceBg.png"],
        ),
    ] {
        let mut row = base_lock.clone();
        (row.id, row.number, row.path, row.form) = (id.clone(), num, path.into(), form.into());
        row.files = files.into_iter().map(str::to_owned).collect();
        locks.nodes.push(row);

        let mut node_out = base_node.clone();
        (
            node_out.node.id,
            node_out.node.number,
            node_out.node.path,
            node_out.node.node_type,
        ) = (id, num, path.into(), kind.into());
        host.nodes.push(node_out);
    }

    let plan = sync(&host, &Input::default()).unwrap();
    assert!(plan.output.warnings.is_empty(), "{:?}", plan.output.warnings);
    assert!(plan.output.nodes.iter().all(|n| n.status == Status::Written));
    let manifest_bytes = plan
        .effects
        .iter()
        .find_map(|e| match e {
            plugin_api::Effect::WriteFile { path, bytes, .. } if path == "Assets/WfTmpSync/manifest.json" => {
                Some(bytes.clone())
            }
            _ => None,
        })
        .unwrap();
    let cli_manifest: Value = serde_json::from_slice(&manifest_bytes).unwrap();
    host.apply_cli(&plan.output, plan.effects);

    // Strict JSON (no trailing comment!) + matching C# reader generated.
    let raw_bindings = &host.files["Assets/wf/wf-bindings.json"];
    let bindings: Value = serde_json::from_slice(raw_bindings).expect("strict wf-bindings.json");
    assert_eq!(bindings["schema"], "wf-unity-bindings/1");
    assert!(host.files.contains_key("Assets/wf/wf-bindings.json.meta"));
    let cs = from_utf8(&host.files["Assets/wf/Scripts/WfBindings.cs"]).unwrap();
    assert!(cs.contains("class WfBindingsManifest"));

    let nodes = bindings["nodes"].as_array().unwrap();
    assert_eq!(nodes.len(), 3);
    let prop_node = nodes.iter().find(|n| n["id"] == id_prop).unwrap();
    assert_eq!(prop_node["props"][0]["anchorKind"], "center");
    let body = &prop_node["props"][0]["bodyBounds"];
    assert_eq!(body["valid"], true);
    assert_eq!(
        (
            body["x"].as_u64(),
            body["y"].as_u64(),
            body["width"].as_u64(),
            body["height"].as_u64()
        ),
        (Some(4), Some(2), Some(8), Some(6))
    );
    // anchor=(8,14), visual center=(8,5) => offsetFromPivotPx.y = -9, unityCenterOffset.y = +9/32 = +0.28125.
    assert!((body["unityCenterOffset"]["y"].as_f64().unwrap() - 0.28125).abs() < 1e-6);

    let icon_node = nodes.iter().find(|n| n["id"] == id_icon).unwrap();
    assert_eq!(icon_node["elements"][0]["name"], "Sword");
    assert_eq!(icon_node["elements"][0]["states"][0]["visualBounds"]["width"], 20);
    let icon_task = cli_manifest["tasks"]
        .as_array()
        .unwrap()
        .iter()
        .find(|t| t["id"] == id_icon)
        .unwrap();
    assert_eq!(icon_task["textures"][0]["multiple"], true);

    let img_node = nodes.iter().find(|n| n["id"] == id_img).unwrap();
    assert_eq!(img_node["images"][0]["resourcePath"], "bg/SpaceBg");
    assert_eq!(img_node["images"][0]["visualBounds"]["width"], 16);
    let img_task = cli_manifest["tasks"]
        .as_array()
        .unwrap()
        .iter()
        .find(|t| t["id"] == id_img)
        .unwrap();
    assert_eq!(img_task["textures"][0]["multiple"], false);

    // Partial sync for #12 preserves #1 and #11 inside wf-bindings.json.
    let partial = sync(
        &host,
        &Input {
            nodes: vec!["#12".into()],
            ..Input::default()
        },
    )
    .unwrap();
    assert!(partial.effects.is_empty());

    // Editing WfBindings.cs protects edits until --force.
    host.files
        .insert("Assets/wf/Scripts/WfBindings.cs".into(), b"// user edit\n".to_vec());
    let kept = sync(&host, &Input::default()).unwrap();
    assert!(kept.output.warnings.iter().any(|w| w.contains("WfBindings.cs")));
    let forced = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    host.apply(forced.effects);

    // Full sync with empty locks cleans wf-bindings.json, .meta, and WfBindings.cs.
    host.locks.as_mut().unwrap().nodes.clear();
    let cleaned = sync(&host, &Input::default()).unwrap();
    host.apply(cleaned.effects);
    assert!(!host.files.contains_key("Assets/wf/wf-bindings.json"));
    assert!(!host.files.contains_key("Assets/wf/wf-bindings.json.meta"));
    assert!(!host.files.contains_key("Assets/wf/Scripts/WfBindings.cs"));
}
