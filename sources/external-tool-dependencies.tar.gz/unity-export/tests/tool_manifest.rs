//! Check the dependency recipe against real editor output, including preview builds.
use plugin_api::{Manifest, VersionExtract};
use regex::Regex;
use semver::{Version, VersionReq};

#[test]
fn only_stable_unity_six_editors_satisfy_the_dependency() {
    let manifest = Manifest::parse(include_str!("../wf-plugin.toml")).unwrap();
    assert_eq!(manifest.permissions.exec, ["unity"]);
    assert_eq!(manifest.tools.len(), 1);
    let tool = &manifest.tools[0];
    assert_eq!(tool.name, "unity");
    let check = tool.version.as_ref().unwrap();
    assert_eq!(check.args, ["-version"]);
    let VersionExtract::Regex { pattern } = &check.extract else {
        panic!("expected an editor version pattern")
    };
    let pattern = Regex::new(pattern).unwrap();
    let required = VersionReq::parse(&check.require).unwrap();
    for (output, compatible) in [
        ("6000.0.1f1", true),
        ("6000.3.27f2\n", true),
        ("6000.6.7f1\r\n", true),
        ("2022.3.62f1", false),
        ("7000.0.0f1", false),
        ("6000.3.0b1", false),
        ("6000.3.0a1", false),
        ("6000.3.0rc1", false),
        ("6000.3.0f1 extra", false),
        ("Unity Hub 3.15.0", false),
    ] {
        let accepted = pattern
            .captures(output)
            .is_some_and(|capture| required.matches(&Version::parse(&capture["version"]).unwrap()));
        assert_eq!(accepted, compatible, "{output}");
    }
}
