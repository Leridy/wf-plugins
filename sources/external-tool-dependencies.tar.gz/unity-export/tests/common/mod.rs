//! The integration tests' in-memory host, with typed mirror answers and case loader.
use globset::Glob;
use plugin_api::{
    Effect, Failure,
    platform::{LocksOutput, NodeInput, NodeOutput},
};
use plugin_guest::{Host, HostError, Platform};
use sha2::{Digest, Sha256};
use std::{
    cell::RefCell,
    collections::{BTreeMap, BTreeSet},
    fmt::Write,
    fs,
    path::Path,
};

#[derive(Default)]
pub struct Fake {
    pub files: BTreeMap<String, Vec<u8>>,
    pub locks: Option<LocksOutput>,
    pub nodes: Vec<NodeOutput>,
    pub tools: BTreeSet<String>,
    pub cleanup: RefCell<Vec<String>>,
}

impl Fake {
    pub fn apply(&mut self, effects: Vec<Effect>) {
        for effect in effects {
            match effect {
                Effect::WriteFile { path, bytes, .. } => {
                    self.files.insert(path, bytes);
                }
                Effect::DeleteFile { path } => {
                    self.files.remove(&path);
                }
                Effect::Exec { .. } => {}
                _ => unreachable!("only writes, deletes and exec"),
            }
        }
        for path in self.cleanup.borrow_mut().drain(..) {
            self.files.remove(&path);
        }
    }

    /// Simulates Unity CLI batchmode execution by materializing `src=`-stamped
    /// outputs for every target marked `write: true` in `Assets/WfTmpSync/manifest.json`.
    #[allow(dead_code)]
    pub fn apply_cli(&mut self, output: &wf_unity_export::Output, effects: Vec<Effect>) {
        let manifest_bytes = effects.iter().find_map(|e| match e {
            Effect::WriteFile { path, bytes, .. } if path.ends_with("Assets/WfTmpSync/manifest.json") => {
                Some(bytes.clone())
            }
            _ => None,
        });
        self.apply(effects);
        let Some(raw) = manifest_bytes else {
            return;
        };
        let manifest: serde_json::Value = serde_json::from_slice(&raw).unwrap();
        let disk_for = |resource: &str| -> String {
            output
                .nodes
                .iter()
                .flat_map(|n| &n.files)
                .find(|f| f.resource == resource)
                .map(|f| f.path.clone())
                .unwrap_or_else(|| panic!("missing output file for {resource}"))
        };
        let stamp = |id: &str, version: u64, body: &str, src_hash: &str| -> Vec<u8> {
            let digest = Sha256::digest(body.as_bytes());
            let mut hex = String::with_capacity(64);
            for b in digest {
                write!(hex, "{b:02x}").expect("write");
            }
            format!("{body}# wf unity-export {id} v{version} sha256={hex} src={src_hash}\n").into_bytes()
        };
        for task in manifest["tasks"].as_array().unwrap() {
            let id = task["id"].as_str().unwrap();
            let version = task["version"].as_u64().unwrap();
            let src_hash = task["srcHash"].as_str().unwrap();
            for tex in task["textures"].as_array().unwrap() {
                if tex["write"].as_bool() != Some(true) {
                    continue;
                }
                let res = format!("{}.meta", tex["assetPath"].as_str().unwrap());
                let disk = disk_for(&res);
                self.files
                    .insert(disk, stamp(id, version, "fileFormatVersion: 2\n", src_hash));
            }
            for list_key in [
                "clips",
                "controllers",
                "tileAssets",
                "materials",
                "animPrefabs",
                "propPrefabs",
                "tilemapPrefabs",
                "uiPrefabs",
                "particlePrefabs",
                "wholeMapPrefabs",
                "parallaxPrefabs",
                "model3dPrefabs",
                "scene3dPrefabs",
            ] {
                for item in task[list_key].as_array().unwrap() {
                    if item["write"].as_bool() != Some(true) {
                        continue;
                    }
                    let asset_res = item["assetPath"].as_str().unwrap();
                    let asset_disk = disk_for(asset_res);
                    self.files.insert(
                        asset_disk,
                        stamp(
                            id,
                            version,
                            "%YAML 1.1\n%TAG !u! tag:unity3d.com,2011:\n--- !u!1 &100000\nGameObject:\n  m_Name: stub\n",
                            src_hash,
                        ),
                    );
                    let meta_res = format!("{asset_res}.meta");
                    let meta_disk = disk_for(&meta_res);
                    self.files
                        .insert(meta_disk, stamp(id, version, "fileFormatVersion: 2\n", src_hash));
                }
            }
        }
    }

    pub fn case(name: &str) -> Self {
        let path = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/cases").join(name);
        Self {
            files: files(&path.join("project")),
            locks: Some(serde_json::from_slice(&fs::read(path.join("locks.json")).unwrap()).unwrap()),
            nodes: serde_json::from_slice(&fs::read(path.join("nodes.json")).unwrap()).unwrap(),
            ..Self::default()
        }
    }
}

impl Host for Fake {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        self.files.keys().filter(|p| matcher.is_match(p)).cloned().collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.files
            .get(path)
            .cloned()
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }

    fn warn(&self, _: &str) {}

    fn tool_available(&self, tool: &str) -> bool {
        self.tools.contains(tool)
    }

    fn cleanup_after_exec(&self, path: &str) -> Result<(), HostError> {
        self.cleanup.borrow_mut().push(path.to_owned());
        Ok(())
    }
}

impl Platform for Fake {
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, HostError> {
        match method {
            "wf.mirror.locks" => self
                .locks
                .as_ref()
                .map(|locks| serde_json::to_vec(locks).unwrap())
                .ok_or_else(|| HostError::new(Failure::NotFound, "no export lock")),
            "wf.mirror.node" => {
                let query: NodeInput = serde_json::from_slice(input).unwrap();
                let node = self
                    .nodes
                    .iter()
                    .find(|n| {
                        query.address == format!("wf://{}", n.node.id)
                            || query.address == format!("#{}", n.node.number)
                            || query.address == n.node.path
                    })
                    .ok_or_else(|| HostError::new(Failure::NotFound, "node"))?;
                Ok(serde_json::to_vec(node).unwrap())
            }
            _ => unreachable!("only mirror reads"),
        }
    }
}

pub fn files(root: &Path) -> BTreeMap<String, Vec<u8>> {
    fn walk(root: &Path, dir: &Path, output: &mut BTreeMap<String, Vec<u8>>) {
        for item in fs::read_dir(dir).unwrap() {
            let path = item.unwrap().path();
            if path.is_dir() {
                walk(root, &path, output);
            } else {
                output.insert(
                    path.strip_prefix(root).unwrap().to_str().unwrap().replace('\\', "/"),
                    fs::read(path).unwrap(),
                );
            }
        }
    }
    let mut output = BTreeMap::new();
    walk(root, root, &mut output);
    output
}
