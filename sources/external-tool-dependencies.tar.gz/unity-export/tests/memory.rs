//! A large but valid sidecar stays below the component's 256 MiB store limit.
mod common;
use common::Fake;
use plugin_guest::counting::Counting;
use std::time::{Duration, Instant};
use wf_unity_export::{Input, sync};

#[global_allocator]
static ALLOCATOR: Counting = Counting;

#[test]
fn thirty_thousand_frames_fit_the_component_budget() {
    let mut host = Fake::case("real-source");
    let key = "spriteActions-1/source/01.png";
    let keys = vec![format!("\"{key}\""); 30_000].join(",");
    let durations = vec!["83.33333333333333"; 30_000].join(",");
    let report = format!(
        r#"{{"images":{{"{key}":{{"type":"png","path":"{key}"}}}},"clips":[{{"actionId":"walk","direction":"source","files":[{keys}],"durationsMs":[{durations}],"loop":true,"anchor":{{"x":4,"y":8}}}}]}}"#
    );
    host.files
        .insert("Assets/wf/hero/animation.json".into(), report.into_bytes());
    let start = Instant::now();
    let (result, peak) = Counting::peak(|| sync(&host, &Input::default()));
    let plan = result.unwrap();
    assert!(!plan.effects.is_empty());
    assert!(peak < 128 << 20, "peak: {peak} bytes");
    assert!(start.elapsed() < Duration::from_secs(20));
    host.apply(plan.effects);
}
