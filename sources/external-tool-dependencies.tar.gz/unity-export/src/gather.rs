//! Reads the mirror and sidecars, plans Unity CLI tasks, and reconciles guarded writes.
use crate::{
    cli_sync::{self, CliRun},
    gather_world::{SharedRuntimes, finish_sync, load_textures},
    paths::{self, invalid},
    types::{File, Input, Node, Output, Plan, Status},
    unity::{
        ExportTarget,
        bindings::{self, BindingNode, NodeBindingData},
        image,
    },
};
use plugin_api::{
    Failure,
    platform::{LockedRow, LocksInput, LocksOutput, Method, NodeInput, NodeOutput},
};
use plugin_guest::{HostError, Platform};
use serde::{Serialize, de::DeserializeOwned};
use std::{
    collections::{BTreeMap, BTreeSet},
    mem,
};

const MAX_SIDECAR: usize = 4 << 20;
const MAX_GLB: usize = 32 << 20;

pub fn sync(host: &dyn Platform, input: &Input) -> Result<Plan, HostError> {
    let mut plan = Plan {
        output: Output::default(),
        effects: Vec::new(),
    };
    let locks: LocksOutput = match answer(
        host,
        Method::MirrorLocks,
        &LocksInput {
            directory: input.directory.clone(),
        },
    ) {
        Ok(locks) => locks,
        Err(error) if error.kind == Failure::NotFound && !input.nodes.is_empty() => {
            selection(host, input, &[], &mut plan.output)?;
            return Ok(plan);
        }
        Err(error) => return Err(error),
    };
    let directory = locks.directory.trim_end_matches('/');
    if directory != "." && !directory.is_empty() {
        paths::relative(directory)?;
    }
    let directory = if directory == "." { "" } else { directory };
    let root = paths::root(host, directory)?;
    if cli_sync::unity_project_locked(host, &root)? {
        return Err(HostError::new(
            Failure::InvalidInput,
            "Unity project is currently locked by an open Unity Editor (Temp/UnityLockfile exists); \
             close Unity and re-run.",
        ));
    }
    let mut cli_run = CliRun::new(cli_sync::packages_has_ugui(host, &root)?);
    let selected = selection(host, input, &locks.nodes, &mut plan.output)?;
    let locked_ids: BTreeSet<String> = locks.nodes.iter().map(|n| n.id.clone()).collect();
    let mut binding_nodes = BTreeMap::new();
    let mut wanted = BTreeSet::new();
    let mut size = 0;
    let mut runtimes = SharedRuntimes::default();

    for row in locks.nodes.iter().filter(|r| selected.contains(&r.id)) {
        sync_node(
            host,
            &locks,
            directory,
            &root,
            input.force,
            row,
            &mut wanted,
            &mut runtimes,
            &mut binding_nodes,
            &mut cli_run,
            &mut plan,
        )?;
    }

    finish_sync(
        host,
        input,
        &locks,
        directory,
        &root,
        &locked_ids,
        &selected,
        binding_nodes,
        &runtimes,
        cli_run,
        &mut wanted,
        &mut size,
        &mut plan,
    )?;
    Ok(plan)
}

#[allow(clippy::too_many_arguments)]
fn sync_node(
    host: &dyn Platform,
    locks: &LocksOutput,
    directory: &str,
    root: &str,
    force: bool,
    row: &LockedRow,
    wanted: &mut BTreeSet<String>,
    runtimes: &mut SharedRuntimes,
    binding_nodes: &mut BTreeMap<String, BindingNode>,
    cli_run: &mut CliRun,
    plan: &mut Plan,
) -> Result<(), HostError> {
    let node: NodeOutput = answer(
        host,
        Method::MirrorNode,
        &NodeInput {
            address: format!("wf://{}", row.id),
        },
    )?;
    let kind = node.node.node_type;
    let mut result = Node {
        id: row.id.clone(),
        number: row.number,
        path: row.path.clone(),
        node_type: kind.clone(),
        status: Status::Skipped,
        files: Vec::new(),
        main_prefab: None,
        elements: Vec::new(),
        reasons: Vec::new(),
    };
    if kind == "image" && row.form == "source" {
        return sync_image_node(
            host,
            locks,
            directory,
            root,
            force,
            row,
            &kind,
            wanted,
            binding_nodes,
            cli_run,
            result,
            plan,
        );
    }
    let Some(SidecarInput { sidecar, prefix, bytes }) = read_node_sidecar(host, directory, row, &kind)? else {
        result.reasons.push(skipped(&kind).into());
        plan.output.push_node(result, Some(&row.form));
        return Ok(());
    };
    let node_dir = paths::join(directory, prefix);
    let raw_name = row.path.rsplit('/').next().unwrap_or("Node");
    let stem = paths::filename(raw_name);
    let node_prefix = format!("{}/{}", row.id, prefix);
    let target = ExportTarget {
        node_prefix: &node_prefix,
        node_dir: &node_dir,
        directory,
        root,
    };

    let planned = cli_sync::plan_sidecar_node(
        host,
        row,
        target,
        prefix,
        &stem,
        raw_name,
        &kind,
        sidecar,
        &bytes,
        cli_run.has_ugui,
        runtimes,
        &mut result,
    )?;
    let binding_data =
        cli_run.record_planned(host, directory, root, locks, row, force, planned, wanted, &mut result)?;
    finish_node(
        directory,
        root,
        row,
        prefix,
        kind,
        binding_data,
        binding_nodes,
        result,
        plan,
    );
    Ok(())
}

struct SidecarInput<'a> {
    sidecar: &'static str,
    prefix: &'a str,
    bytes: Vec<u8>,
}

fn read_node_sidecar<'a>(
    host: &dyn Platform,
    directory: &str,
    row: &'a LockedRow,
    kind: &str,
) -> Result<Option<SidecarInput<'a>>, HostError> {
    let Some(sidecar) = sidecar(kind, &row.form) else {
        return Ok(None);
    };
    let candidates: Vec<_> = row
        .files
        .iter()
        .filter(|f| f.rsplit('/').next() == Some(sidecar))
        .collect();
    let [sidecar_path] = candidates.as_slice() else {
        return Err(invalid(format!(
            "#{}: expected exactly one {sidecar} in the export lock",
            row.number
        )));
    };
    paths::relative(sidecar_path)?;
    let prefix = paths::parent(sidecar_path);
    let bytes = host.read(&paths::join(directory, sidecar_path))?;
    let max_bytes = if sidecar == "engine-scene.glb" {
        MAX_GLB
    } else {
        MAX_SIDECAR
    };
    if bytes.len() > max_bytes {
        return Err(invalid("sidecar exceeds size limit; export fewer entries"));
    }
    Ok(Some(SidecarInput { sidecar, prefix, bytes }))
}

#[allow(clippy::too_many_arguments)]
fn finish_node(
    directory: &str,
    root: &str,
    row: &LockedRow,
    prefix: &str,
    kind: String,
    binding_data: NodeBindingData,
    binding_nodes: &mut BTreeMap<String, BindingNode>,
    mut result: Node,
    plan: &mut Plan,
) {
    result.status = status(&result.files);
    if result.status != Status::Skipped {
        binding_nodes.insert(
            row.id.clone(),
            bindings::build_binding_node(
                row,
                kind,
                directory,
                root,
                prefix,
                result.main_prefab.as_deref(),
                binding_data,
            ),
        );
    }
    plan.output.push_node(result, Some(&row.form));
}

#[allow(clippy::too_many_arguments)]
fn sync_image_node(
    host: &dyn Platform,
    locks: &LocksOutput,
    directory: &str,
    root: &str,
    force: bool,
    row: &LockedRow,
    kind: &str,
    wanted: &mut BTreeSet<String>,
    binding_nodes: &mut BTreeMap<String, BindingNode>,
    cli_run: &mut CliRun,
    mut result: Node,
    plan: &mut Plan,
) -> Result<(), HostError> {
    let img_files: Vec<String> = row.files.iter().filter(|f| image::is_image_file(f)).cloned().collect();
    if img_files.is_empty() {
        result.reasons.push(skipped(kind).into());
        plan.output.push_node(result, Some(&row.form));
        return Ok(());
    }
    for rel in &img_files {
        paths::relative(rel)?;
    }
    let png_files: Vec<&str> = img_files
        .iter()
        .filter(|f| image::is_png_file(f))
        .map(String::as_str)
        .collect();
    let (dims, masks) = load_textures(host, row, directory, "", png_files.into_iter(), true, true)?;
    let target = ExportTarget {
        node_prefix: &row.id,
        node_dir: directory,
        directory,
        root,
    };
    let mut planned = cli_sync::assets::plan_image(&img_files, target, &row.id, row.version, &dims, &masks);
    result.reasons.extend(mem::take(&mut planned.notes));
    let binding = cli_run.record_planned(host, directory, root, locks, row, force, planned, wanted, &mut result)?;
    result.status = status(&result.files);
    if !binding.images.is_empty() {
        let rel_dir = paths::parent(&img_files[0]);
        binding_nodes.insert(
            row.id.clone(),
            bindings::build_binding_node(row, kind.to_owned(), directory, root, rel_dir, None, binding),
        );
    }
    plan.output.push_node(result, Some(&row.form));
    Ok(())
}

fn sidecar(kind: &str, form: &str) -> Option<&'static str> {
    match (kind, form) {
        ("frame_animation" | "character_effect", "frames" | "strips" | "atlas") => Some("animation.json"),
        ("ui", "pieces" | "atlas") => Some("ui.json"),
        ("icon", "pieces" | "atlas" | "slices") => Some("icons.json"),
        ("tilemap", "source") => Some("tilemap.json"),
        ("particle_effect" | "whole_map" | "scrolling_scene" | "scroll_map", "source") => Some("main.json"),
        ("prop", "pieces" | "atlas") => Some("props.json"),
        ("scene3d_map", "source") => Some("engine-scene.glb"),
        ("model_3d", "source") => Some("model.json"),
        _ => None,
    }
}

fn skipped(kind: &str) -> &'static str {
    match kind {
        "word_art" | "music" | "sound_effect" | "voice" | "tts" | "video" | "character_art" => {
            "Unity imports these files directly (textures, audio or video); no generated prefab is needed."
        }
        "image" => {
            "Export image nodes as `source` with PNG/image files to generate .png.meta and wf-bindings.json entries."
        }
        "icon" => "Export icon sets as `pieces` or `atlas` to generate .png.meta slices and wf-bindings.json entries.",
        "skeletal_animation" => "Spine needs the spine-unity runtime; this plugin does not generate it.",
        _ => {
            "This node type or export form has no Unity conversion; export animations as frames, strips or atlas, \
             UI kits, icons or props as pieces or atlas, images as source, and maps, particles or 3D assets as source."
        }
    }
}

fn status(files: &[File]) -> Status {
    for st in [Status::Kept, Status::Updated, Status::Written, Status::Unchanged] {
        if files.iter().any(|f| f.status == st) {
            return st;
        }
    }
    Status::Skipped
}

fn selection(
    host: &dyn Platform,
    input: &Input,
    rows: &[LockedRow],
    output: &mut Output,
) -> Result<BTreeSet<String>, HostError> {
    if input.nodes.is_empty() {
        return Ok(rows.iter().map(|n| n.id.clone()).collect());
    }
    let mut selected = BTreeSet::new();
    for address in &input.nodes {
        let row = rows.iter().find(|n| {
            *address == n.path || *address == format!("#{}", n.number) || *address == format!("wf://{}", n.id)
        });
        let id = if let Some(row) = row {
            row.id.clone()
        } else {
            let node: NodeOutput = answer(
                host,
                Method::MirrorNode,
                &NodeInput {
                    address: address.clone(),
                },
            )?;
            if !rows.iter().any(|n| n.id == node.node.id) {
                if !output.nodes.iter().any(|n| n.id == node.node.id) {
                    output.push_node(
                        Node {
                            id: node.node.id,
                            number: node.node.number,
                            path: node.node.path,
                            node_type: node.node.node_type,
                            status: Status::Skipped,
                            files: Vec::new(),
                            main_prefab: None,
                            elements: Vec::new(),
                            reasons: vec![format!(
                                "Not in this export lock; run wf export '#{}' first.",
                                node.node.number
                            )],
                        },
                        None,
                    );
                }
                continue;
            }
            node.node.id
        };
        selected.insert(id);
    }
    Ok(selected)
}

fn answer<I: Serialize, O: DeserializeOwned>(host: &dyn Platform, method: Method, input: &I) -> Result<O, HostError> {
    let input = serde_json::to_vec(input).map_err(|e| HostError::new(Failure::Internal, e.to_string()))?;
    serde_json::from_slice(&host.call(method.name(), &input)?)
        .map_err(|e| HostError::new(Failure::Internal, format!("invalid platform answer: {e}")))
}
