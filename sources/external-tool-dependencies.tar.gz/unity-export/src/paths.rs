//! Paths at the export boundary never escape the project's read grant or Unity Assets/.
use plugin_api::Failure;
use plugin_guest::{Host, HostError};

pub fn invalid(message: impl Into<String>) -> HostError {
    HostError::new(Failure::InvalidInput, message)
}

pub fn relative(path: &str) -> Result<(), HostError> {
    if path.is_empty()
        || path.contains(['\\', ':'])
        || path.chars().any(char::is_control)
        || path
            .split('/')
            .any(|s| s.is_empty() || s.starts_with('.') || s.ends_with(['.', ' ']))
    {
        return Err(invalid(format!("unsafe or unreadable export path: {path:?}")));
    }
    Ok(())
}

pub fn join(directory: &str, path: &str) -> String {
    if directory.is_empty() {
        path.into()
    } else {
        format!("{directory}/{path}")
    }
}

pub fn parent(path: &str) -> &str {
    path.rsplit_once('/').map_or("", |(parent, _)| parent)
}

/// Find the Unity project root above `directory` and ensure `directory` lies under `Assets/`.
pub fn root(host: &dyn Host, directory: &str) -> Result<String, HostError> {
    let mut dir = directory;
    loop {
        match host.read(&join(dir, "ProjectSettings/ProjectVersion.txt")) {
            Ok(_) => {
                let rel = asset_path(dir, directory);
                if rel != "Assets" && !rel.starts_with("Assets/") {
                    return Err(invalid(format!(
                        "Export directory {directory:?} is outside Unity's Assets/ folder; \
                         set export_dir under Assets/ (for example Assets/wf)."
                    )));
                }
                return Ok(dir.into());
            }
            Err(e) if e.not_found() => {}
            Err(e) => return Err(e),
        }
        if dir.is_empty() {
            break;
        }
        dir = parent(dir);
    }
    Err(invalid(
        "No ProjectSettings/ProjectVersion.txt above the export directory; set export_dir inside a Unity project's Assets/ folder.",
    ))
}

/// Project-relative Unity asset path (`Assets/...`).
pub fn asset_path(root: &str, path: &str) -> String {
    if root.is_empty() {
        path.into()
    } else {
        path.strip_prefix(root).unwrap_or(path).trim_start_matches('/').into()
    }
}

pub fn glob(path: &str) -> String {
    path.chars()
        .map(|c| match c {
            '*' | '?' | '[' | ']' | '{' | '}' => format!("[{c}]"),
            c => c.to_string(),
        })
        .collect()
}

/// Keep readable Unicode names, remove path syntax, and bound the UTF-8 length.
pub fn filename(name: &str) -> String {
    let mut safe = String::new();
    for c in name.chars() {
        let c = if c.is_alphanumeric() || matches!(c, '-' | '_') {
            c
        } else {
            '_'
        };
        if safe.len() + c.len_utf8() > 120 {
            break;
        }
        safe.push(c);
    }
    if safe.is_empty() {
        safe.push_str("Node");
    }
    let upper = safe.to_ascii_uppercase();
    if matches!(upper.as_str(), "CON" | "PRN" | "AUX" | "NUL")
        || (upper.len() == 4
            && (upper.starts_with("COM") || upper.starts_with("LPT"))
            && upper.as_bytes()[3].is_ascii_digit())
    {
        safe.insert_str(0, "Node_");
    }
    safe
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing::Fake;

    #[test]
    fn root_requires_project_version_and_assets_folder() {
        let mut host = Fake::default();
        assert!(root(&host, "Assets/wf").is_err());

        host.files.insert(
            "ProjectSettings/ProjectVersion.txt".into(),
            b"m_EditorVersion: 6000.6.7f1\n".into(),
        );
        assert_eq!(root(&host, "Assets/wf").unwrap(), "");
        assert!(root(&host, "wf").is_err());
        assert!(root(&host, "assets/wf").is_err());

        let mut nested = Fake::default();
        nested.files.insert(
            "game/ProjectSettings/ProjectVersion.txt".into(),
            b"m_EditorVersion: 6000.6.7f1\n".into(),
        );
        assert_eq!(root(&nested, "game/Assets/wf").unwrap(), "game");
        assert_eq!(
            asset_path("game", "game/Assets/wf/Hero.prefab"),
            "Assets/wf/Hero.prefab"
        );
    }
}
