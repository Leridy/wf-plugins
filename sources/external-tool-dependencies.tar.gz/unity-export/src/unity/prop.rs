//! Prop set sprite registration and binding builder for Unity CLI sync.
use super::bindings::{
    BindingPoint, BindingPolygon, BindingProp, BindingPropAnim, BindingPropState, BindingSize, SpriteTable,
    anchor_kind_str, to_binding_bounds,
};
use super::texture::{FilterMode, SliceSpec, SpriteKey, TextureRegistry, pivot_from_top_left};
use crate::model::{Point, PropSet, png::VisualBounds, prop::PropObject};

pub(crate) fn register_prop_sprites(
    registry: &mut TextureRegistry,
    props: &PropSet,
) -> (Vec<Vec<SpriteKey>>, Vec<Vec<Vec<SpriteKey>>>) {
    let mut state_keys = Vec::with_capacity(props.objects.len());
    let mut anim_keys = Vec::with_capacity(props.objects.len());
    for obj in &props.objects {
        let ppu = f64::from(obj.pixels_per_tile);
        let pivot = pivot_from_top_left(obj.anchor.x, obj.anchor.y, obj.canvas_width, obj.canvas_height);
        let obj_states = obj
            .states
            .iter()
            .map(|st| {
                registry.register(
                    &st.texture.path,
                    &format!("{}_{}", obj.id, st.id),
                    SliceSpec {
                        rect: st.texture.region,
                        pivot,
                        border: [0.0; 4],
                        ppu,
                        filter: FilterMode::Bilinear,
                    },
                )
            })
            .collect();
        state_keys.push(obj_states);

        let obj_anims = obj
            .animations
            .iter()
            .map(|tr| {
                tr.textures
                    .iter()
                    .enumerate()
                    .map(|(i, tex)| {
                        registry.register(
                            &tex.path,
                            &format!("{}_{}_{}", obj.id, tr.id, i + 1),
                            SliceSpec {
                                rect: tex.region,
                                pivot,
                                border: [0.0; 4],
                                ppu,
                                filter: FilterMode::Bilinear,
                            },
                        )
                    })
                    .collect()
            })
            .collect();
        anim_keys.push(obj_anims);
    }
    (state_keys, anim_keys)
}

pub(crate) fn build_prop_binding(
    obj: &PropObject,
    prefab: String,
    state_keys: &[SpriteKey],
    anim_keys: &[Vec<SpriteKey>],
    clip_assets: Vec<String>,
    table: &mut SpriteTable<'_>,
) -> BindingProp {
    let ppu = f64::from(obj.pixels_per_tile);
    let pivot = pivot_from_top_left(obj.anchor.x, obj.anchor.y, obj.canvas_width, obj.canvas_height);
    let mut raw_state_bounds = Vec::new();
    let mut states_out = Vec::with_capacity(obj.states.len());
    for (st, key) in obj.states.iter().zip(state_keys) {
        let sprite_index = table.add(key);
        if let Some(raw) = table.raw_bounds(sprite_index) {
            raw_state_bounds.push(raw);
        }
        let collision_px = polygons_from_points(&st.collision, 1.0, false);
        let collision_unity = polygons_from_points(&st.collision, ppu, true);
        states_out.push(BindingPropState {
            id: st.id.clone(),
            sprite_index,
            visual_bounds: table.sprites[sprite_index].visual_bounds.clone(),
            collision_unity,
            collision_px,
        });
    }
    let body_bounds = to_binding_bounds(
        VisualBounds::union(&raw_state_bounds, obj.canvas_width, obj.canvas_height),
        obj.anchor.x,
        obj.anchor.y,
        ppu,
    );
    let animations_out = obj
        .animations
        .iter()
        .zip(clip_assets)
        .zip(anim_keys)
        .map(|((tr, clip_asset), keys)| BindingPropAnim {
            id: tr.id.clone(),
            clip_asset,
            total_ms: tr.durations_ms.iter().sum(),
            durations_ms: tr.durations_ms.clone(),
            looped: tr.looped,
            frame_sprites: keys.iter().map(|k| table.add(k)).collect(),
        })
        .collect();

    BindingProp {
        id: obj.id.clone(),
        name: obj.name.clone(),
        prefab,
        canvas: BindingSize {
            width: obj.canvas_width,
            height: obj.canvas_height,
        },
        anchor: BindingPoint {
            x: obj.anchor.x,
            y: obj.anchor.y,
        },
        anchor_kind: anchor_kind_str(obj.anchor_kind).to_owned(),
        pivot: BindingPoint {
            x: pivot[0],
            y: pivot[1],
        },
        pixels_per_tile: obj.pixels_per_tile,
        body_bounds,
        states: states_out,
        animations: animations_out,
    }
}

fn polygons_from_points(polygons: &[Vec<Point>], scale: f64, flip_y: bool) -> Vec<BindingPolygon> {
    polygons
        .iter()
        .map(|poly| BindingPolygon {
            points: poly
                .iter()
                .map(|p| BindingPoint {
                    x: p.x / scale,
                    y: if flip_y { -p.y / scale } else { p.y / scale },
                })
                .collect(),
        })
        .collect()
}
