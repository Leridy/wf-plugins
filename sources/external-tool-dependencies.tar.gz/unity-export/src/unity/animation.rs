//! Frame animation & character effect sprite registration, naming, and binding helpers.
use super::bindings::{BindingClip, BindingPoint, BindingSize, SpriteTable, to_binding_bounds};
use super::texture::{FilterMode, SliceSpec, SpriteKey, TextureRegistry, pivot_from_top_left};
use crate::model::{Animation, Clip, Texture, png::VisualBounds};
use std::collections::{BTreeMap, BTreeSet};

pub(crate) const DEFAULT_PPU: f64 = 100.0;

pub(crate) fn register_clips(
    registry: &mut TextureRegistry,
    anim: &Animation,
    dims: &BTreeMap<String, (u32, u32)>,
) -> Vec<Vec<(SpriteKey, [f64; 2])>> {
    anim.clips
        .iter()
        .map(|clip| {
            clip.frames
                .iter()
                .map(|frame| {
                    let (fw, fh) = texture_frame_size(&frame.texture, dims);
                    let pivot = pivot_from_top_left(clip.anchor.x, clip.anchor.y, fw, fh);
                    let key = registry.register(
                        &frame.texture.path,
                        &clip.name,
                        SliceSpec {
                            rect: frame.texture.region,
                            pivot,
                            border: [0.0; 4],
                            ppu: DEFAULT_PPU,
                            filter: FilterMode::Bilinear,
                        },
                    );
                    (key, [fw / DEFAULT_PPU, fh / DEFAULT_PPU])
                })
                .collect()
        })
        .collect()
}

pub(crate) fn build_clip_binding(
    clip: &Clip,
    keys: &[(SpriteKey, [f64; 2])],
    clip_asset: String,
    durations: Vec<f64>,
    (fw, fh): (f64, f64),
    table: &mut SpriteTable<'_>,
) -> BindingClip {
    let pivot = pivot_from_top_left(clip.anchor.x, clip.anchor.y, fw, fh);
    let frame_sprites: Vec<usize> = keys.iter().map(|(k, _)| table.add(k)).collect();
    let unique_bounds: Vec<VisualBounds> = frame_sprites
        .iter()
        .copied()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .filter_map(|idx| table.raw_bounds(idx))
        .collect();
    let body_bounds = to_binding_bounds(
        VisualBounds::union(&unique_bounds, fw, fh),
        clip.anchor.x,
        clip.anchor.y,
        DEFAULT_PPU,
    );
    let total_ms = durations.iter().sum();
    BindingClip {
        action_id: clip.action_id.clone(),
        direction: clip.direction.clone(),
        name: clip.name.clone(),
        clip_asset,
        canvas: BindingSize { width: fw, height: fh },
        anchor: BindingPoint {
            x: clip.anchor.x,
            y: clip.anchor.y,
        },
        pivot: BindingPoint {
            x: pivot[0],
            y: pivot[1],
        },
        ppu: DEFAULT_PPU,
        looped: clip.looped,
        total_ms,
        body_bounds,
        durations_ms: durations,
        frame_sprites,
    }
}

pub fn texture_frame_size(tex: &Texture, dims: &BTreeMap<String, (u32, u32)>) -> (f64, f64) {
    if let Some(r) = tex.region {
        (r.w, r.h)
    } else {
        let (w, h) = dims[&tex.path];
        (f64::from(w), f64::from(h))
    }
}

pub fn rel_prefix<'a>(node_dir: &'a str, directory: &str) -> &'a str {
    node_dir
        .strip_prefix(directory)
        .unwrap_or(node_dir)
        .trim_start_matches('/')
}

pub fn join_rel(prefix: &str, path: &str) -> String {
    if prefix.is_empty() {
        path.to_owned()
    } else {
        format!("{prefix}/{path}")
    }
}

pub fn unique_name(used: &mut BTreeSet<String>, base: &str) -> String {
    if used.insert(base.to_owned()) {
        return base.to_owned();
    }
    for i in 2usize.. {
        let candidate = format!("{base}_{i}");
        if used.insert(candidate.clone()) {
            return candidate;
        }
    }
    unreachable!()
}
