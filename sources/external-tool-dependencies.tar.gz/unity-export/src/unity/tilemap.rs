//! Tile map sprite registration and grid-coordinate helpers for Unity CLI sync.
use super::texture::{FilterMode, SliceSpec, SpriteKey, TextureRegistry};
use crate::model::{Area, Rect, TileMap, tilemap::GroundTile};

pub(crate) fn register_map_sprites(
    map: &TileMap,
    ppu: f64,
    registry: &mut TextureRegistry,
) -> (Vec<SpriteKey>, Vec<SpriteKey>) {
    let to_rect = |a: Area| Rect {
        x: a.x,
        y: a.y,
        w: a.width,
        h: a.height,
    };
    let slice_of = |rect: Option<Rect>| SliceSpec {
        rect,
        pivot: [0.5, 0.5],
        border: [0.0; 4],
        ppu,
        filter: FilterMode::Point,
    };
    let ground_keys = map
        .ground
        .iter()
        .enumerate()
        .map(|(idx, tile)| {
            registry.register(
                &map.textures[&tile.texture].file,
                &format!("{}_{idx}", tile.texture),
                slice_of(Some(to_rect(tile.source))),
            )
        })
        .collect();
    let sprite_keys = map
        .sprites
        .iter()
        .enumerate()
        .map(|(idx, sprite)| {
            registry.register(
                &map.textures[&sprite.texture].file,
                &format!("{}_s{idx}", sprite.texture),
                slice_of(sprite.source.map(to_rect)),
            )
        })
        .collect();
    for terrain in &map.terrains {
        for tile in &terrain.tiles {
            registry.register(
                &map.textures[&tile.texture].file,
                &format!("{}_{}_m{}", terrain.id, tile.texture, tile.mask),
                slice_of(Some(to_rect(tile.source))),
            );
        }
    }
    (ground_keys, sprite_keys)
}

#[allow(clippy::cast_precision_loss)]
fn cell_f64(v: i64) -> f64 {
    v as f64
}

pub(crate) fn unity_cell(wf_cell: [i64; 2], is_iso: bool) -> [i64; 2] {
    if is_iso {
        [-wf_cell[1], -wf_cell[0]]
    } else {
        [wf_cell[0], -wf_cell[1]]
    }
}

pub(crate) fn ground_shift(first: &GroundTile, cell_w: f64, cell_h: f64, ppu: f64, is_iso: bool) -> [f64; 2] {
    let tgt_x = (first.target.x + first.target.width * 0.5) / ppu;
    let tgt_y = -(first.target.y + first.target.height * 0.5) / ppu;
    let [ux, uy] = unity_cell(first.cell, is_iso);
    let (uxf, uyf) = (cell_f64(ux), cell_f64(uy));
    let (loc_x, loc_y) = if is_iso {
        ((uxf - uyf) * 0.5 * cell_w, (uxf + uyf + 1.0) * 0.5 * cell_h)
    } else {
        ((uxf + 0.5) * cell_w, (uyf + 0.5) * cell_h)
    };
    [tgt_x - loc_x, tgt_y - loc_y]
}
