//! Standalone image node registration and binding records.
use super::bindings::{
    BindingImage, BindingPoint, BindingSize, BindingVisualBounds, NodeBindingData, SpriteTable, resources_load_path,
};
use super::texture::{FilterMode, SliceSpec, SpriteKey, TextureRegistry};
use crate::model::AlphaMask;
use crate::paths;
use std::collections::BTreeMap;
use std::path::Path;

pub fn is_image_file(rel: &str) -> bool {
    Path::new(rel).extension().is_some_and(|e| {
        e.eq_ignore_ascii_case("png")
            || e.eq_ignore_ascii_case("jpg")
            || e.eq_ignore_ascii_case("jpeg")
            || e.eq_ignore_ascii_case("webp")
            || e.eq_ignore_ascii_case("tga")
            || e.eq_ignore_ascii_case("psd")
    })
}

pub fn is_png_file(rel: &str) -> bool {
    Path::new(rel)
        .extension()
        .is_some_and(|e| e.eq_ignore_ascii_case("png"))
}

pub(crate) fn register_images(
    rel_files: &[String],
    dims: &BTreeMap<String, (u32, u32)>,
    registry: &mut TextureRegistry,
) -> (Vec<(String, SpriteKey)>, Vec<String>) {
    let mut png_keys: Vec<(String, SpriteKey)> = Vec::new();
    let mut other_images: Vec<String> = Vec::new();
    for rel in rel_files {
        if dims.contains_key(rel) {
            let key = registry.register(
                rel,
                paths::filename(rel).as_str(),
                SliceSpec {
                    rect: None,
                    pivot: [0.5, 0.5],
                    border: [0.0; 4],
                    ppu: 100.0,
                    filter: FilterMode::Bilinear,
                },
            );
            png_keys.push((rel.clone(), key));
        } else {
            other_images.push(rel.clone());
        }
    }
    (png_keys, other_images)
}

pub(crate) fn build_image_binding(
    directory: &str,
    root: &str,
    png_keys: &[(String, SpriteKey)],
    other_images: Vec<String>,
    resolved: &super::texture::ResolvedSprites,
    masks: &BTreeMap<String, AlphaMask>,
) -> NodeBindingData {
    let mut table = SpriteTable::new(resolved, masks);
    let mut images = Vec::with_capacity(png_keys.len() + other_images.len());

    for (rel, key) in png_keys {
        let sprite_index = table.add(key);
        let sprite = &table.sprites[sprite_index];
        let name = rel.rsplit('/').next().unwrap_or(rel).to_owned();
        images.push(BindingImage {
            name,
            asset_path: sprite.asset_path.clone(),
            resource_path: sprite.resource_path.clone(),
            sprite_index: i32::try_from(sprite_index).unwrap_or(-1),
            size: sprite.texture_size.clone(),
            pivot: sprite.pivot.clone(),
            ppu: sprite.ppu,
            visual_bounds: sprite.visual_bounds.clone(),
        });
    }

    for rel in other_images {
        let full = paths::join(directory, &rel);
        let asset_path = paths::asset_path(root, &full);
        let name = rel.rsplit('/').next().unwrap_or(&rel).to_owned();
        images.push(BindingImage {
            name,
            resource_path: resources_load_path(&asset_path).unwrap_or_default(),
            asset_path,
            sprite_index: -1,
            size: BindingSize::default(),
            pivot: BindingPoint::default(),
            ppu: 100.0,
            visual_bounds: BindingVisualBounds::default(),
        });
    }

    NodeBindingData {
        sprites: table.sprites,
        images,
        ..NodeBindingData::default()
    }
}
