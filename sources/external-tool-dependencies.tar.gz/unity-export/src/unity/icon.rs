//! Icon set texture registration and binding entries.
use super::bindings::{BindingElement, BindingElementState, BindingRect, BindingSize, NodeBindingData, SpriteTable};
use super::texture::{FilterMode, SliceSpec, SpriteKey, TextureRegistry};
use crate::model::{AlphaMask, IconSet};
use crate::types::Element;
use std::collections::BTreeMap;

pub(crate) fn register_icons(icons: &IconSet, registry: &mut TextureRegistry) -> Vec<Vec<SpriteKey>> {
    let mut keys: Vec<Vec<SpriteKey>> = Vec::with_capacity(icons.elements.len());
    for entry in &icons.elements {
        let mut state_keys = Vec::with_capacity(entry.states.len());
        for st in &entry.states {
            let hint = if entry.states.len() == 1 {
                format!("{}_{}", entry.kind, entry.name)
            } else {
                format!("{}_{}", entry.name, st.name)
            };
            state_keys.push(registry.register(
                &st.texture.path,
                &hint,
                SliceSpec {
                    rect: st.texture.region,
                    pivot: [0.5, 0.5],
                    border: [0.0; 4],
                    ppu: 100.0,
                    filter: FilterMode::Bilinear,
                },
            ));
        }
        keys.push(state_keys);
    }
    keys
}

pub(crate) fn build_icon_binding(
    icons: &IconSet,
    keys: &[Vec<SpriteKey>],
    resolved: &super::texture::ResolvedSprites,
    masks: &BTreeMap<String, AlphaMask>,
) -> (Vec<Element>, NodeBindingData) {
    let mut table = SpriteTable::new(resolved, masks);
    let mut elements = Vec::with_capacity(icons.elements.len());
    let mut binding_elements = Vec::with_capacity(icons.elements.len());

    for (entry, state_keys) in icons.elements.iter().zip(keys) {
        elements.push(Element {
            name: entry.name.clone(),
            prefab: None,
        });
        let mut states = Vec::with_capacity(entry.states.len());
        for (st, key) in entry.states.iter().zip(state_keys) {
            let sprite_index = table.add(key);
            let sprite = &table.sprites[sprite_index];
            states.push(BindingElementState {
                name: st.name.clone(),
                role: st
                    .role
                    .map_or_else(String::new, |r| format!("{r:?}").to_ascii_lowercase()),
                sprite_index,
                rect: sprite.rect.clone(),
                border: sprite.border.clone(),
                text_safe: BindingRect::default(),
                visual_bounds: sprite.visual_bounds.clone(),
            });
        }
        binding_elements.push(BindingElement {
            name: entry.name.clone(),
            kind: entry.kind.clone(),
            size: BindingSize {
                width: entry.width,
                height: entry.height,
            },
            prefab: String::new(),
            states,
        });
    }

    (
        elements,
        NodeBindingData {
            sprites: table.sprites,
            elements: binding_elements,
            ..NodeBindingData::default()
        },
    )
}
