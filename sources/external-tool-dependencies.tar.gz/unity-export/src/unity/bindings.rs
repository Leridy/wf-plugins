//! Generates `wf-bindings.json` (`wf-unity-bindings/1`) and `Scripts/WfBindings.cs`
//! for C# and xLua custom loaders, with PNG alpha `visualBounds` measurements.
use super::texture::{ResolvedSprites, SpriteKey};
use super::{Document, StampFormat, cs_meta, doc, guid, native_meta};
use crate::model::png::{AlphaMask, VisualBounds};
use crate::model::{PropAnchorKind, Rect};
use crate::paths;
use crate::reconcile;
use crate::types::Status;
use plugin_api::{Effect, platform::LockedRow};
use plugin_guest::{Host, HostError};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, BTreeSet};

pub const SCHEMA: &str = "wf-unity-bindings/1";
pub const MANIFEST_REL: &str = "wf-bindings.json";
pub const SHARED_OWNER_ID: &str = "shared-bindings";
const SCRIPT_REL: &str = "Scripts/WfBindings.cs";
const SCRIPT_BODY: &str = include_str!("WfBindings.cs");

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingsManifest {
    pub schema: String,
    pub directory: String,
    #[serde(default)]
    pub nodes: Vec<BindingNode>,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingPoint {
    pub x: f64,
    pub y: f64,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingSize {
    pub width: f64,
    pub height: f64,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingRect {
    pub valid: bool,
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingBorder {
    pub left: f64,
    pub bottom: f64,
    pub right: f64,
    pub top: f64,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingVisualBounds {
    pub valid: bool,
    pub x: u32,
    pub y: u32,
    pub width: u32,
    pub height: u32,
    pub center_x: f64,
    pub center_y: f64,
    pub fill_ratio: f64,
    pub offset_from_pivot_px: BindingPoint,
    pub unity_center_offset: BindingPoint,
    pub unity_visual_size: BindingPoint,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingSprite {
    pub asset_path: String,
    pub resource_path: String,
    pub sprite_name: String,
    pub tex_guid: String,
    pub internal_id: i64,
    pub rect: BindingRect,
    pub texture_size: BindingSize,
    pub pivot: BindingPoint,
    pub ppu: f64,
    pub border: BindingBorder,
    pub visual_bounds: BindingVisualBounds,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingPolygon {
    pub points: Vec<BindingPoint>,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingPropState {
    pub id: String,
    pub sprite_index: usize,
    pub visual_bounds: BindingVisualBounds,
    pub collision_unity: Vec<BindingPolygon>,
    pub collision_px: Vec<BindingPolygon>,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingPropAnim {
    pub id: String,
    pub clip_asset: String,
    pub durations_ms: Vec<f64>,
    pub total_ms: f64,
    #[serde(rename = "loop")]
    pub looped: bool,
    pub frame_sprites: Vec<usize>,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingProp {
    pub id: String,
    pub name: String,
    pub prefab: String,
    pub canvas: BindingSize,
    pub anchor: BindingPoint,
    pub anchor_kind: String,
    pub pivot: BindingPoint,
    pub pixels_per_tile: u32,
    pub body_bounds: BindingVisualBounds,
    pub states: Vec<BindingPropState>,
    pub animations: Vec<BindingPropAnim>,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingClip {
    pub action_id: String,
    pub direction: String,
    pub name: String,
    pub clip_asset: String,
    pub canvas: BindingSize,
    pub anchor: BindingPoint,
    pub pivot: BindingPoint,
    pub ppu: f64,
    #[serde(rename = "loop")]
    pub looped: bool,
    pub total_ms: f64,
    pub body_bounds: BindingVisualBounds,
    pub durations_ms: Vec<f64>,
    pub frame_sprites: Vec<usize>,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingElementState {
    pub name: String,
    pub role: String,
    pub sprite_index: usize,
    pub rect: BindingRect,
    pub border: BindingBorder,
    pub text_safe: BindingRect,
    pub visual_bounds: BindingVisualBounds,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingElement {
    pub name: String,
    pub kind: String,
    pub size: BindingSize,
    pub prefab: String,
    pub states: Vec<BindingElementState>,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingImage {
    pub name: String,
    pub asset_path: String,
    pub resource_path: String,
    pub sprite_index: i32,
    pub size: BindingSize,
    pub pivot: BindingPoint,
    pub ppu: f64,
    pub visual_bounds: BindingVisualBounds,
}

#[derive(Clone, Debug, Default, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BindingNode {
    pub id: String,
    pub number: u64,
    pub path: String,
    pub node_type: String,
    pub form: String,
    pub asset_base: String,
    pub resource_base: String,
    pub main_prefab: String,
    #[serde(default)]
    pub sprites: Vec<BindingSprite>,
    #[serde(default)]
    pub props: Vec<BindingProp>,
    #[serde(default)]
    pub clips: Vec<BindingClip>,
    #[serde(default)]
    pub elements: Vec<BindingElement>,
    #[serde(default)]
    pub images: Vec<BindingImage>,
}

#[derive(Default)]
pub struct NodeBindingData {
    pub sprites: Vec<BindingSprite>,
    pub props: Vec<BindingProp>,
    pub clips: Vec<BindingClip>,
    pub elements: Vec<BindingElement>,
    pub images: Vec<BindingImage>,
}

pub fn build_binding_node(
    row: &LockedRow,
    kind: String,
    directory: &str,
    root: &str,
    rel_dir: &str,
    main_prefab: Option<&str>,
    data: NodeBindingData,
) -> BindingNode {
    let asset_base = paths::asset_path(root, &paths::join(directory, rel_dir));
    let resource_base = resources_load_path(&format!("{asset_base}/_")).map_or_else(String::new, |p| {
        p.trim_end_matches("/_").trim_end_matches('_').to_owned()
    });
    BindingNode {
        id: row.id.clone(),
        number: row.number,
        path: row.path.clone(),
        node_type: kind,
        form: row.form.clone(),
        asset_base,
        resource_base,
        main_prefab: main_prefab.unwrap_or_default().to_owned(),
        sprites: data.sprites,
        props: data.props,
        clips: data.clips,
        elements: data.elements,
        images: data.images,
    }
}

pub struct SpriteTable<'a> {
    resolved: &'a ResolvedSprites,
    masks: &'a BTreeMap<String, AlphaMask>,
    index: BTreeMap<(String, Option<[u64; 4]>), usize>,
    pub sprites: Vec<BindingSprite>,
    pub raw_bounds: Vec<Option<VisualBounds>>,
}

impl<'a> SpriteTable<'a> {
    pub fn new(resolved: &'a ResolvedSprites, masks: &'a BTreeMap<String, AlphaMask>) -> Self {
        Self {
            resolved,
            masks,
            index: BTreeMap::new(),
            sprites: Vec::new(),
            raw_bounds: Vec::new(),
        }
    }

    pub fn add(&mut self, key: &SpriteKey) -> usize {
        let info = self.resolved.slice_info(key);
        let rect_key = (
            info.tex_path.clone(),
            Some([
                info.rect[0].to_bits(),
                info.rect[1].to_bits(),
                info.rect[2].to_bits(),
                info.rect[3].to_bits(),
            ]),
        );
        if let Some(&idx) = self.index.get(&rect_key) {
            return idx;
        }
        let rect = Rect {
            x: info.rect[0],
            y: info.rect[1],
            w: info.rect[2],
            h: info.rect[3],
        };
        let raw = self
            .masks
            .get(&info.tex_path)
            .and_then(|m| m.bounds_in_rect(Some(rect)));
        let anchor_x = info.pivot[0] * info.rect[2];
        let anchor_y = (1.0 - info.pivot[1]) * info.rect[3];
        let visual_bounds = to_binding_bounds(raw, anchor_x, anchor_y, info.ppu);
        let idx = self.sprites.len();
        self.sprites.push(BindingSprite {
            asset_path: info.asset_path.clone(),
            resource_path: resources_load_path(&info.asset_path).unwrap_or_default(),
            sprite_name: info.sprite_name.clone(),
            tex_guid: info.tex_guid.clone(),
            internal_id: info.internal_id,
            rect: BindingRect {
                valid: true,
                x: info.rect[0],
                y: info.rect[1],
                w: info.rect[2],
                h: info.rect[3],
            },
            texture_size: BindingSize {
                width: f64::from(info.texture_dims.0),
                height: f64::from(info.texture_dims.1),
            },
            pivot: BindingPoint {
                x: info.pivot[0],
                y: info.pivot[1],
            },
            ppu: info.ppu,
            border: BindingBorder {
                left: info.border[0],
                bottom: info.border[1],
                right: info.border[2],
                top: info.border[3],
            },
            visual_bounds,
        });
        self.raw_bounds.push(raw);
        self.index.insert(rect_key, idx);
        idx
    }

    pub fn raw_bounds(&self, idx: usize) -> Option<VisualBounds> {
        self.raw_bounds.get(idx).copied().flatten()
    }
}

pub fn to_binding_bounds(bounds: Option<VisualBounds>, anchor_x: f64, anchor_y: f64, ppu: f64) -> BindingVisualBounds {
    let Some(b) = bounds else {
        return BindingVisualBounds::default();
    };
    let delta_x = b.center_x - anchor_x;
    let delta_y = b.center_y - anchor_y;
    let safe_ppu = if ppu > 0.0 { ppu } else { 100.0 };
    BindingVisualBounds {
        valid: true,
        x: b.x,
        y: b.y,
        width: b.width,
        height: b.height,
        center_x: b.center_x,
        center_y: b.center_y,
        fill_ratio: b.fill_ratio,
        offset_from_pivot_px: BindingPoint { x: delta_x, y: delta_y },
        unity_center_offset: BindingPoint {
            x: delta_x / safe_ppu,
            y: -delta_y / safe_ppu,
        },
        unity_visual_size: BindingPoint {
            x: f64::from(b.width) / safe_ppu,
            y: f64::from(b.height) / safe_ppu,
        },
    }
}

pub fn anchor_kind_str(kind: PropAnchorKind) -> &'static str {
    match kind {
        PropAnchorKind::Foot => "foot",
        PropAnchorKind::Hang => "hang",
        PropAnchorKind::Center => "center",
    }
}

pub fn resources_load_path(asset_path: &str) -> Option<String> {
    let tail = asset_path.split_once("/Resources/").map(|(_, rest)| rest)?;
    let no_ext = match (tail.rfind('/'), tail.rfind('.')) {
        (Some(slash), Some(dot)) if dot > slash => &tail[..dot],
        (None, Some(dot)) => &tail[..dot],
        _ => tail,
    };
    (!no_ext.is_empty()).then(|| no_ext.to_owned())
}

pub fn runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let mut cs_doc = doc(directory, root, SCRIPT_REL.into(), SCRIPT_BODY.into(), false);
    cs_doc.stamp = StampFormat::Code;
    vec![
        cs_doc,
        doc(
            directory,
            root,
            format!("{SCRIPT_REL}.meta"),
            cs_meta(&guid(&format!("{SHARED_OWNER_ID}:{SCRIPT_REL}"))),
            false,
        ),
    ]
}

#[allow(clippy::too_many_arguments)]
pub fn sync_manifest(
    host: &dyn Host,
    directory: &str,
    root: &str,
    force: bool,
    full_sync: bool,
    locked_ids: &BTreeSet<String>,
    selected_ids: &BTreeSet<String>,
    updated_nodes: BTreeMap<String, BindingNode>,
    wanted: &mut BTreeSet<String>,
    warnings: &mut Vec<String>,
    effects: &mut Vec<Effect>,
) -> Result<bool, HostError> {
    let dir_asset = paths::asset_path(root, directory);
    let manifest_disk = paths::join(directory, MANIFEST_REL);
    let meta_disk = format!("{manifest_disk}.meta");

    let mut nodes_by_id: BTreeMap<String, BindingNode> = if let Ok(raw) = host.read(&manifest_disk)
        && let Ok(existing) = serde_json::from_slice::<BindingsManifest>(&raw)
        && existing.schema == SCHEMA
    {
        existing.nodes.into_iter().map(|n| (n.id.clone(), n)).collect()
    } else {
        BTreeMap::new()
    };

    if full_sync {
        nodes_by_id.retain(|id, _| locked_ids.contains(id) && !selected_ids.contains(id));
    } else {
        nodes_by_id.retain(|id, _| !selected_ids.contains(id));
    }
    for (id, node) in updated_nodes {
        nodes_by_id.insert(id, node);
    }

    if nodes_by_id.is_empty() {
        if full_sync {
            for path in [manifest_disk, meta_disk] {
                if host.read(&path).is_ok() {
                    effects.push(Effect::DeleteFile { path });
                }
            }
        }
        return Ok(false);
    }

    wanted.insert(manifest_disk.clone());
    wanted.insert(meta_disk.clone());

    let mut nodes: Vec<BindingNode> = nodes_by_id.into_values().collect();
    nodes.sort_by(|a, b| (a.number, &a.id).cmp(&(b.number, &b.id)));
    let manifest = BindingsManifest {
        schema: SCHEMA.to_owned(),
        directory: dir_asset,
        nodes,
    };
    let mut json_bytes = serde_json::to_vec(&manifest).expect("manifest serializes");
    json_bytes.push(b'\n');

    let existing = match host.read(&manifest_disk) {
        Ok(old) => Some(old),
        Err(e) if e.not_found() => None,
        Err(e) => return Err(e),
    };
    if existing.as_deref() != Some(json_bytes.as_slice()) {
        paths::relative(&manifest_disk)?;
        effects.push(Effect::WriteFile {
            path: manifest_disk,
            bytes: json_bytes,
            overwrite: existing.is_some(),
        });
    }

    let meta_body = native_meta(&guid(&format!("{SHARED_OWNER_ID}:{MANIFEST_REL}")), 4_900_000);
    let meta_bytes = reconcile::stamped(SHARED_OWNER_ID, 1, &meta_body, StampFormat::TrailingComment);
    if reconcile::file(host, &meta_disk, meta_bytes, force, effects)? == Status::Kept {
        warnings.push(format!(
            "{meta_disk}: bindings .meta has local edits; use --force to replace it."
        ));
    }
    Ok(true)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resources_load_path_extracts_extensionless_subpath() {
        assert_eq!(
            resources_load_path("Assets/Resources/wf/ships/Scout.png").as_deref(),
            Some("wf/ships/Scout")
        );
        assert_eq!(resources_load_path("Assets/wf/ships/Scout.png"), None);
    }
}
