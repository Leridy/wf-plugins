using System;
using UnityEngine;

namespace WeaveForge.Export
{
    [Serializable]
    public struct WfNavRect
    {
        public int x;
        public int y;
        public int width;
        public int height;
    }

    [Serializable]
    public struct WfNavConnection
    {
        public string id;
        public string kind;
        public string from;
        public string to;
        public Vector2 a;
        public Vector2 b;
    }

    /// <summary>
    /// Stores decoded 8 px navigation walkable spans, stairs/ramp connections,
    /// and character metrics exported from WeaveForge whole_map.
    /// </summary>
    public sealed class WfWholeMapNav : MonoBehaviour
    {
        public string perspective = "orthographic";
        public int tileWidth;
        public int tileHeight;
        public int characterRadius = 12;
        public int characterSpeed = 180;
        public float pixelsPerUnit = 100f;
        public WfNavRect[] walkableRects = Array.Empty<WfNavRect>();
        public WfNavConnection[] connections = Array.Empty<WfNavConnection>();

        public bool IsWalkableWorld(Vector2 worldPos)
        {
            float px = worldPos.x * pixelsPerUnit;
            float py = -worldPos.y * pixelsPerUnit;
            for (int i = 0; i < walkableRects.Length; i++)
            {
                WfNavRect r = walkableRects[i];
                if (px >= r.x && px <= r.x + r.width && py >= r.y && py <= r.y + r.height)
                    return true;
            }
            return false;
        }
    }
}
