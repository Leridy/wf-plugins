//! Shared `WfParticlePlayer.cs` and `WfParticleUnlit.shader` runtime documents.
use super::{Document, cs_meta, doc, guid, shader_meta};

pub const PLAYER_SCRIPT_PATH: &str = "Scripts/WfParticlePlayer.cs";
pub const PLAYER_SCRIPT_META_PATH: &str = "Scripts/WfParticlePlayer.cs.meta";
pub const SHADER_PATH: &str = "Shaders/WfParticleUnlit.shader";
pub const SHADER_META_PATH: &str = "Shaders/WfParticleUnlit.shader.meta";

const PLAYER_CS_SOURCE: &str = include_str!("WfParticlePlayer.cs");
const PARTICLE_SHADER_SOURCE: &str = include_str!("WfParticleUnlit.shader");

pub const SHARED_OWNER_ID: &str = "shared-particle-runtime";

pub fn shared_runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let cs_guid = guid("shared:WfParticlePlayer.cs");
    let sh_guid = guid("shared:WfParticleUnlit.shader");
    vec![
        doc(
            directory,
            root,
            PLAYER_SCRIPT_PATH.into(),
            PLAYER_CS_SOURCE.into(),
            false,
        ),
        doc(
            directory,
            root,
            PLAYER_SCRIPT_META_PATH.into(),
            cs_meta(&cs_guid),
            false,
        ),
        doc(
            directory,
            root,
            SHADER_PATH.into(),
            PARTICLE_SHADER_SOURCE.into(),
            false,
        ),
        doc(directory, root, SHADER_META_PATH.into(), shader_meta(&sh_guid), false),
    ]
}
