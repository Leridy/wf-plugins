//! Shared `WfParallaxLayer.cs` runtime document.
use super::{Document, cs_meta, doc, guid};

pub const SHARED_OWNER_ID: &str = "shared-parallax-runtime";
const LAYER_SCRIPT_PATH: &str = "Scripts/WfParallaxLayer.cs";
const LAYER_SCRIPT_META_PATH: &str = "Scripts/WfParallaxLayer.cs.meta";
const LAYER_CS_SOURCE: &str = include_str!("WfParallaxLayer.cs");

pub fn shared_runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let cs_guid = guid("shared:WfParallaxLayer.cs");
    vec![
        doc(directory, root, LAYER_SCRIPT_PATH.into(), LAYER_CS_SOURCE.into(), false),
        doc(directory, root, LAYER_SCRIPT_META_PATH.into(), cs_meta(&cs_guid), false),
    ]
}
