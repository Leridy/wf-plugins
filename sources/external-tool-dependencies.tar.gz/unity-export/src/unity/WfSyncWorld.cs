#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace WeaveForge.Editor
{
    internal static class WfSyncWorld
    {
        public static void ProcessTask(SyncTask task, List<StampTarget> stamps)
        {
            ProcessMaterials(task, stamps);
            ProcessParticles(task, stamps);
            ProcessWholeMaps(task, stamps);
            ProcessParallax(task, stamps);
            ProcessModel3d(task, stamps);
            ProcessScene3d(task, stamps);
        }

        private static void ProcessMaterials(SyncTask task, List<StampTarget> stamps)
        {
            if (task.materials == null) return;
            foreach (var m in task.materials)
            {
                if (!m.write) continue;
                WfSyncRunner.EnsureParentDir(m.assetPath);
                var sh = AssetDatabase.LoadAssetAtPath<Shader>(m.shaderAssetPath);
                var mat = sh != null ? new Material(sh) : new Material(Shader.Find("Sprites/Default"));
                mat.name = m.name;
                var maskTex = AssetDatabase.LoadAssetAtPath<Texture2D>(m.maskTexAssetPath);
                if (maskTex != null) mat.SetTexture("_MaskTex", maskTex);
                mat.SetColor("_TexelSize", new Color(1f / Mathf.Max(1, m.width), 1f / Mathf.Max(1, m.height), m.width, m.height));
                mat.SetColor("_Color", Color.white);
                AssetDatabase.CreateAsset(mat, m.assetPath);
                WfSyncRunner.QueueAssetAndMeta(stamps, m.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessParticles(SyncTask task, List<StampTarget> stamps)
        {
            if (task.particlePrefabs == null) return;
            var playerType = WfSyncRunner.FindType("WeaveForge.WfParticlePlayer", "Assembly-CSharp");
            foreach (var p in task.particlePrefabs)
            {
                if (!p.write) continue;
                WfSyncRunner.EnsureParentDir(p.assetPath);
                var go = new GameObject(p.displayName);
                if (playerType != null)
                {
                    var comp = go.AddComponent(playerType);
                    var so = new SerializedObject(comp);
                    so.FindProperty("autoplay").boolValue = true;
                    so.FindProperty("unitScale").floatValue = 1f;
                    so.FindProperty("particleShader").objectReferenceValue = AssetDatabase.LoadAssetAtPath<Shader>(p.shaderAssetPath);
                    so.FindProperty("duration").floatValue = (float)p.duration;
                    so.FindProperty("looping").boolValue = p.looping;
                    so.FindProperty("planar").boolValue = p.planar;
                    var emArr = so.FindProperty("emitters");
                    emArr.arraySize = p.emitters.Count;
                    for (int i = 0; i < p.emitters.Count; i++)
                    {
                        var e = p.emitters[i];
                        var el = emArr.GetArrayElementAtIndex(i);
                        el.FindPropertyRelative("id").stringValue = e.id;
                        el.FindPropertyRelative("randomState").longValue = e.randomState;
                        el.FindPropertyRelative("rate").floatValue = (float)e.rate;
                        el.FindPropertyRelative("burst").intValue = e.burst;
                        el.FindPropertyRelative("delay").floatValue = (float)e.delay;
                        el.FindPropertyRelative("lifetime").vector2Value = new Vector2((float)e.lifetimeMin, (float)e.lifetimeMax);
                        el.FindPropertyRelative("position").vector3Value = ToV3(e.position);
                        el.FindPropertyRelative("spread").vector3Value = ToV3(e.spread);
                        el.FindPropertyRelative("velocity").vector3Value = ToV3(e.velocity);
                        el.FindPropertyRelative("velocitySpread").vector3Value = ToV3(e.velocitySpread);
                        el.FindPropertyRelative("gravity").vector3Value = ToV3(e.gravity);
                        el.FindPropertyRelative("drag").floatValue = (float)e.drag;
                        SetFloatArr(el.FindPropertyRelative("size"), e.size);
                        SetFloatArr(el.FindPropertyRelative("opacity"), e.opacity);
                        var cArr = el.FindPropertyRelative("color");
                        cArr.arraySize = e.colors.Count;
                        for (int c = 0; c < e.colors.Count; c++)
                        {
                            ColorUtility.TryParseHtmlString(e.colors[c], out var col);
                            cArr.GetArrayElementAtIndex(c).colorValue = col;
                        }
                        el.FindPropertyRelative("additive").boolValue = e.additive;
                        el.FindPropertyRelative("texture").objectReferenceValue = AssetDatabase.LoadAssetAtPath<Texture2D>(e.texAssetPath);
                        el.FindPropertyRelative("fit").vector2Value = new Vector2((float)e.fitX, (float)e.fitY);
                        el.FindPropertyRelative("orientation").stringValue = e.orientation;
                        el.FindPropertyRelative("tilt").floatValue = (float)e.tilt;
                        el.FindPropertyRelative("flip").boolValue = e.flip;
                        el.FindPropertyRelative("sizeJitter").floatValue = (float)e.sizeJitter;
                        el.FindPropertyRelative("stretch").floatValue = (float)e.stretch;
                        var rad = el.FindPropertyRelative("radial");
                        rad.FindPropertyRelative("enabled").boolValue = e.hasRadial;
                        rad.FindPropertyRelative("speed").vector2Value = new Vector2((float)e.radialSpeedMin, (float)e.radialSpeedMax);
                        rad.FindPropertyRelative("radius").vector2Value = new Vector2((float)e.radialRadiusMin, (float)e.radialRadiusMax);
                        rad.FindPropertyRelative("cone").floatValue = (float)e.radialCone;
                        var grd = el.FindPropertyRelative("ground");
                        grd.FindPropertyRelative("enabled").boolValue = e.hasGround;
                        grd.FindPropertyRelative("bounce").floatValue = (float)e.groundBounce;
                        grd.FindPropertyRelative("friction").floatValue = (float)e.groundFriction;
                        grd.FindPropertyRelative("kill").boolValue = e.groundKill;
                        var trArr = el.FindPropertyRelative("triggers");
                        trArr.arraySize = e.triggers.Count;
                        for (int t = 0; t < e.triggers.Count; t++)
                        {
                            var tel = trArr.GetArrayElementAtIndex(t);
                            tel.FindPropertyRelative("on").stringValue = e.triggers[t].on;
                            tel.FindPropertyRelative("emitter").stringValue = e.triggers[t].emitter;
                            tel.FindPropertyRelative("count").intValue = e.triggers[t].count;
                            tel.FindPropertyRelative("inherit").floatValue = (float)e.triggers[t].inherit;
                        }
                        el.FindPropertyRelative("maxParticles").intValue = e.maxParticles;
                    }
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
                PrefabUtility.SaveAsPrefabAsset(go, p.assetPath);
                UnityEngine.Object.DestroyImmediate(go);
                WfSyncRunner.QueueAssetAndMeta(stamps, p.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessWholeMaps(SyncTask task, List<StampTarget> stamps)
        {
            if (task.wholeMapPrefabs == null) return;
            var navType = WfSyncRunner.FindType("WeaveForge.Export.WfWholeMapNav", "Assembly-CSharp");
            foreach (var p in task.wholeMapPrefabs)
            {
                if (!p.write) continue;
                WfSyncRunner.EnsureParentDir(p.assetPath);
                var rootGo = new GameObject(p.displayName);
                if (navType != null)
                {
                    var nav = rootGo.AddComponent(navType);
                    var so = new SerializedObject(nav);
                    so.FindProperty("perspective").stringValue = p.perspective;
                    so.FindProperty("tileWidth").intValue = p.tileWidth;
                    so.FindProperty("tileHeight").intValue = p.tileHeight;
                    so.FindProperty("characterRadius").intValue = p.characterRadius;
                    so.FindProperty("characterSpeed").intValue = p.characterSpeed;
                    so.FindProperty("pixelsPerUnit").floatValue = 100f;
                    var rProp = so.FindProperty("walkableRects");
                    rProp.arraySize = p.navRects.Count;
                    for (int i = 0; i < p.navRects.Count; i++)
                    {
                        var el = rProp.GetArrayElementAtIndex(i);
                        el.FindPropertyRelative("x").intValue = p.navRects[i].x;
                        el.FindPropertyRelative("y").intValue = p.navRects[i].y;
                        el.FindPropertyRelative("width").intValue = p.navRects[i].width;
                        el.FindPropertyRelative("height").intValue = p.navRects[i].height;
                    }
                    var cProp = so.FindProperty("connections");
                    cProp.arraySize = p.connections.Count;
                    for (int i = 0; i < p.connections.Count; i++)
                    {
                        var el = cProp.GetArrayElementAtIndex(i);
                        el.FindPropertyRelative("id").stringValue = p.connections[i].id;
                        el.FindPropertyRelative("kind").stringValue = p.connections[i].kind;
                        el.FindPropertyRelative("from").stringValue = p.connections[i].from;
                        el.FindPropertyRelative("to").stringValue = p.connections[i].to;
                        el.FindPropertyRelative("a").vector2Value = new Vector2((float)p.connections[i].ax, (float)p.connections[i].ay);
                        el.FindPropertyRelative("b").vector2Value = new Vector2((float)p.connections[i].bx, (float)p.connections[i].by);
                    }
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
                var groundGo = new GameObject("Ground"); groundGo.transform.SetParent(rootGo.transform, false);
                foreach (var tile in p.tiles)
                {
                    var tGo = new GameObject(tile.name);
                    tGo.transform.SetParent(groundGo.transform, false);
                    tGo.transform.localPosition = new Vector3((float)tile.posX, (float)tile.posY, 0f);
                    tGo.transform.localScale = new Vector3((float)tile.scaleX, (float)tile.scaleY, 1f);
                    var sr = tGo.AddComponent<SpriteRenderer>();
                    sr.sprite = WfSyncRunner.LoadSprite(tile.texAssetPath, tile.multiple, tile.spriteName);
                    sr.sortingOrder = tile.order;
                    if (!string.IsNullOrEmpty(tile.matAssetPath))
                    {
                        var mat = AssetDatabase.LoadAssetAtPath<Material>(tile.matAssetPath);
                        if (mat != null) sr.sharedMaterial = mat;
                    }
                }
                var belowGo = new GameObject("Below"); belowGo.transform.SetParent(rootGo.transform, false);
                var sortedGo = new GameObject("Sorted"); sortedGo.transform.SetParent(rootGo.transform, false);
                var aboveGo = new GameObject("Above"); aboveGo.transform.SetParent(rootGo.transform, false);
                foreach (var part in p.parts)
                {
                    var parent = part.band == "Below" ? belowGo : (part.band == "Above" ? aboveGo : sortedGo);
                    var pGo = new GameObject(part.name);
                    pGo.transform.SetParent(parent.transform, false);
                    pGo.transform.localPosition = new Vector3((float)part.posX, (float)part.posY, 0f);
                    var sr = pGo.AddComponent<SpriteRenderer>();
                    sr.sprite = WfSyncRunner.LoadSprite(part.texAssetPath, part.multiple, part.spriteName);
                    sr.spriteSortPoint = SpriteSortPoint.Pivot;
                    sr.sortingOrder = part.order;
                }
                var colGo = new GameObject("Collision"); colGo.transform.SetParent(rootGo.transform, false);
                foreach (var col in p.colliders)
                {
                    AddPolygonCollider(colGo, col.polys, false);
                }
                var regGo = new GameObject("Regions"); regGo.transform.SetParent(rootGo.transform, false);
                foreach (var reg in p.regions)
                {
                    var rGo = new GameObject(reg.name);
                    rGo.transform.SetParent(regGo.transform, false);
                    AddPolygonCollider(rGo, new List<PolyPathSpec> { reg.poly }, true);
                }
                PrefabUtility.SaveAsPrefabAsset(rootGo, p.assetPath);
                UnityEngine.Object.DestroyImmediate(rootGo);
                WfSyncRunner.QueueAssetAndMeta(stamps, p.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessParallax(SyncTask task, List<StampTarget> stamps)
        {
            if (task.parallaxPrefabs == null) return;
            var layerType = WfSyncRunner.FindType("WeaveForge.Export.WfParallaxLayer", "Assembly-CSharp");
            foreach (var p in task.parallaxPrefabs)
            {
                if (!p.write) continue;
                WfSyncRunner.EnsureParentDir(p.assetPath);
                var rootGo = new GameObject(p.displayName);
                var bd = new GameObject("Backdrop");
                bd.transform.SetParent(rootGo.transform, false);
                bd.SetActive(p.backdrop.visible);
                AddParallaxSprite(bd, layerType, p.backdrop);
                var behind = new GameObject("BehindLayers"); behind.transform.SetParent(rootGo.transform, false);
                var front = new GameObject("FrontLayers"); front.transform.SetParent(rootGo.transform, false);
                foreach (var it in p.items)
                {
                    var go = new GameObject(it.name);
                    go.transform.SetParent((it.front ? front : behind).transform, false);
                    go.transform.localPosition = new Vector3((float)it.posX, (float)it.posY, 0f);
                    go.transform.localScale = new Vector3((float)it.scaleX, (float)it.scaleY, 1f);
                    go.SetActive(it.visible);
                    AddParallaxSprite(go, layerType, it);
                }
                if (p.hasLevel)
                {
                    var lvGo = new GameObject("Level"); lvGo.transform.SetParent(rootGo.transform, false);
                    foreach (var sp in p.levelSprites)
                    {
                        var g = new GameObject(sp.name);
                        g.transform.SetParent(lvGo.transform, false);
                        g.transform.localPosition = new Vector3((float)sp.posX, (float)sp.posY, 0f);
                        var sr = g.AddComponent<SpriteRenderer>();
                        sr.sprite = WfSyncRunner.LoadSprite(sp.texAssetPath, sp.multiple, sp.spriteName);
                        sr.sortingOrder = sp.order;
                    }
                    foreach (var bx in p.levelBoxes)
                    {
                        AddBoxCollider2D(lvGo, new Vector2((float)bx.cx, (float)bx.cy), new Vector2((float)bx.w, (float)bx.h), false);
                    }
                    foreach (var poly in p.levelPolys)
                    {
                        AddPolygonCollider(lvGo, new List<PolyPathSpec> { poly }, false);
                    }
                    foreach (var trig in p.levelTriggers)
                    {
                        var tGo = new GameObject(trig.name);
                        tGo.transform.SetParent(lvGo.transform, false);
                        tGo.transform.localPosition = new Vector3((float)trig.cx, (float)trig.cy, 0f);
                        AddBoxCollider2D(tGo, Vector2.zero, new Vector2((float)trig.w, (float)trig.h), true);
                    }
                    foreach (var mk in p.levelMarkers)
                    {
                        var mGo = new GameObject(mk.name);
                        mGo.transform.SetParent(lvGo.transform, false);
                        mGo.transform.localPosition = new Vector3((float)mk.x, (float)mk.y, 0f);
                    }
                }
                PrefabUtility.SaveAsPrefabAsset(rootGo, p.assetPath);
                UnityEngine.Object.DestroyImmediate(rootGo);
                WfSyncRunner.QueueAssetAndMeta(stamps, p.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void AddParallaxSprite(GameObject go, Type layerType, ParallaxSpriteSpec s)
        {
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = WfSyncRunner.LoadSprite(s.texAssetPath, s.multiple, s.spriteName);
            sr.flipX = s.flipX;
            sr.color = new Color(1f, 1f, 1f, (float)s.opacity);
            sr.sortingOrder = s.order;
            if (layerType != null)
            {
                var comp = go.AddComponent(layerType);
                var so = new SerializedObject(comp);
                so.FindProperty("parallaxSpeed").floatValue = (float)s.speed;
                so.FindProperty("driftSpeed").floatValue = (float)s.drift;
                so.FindProperty("bobAmplitude").floatValue = (float)s.bobAmp;
                so.FindProperty("bobPeriod").floatValue = (float)s.bobPeriod;
                so.FindProperty("swayDegrees").floatValue = (float)s.swayDeg;
                so.FindProperty("swayPeriod").floatValue = (float)s.swayPeriod;
                so.FindProperty("repeatSpan").floatValue = (float)s.repeatSpan;
                so.FindProperty("pixelsPerUnit").floatValue = 100f;
                so.ApplyModifiedPropertiesWithoutUndo();
            }
        }

        private static void ProcessModel3d(SyncTask task, List<StampTarget> stamps)
        {
            if (task.model3dPrefabs == null) return;
            var metaType = WfSyncRunner.FindType("WeaveForge.Export.WfSpatialMeta", "Assembly-CSharp");
            foreach (var p in task.model3dPrefabs)
            {
                if (!p.write) continue;
                WfSyncRunner.EnsureParentDir(p.assetPath);
                var rootGo = new GameObject(p.displayName);
                TryAttachGlbVisual(rootGo, p.glbAssetPath);
                if (p.capsuleCollider)
                {
                    AddCapsuleCollider(rootGo, (float)p.radius, (float)p.height, ToV3(p.center));
                }
                else
                {
                    AddBoxCollider3D(rootGo, ToV3(p.size), ToV3(p.center), false);
                }
                if (metaType != null)
                {
                    var mb = rootGo.AddComponent(metaType);
                    var so = new SerializedObject(mb);
                    so.FindProperty("kind").stringValue = "model_3d";
                    so.FindProperty("glbRelativePath").stringValue = p.glbAssetPath;
                    so.FindProperty("height").floatValue = (float)p.modelHeight;
                    so.FindProperty("bottom").floatValue = (float)p.bottom;
                    so.FindProperty("bonesJson").stringValue = p.bonesJson;
                    var clips = so.FindProperty("clips");
                    clips.arraySize = p.clips.Count;
                    for (int i = 0; i < p.clips.Count; i++)
                    {
                        var el = clips.GetArrayElementAtIndex(i);
                        el.FindPropertyRelative("name").stringValue = p.clips[i].name;
                        el.FindPropertyRelative("duration").floatValue = (float)p.clips[i].duration;
                        el.FindPropertyRelative("loops").boolValue = p.clips[i].loops;
                        el.FindPropertyRelative("travel").vector3Value = ToV3(p.clips[i].travel);
                        el.FindPropertyRelative("soleLow").floatValue = (float)p.clips[i].soleLow;
                        el.FindPropertyRelative("soleHigh").floatValue = (float)p.clips[i].soleHigh;
                        el.FindPropertyRelative("liftoffs").intValue = p.clips[i].liftoffs;
                        var ch = el.FindPropertyRelative("checks");
                        ch.arraySize = p.clips[i].checks.Count;
                        for (int j = 0; j < p.clips[i].checks.Count; j++) ch.GetArrayElementAtIndex(j).stringValue = p.clips[i].checks[j];
                    }
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
                foreach (var sk in p.sockets)
                {
                    var sGo = new GameObject(sk.name);
                    sGo.transform.SetParent(rootGo.transform, false);
                    sGo.transform.localPosition = ToV3(sk.position);
                }
                PrefabUtility.SaveAsPrefabAsset(rootGo, p.assetPath);
                UnityEngine.Object.DestroyImmediate(rootGo);
                WfSyncRunner.QueueAssetAndMeta(stamps, p.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessScene3d(SyncTask task, List<StampTarget> stamps)
        {
            if (task.scene3dPrefabs == null) return;
            var metaType = WfSyncRunner.FindType("WeaveForge.Export.WfSpatialMeta", "Assembly-CSharp");
            foreach (var p in task.scene3dPrefabs)
            {
                if (!p.write) continue;
                WfSyncRunner.EnsureParentDir(p.assetPath);
                var rootGo = new GameObject(p.displayName);
                TryAttachGlbVisual(rootGo, p.glbAssetPath);
                if (metaType != null)
                {
                    var mb = rootGo.AddComponent(metaType);
                    var so = new SerializedObject(mb);
                    so.FindProperty("kind").stringValue = "scene3d_map";
                    so.FindProperty("glbRelativePath").stringValue = p.glbAssetPath;
                    var bd = so.FindProperty("blockedDoors");
                    bd.arraySize = p.blockedDoors.Count;
                    for (int i = 0; i < p.blockedDoors.Count; i++) bd.GetArrayElementAtIndex(i).stringValue = p.blockedDoors[i];
                    so.FindProperty("ambientColor").colorValue = new Color((float)p.ambientR, (float)p.ambientG, (float)p.ambientB, 1f);
                    so.FindProperty("ambientIntensity").floatValue = (float)p.ambientIntensity;
                    so.FindProperty("fogEnabled").boolValue = p.fogEnabled;
                    so.FindProperty("fogColor").colorValue = new Color((float)p.fogR, (float)p.fogG, (float)p.fogB, 1f);
                    so.FindProperty("fogDensity").floatValue = (float)p.fogDensity;
                    var roles = so.FindProperty("roles");
                    roles.arraySize = p.roles.Count;
                    for (int i = 0; i < p.roles.Count; i++)
                    {
                        var rel = roles.GetArrayElementAtIndex(i);
                        rel.FindPropertyRelative("role").stringValue = p.roles[i].role;
                        rel.FindPropertyRelative("id").stringValue = p.roles[i].id;
                        rel.FindPropertyRelative("nodeName").stringValue = p.roles[i].nodeName;
                        rel.FindPropertyRelative("position").vector3Value = ToV3(p.roles[i].pos);
                        rel.FindPropertyRelative("forward").vector3Value = ToV3(p.roles[i].forward);
                        rel.FindPropertyRelative("blocked").boolValue = p.roles[i].blocked;
                    }
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
                var colGo = new GameObject("Collision"); colGo.transform.SetParent(rootGo.transform, false);
                foreach (var c in p.colliders)
                {
                    var cg = new GameObject(c.name); cg.transform.SetParent(colGo.transform, false);
                    cg.transform.localPosition = ToV3(c.center);
                    AddBoxCollider3D(cg, ToV3(c.size), Vector3.zero, false);
                }
                var rolesGo = new GameObject("Roles"); rolesGo.transform.SetParent(rootGo.transform, false);
                foreach (var r in p.roleNodes)
                {
                    var rg = new GameObject(r.name); rg.transform.SetParent(rolesGo.transform, false);
                    rg.transform.localPosition = ToV3(r.center);
                    if (r.isTrigger) { AddBoxCollider3D(rg, ToV3(r.size), Vector3.zero, true); }
                }
                PrefabUtility.SaveAsPrefabAsset(rootGo, p.assetPath);
                UnityEngine.Object.DestroyImmediate(rootGo);
                WfSyncRunner.QueueAssetAndMeta(stamps, p.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void TryAttachGlbVisual(GameObject rootGo, string glbPath)
        {
            var glb = AssetDatabase.LoadAssetAtPath<GameObject>(glbPath);
            if (glb != null)
            {
                var inst = PrefabUtility.InstantiatePrefab(glb) as GameObject;
                if (inst != null) { inst.name = "Visual"; inst.transform.SetParent(rootGo.transform, false); }
            }
        }

        private static Vector3 ToV3(Vec3Spec v) => new Vector3((float)v.x, (float)v.y, (float)v.z);

        private static void SetFloatArr(SerializedProperty prop, List<double> values)
        {
            prop.arraySize = values.Count;
            for (int i = 0; i < values.Count; i++) prop.GetArrayElementAtIndex(i).floatValue = (float)values[i];
        }

        internal static void AddPolygonCollider(GameObject go, List<PolyPathSpec> polys, bool isTrigger)
        {
            var polyType = WfSyncRunner.FindType("UnityEngine.PolygonCollider2D", "UnityEngine.Physics2DModule");
            if (polyType == null || polys == null || polys.Count == 0) return;
            var polyCol = go.AddComponent(polyType);
            if (isTrigger) WfSyncRunner.SetMember(polyCol, "isTrigger", true);
            WfSyncRunner.SetMember(polyCol, "pathCount", polys.Count);
            for (int i = 0; i < polys.Count; i++)
            {
                var pts = new Vector2[polys[i].points.Count];
                for (int j = 0; j < polys[i].points.Count; j++)
                    pts[j] = new Vector2((float)polys[i].points[j].x, (float)polys[i].points[j].y);
                WfSyncRunner.CallMethod(polyCol, "SetPath", i, pts);
            }
        }

        internal static void AddBoxCollider2D(GameObject go, Vector2 offset, Vector2 size, bool isTrigger)
        {
            var t = WfSyncRunner.FindType("UnityEngine.BoxCollider2D", "UnityEngine.Physics2DModule");
            if (t == null) return;
            var bc = go.AddComponent(t);
            WfSyncRunner.SetMember(bc, "isTrigger", isTrigger);
            WfSyncRunner.SetMember(bc, "offset", offset);
            WfSyncRunner.SetMember(bc, "size", size);
        }

        internal static void AddCapsuleCollider(GameObject go, float radius, float height, Vector3 center)
        {
            var t = WfSyncRunner.FindType("UnityEngine.CapsuleCollider", "UnityEngine.PhysicsModule");
            if (t == null) return;
            var cc = go.AddComponent(t);
            WfSyncRunner.SetMember(cc, "radius", radius);
            WfSyncRunner.SetMember(cc, "height", height);
            WfSyncRunner.SetMember(cc, "direction", 1);
            WfSyncRunner.SetMember(cc, "center", center);
        }

        internal static void AddBoxCollider3D(GameObject go, Vector3 size, Vector3 center, bool isTrigger)
        {
            var t = WfSyncRunner.FindType("UnityEngine.BoxCollider", "UnityEngine.PhysicsModule");
            if (t == null) return;
            var bc = go.AddComponent(t);
            WfSyncRunner.SetMember(bc, "size", size);
            WfSyncRunner.SetMember(bc, "center", center);
            if (isTrigger) WfSyncRunner.SetMember(bc, "isTrigger", true);
        }
    }

    [Serializable] public class ParticlePrefabTask { public bool write; public string assetPath; public string displayName; public string shaderAssetPath; public double duration; public bool looping; public bool planar; public List<ParticleEmitterSpec> emitters; }
    [Serializable] public class ParticleEmitterSpec { public string id; public long randomState; public double rate; public int burst; public double delay; public double lifetimeMin; public double lifetimeMax; public Vec3Spec position; public Vec3Spec spread; public Vec3Spec velocity; public Vec3Spec velocitySpread; public Vec3Spec gravity; public double drag; public List<double> size; public List<double> opacity; public List<string> colors; public bool additive; public string texAssetPath; public double fitX; public double fitY; public string orientation; public double tilt; public bool flip; public double sizeJitter; public double stretch; public bool hasRadial; public double radialSpeedMin; public double radialSpeedMax; public double radialRadiusMin; public double radialRadiusMax; public double radialCone; public bool hasGround; public double groundBounce; public double groundFriction; public bool groundKill; public List<ParticleTriggerSpec> triggers; public int maxParticles; }
    [Serializable] public class ParticleTriggerSpec { public string on; public string emitter; public int count; public double inherit; }
    [Serializable] public class WholeMapPrefabTask { public bool write; public string assetPath; public string displayName; public string perspective; public int tileWidth; public int tileHeight; public int characterRadius; public int characterSpeed; public List<WholeNavRectSpec> navRects; public List<WholeNavConnSpec> connections; public List<WholeTileSpec> tiles; public List<WholePartSpec> parts; public List<WholeColliderSpec> colliders; public List<WholeRegionSpec> regions; }
    [Serializable] public class WholeNavRectSpec { public int x; public int y; public int width; public int height; }
    [Serializable] public class WholeNavConnSpec { public string id; public string kind; public string from; public string to; public double ax; public double ay; public double bx; public double by; }
    [Serializable] public class WholeTileSpec { public string name; public double posX; public double posY; public double scaleX; public double scaleY; public string texAssetPath; public bool multiple; public string spriteName; public int order; public string matAssetPath; }
    [Serializable] public class WholePartSpec { public string name; public string band; public double posX; public double posY; public string texAssetPath; public bool multiple; public string spriteName; public int order; }
    [Serializable] public class WholeColliderSpec { public List<PolyPathSpec> polys; }
    [Serializable] public class WholeRegionSpec { public string name; public PolyPathSpec poly; }
    [Serializable] public class ParallaxPrefabTask { public bool write; public string assetPath; public string displayName; public ParallaxSpriteSpec backdrop; public List<ParallaxSpriteSpec> items; public bool hasLevel; public List<ParallaxLevelSpriteSpec> levelSprites; public List<ParallaxBoxSpec> levelBoxes; public List<PolyPathSpec> levelPolys; public List<ParallaxTriggerSpec> levelTriggers; public List<ParallaxMarkerSpec> levelMarkers; }
    [Serializable] public class ParallaxSpriteSpec { public string name; public bool front; public bool visible; public double posX; public double posY; public double scaleX; public double scaleY; public string texAssetPath; public bool multiple; public string spriteName; public bool flipX; public double opacity; public int order; public double speed; public double drift; public double bobAmp; public double bobPeriod; public double swayDeg; public double swayPeriod; public double repeatSpan; }
    [Serializable] public class ParallaxLevelSpriteSpec { public string name; public double posX; public double posY; public string texAssetPath; public bool multiple; public string spriteName; public int order; }
    [Serializable] public class ParallaxBoxSpec { public double cx; public double cy; public double w; public double h; }
    [Serializable] public class ParallaxTriggerSpec { public string name; public double cx; public double cy; public double w; public double h; }
    [Serializable] public class ParallaxMarkerSpec { public string name; public double x; public double y; }
    [Serializable] public class Model3dPrefabTask { public bool write; public string assetPath; public string displayName; public string glbAssetPath; public bool capsuleCollider; public double radius; public double height; public Vec3Spec size; public Vec3Spec center; public double modelHeight; public double bottom; public string bonesJson; public List<ModelClipSpec> clips; public List<ModelSocketSpec> sockets; }
    [Serializable] public class ModelClipSpec { public string name; public double duration; public bool loops; public Vec3Spec travel; public double soleLow; public double soleHigh; public int liftoffs; public List<string> checks; }
    [Serializable] public class ModelSocketSpec { public string name; public Vec3Spec position; }
    [Serializable] public class Scene3dPrefabTask { public bool write; public string assetPath; public string displayName; public string glbAssetPath; public List<string> blockedDoors; public double ambientR; public double ambientG; public double ambientB; public double ambientIntensity; public bool fogEnabled; public double fogR; public double fogG; public double fogB; public double fogDensity; public List<Scene3dRoleSpec> roles; public List<Scene3dColSpec> colliders; public List<Scene3dRoleNodeSpec> roleNodes; }
    [Serializable] public class Scene3dRoleSpec { public string role; public string id; public string nodeName; public Vec3Spec pos; public Vec3Spec forward; public bool blocked; }
    [Serializable] public class Scene3dColSpec { public string name; public Vec3Spec center; public Vec3Spec size; }
    [Serializable] public class Scene3dRoleNodeSpec { public string name; public Vec3Spec center; public bool isTrigger; public Vec3Spec size; }
}
#endif
