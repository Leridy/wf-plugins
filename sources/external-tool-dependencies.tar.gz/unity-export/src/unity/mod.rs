//! Deterministic Unity GUID/fileID generation, shared document helpers, and bindings/texture modules.
pub mod animation;
pub mod bindings;
pub mod icon;
pub mod image;
pub mod parallax;
pub mod particle;
pub mod prop;
pub mod spatial;
pub mod texture;
pub mod tilemap;
pub mod ui;

pub mod whole_map;

use crate::reconcile::StampFormat;
use sha2::{Digest, Sha256};
use std::fmt::Write;
use std::path::Path;

/// Shared path/root identity context for exporting one WeaveForge node.
#[derive(Clone, Copy)]
pub struct ExportTarget<'a> {
    pub node_prefix: &'a str,
    pub node_dir: &'a str,
    pub directory: &'a str,
    pub root: &'a str,
}

/// One generated Unity `.meta`, JSON manifest, C# script, or shader file.
pub struct Document {
    /// Path relative to the export directory (`Assets/wf/...` tail).
    pub rel_path: String,
    pub body: String,
    pub stamp: StampFormat,
}

/// Deterministic 32-character lowercase hexadecimal Unity GUID from `seed`.
pub fn guid(seed: &str) -> String {
    let digest = Sha256::digest(format!("wf-unity-export:guid:{seed}").as_bytes());
    let mut hex = String::with_capacity(32);
    for byte in &digest[..16] {
        write!(hex, "{byte:02x}").expect("write to String");
    }
    hex
}

/// Deterministic positive non-zero 64-bit Unity local `fileID` (avoiding built-in ranges < 100_000).
pub fn file_id(seed: &str) -> i64 {
    let digest = Sha256::digest(format!("wf-unity-export:fileid:{seed}").as_bytes());
    let raw = u64::from_le_bytes(digest[..8].try_into().expect("8 bytes")) & 0x7FFF_FFFF_FFFF_FFFF;
    let clamped = i64::try_from(raw).expect("masked to 63 bits");
    if clamped < 100_000 { clamped + 100_000 } else { clamped }
}

/// Deterministic negative or positive non-zero `internalID` for `TextureImporter` sprites.
pub fn sprite_internal_id(seed: &str) -> i64 {
    file_id(&format!("sprite:{seed}"))
}

pub fn doc(_directory: &str, _root: &str, rel_path: String, body: String, _main_prefab: bool) -> Document {
    let is_code = Path::new(&rel_path)
        .extension()
        .is_some_and(|ext| ext.eq_ignore_ascii_case("cs") || ext.eq_ignore_ascii_case("shader"));
    let stamp = if is_code {
        StampFormat::Code
    } else {
        StampFormat::TrailingComment
    };
    Document { rel_path, body, stamp }
}

pub fn native_meta(guid: &str, main_object_file_id: i64) -> String {
    format!(
        "fileFormatVersion: 2\n\
         guid: {guid}\n\
         NativeFormatImporter:\n  \
           externalObjects: {{}}\n  \
           mainObjectFileID: {main_object_file_id}\n  \
           userData: \n  \
           assetBundleName: \n  \
           assetBundleVariant: \n"
    )
}

pub fn cs_meta(guid: &str) -> String {
    format!("fileFormatVersion: 2\nguid: {guid}\n")
}

pub fn shader_meta(guid: &str) -> String {
    format!(
        "fileFormatVersion: 2\n\
         guid: {guid}\n\
         ShaderImporter:\n  \
           externalObjects: {{}}\n  \
           defaultTextures: []\n  \
           nonModifiableTextures: []\n  \
           userData: \n  \
           assetBundleName: \n  \
           assetBundleVariant: \n"
    )
}
