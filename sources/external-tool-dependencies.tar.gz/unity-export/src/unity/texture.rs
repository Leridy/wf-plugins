//! TextureImporter CLI spec builder for Single and Multiple sprite sheets.
use super::{guid, sprite_internal_id};
use crate::model::{Margins, Rect};
use crate::paths;
use std::collections::BTreeMap;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FilterMode {
    Point = 0,
    Bilinear = 1,
}

#[derive(Clone, Copy, Debug)]
pub struct SliceSpec {
    /// Source rectangle in top-left pixels (`None` uses the whole image).
    pub rect: Option<Rect>,
    /// Normalized Unity pivot (`{0,0}` bottom-left, `{1,1}` top-right).
    pub pivot: [f64; 2],
    /// 9-slice border in pixels (`[left, bottom, right, top]`).
    pub border: [f64; 4],
    pub ppu: f64,
    pub filter: FilterMode,
}

impl SliceSpec {
    pub fn border_from_margins(m: Margins) -> [f64; 4] {
        [m.left, m.bottom, m.right, m.top]
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub struct SpriteKey {
    pub tex_path: String,
    rect_bits: Option<[u64; 4]>,
}

struct RegisteredSlice {
    name: String,
    rect: Option<Rect>,
    pivot: [f64; 2],
    border: [f64; 4],
}

struct TextureEntry {
    dimensions: (u32, u32),
    ppu: f64,
    filter: FilterMode,
    has_regions: bool,
    slices: Vec<RegisteredSlice>,
    resolved: BTreeMap<Option<[u64; 4]>, ResolvedSliceInfo>,
    guid: String,
}

#[derive(Clone, Debug)]
pub struct ResolvedSliceInfo {
    pub tex_path: String,
    pub asset_path: String,
    pub sprite_name: String,
    pub tex_guid: String,
    pub internal_id: i64,
    pub texture_dims: (u32, u32),
    pub rect: [f64; 4],
    pub pivot: [f64; 2],
    pub border: [f64; 4],
    pub ppu: f64,
}

/// Typed slice spec sent to Unity `WfSyncRunner.cs` for `TextureImporter` configuration.
#[derive(Clone, Debug)]
pub struct CliSliceSpec {
    pub name: String,
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub pivot: [f64; 2],
    pub border: [f64; 4],
    pub sprite_id: String,
    pub internal_id: i64,
}

/// Typed texture import spec sent to Unity `WfSyncRunner.cs`.
#[derive(Clone, Debug)]
pub struct CliTextureSpec {
    pub asset_path: String,
    pub meta_rel_path: String,
    pub guid: String,
    pub ppu: f64,
    pub filter_mode: u8,
    pub multiple: bool,
    pub slices: Vec<CliSliceSpec>,
}

struct BuiltTexture {
    tex_stem: String,
    asset_path: String,
    meta_rel_path: String,
    multiple: bool,
    single_pivot: [f64; 2],
    single_border: [f64; 4],
    single_internal_id: i64,
    dims: (u32, u32),
    ppu: f64,
    filter: FilterMode,
    guid: String,
    rows: Vec<CliSliceSpec>,
}

/// Accumulates all texture/slice requirements for a node and resolves final Unity Sprite / Texture2D references.
pub struct TextureRegistry {
    textures: BTreeMap<String, TextureEntry>,
    pub notes: Vec<String>,
}

impl TextureRegistry {
    pub fn new(node_prefix: &str, dims: &BTreeMap<String, (u32, u32)>) -> Self {
        let mut textures = BTreeMap::new();
        for (rel_path, &(w, h)) in dims {
            textures.insert(
                rel_path.clone(),
                TextureEntry {
                    dimensions: (w, h),
                    ppu: 100.0,
                    filter: FilterMode::Bilinear,
                    has_regions: false,
                    slices: Vec::new(),
                    resolved: BTreeMap::new(),
                    guid: guid(&format!("{node_prefix}:{rel_path}")),
                },
            );
        }
        Self {
            textures,
            notes: Vec::new(),
        }
    }

    /// Register a texture usage and return an opaque lookup key to resolve after all registrations finish.
    pub fn register(&mut self, tex_path: &str, name_hint: &str, spec: SliceSpec) -> SpriteKey {
        let entry = self
            .textures
            .get_mut(tex_path)
            .expect("texture dimensions must be preloaded for every referenced PNG");
        entry.ppu = spec.ppu;
        entry.filter = spec.filter;
        let rect_bits = spec
            .rect
            .map(|r| [r.x.to_bits(), r.y.to_bits(), r.w.to_bits(), r.h.to_bits()]);
        if rect_bits.is_some() {
            entry.has_regions = true;
        }
        if let Some(existing) = entry.slices.iter().find(|s| {
            s.rect
                .map(|r| [r.x.to_bits(), r.y.to_bits(), r.w.to_bits(), r.h.to_bits()])
                == rect_bits
        }) {
            if existing.pivot.map(f64::to_bits) != spec.pivot.map(f64::to_bits)
                || existing.border.map(f64::to_bits) != spec.border.map(f64::to_bits)
            {
                self.notes.push(format!(
                    "{tex_path}: region reused with a different pivot or slice border; keeping the first registration ({}).",
                    existing.name
                ));
            }
        } else {
            entry.slices.push(RegisteredSlice {
                name: unique_slice_name(&entry.slices, name_hint),
                rect: spec.rect,
                pivot: spec.pivot,
                border: spec.border,
            });
        }
        SpriteKey {
            tex_path: tex_path.to_owned(),
            rect_bits,
        }
    }

    fn finalize_entries(
        mut self,
        node_dir: &str,
        root: &str,
        directory: &str,
    ) -> (ResolvedSprites, Vec<BuiltTexture>, Vec<String>) {
        let mut refs = BTreeMap::new();
        let mut built = Vec::with_capacity(self.textures.len());
        let dir_rel_prefix = node_dir
            .strip_prefix(directory)
            .unwrap_or(node_dir)
            .trim_start_matches('/');
        for (tex_path, entry) in &mut self.textures {
            let meta_rel_path = if dir_rel_prefix.is_empty() {
                format!("{tex_path}.meta")
            } else {
                format!("{dir_rel_prefix}/{tex_path}.meta")
            };
            let tex_stem = tex_path.rsplit('/').next().unwrap_or("sprite").trim_end_matches(".png");
            let asset_path = if dir_rel_prefix.is_empty() {
                paths::asset_path(root, &paths::join(directory, tex_path))
            } else {
                paths::asset_path(root, &paths::join(directory, &format!("{dir_rel_prefix}/{tex_path}")))
            };
            let multiple = entry.has_regions || entry.slices.len() > 1;
            let (single_pivot, single_border, single_internal_id, rows) = if multiple {
                let rows = resolve_multiple_entry(tex_path, tex_stem, &asset_path, entry);
                ([0.5, 0.5], [0.0; 4], 0, rows)
            } else {
                resolve_single_entry(tex_path, tex_stem, &asset_path, entry)
            };
            refs.insert(
                tex_path.clone(),
                ResolvedTexture {
                    slots: entry.resolved.clone(),
                },
            );
            built.push(BuiltTexture {
                tex_stem: tex_stem.to_owned(),
                asset_path,
                meta_rel_path,
                multiple,
                single_pivot,
                single_border,
                single_internal_id,
                dims: entry.dimensions,
                ppu: entry.ppu,
                filter: entry.filter,
                guid: entry.guid.clone(),
                rows,
            });
        }
        (ResolvedSprites { map: refs }, built, self.notes)
    }

    /// Finalize internal IDs and produce Unity CLI `TextureImporter` specs plus reuse notes.
    pub fn build_cli(
        self,
        node_dir: &str,
        root: &str,
        directory: &str,
    ) -> (ResolvedSprites, Vec<CliTextureSpec>, Vec<String>) {
        let (resolved, built, notes) = self.finalize_entries(node_dir, root, directory);
        let specs = built
            .into_iter()
            .map(|item| {
                let slices = if item.multiple {
                    item.rows
                } else {
                    vec![CliSliceSpec {
                        name: item.tex_stem,
                        x: 0.0,
                        y: 0.0,
                        w: f64::from(item.dims.0),
                        h: f64::from(item.dims.1),
                        pivot: item.single_pivot,
                        border: item.single_border,
                        sprite_id: String::new(),
                        internal_id: item.single_internal_id,
                    }]
                };
                CliTextureSpec {
                    asset_path: item.asset_path,
                    meta_rel_path: item.meta_rel_path,
                    guid: item.guid,
                    ppu: item.ppu,
                    filter_mode: item.filter as u8,
                    multiple: item.multiple,
                    slices,
                }
            })
            .collect();
        (resolved, specs, notes)
    }
}

fn resolve_single_entry(
    tex_path: &str,
    tex_stem: &str,
    asset_path: &str,
    entry: &mut TextureEntry,
) -> ([f64; 2], [f64; 4], i64, Vec<CliSliceSpec>) {
    let (w, h) = entry.dimensions;
    let slice = entry.slices.first();
    let pivot = slice.map_or([0.5, 0.5], |s| s.pivot);
    let border = slice.map_or([0.0; 4], |s| s.border);
    let internal_id = sprite_internal_id(&format!("{}:{tex_path}:0", entry.guid));
    let sprite_name = format!("{tex_stem}_0");
    let key_bits = slice
        .and_then(|s| s.rect)
        .map(|r| [r.x.to_bits(), r.y.to_bits(), r.w.to_bits(), r.h.to_bits()]);
    entry.resolved.insert(
        key_bits,
        ResolvedSliceInfo {
            tex_path: tex_path.to_owned(),
            asset_path: asset_path.to_owned(),
            sprite_name,
            tex_guid: entry.guid.clone(),
            internal_id: 21_300_000,
            texture_dims: (w, h),
            rect: [0.0, 0.0, f64::from(w), f64::from(h)],
            pivot,
            border,
            ppu: entry.ppu,
        },
    );
    (pivot, border, internal_id, Vec::new())
}

fn resolve_multiple_entry(
    tex_path: &str,
    tex_stem: &str,
    asset_path: &str,
    entry: &mut TextureEntry,
) -> Vec<CliSliceSpec> {
    let (w, h) = entry.dimensions;
    if entry.slices.is_empty() {
        entry.slices.push(RegisteredSlice {
            name: format!("{tex_stem}_0"),
            rect: None,
            pivot: [0.5, 0.5],
            border: [0.0; 4],
        });
    }
    let mut rows = Vec::with_capacity(entry.slices.len());
    for s in &entry.slices {
        let rect = s.rect.unwrap_or(Rect {
            x: 0.0,
            y: 0.0,
            w: f64::from(w),
            h: f64::from(h),
        });
        let unity_y = (f64::from(h) - (rect.y + rect.h)).max(0.0);
        let id_seed = format!("{}:{tex_path}:{}:{}:{}:{}", entry.guid, rect.x, rect.y, rect.w, rect.h);
        let internal_id = sprite_internal_id(&id_seed);
        let sprite_id = guid(&format!("spriteid:{id_seed}"));
        let key_bits = s
            .rect
            .map(|r| [r.x.to_bits(), r.y.to_bits(), r.w.to_bits(), r.h.to_bits()]);
        entry.resolved.insert(
            key_bits,
            ResolvedSliceInfo {
                tex_path: tex_path.to_owned(),
                asset_path: asset_path.to_owned(),
                sprite_name: s.name.clone(),
                tex_guid: entry.guid.clone(),
                internal_id,
                texture_dims: (w, h),
                rect: [rect.x, rect.y, rect.w, rect.h],
                pivot: s.pivot,
                border: s.border,
                ppu: entry.ppu,
            },
        );
        rows.push(CliSliceSpec {
            name: s.name.clone(),
            x: rect.x,
            y: unity_y,
            w: rect.w,
            h: rect.h,
            pivot: s.pivot,
            border: s.border,
            sprite_id,
            internal_id,
        });
    }
    rows
}

struct ResolvedTexture {
    slots: BTreeMap<Option<[u64; 4]>, ResolvedSliceInfo>,
}

pub struct ResolvedSprites {
    map: BTreeMap<String, ResolvedTexture>,
}

impl ResolvedSprites {
    pub fn slice_info(&self, key: &SpriteKey) -> &ResolvedSliceInfo {
        &self.map[&key.tex_path].slots[&key.rect_bits]
    }
}

pub fn pivot_from_top_left(anchor_x: f64, anchor_y: f64, width: f64, height: f64) -> [f64; 2] {
    [
        if width > 0.0 { anchor_x / width } else { 0.5 },
        if height > 0.0 { 1.0 - anchor_y / height } else { 0.5 },
    ]
}

fn unique_slice_name(existing: &[RegisteredSlice], hint: &str) -> String {
    let base: String = hint
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '_' || c == '-' {
                c
            } else {
                '_'
            }
        })
        .collect();
    let base = if base.is_empty() { "slice".to_owned() } else { base };
    if !existing.iter().any(|s| s.name == base) {
        return base;
    }
    for n in 1usize.. {
        let candidate = format!("{base}_{n}");
        if !existing.iter().any(|s| s.name == candidate) {
            return candidate;
        }
    }
    unreachable!()
}
