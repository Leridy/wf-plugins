using System;
using System.Collections.Generic;
using UnityEngine;

namespace WeaveForge
{
    /// <summary>
    /// Generated C# and xLua-compatible binding reader for <c>wf-bindings.json</c>.
    /// Keeps original WeaveForge pivots intact while exposing alpha-measured
    /// visual bounds, center offsets, prop states/colliders, animation timings,
    /// and UI/Icon element metadata.
    /// </summary>
    public static class WfBindings
    {
        public static WfBindingsManifest LoadFromJson(string json)
        {
            if (string.IsNullOrEmpty(json))
            {
                return null;
            }
            WfBindingsManifest manifest = JsonUtility.FromJson<WfBindingsManifest>(json);
            if (manifest != null)
            {
                manifest.RebuildIndex();
            }
            return manifest;
        }

        public static WfBindingsManifest LoadFromTextAsset(TextAsset asset)
        {
            return asset != null ? LoadFromJson(asset.text) : null;
        }

        public static WfBindingsManifest LoadFromResources(string resourcePath)
        {
            if (string.IsNullOrEmpty(resourcePath))
            {
                return null;
            }
            TextAsset asset = Resources.Load<TextAsset>(resourcePath);
            return LoadFromTextAsset(asset);
        }

        /// <summary>
        /// Compute uniform scale multiplier to fit a trimmed visual body inside a target Unity world size.
        /// </summary>
        public static float ComputeFitScale(WfVisualBounds bounds, float targetWorldWidth, float targetWorldHeight)
        {
            if (bounds == null || !bounds.valid || bounds.unityVisualSize == null)
            {
                return 1f;
            }
            float w = bounds.unityVisualSize.x;
            float h = bounds.unityVisualSize.y;
            if (w <= 0f || h <= 0f)
            {
                return 1f;
            }
            return Mathf.Min(targetWorldWidth / w, targetWorldHeight / h);
        }
    }

    [Serializable]
    public sealed class WfBindingsManifest
    {
        public string schema;
        public string directory;
        public List<WfBindingNode> nodes = new List<WfBindingNode>();

        [NonSerialized]
        private Dictionary<string, WfBindingNode> byId;
        [NonSerialized]
        private Dictionary<ulong, WfBindingNode> byNumber;
        [NonSerialized]
        private Dictionary<string, WfBindingNode> byPath;

        public void RebuildIndex()
        {
            byId = new Dictionary<string, WfBindingNode>();
            byNumber = new Dictionary<ulong, WfBindingNode>();
            byPath = new Dictionary<string, WfBindingNode>();
            if (nodes == null)
            {
                return;
            }
            for (int i = 0; i < nodes.Count; i++)
            {
                WfBindingNode node = nodes[i];
                if (node == null)
                {
                    continue;
                }
                if (!string.IsNullOrEmpty(node.id))
                {
                    byId[node.id] = node;
                }
                byNumber[node.number] = node;
                if (!string.IsNullOrEmpty(node.path))
                {
                    byPath[node.path] = node;
                }
                node.RebuildIndex();
            }
        }

        public WfBindingNode FindById(string nodeId)
        {
            if (byId == null)
            {
                RebuildIndex();
            }
            WfBindingNode found;
            return !string.IsNullOrEmpty(nodeId) && byId.TryGetValue(nodeId, out found) ? found : null;
        }

        public WfBindingNode FindByNumber(ulong number)
        {
            if (byNumber == null)
            {
                RebuildIndex();
            }
            WfBindingNode found;
            return byNumber.TryGetValue(number, out found) ? found : null;
        }

        public WfBindingNode FindByPath(string nodePath)
        {
            if (byPath == null)
            {
                RebuildIndex();
            }
            WfBindingNode found;
            return !string.IsNullOrEmpty(nodePath) && byPath.TryGetValue(nodePath, out found) ? found : null;
        }
    }

    [Serializable]
    public sealed class WfBindingNode
    {
        public string id;
        public ulong number;
        public string path;
        public string nodeType;
        public string form;
        public string assetBase;
        public string resourceBase;
        public string mainPrefab;
        public List<WfBindingSprite> sprites = new List<WfBindingSprite>();
        public List<WfBindingProp> props = new List<WfBindingProp>();
        public List<WfBindingClip> clips = new List<WfBindingClip>();
        public List<WfBindingElement> elements = new List<WfBindingElement>();
        public List<WfBindingImage> images = new List<WfBindingImage>();

        [NonSerialized]
        private Dictionary<string, WfBindingProp> propsById;
        [NonSerialized]
        private Dictionary<string, WfBindingElement> elementsByName;
        [NonSerialized]
        private Dictionary<string, WfBindingClip> clipsByName;

        public void RebuildIndex()
        {
            propsById = new Dictionary<string, WfBindingProp>();
            elementsByName = new Dictionary<string, WfBindingElement>();
            clipsByName = new Dictionary<string, WfBindingClip>();
            if (props != null)
            {
                for (int i = 0; i < props.Count; i++)
                {
                    WfBindingProp p = props[i];
                    if (p != null && !string.IsNullOrEmpty(p.id))
                    {
                        propsById[p.id] = p;
                    }
                }
            }
            if (elements != null)
            {
                for (int i = 0; i < elements.Count; i++)
                {
                    WfBindingElement el = elements[i];
                    if (el != null && !string.IsNullOrEmpty(el.name))
                    {
                        elementsByName[el.name] = el;
                    }
                }
            }
            if (clips != null)
            {
                for (int i = 0; i < clips.Count; i++)
                {
                    WfBindingClip clip = clips[i];
                    if (clip != null && !string.IsNullOrEmpty(clip.name))
                    {
                        clipsByName[clip.name] = clip;
                    }
                }
            }
        }

        public WfBindingSprite GetSprite(int index)
        {
            if (sprites == null || index < 0 || index >= sprites.Count)
            {
                return null;
            }
            return sprites[index];
        }

        public WfBindingProp FindProp(string idOrName)
        {
            if (propsById == null)
            {
                RebuildIndex();
            }
            WfBindingProp found;
            if (!string.IsNullOrEmpty(idOrName) && propsById.TryGetValue(idOrName, out found))
            {
                return found;
            }
            if (props != null)
            {
                for (int i = 0; i < props.Count; i++)
                {
                    if (props[i] != null && props[i].name == idOrName)
                    {
                        return props[i];
                    }
                }
            }
            return null;
        }

        public WfBindingElement FindElement(string name)
        {
            if (elementsByName == null)
            {
                RebuildIndex();
            }
            WfBindingElement found;
            return !string.IsNullOrEmpty(name) && elementsByName.TryGetValue(name, out found) ? found : null;
        }

        public WfBindingClip FindClip(string name)
        {
            if (clipsByName == null)
            {
                RebuildIndex();
            }
            WfBindingClip found;
            return !string.IsNullOrEmpty(name) && clipsByName.TryGetValue(name, out found) ? found : null;
        }

        public WfBindingClip FindClip(string actionId, string direction)
        {
            if (clips == null)
            {
                return null;
            }
            for (int i = 0; i < clips.Count; i++)
            {
                WfBindingClip clip = clips[i];
                if (clip != null && clip.actionId == actionId && clip.direction == direction)
                {
                    return clip;
                }
            }
            return null;
        }
    }

    [Serializable]
    public sealed class WfPoint
    {
        public float x;
        public float y;

        public Vector2 ToVector2()
        {
            return new Vector2(x, y);
        }
    }

    [Serializable]
    public sealed class WfSize
    {
        public float width;
        public float height;
    }

    [Serializable]
    public sealed class WfRect
    {
        public bool valid;
        public float x;
        public float y;
        public float w;
        public float h;
    }

    [Serializable]
    public sealed class WfBorder
    {
        public float left;
        public float bottom;
        public float right;
        public float top;
    }

    [Serializable]
    public sealed class WfVisualBounds
    {
        public bool valid;
        public uint x;
        public uint y;
        public uint width;
        public uint height;
        public float centerX;
        public float centerY;
        public float fillRatio;
        public WfPoint offsetFromPivotPx = new WfPoint();
        public WfPoint unityCenterOffset = new WfPoint();
        public WfPoint unityVisualSize = new WfPoint();
    }

    [Serializable]
    public sealed class WfBindingSprite
    {
        public string assetPath;
        public string resourcePath;
        public string spriteName;
        public string texGuid;
        public long internalId;
        public WfRect rect = new WfRect();
        public WfSize textureSize = new WfSize();
        public WfPoint pivot = new WfPoint();
        public float ppu;
        public WfBorder border = new WfBorder();
        public WfVisualBounds visualBounds = new WfVisualBounds();
    }

    [Serializable]
    public sealed class WfPolygon
    {
        public List<WfPoint> points = new List<WfPoint>();
    }

    [Serializable]
    public sealed class WfBindingPropState
    {
        public string id;
        public int spriteIndex;
        public WfVisualBounds visualBounds = new WfVisualBounds();
        public List<WfPolygon> collisionUnity = new List<WfPolygon>();
        public List<WfPolygon> collisionPx = new List<WfPolygon>();
    }

    [Serializable]
    public sealed class WfBindingPropAnim
    {
        public string id;
        public string clipAsset;
        public List<float> durationsMs = new List<float>();
        public float totalMs;
        public bool loop;
        public List<int> frameSprites = new List<int>();
    }

    [Serializable]
    public sealed class WfBindingProp
    {
        public string id;
        public string name;
        public string prefab;
        public WfSize canvas = new WfSize();
        public WfPoint anchor = new WfPoint();
        public string anchorKind;
        public WfPoint pivot = new WfPoint();
        public uint pixelsPerTile;
        public WfVisualBounds bodyBounds = new WfVisualBounds();
        public List<WfBindingPropState> states = new List<WfBindingPropState>();
        public List<WfBindingPropAnim> animations = new List<WfBindingPropAnim>();
    }

    [Serializable]
    public sealed class WfBindingClip
    {
        public string actionId;
        public string direction;
        public string name;
        public string clipAsset;
        public WfSize canvas = new WfSize();
        public WfPoint anchor = new WfPoint();
        public WfPoint pivot = new WfPoint();
        public float ppu;
        public bool loop;
        public float totalMs;
        public WfVisualBounds bodyBounds = new WfVisualBounds();
        public List<float> durationsMs = new List<float>();
        public List<int> frameSprites = new List<int>();
    }

    [Serializable]
    public sealed class WfBindingElementState
    {
        public string name;
        public string role;
        public int spriteIndex;
        public WfRect rect = new WfRect();
        public WfBorder border = new WfBorder();
        public WfRect textSafe = new WfRect();
        public WfVisualBounds visualBounds = new WfVisualBounds();
    }

    [Serializable]
    public sealed class WfBindingElement
    {
        public string name;
        public string kind;
        public WfSize size = new WfSize();
        public string prefab;
        public List<WfBindingElementState> states = new List<WfBindingElementState>();
    }

    [Serializable]
    public sealed class WfBindingImage
    {
        public string name;
        public string assetPath;
        public string resourcePath;
        public int spriteIndex;
        public WfSize size = new WfSize();
        public WfPoint pivot = new WfPoint();
        public float ppu;
        public WfVisualBounds visualBounds = new WfVisualBounds();
    }
}
