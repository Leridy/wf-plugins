using UnityEngine;

namespace WeaveForge.Export
{
    /// <summary>
    /// Replays WeaveForge scrolling_scene parallax factors, drift, bob, sway,
    /// and optional horizontal repeatSpan wrapping in Unity.
    /// </summary>
    public sealed class WfParallaxLayer : MonoBehaviour
    {
        public float parallaxSpeed = 1f;
        public float driftSpeed;
        public float bobAmplitude;
        public float bobPeriod = 2f;
        public float swayDegrees;
        public float swayPeriod = 2f;
        public float repeatSpan;
        public float pixelsPerUnit = 100f;

        private Vector3 _originLocal;
        private Transform _cam;
        private float _camOriginX;
        private float _elapsed;

        private void OnEnable()
        {
            _originLocal = transform.localPosition;
            Camera mainCam = Camera.main;
            if (mainCam != null)
            {
                _cam = mainCam.transform;
                _camOriginX = _cam.position.x;
            }
        }

        private void LateUpdate()
        {
            _elapsed += Time.deltaTime;
            float dx = driftSpeed * _elapsed / Mathf.Max(1f, pixelsPerUnit);
            if (_cam != null)
            {
                dx += (_cam.position.x - _camOriginX) * (1f - parallaxSpeed);
            }
            if (repeatSpan > 0f)
            {
                float spanWorld = repeatSpan / Mathf.Max(1f, pixelsPerUnit);
                dx = Mathf.Repeat(dx + spanWorld * 0.5f, spanWorld) - spanWorld * 0.5f;
            }
            float dy = 0f;
            if (bobAmplitude != 0f && bobPeriod > 0f)
            {
                dy = -Mathf.Sin(_elapsed * (Mathf.PI * 2f) / bobPeriod) * (bobAmplitude / Mathf.Max(1f, pixelsPerUnit));
            }
            transform.localPosition = new Vector3(_originLocal.x + dx, _originLocal.y + dy, _originLocal.z);
            if (swayDegrees != 0f && swayPeriod > 0f)
            {
                float angle = swayDegrees * Mathf.Sin(_elapsed * (Mathf.PI * 2f) / swayPeriod);
                transform.localRotation = Quaternion.Euler(0f, 0f, -angle);
            }
        }
    }
}
