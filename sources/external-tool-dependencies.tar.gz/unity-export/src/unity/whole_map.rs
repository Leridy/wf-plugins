//! Shared `WfWholeMapTile.shader` and `WfWholeMapNav.cs` runtime documents.
use super::{Document, cs_meta, doc, guid, shader_meta};

pub const SHARED_OWNER_ID: &str = "shared-whole-map-runtime";
pub const SHADER_PATH: &str = "Shaders/WfWholeMapTile.shader";
const SHADER_META_PATH: &str = "Shaders/WfWholeMapTile.shader.meta";
const NAV_SCRIPT_PATH: &str = "Scripts/WfWholeMapNav.cs";
const NAV_SCRIPT_META_PATH: &str = "Scripts/WfWholeMapNav.cs.meta";

const SHADER_SOURCE: &str = include_str!("WfWholeMapTile.shader");
const NAV_CS_SOURCE: &str = include_str!("WfWholeMapNav.cs");

pub fn shared_runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let sh_guid = guid("shared:WfWholeMapTile.shader");
    let cs_guid = guid("shared:WfWholeMapNav.cs");
    vec![
        doc(directory, root, SHADER_PATH.into(), SHADER_SOURCE.into(), false),
        doc(directory, root, SHADER_META_PATH.into(), shader_meta(&sh_guid), false),
        doc(directory, root, NAV_SCRIPT_PATH.into(), NAV_CS_SOURCE.into(), false),
        doc(directory, root, NAV_SCRIPT_META_PATH.into(), cs_meta(&cs_guid), false),
    ]
}
