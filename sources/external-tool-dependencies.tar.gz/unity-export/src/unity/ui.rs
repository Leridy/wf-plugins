//! UI kit widget registration and binding builder for Unity CLI sync.
use super::bindings::{BindingElement, BindingElementState, BindingRect, BindingSize, SpriteTable};
use super::texture::{FilterMode, SliceSpec, SpriteKey, TextureRegistry};
use crate::model::{Kit, Margins, Style, ui::Widget};

pub(crate) struct RawStyle {
    pub style: Style,
    pub key: SpriteKey,
    pub sliced: bool,
    pub content: Option<Margins>,
    pub size: [f64; 2],
}

pub(crate) struct RegisteredWidget {
    pub widget_index: usize,
    pub states: Vec<RawStyle>,
}

pub(crate) fn register_widgets(registry: &mut TextureRegistry, kit: &Kit) -> Vec<RegisteredWidget> {
    kit.widgets
        .iter()
        .enumerate()
        .map(|(widget_index, widget)| {
            let states = widget
                .states
                .iter()
                .map(|state| {
                    let border = SliceSpec::border_from_margins(state.slice);
                    let sliced = border.iter().any(|&v| v > 0.0);
                    let key = registry.register(
                        &state.texture.path,
                        &format!("{}_{:?}", widget.name, state.style),
                        SliceSpec {
                            rect: state.texture.region,
                            pivot: [0.5, 0.5],
                            border,
                            ppu: 100.0,
                            filter: FilterMode::Bilinear,
                        },
                    );
                    RawStyle {
                        style: state.style,
                        key,
                        sliced,
                        content: state.content,
                        size: [state.width, state.height],
                    }
                })
                .collect();
            RegisteredWidget { widget_index, states }
        })
        .collect()
}

pub(crate) fn build_element_binding(
    widget: &Widget,
    prefab: String,
    raw_states: &[RawStyle],
    table: &mut SpriteTable<'_>,
) -> BindingElement {
    let mut states_out = Vec::with_capacity(raw_states.len());
    for st in raw_states {
        let sprite_index = table.add(&st.key);
        let sprite = &table.sprites[sprite_index];
        let role = format!("{:?}", st.style).to_ascii_lowercase();
        let text_safe = st.content.map_or_else(BindingRect::default, |m| BindingRect {
            valid: true,
            x: m.left,
            y: m.top,
            w: (st.size[0] - m.left - m.right).max(0.0),
            h: (st.size[1] - m.top - m.bottom).max(0.0),
        });
        states_out.push(BindingElementState {
            name: role.clone(),
            role,
            sprite_index,
            rect: sprite.rect.clone(),
            border: sprite.border.clone(),
            text_safe,
            visual_bounds: sprite.visual_bounds.clone(),
        });
    }
    BindingElement {
        name: widget.name.clone(),
        kind: format!("{:?}", widget.kind).to_ascii_lowercase(),
        size: BindingSize {
            width: widget.size.0,
            height: widget.size.1,
        },
        prefab,
        states: states_out,
    }
}
