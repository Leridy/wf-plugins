Shader "WeaveForge/WholeMapTile"
{
    Properties
    {
        [PerRendererData] _MainTex ("Base Tile", 2D) = "white" {}
        _MaskTex ("Tile Mask", 2D) = "white" {}
        _TexelSize ("Tile Texel Size (1/w, 1/h, w, h)", Vector) = (0.001, 0.001, 1000, 1000)
        _Color ("Tint", Color) = (1,1,1,1)
    }
    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True" }
        Cull Off
        Lighting Off
        ZWrite Off
        Blend SrcAlpha OneMinusSrcAlpha

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            struct appdata { float4 vertex : POSITION; float2 uv : TEXCOORD0; fixed4 color : COLOR; };
            struct v2f { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; fixed4 color : COLOR; };

            sampler2D _MainTex;
            sampler2D _MaskTex;
            float4 _TexelSize;
            fixed4 _Color;

            v2f vert(appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.uv = v.uv;
                o.color = v.color * _Color;
                return o;
            }

            fixed4 frag(v2f i) : SV_Target
            {
                fixed4 baseCol = tex2D(_MainTex, i.uv);
                float maxAlpha = 0.0;
                for (int dy = -1; dy <= 1; dy++)
                {
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        float2 suv = saturate(i.uv + float2(dx, dy) * _TexelSize.xy);
                        maxAlpha = max(maxAlpha, tex2D(_MaskTex, suv).a);
                    }
                }
                baseCol.a *= maxAlpha;
                return baseCol * i.color;
            }
            ENDCG
        }
    }
}
