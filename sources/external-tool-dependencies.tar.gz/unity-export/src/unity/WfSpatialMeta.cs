using System;
using UnityEngine;

namespace WeaveForge.Export
{
    [Serializable]
    public struct WfSceneRoleEntry
    {
        public string role;
        public string id;
        public string nodeName;
        public Vector3 position;
        public Vector3 forward;
        public bool blocked;
    }

    [Serializable]
    public struct WfModelClipMeta
    {
        public string name;
        public float duration;
        public bool loops;
        public Vector3 travel;
        public float soleLow;
        public float soleHigh;
        public int liftoffs;
        public string[] checks;
    }

    /// <summary>
    /// Attaches exported WeaveForge 3D semantics (scene roles, blocked doors,
    /// environment hints, bonesjson, motion clips, and source GLB relative path).
    /// </summary>
    public sealed class WfSpatialMeta : MonoBehaviour
    {
        public string kind = "model_3d";
        public string glbRelativePath = "";
        public float height;
        public float bottom;
        public string bonesJson = "{}";
        public string[] blockedDoors = Array.Empty<string>();
        public Color ambientColor = new Color(0.5f, 0.5f, 0.5f, 1f);
        public float ambientIntensity = 1f;
        public bool fogEnabled;
        public Color fogColor = Color.gray;
        public float fogDensity;
        public WfSceneRoleEntry[] roles = Array.Empty<WfSceneRoleEntry>();
        public WfModelClipMeta[] clips = Array.Empty<WfModelClipMeta>();
    }
}
