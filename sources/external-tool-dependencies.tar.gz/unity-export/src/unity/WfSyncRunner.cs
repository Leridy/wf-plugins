#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace WeaveForge.Editor
{
    public struct StampTarget
    {
        public string path;
        public string id;
        public long version;
        public string srcHash;
    }

    public static class WfSyncRunner
    {
        private static string ProjectPath(string relPath)
        {
            var root = Path.GetDirectoryName(Application.dataPath);
            return Path.Combine(root ?? "", relPath);
        }

        public static void Run()
        {
            var manifestPath = ProjectPath("Assets/WfTmpSync/manifest.json");
            if (!File.Exists(manifestPath))
            {
                Debug.LogError("WeaveForge sync manifest missing: " + manifestPath);
                EditorApplication.Exit(1);
                return;
            }
            var raw = File.ReadAllText(manifestPath, Encoding.UTF8);
            var manifest = JsonUtility.FromJson<SyncManifest>(raw);
            if (manifest == null || manifest.tasks == null)
            {
                Debug.LogError("WeaveForge invalid sync manifest JSON.");
                EditorApplication.Exit(1);
                return;
            }

            var stamps = new List<StampTarget>();
            foreach (var task in manifest.tasks)
            {
                ProcessTextures(task, stamps);
            }
            AssetDatabase.Refresh();
            foreach (var task in manifest.tasks)
            {
                ProcessClips(task, stamps);
                ProcessControllers(task, stamps);
                ProcessTileAssets(task, stamps);
                ProcessAnimPrefabs(task, stamps);
                ProcessPropPrefabs(task, stamps);
                ProcessTilemapPrefabs(task, stamps);
                ProcessUiPrefabs(task, stamps);
                WfSyncWorld.ProcessTask(task, stamps);
            }
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            foreach (var st in stamps)
            {
                StampFile(st.path, st.id, st.version, st.srcHash);
            }
        }

        internal static void QueueAssetAndMeta(List<StampTarget> stamps, string assetPath, string id, long version, string srcHash)
        {
            stamps.Add(new StampTarget { path = assetPath, id = id, version = version, srcHash = srcHash });
            stamps.Add(new StampTarget { path = assetPath + ".meta", id = id, version = version, srcHash = srcHash });
        }

        internal static void EnsureParentDir(string assetPath)
        {
            var normalized = assetPath.Replace('\\', '/');
            var dir = Path.GetDirectoryName(normalized)?.Replace('\\', '/');
            if (string.IsNullOrEmpty(dir)) return;
            var parts = dir.Split('/');
            if (parts.Length < 2 || parts[0] != "Assets")
            {
                var disk = ProjectPath(dir);
                if (!Directory.Exists(disk)) Directory.CreateDirectory(disk);
                return;
            }
            var cur = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                var next = cur + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(cur, parts[i]);
                }
                cur = next;
            }
        }

        internal static Sprite LoadSprite(string texAssetPath, bool multiple, string spriteName)
        {
            if (!multiple)
            {
                return AssetDatabase.LoadAssetAtPath<Sprite>(texAssetPath);
            }
            foreach (var obj in AssetDatabase.LoadAllAssetsAtPath(texAssetPath))
            {
                if (obj is Sprite sp && sp.name == spriteName)
                {
                    return sp;
                }
            }
            return AssetDatabase.LoadAssetAtPath<Sprite>(texAssetPath);
        }

        internal static Type FindType(string fullName, string defaultAssembly)
        {
            var t = Type.GetType(fullName + ", " + defaultAssembly);
            if (t != null) return t;
            foreach (var asm in new[] { "Assembly-CSharp", "UnityEngine", "UnityEditor", "UnityEngine.CoreModule", "UnityEngine.GridModule" })
            {
                t = Type.GetType(fullName + ", " + asm);
                if (t != null) return t;
            }
            return Type.GetType(fullName);
        }

        internal static void SetMember(object target, string name, object value)
        {
            var t = target.GetType();
            var p = t.GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            if (p != null) { p.SetValue(target, Coerce(p.PropertyType, value)); return; }
            var f = t.GetField(name, BindingFlags.Public | BindingFlags.Instance);
            if (f != null) f.SetValue(target, Coerce(f.FieldType, value));
        }

        internal static object GetMember(object target, string name)
        {
            var t = target.GetType();
            var p = t.GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
            if (p != null) return p.GetValue(target);
            var f = t.GetField(name, BindingFlags.Public | BindingFlags.Instance);
            return f != null ? f.GetValue(target) : null;
        }

        private static object Coerce(Type targetType, object value)
        {
            if (value != null && targetType.IsEnum)
            {
                if (value is string s) return Enum.Parse(targetType, s);
                return Enum.ToObject(targetType, value);
            }
            return value;
        }

        internal static object CallMethod(object target, string name, params object[] args)
        {
            return InvokeMatched(target.GetType(), target, BindingFlags.Public | BindingFlags.Instance, name, args);
        }

        internal static object CallStatic(Type type, string name, params object[] args)
        {
            return InvokeMatched(type, null, BindingFlags.Public | BindingFlags.Static, name, args);
        }

        private static object InvokeMatched(Type type, object instance, BindingFlags flags, string name, object[] args)
        {
            MethodInfo fallback = null;
            foreach (var m in type.GetMethods(flags))
            {
                if (m.Name != name) continue;
                var ps = m.GetParameters();
                if (ps.Length != args.Length) continue;
                fallback ??= m;
                bool ok = true;
                for (int i = 0; i < ps.Length; i++)
                {
                    if (args[i] != null && !ps[i].ParameterType.IsInstanceOfType(args[i])) { ok = false; break; }
                }
                if (ok) return m.Invoke(instance, args);
            }
            return fallback?.Invoke(instance, args);
        }

        private static void StampFile(string path, string id, long version, string srcHash)
        {
            var diskPath = ProjectPath(path);
            if (!File.Exists(diskPath)) return;
            var body = File.ReadAllText(diskPath, Encoding.UTF8);
            var idx = body.LastIndexOf("\n# wf unity-export ", StringComparison.Ordinal);
            if (idx >= 0) body = body.Substring(0, idx + 1);
            else if (body.StartsWith("# wf unity-export ", StringComparison.Ordinal)) body = "";
            if (!body.EndsWith("\n", StringComparison.Ordinal)) body += "\n";
            using (var sha = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(body);
                var digest = BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
                var footer = $"# wf unity-export {id} v{version} sha256={digest} src={srcHash}\n";
                File.WriteAllText(diskPath, body + footer, new UTF8Encoding(false));
            }
        }

        private static void ProcessTextures(SyncTask task, List<StampTarget> stamps)
        {
            if (task.textures == null) return;
            foreach (var tex in task.textures)
            {
                if (!tex.write) continue;
                var imp = AssetImporter.GetAtPath(tex.assetPath) as TextureImporter;
                if (imp == null) continue;
                imp.textureType = TextureImporterType.Sprite;
                imp.filterMode = tex.filterMode == 0 ? FilterMode.Point : FilterMode.Bilinear;
                imp.spritePixelsPerUnit = (float)tex.ppu;
                imp.alphaIsTransparency = true;
                imp.mipmapEnabled = false;
                if (!tex.multiple && tex.slices != null && tex.slices.Count > 0)
                {
                    var s0 = tex.slices[0];
                    imp.spriteImportMode = SpriteImportMode.Single;
                    imp.spriteBorder = new Vector4((float)s0.borderL, (float)s0.borderB, (float)s0.borderR, (float)s0.borderT);
                    var tis = new TextureImporterSettings();
                    imp.ReadTextureSettings(tis);
                    tis.spriteAlignment = (int)SpriteAlignment.Custom;
                    tis.spritePivot = new Vector2((float)s0.pivotX, (float)s0.pivotY);
                    imp.SetTextureSettings(tis);
                }
                else
                {
                    imp.spriteImportMode = SpriteImportMode.Multiple;
                    var so = new SerializedObject(imp);
                    var spritesProp = so.FindProperty("m_SpriteSheet.m_Sprites");
                    spritesProp.arraySize = tex.slices.Count;
                    for (int i = 0; i < tex.slices.Count; i++)
                    {
                        var sl = tex.slices[i];
                        var el = spritesProp.GetArrayElementAtIndex(i);
                        el.FindPropertyRelative("m_Name").stringValue = sl.name;
                        el.FindPropertyRelative("m_Rect").rectValue = new Rect((float)sl.x, (float)sl.y, (float)sl.w, (float)sl.h);
                        el.FindPropertyRelative("m_Pivot").vector2Value = new Vector2((float)sl.pivotX, (float)sl.pivotY);
                        el.FindPropertyRelative("m_Border").vector4Value = new Vector4((float)sl.borderL, (float)sl.borderB, (float)sl.borderR, (float)sl.borderT);
                        el.FindPropertyRelative("m_Alignment").intValue = 9;
                        el.FindPropertyRelative("m_InternalID").longValue = sl.internalId;
                        el.FindPropertyRelative("m_SpriteID").stringValue = string.IsNullOrEmpty(sl.spriteId) ? Guid.NewGuid().ToString("N") : sl.spriteId;
                    }
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
                imp.SaveAndReimport();
                stamps.Add(new StampTarget { path = tex.assetPath + ".meta", id = task.id, version = task.version, srcHash = task.srcHash });
            }
        }

        private static void ProcessClips(SyncTask task, List<StampTarget> stamps)
        {
            if (task.clips == null || task.clips.Count == 0) return;
            var clipType = FindType("UnityEngine.AnimationClip", "UnityEngine.AnimationModule");
            var kfType = FindType("UnityEditor.ObjectReferenceKeyframe", "UnityEditor");
            var ecbType = FindType("UnityEditor.EditorCurveBinding", "UnityEditor");
            var auType = FindType("UnityEditor.AnimationUtility", "UnityEditor");
            if (clipType == null || kfType == null || ecbType == null || auType == null) return;
            foreach (var c in task.clips)
            {
                if (!c.write) continue;
                EnsureParentDir(c.assetPath);
                var clip = Activator.CreateInstance(clipType) as UnityEngine.Object;
                clip.name = c.stateName;
                SetMember(clip, "frameRate", (float)c.sampleRate);
                var keyList = new List<object>(c.frames.Count + 1);
                double t = 0.0;
                Sprite lastSp = null;
                foreach (var f in c.frames)
                {
                    var sp = LoadSprite(f.texAssetPath, f.multiple, f.spriteName);
                    var kf = Activator.CreateInstance(kfType);
                    SetMember(kf, "time", (float)t);
                    SetMember(kf, "value", sp);
                    keyList.Add(kf);
                    t += f.durationMs / 1000.0;
                    lastSp = sp;
                }
                if (lastSp != null)
                {
                    var kf = Activator.CreateInstance(kfType);
                    SetMember(kf, "time", (float)t);
                    SetMember(kf, "value", lastSp);
                    keyList.Add(kf);
                }
                var arr = Array.CreateInstance(kfType, keyList.Count);
                for (int i = 0; i < keyList.Count; i++) arr.SetValue(keyList[i], i);
                var binding = CallStatic(ecbType, "PPtrCurve", "", typeof(SpriteRenderer), "m_Sprite");
                CallStatic(auType, "SetObjectReferenceCurve", clip, binding, arr);
                var so = new SerializedObject(clip);
                var loopProp = so.FindProperty("m_AnimationClipSettings.m_LoopTime");
                if (loopProp != null)
                {
                    loopProp.boolValue = c.looped;
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
                AssetDatabase.CreateAsset(clip, c.assetPath);
                QueueAssetAndMeta(stamps, c.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessControllers(SyncTask task, List<StampTarget> stamps)
        {
            if (task.controllers == null || task.controllers.Count == 0) return;
            var ctrlType = FindType("UnityEditor.Animations.AnimatorController", "UnityEditor");
            if (ctrlType == null) return;
            foreach (var ctrlSpec in task.controllers)
            {
                if (!ctrlSpec.write) continue;
                EnsureParentDir(ctrlSpec.assetPath);
                if (File.Exists(ProjectPath(ctrlSpec.assetPath))) AssetDatabase.DeleteAsset(ctrlSpec.assetPath);
                var ctrl = CallStatic(ctrlType, "CreateAnimatorControllerAtPath", ctrlSpec.assetPath) as UnityEngine.Object;
                var layers = (Array)GetMember(ctrl, "layers");
                var sm = GetMember(layers.GetValue(0), "stateMachine");
                for (int i = 0; i < ctrlSpec.states.Count; i++)
                {
                    var stSpec = ctrlSpec.states[i];
                    var st = CallMethod(sm, "AddState", stSpec.name);
                    var clip = AssetDatabase.LoadMainAssetAtPath(stSpec.clipAssetPath);
                    SetMember(st, "motion", clip);
                    if (i == 0) SetMember(sm, "defaultState", st);
                }
                EditorUtility.SetDirty(ctrl);
                QueueAssetAndMeta(stamps, ctrlSpec.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessTileAssets(SyncTask task, List<StampTarget> stamps)
        {
            if (task.tileAssets == null || task.tileAssets.Count == 0) return;
            var tileType = FindType("UnityEngine.Tilemaps.Tile", "UnityEngine.TilemapModule");
            if (tileType == null) return;
            foreach (var t in task.tileAssets)
            {
                if (!t.write) continue;
                EnsureParentDir(t.assetPath);
                var tile = ScriptableObject.CreateInstance(tileType);
                tile.name = t.name;
                SetMember(tile, "sprite", LoadSprite(t.texAssetPath, t.multiple, t.spriteName));
                SetMember(tile, "color", Color.white);
                SetMember(tile, "flags", "LockColor");
                SetMember(tile, "colliderType", "None");
                AssetDatabase.CreateAsset(tile, t.assetPath);
                QueueAssetAndMeta(stamps, t.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessAnimPrefabs(SyncTask task, List<StampTarget> stamps)
        {
            if (task.animPrefabs == null) return;
            var animType = FindType("UnityEngine.Animator", "UnityEngine.AnimationModule");
            foreach (var p in task.animPrefabs)
            {
                if (!p.write) continue;
                EnsureParentDir(p.assetPath);
                var go = new GameObject(p.displayName);
                var sr = go.AddComponent<SpriteRenderer>();
                sr.sprite = LoadSprite(p.texAssetPath, p.multiple, p.spriteName);
                if (animType != null && !string.IsNullOrEmpty(p.ctrlAssetPath))
                {
                    var anim = go.AddComponent(animType);
                    SetMember(anim, "runtimeAnimatorController", AssetDatabase.LoadMainAssetAtPath(p.ctrlAssetPath));
                }
                PrefabUtility.SaveAsPrefabAsset(go, p.assetPath);
                UnityEngine.Object.DestroyImmediate(go);
                QueueAssetAndMeta(stamps, p.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessPropPrefabs(SyncTask task, List<StampTarget> stamps)
        {
            if (task.propPrefabs == null) return;
            var animType = FindType("UnityEngine.Animator", "UnityEngine.AnimationModule");
            foreach (var p in task.propPrefabs)
            {
                if (!p.write) continue;
                EnsureParentDir(p.assetPath);
                var go = new GameObject(p.name);
                var sr = go.AddComponent<SpriteRenderer>();
                sr.sprite = LoadSprite(p.texAssetPath, p.multiple, p.spriteName);
                if (animType != null && !string.IsNullOrEmpty(p.ctrlAssetPath))
                {
                    var anim = go.AddComponent(animType);
                    SetMember(anim, "runtimeAnimatorController", AssetDatabase.LoadMainAssetAtPath(p.ctrlAssetPath));
                }
                if (p.rootPolys != null && p.rootPolys.Count > 0)
                {
                    WfSyncWorld.AddPolygonCollider(go, p.rootPolys, false);
                }
                if (p.stateColliders != null)
                {
                    foreach (var sc in p.stateColliders)
                    {
                        var child = new GameObject(sc.name);
                        child.transform.SetParent(go.transform, false);
                        child.SetActive(sc.active);
                        WfSyncWorld.AddPolygonCollider(child, sc.polys, false);
                    }
                }
                PrefabUtility.SaveAsPrefabAsset(go, p.assetPath);
                UnityEngine.Object.DestroyImmediate(go);
                QueueAssetAndMeta(stamps, p.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessTilemapPrefabs(SyncTask task, List<StampTarget> stamps)
        {
            if (task.tilemapPrefabs == null || task.tilemapPrefabs.Count == 0) return;
            var gridType = FindType("UnityEngine.Grid", "UnityEngine.GridModule");
            var tmType = FindType("UnityEngine.Tilemaps.Tilemap", "UnityEngine.TilemapModule");
            var tmrType = FindType("UnityEngine.Tilemaps.TilemapRenderer", "UnityEngine.TilemapModule");
            var edgeType = FindType("UnityEngine.EdgeCollider2D", "UnityEngine.Physics2DModule");
            foreach (var p in task.tilemapPrefabs)
            {
                if (!p.write) continue;
                EnsureParentDir(p.assetPath);
                var rootGo = new GameObject(p.displayName);
                if (gridType != null)
                {
                    var grid = rootGo.AddComponent(gridType);
                    SetMember(grid, "cellLayout", p.isometric ? "Isometric" : "Rectangle");
                    SetMember(grid, "cellSize", new Vector3(1f, (float)p.cellHeight, p.isometric ? 1f : 0f));
                }
                foreach (var layer in p.layers)
                {
                    var lGo = new GameObject(layer.name);
                    lGo.transform.SetParent(rootGo.transform, false);
                    lGo.transform.localPosition = new Vector3((float)layer.shiftX, (float)layer.shiftY, 0f);
                    if (tmType != null && tmrType != null)
                    {
                        var tm = lGo.AddComponent(tmType);
                        var tmr = lGo.AddComponent(tmrType);
                        SetMember(tmr, "sortingOrder", layer.order);
                        if (p.isometric) SetMember(tmr, "sortOrder", "TopRight");
                        foreach (var cell in layer.cells)
                        {
                            var tile = AssetDatabase.LoadMainAssetAtPath(cell.tileAssetPath);
                            if (tile != null) CallMethod(tm, "SetTile", new Vector3Int(cell.x, cell.y, 0), tile);
                        }
                    }
                }
                if (p.sprites != null && p.sprites.Count > 0)
                {
                    var sceneGo = new GameObject("Scene");
                    sceneGo.transform.SetParent(rootGo.transform, false);
                    foreach (var spSpec in p.sprites)
                    {
                        var spGo = new GameObject(spSpec.name);
                        spGo.transform.SetParent(sceneGo.transform, false);
                        spGo.transform.localPosition = new Vector3((float)spSpec.posX, (float)spSpec.posY, 0f);
                        spGo.transform.localRotation = Quaternion.Euler(0f, 0f, (float)spSpec.rotDeg);
                        var visGo = new GameObject("Visual");
                        visGo.transform.SetParent(spGo.transform, false);
                        visGo.transform.localPosition = new Vector3((float)spSpec.visX, (float)spSpec.visY, 0f);
                        visGo.transform.localScale = new Vector3((float)spSpec.scaleX, (float)spSpec.scaleY, 1f);
                        var sr = visGo.AddComponent<SpriteRenderer>();
                        sr.sprite = LoadSprite(spSpec.texAssetPath, spSpec.multiple, spSpec.spriteName);
                        sr.flipX = spSpec.flipX;
                        sr.color = new Color(1f, 1f, 1f, (float)spSpec.opacity);
                        sr.sortingOrder = spSpec.order;
                    }
                }
                if ((p.obstacles != null && p.obstacles.Count > 0) || (p.walkable != null && p.walkable.Count > 0))
                {
                    var colGo = new GameObject("Collision");
                    colGo.transform.SetParent(rootGo.transform, false);
                    foreach (var obs in p.obstacles)
                    {
                        var oGo = new GameObject(obs.name);
                        oGo.transform.SetParent(colGo.transform, false);
                        WfSyncWorld.AddPolygonCollider(oGo, new List<PolyPathSpec> { obs.poly }, false);
                    }
                    if (edgeType != null)
                    {
                        foreach (var edge in p.walkable)
                        {
                            var eGo = new GameObject(edge.name);
                            eGo.transform.SetParent(colGo.transform, false);
                            var ec = eGo.AddComponent(edgeType);
                            var pts = new List<Vector2>(edge.poly.points.Count + 1);
                            foreach (var pt in edge.poly.points) pts.Add(new Vector2((float)pt.x, (float)pt.y));
                            if (pts.Count > 1 && pts[pts.Count - 1] != pts[0]) pts.Add(pts[0]);
                            SetMember(ec, "points", pts.ToArray());
                        }
                    }
                }
                if (p.hasSpawn)
                {
                    var spawnGo = new GameObject("Spawn");
                    spawnGo.transform.SetParent(rootGo.transform, false);
                    spawnGo.transform.localPosition = new Vector3((float)p.spawnX, (float)p.spawnY, 0f);
                }
                PrefabUtility.SaveAsPrefabAsset(rootGo, p.assetPath);
                UnityEngine.Object.DestroyImmediate(rootGo);
                QueueAssetAndMeta(stamps, p.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static void ProcessUiPrefabs(SyncTask task, List<StampTarget> stamps)
        {
            if (task.uiPrefabs == null || task.uiPrefabs.Count == 0) return;
            var imgType = FindType("UnityEngine.UI.Image", "UnityEngine.UI");
            var btnType = FindType("UnityEngine.UI.Button", "UnityEngine.UI");
            var togType = FindType("UnityEngine.UI.Toggle", "UnityEngine.UI");
            var sldType = FindType("UnityEngine.UI.Slider", "UnityEngine.UI");
            if (imgType == null) return;
            foreach (var u in task.uiPrefabs)
            {
                if (!u.write) continue;
                EnsureParentDir(u.assetPath);
                var go = CreateUiNode(u.name, null, (float)u.width, (float)u.height);
                if (u.kind == "press")
                {
                    var img = AddUiImage(go, imgType, u.rest);
                    var sel = go.AddComponent(btnType);
                    ConfigureSelectable(sel, img, u.hover, u.pressed, u.disabled, true);
                    if (u.hasContent) CreateUiInsetChild("Content", go, u.content);
                }
                else if (u.kind == "flip")
                {
                    var bg = CreateUiFullStretch("Background", go);
                    var bgImg = AddUiImage(bg, imgType, u.rest);
                    var ck = CreateUiFullStretch("Checkmark", go);
                    var ckImg = AddUiImage(ck, imgType, u.onSprite);
                    var tog = go.AddComponent(togType);
                    ConfigureSelectable(tog, bgImg, u.hover, u.pressed, u.disabled, true);
                    var so = new SerializedObject(tog);
                    var gProp = so.FindProperty("graphic");
                    if (gProp != null) { gProp.objectReferenceValue = ckImg; so.ApplyModifiedPropertiesWithoutUndo(); }
                }
                else
                {
                    var bg = CreateUiFullStretch("Background", go);
                    AddUiImage(bg, imgType, u.rest);
                    var fillArea = CreateUiFullStretch("Fill Area", go);
                    var fill = CreateUiFullStretch("Fill", fillArea);
                    var fillImg = AddUiImage(fill, imgType, u.onSprite);
                    var handleArea = CreateUiFullStretch("Handle Slide Area", go);
                    GameObject handle = null;
                    if (!string.IsNullOrEmpty(u.thumbRest.texAssetPath))
                    {
                        handle = CreateUiNode("Handle", handleArea, 20f, (float)u.height);
                        AddUiImage(handle, imgType, u.thumbRest);
                    }
                    var sld = go.AddComponent(sldType);
                    if (u.kind == "slide")
                    {
                        ConfigureSelectable(sld, handle != null ? handle.GetComponent(imgType) : null, u.thumbHover, u.thumbHover, u.thumbDisabled, true);
                    }
                    else
                    {
                        ConfigureSelectable(sld, null, u.hover, u.pressed, u.disabled, false);
                    }
                    var so = new SerializedObject(sld);
                    var fProp = so.FindProperty("m_FillRect");
                    if (fProp != null) fProp.objectReferenceValue = fill.GetComponent<RectTransform>();
                    if (handle != null) { var hProp = so.FindProperty("m_HandleRect"); if (hProp != null) hProp.objectReferenceValue = handle.GetComponent<RectTransform>(); }
                    so.ApplyModifiedPropertiesWithoutUndo();
                }
                PrefabUtility.SaveAsPrefabAsset(go, u.assetPath);
                UnityEngine.Object.DestroyImmediate(go);
                QueueAssetAndMeta(stamps, u.assetPath, task.id, task.version, task.srcHash);
            }
        }

        private static GameObject CreateUiNode(string name, GameObject parent, float w, float h)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = 5;
            if (parent != null) go.transform.SetParent(parent.transform, false);
            var rt = go.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(w, h);
            return go;
        }

        private static GameObject CreateUiFullStretch(string name, GameObject parent)
        {
            var go = CreateUiNode(name, parent, 0f, 0f);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero; rt.offsetMax = Vector2.zero;
            return go;
        }

        private static void CreateUiInsetChild(string name, GameObject parent, double[] m)
        {
            var go = CreateUiFullStretch(name, parent);
            var rt = go.GetComponent<RectTransform>();
            rt.offsetMin = new Vector2((float)m[0], (float)m[3]);
            rt.offsetMax = new Vector2(-(float)m[1], -(float)m[2]);
        }

        private static Component AddUiImage(GameObject go, Type imgType, SpriteRefSpec spSpec)
        {
            var crType = FindType("UnityEngine.CanvasRenderer", "UnityEngine.UIModule");
            if (crType != null) go.AddComponent(crType);
            var img = go.AddComponent(imgType);
            if (!string.IsNullOrEmpty(spSpec.texAssetPath))
            {
                var sp = LoadSprite(spSpec.texAssetPath, spSpec.multiple, spSpec.spriteName);
                var so = new SerializedObject(img);
                so.FindProperty("m_Sprite").objectReferenceValue = sp;
                if (spSpec.sliced) so.FindProperty("m_Type").intValue = 1;
                so.ApplyModifiedPropertiesWithoutUndo();
            }
            return img;
        }

        private static void ConfigureSelectable(Component sel, Component targetGraphic, SpriteRefSpec hover, SpriteRefSpec pressed, SpriteRefSpec disabled, bool interactable)
        {
            var so = new SerializedObject(sel);
            var iProp = so.FindProperty("m_Interactable"); if (iProp != null) iProp.boolValue = interactable;
            var tProp = so.FindProperty("m_TargetGraphic"); if (tProp != null) tProp.objectReferenceValue = targetGraphic;
            var hSp = !string.IsNullOrEmpty(hover.texAssetPath) ? LoadSprite(hover.texAssetPath, hover.multiple, hover.spriteName) : null;
            var pSp = !string.IsNullOrEmpty(pressed.texAssetPath) ? LoadSprite(pressed.texAssetPath, pressed.multiple, pressed.spriteName) : null;
            var dSp = !string.IsNullOrEmpty(disabled.texAssetPath) ? LoadSprite(disabled.texAssetPath, disabled.multiple, disabled.spriteName) : null;
            var trProp = so.FindProperty("m_Transition"); if (trProp != null) trProp.intValue = (hSp != null || pSp != null || dSp != null) ? 2 : 1;
            var ss = so.FindProperty("m_SpriteState");
            if (ss != null)
            {
                ss.FindPropertyRelative("m_HighlightedSprite").objectReferenceValue = hSp;
                ss.FindPropertyRelative("m_PressedSprite").objectReferenceValue = pSp;
                ss.FindPropertyRelative("m_DisabledSprite").objectReferenceValue = dSp;
            }
            so.ApplyModifiedPropertiesWithoutUndo();
        }
    }

    [Serializable] public class SyncManifest { public List<SyncTask> tasks; }
    [Serializable] public class SyncTask {
        public string id; public long version; public string srcHash;
        public List<TextureTask> textures; public List<ClipTask> clips; public List<ControllerTask> controllers;
        public List<TileAssetTask> tileAssets; public List<MaterialTask> materials;
        public List<AnimPrefabTask> animPrefabs; public List<PropPrefabTask> propPrefabs;
        public List<TilemapPrefabTask> tilemapPrefabs; public List<UiPrefabTask> uiPrefabs;
        public List<ParticlePrefabTask> particlePrefabs; public List<WholeMapPrefabTask> wholeMapPrefabs;
        public List<ParallaxPrefabTask> parallaxPrefabs; public List<Model3dPrefabTask> model3dPrefabs;
        public List<Scene3dPrefabTask> scene3dPrefabs;
    }
    [Serializable] public class TextureTask { public bool write; public string assetPath; public double ppu; public int filterMode; public bool multiple; public List<SliceSpec> slices; }
    [Serializable] public class SliceSpec { public string name; public double x; public double y; public double w; public double h; public double pivotX; public double pivotY; public double borderL; public double borderB; public double borderR; public double borderT; public string spriteId; public long internalId; }
    [Serializable] public class SpriteRefSpec { public string texAssetPath; public bool multiple; public string spriteName; public bool sliced; }
    [Serializable] public class ClipTask { public bool write; public string assetPath; public string stateName; public double sampleRate; public bool looped; public List<ClipFrameSpec> frames; }
    [Serializable] public class ClipFrameSpec { public string texAssetPath; public bool multiple; public string spriteName; public double durationMs; }
    [Serializable] public class ControllerTask { public bool write; public string assetPath; public List<ControllerStateSpec> states; }
    [Serializable] public class ControllerStateSpec { public string name; public string clipAssetPath; }
    [Serializable] public class TileAssetTask { public bool write; public string assetPath; public string name; public string texAssetPath; public bool multiple; public string spriteName; }
    [Serializable] public class MaterialTask { public bool write; public string assetPath; public string name; public string shaderAssetPath; public string maskTexAssetPath; public int width; public int height; }
    [Serializable] public class AnimPrefabTask { public bool write; public string assetPath; public string displayName; public string texAssetPath; public bool multiple; public string spriteName; public string ctrlAssetPath; }
    [Serializable] public class PropPrefabTask { public bool write; public string assetPath; public string name; public string texAssetPath; public bool multiple; public string spriteName; public string ctrlAssetPath; public List<PolyPathSpec> rootPolys; public List<PropStateColliderSpec> stateColliders; }
    [Serializable] public class PropStateColliderSpec { public string name; public bool active; public List<PolyPathSpec> polys; }
    [Serializable] public class TilemapPrefabTask { public bool write; public string assetPath; public string displayName; public bool isometric; public double cellHeight; public List<TilemapLayerSpec> layers; public List<TilemapSpriteSpec> sprites; public List<TilemapObsSpec> obstacles; public List<TilemapObsSpec> walkable; public bool hasSpawn; public double spawnX; public double spawnY; }
    [Serializable] public class TilemapLayerSpec { public string name; public int order; public double shiftX; public double shiftY; public List<TilemapCellSpec> cells; }
    [Serializable] public class TilemapCellSpec { public int x; public int y; public string tileAssetPath; }
    [Serializable] public class TilemapSpriteSpec { public string name; public double posX; public double posY; public double rotDeg; public double visX; public double visY; public double scaleX; public double scaleY; public string texAssetPath; public bool multiple; public string spriteName; public bool flipX; public double opacity; public int order; }
    [Serializable] public class TilemapObsSpec { public string name; public PolyPathSpec poly; }
    [Serializable] public class Vec2Spec { public double x; public double y; }
    [Serializable] public class Vec3Spec { public double x; public double y; public double z; }
    [Serializable] public class PolyPathSpec { public List<Vec2Spec> points; }
    [Serializable] public class UiPrefabTask { public bool write; public string assetPath; public string name; public string kind; public double width; public double height; public SpriteRefSpec rest; public SpriteRefSpec hover; public SpriteRefSpec pressed; public SpriteRefSpec disabled; public SpriteRefSpec onSprite; public SpriteRefSpec thumbRest; public SpriteRefSpec thumbHover; public SpriteRefSpec thumbDisabled; public bool hasContent; public double[] content; }
}
#endif
