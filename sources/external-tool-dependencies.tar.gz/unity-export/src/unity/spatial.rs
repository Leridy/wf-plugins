//! Shared `WfSpatialMeta.cs` runtime document.
use super::{Document, cs_meta, doc, guid};

pub const SHARED_OWNER_ID: &str = "shared-spatial-runtime";
const META_SCRIPT_PATH: &str = "Scripts/WfSpatialMeta.cs";
const META_SCRIPT_META_PATH: &str = "Scripts/WfSpatialMeta.cs.meta";
const META_CS_SOURCE: &str = include_str!("WfSpatialMeta.cs");

pub fn shared_runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let cs_guid = guid("shared:WfSpatialMeta.cs");
    vec![
        doc(directory, root, META_SCRIPT_PATH.into(), META_CS_SOURCE.into(), false),
        doc(directory, root, META_SCRIPT_META_PATH.into(), cs_meta(&cs_guid), false),
    ]
}
