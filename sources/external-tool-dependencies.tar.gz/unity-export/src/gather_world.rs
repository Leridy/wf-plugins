//! Texture loading, shared Unity runtimes, leftover cleanup, and CLI dispatch.
use crate::{
    cli_sync::{self, CliRun},
    model::{AlphaMask, png},
    paths::{self, invalid},
    reconcile,
    types::{Input, Plan, Status},
    unity::{
        Document,
        bindings::{self, BindingNode},
        parallax, particle, spatial, whole_map,
    },
};
use plugin_api::{
    Effect,
    platform::{LockedRow, LocksOutput},
};
use plugin_guest::{Host, HostError};
use std::collections::{BTreeMap, BTreeSet};

pub const MAX_OUTPUT: usize = 16 << 20;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum SharedKind {
    Particle,
    WholeMap,
    Parallax,
    Spatial,
}

pub type SharedRuntimes = BTreeSet<SharedKind>;
pub type TextureLoadResult = (BTreeMap<String, (u32, u32)>, BTreeMap<String, AlphaMask>);

#[allow(clippy::too_many_arguments)]
pub fn sync_shared_runtimes(
    host: &dyn Host,
    locks: &LocksOutput,
    directory: &str,
    root: &str,
    force: bool,
    runtimes: &SharedRuntimes,
    wanted: &mut BTreeSet<String>,
    size: &mut usize,
    plan: &mut Plan,
) -> Result<(), HostError> {
    type SharedBuilder = fn(&str, &str) -> Vec<Document>;
    let groups: [(SharedKind, &str, SharedBuilder); 4] = [
        (
            SharedKind::Particle,
            particle::SHARED_OWNER_ID,
            particle::shared_runtime_documents,
        ),
        (
            SharedKind::WholeMap,
            whole_map::SHARED_OWNER_ID,
            whole_map::shared_runtime_documents,
        ),
        (
            SharedKind::Parallax,
            parallax::SHARED_OWNER_ID,
            parallax::shared_runtime_documents,
        ),
        (
            SharedKind::Spatial,
            spatial::SHARED_OWNER_ID,
            spatial::shared_runtime_documents,
        ),
    ];

    for (kind, owner_id, build_docs) in groups {
        if !runtimes.contains(&kind) {
            continue;
        }
        emit_shared_docs(
            host,
            locks,
            directory,
            force,
            owner_id,
            build_docs(directory, root),
            wanted,
            size,
            plan,
        )?;
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
pub fn emit_shared_docs(
    host: &dyn Host,
    locks: &LocksOutput,
    directory: &str,
    force: bool,
    owner_id: &str,
    docs: Vec<Document>,
    wanted: &mut BTreeSet<String>,
    size: &mut usize,
    plan: &mut Plan,
) -> Result<(), HostError> {
    for document in docs {
        let path = paths::join(directory, &document.rel_path);
        if !wanted.insert(path.clone()) {
            return Err(invalid(format!("generated paths collide: {path}")));
        }
        ensure_not_locked(locks, directory, &path)?;
        let bytes = reconcile::stamped(owner_id, 1, &document.body, document.stamp);
        *size += bytes.len();
        if *size > MAX_OUTPUT {
            return Err(invalid("generated output exceeds 16 MiB; sync fewer nodes"));
        }
        let st = reconcile::file(host, &path, bytes, force, &mut plan.effects)?;
        if st == Status::Kept {
            plan.output.warnings.push(format!(
                "{path}: shared runtime has local edits; use --force to replace it."
            ));
        }
    }
    Ok(())
}

pub fn ensure_not_locked(locks: &LocksOutput, directory: &str, path: &str) -> Result<(), HostError> {
    if locks
        .nodes
        .iter()
        .any(|r| r.files.iter().any(|f| paths::join(directory, f) == path))
    {
        return Err(invalid(format!("generated path belongs to wf export: {path}")));
    }
    Ok(())
}

pub fn load_textures<'a>(
    host: &dyn Host,
    row: &LockedRow,
    directory: &str,
    prefix: &str,
    paths_iter: impl Iterator<Item = &'a str>,
    read_dims: bool,
    decode_alpha: bool,
) -> Result<TextureLoadResult, HostError> {
    let locked: BTreeSet<_> = row.files.iter().map(String::as_str).collect();
    let mut dims = BTreeMap::new();
    let mut masks = BTreeMap::new();
    for rel in paths_iter.collect::<BTreeSet<_>>() {
        let locked_path = paths::join(prefix, rel);
        if !locked.contains(locked_path.as_str()) {
            return Err(invalid(format!(
                "texture {locked_path:?} is not in the node's export lock"
            )));
        }
        let disk_path = paths::join(directory, &locked_path);
        let bytes = host.read(&disk_path)?;
        if read_dims {
            dims.insert(rel.to_owned(), png::dimensions(&bytes)?);
        }
        if decode_alpha && let Some(mask) = png::decode_alpha_optional(&bytes)? {
            masks.insert(rel.to_owned(), mask);
        }
    }
    Ok((dims, masks))
}

/// Removes stale previously generated files belonging to the active selection.
pub fn leftovers(
    host: &dyn Host,
    directory: &str,
    locks: &LocksOutput,
    all: bool,
    selected: &BTreeSet<String>,
    wanted: &BTreeSet<String>,
    plan: &mut Plan,
) -> Result<(), HostError> {
    let pattern = paths::join(
        &paths::glob(directory),
        "**/*.{meta,anim,controller,asset,prefab,mat,cs,shader}",
    );
    let listed = host.list(&pattern);
    if listed.len() >= host.list_limit() {
        plan.output
            .warnings
            .push("Generated-file discovery reached the host listing limit; some leftovers may remain.".into());
    }
    let locked: BTreeSet<_> = locks
        .nodes
        .iter()
        .flat_map(|r| &r.files)
        .map(|f| paths::join(directory, f))
        .collect();
    for path in listed {
        if wanted.contains(&path) || locked.contains(&path) {
            continue;
        }
        let bytes = host.read(&path)?;
        if let Some(id) = reconcile::owner(&bytes)
            && (all || selected.contains(id))
        {
            paths::relative(&path)?;
            plan.output.deleted.push(path.clone());
            plan.effects.push(Effect::DeleteFile { path });
        }
    }
    plan.output.deleted.sort();
    Ok(())
}

/// Emits bindings, shared runtime scripts, leftover deletions, and Unity CLI tasks.
#[allow(clippy::too_many_arguments)]
pub fn finish_sync(
    host: &dyn Host,
    input: &Input,
    locks: &LocksOutput,
    directory: &str,
    root: &str,
    locked_ids: &BTreeSet<String>,
    selected: &BTreeSet<String>,
    binding_nodes: BTreeMap<String, BindingNode>,
    runtimes: &SharedRuntimes,
    cli_run: CliRun,
    wanted: &mut BTreeSet<String>,
    size: &mut usize,
    plan: &mut Plan,
) -> Result<(), HostError> {
    let has_bindings = bindings::sync_manifest(
        host,
        directory,
        root,
        input.force,
        input.nodes.is_empty(),
        locked_ids,
        selected,
        binding_nodes,
        wanted,
        &mut plan.output.warnings,
        &mut plan.effects,
    )?;
    if has_bindings {
        emit_shared_docs(
            host,
            locks,
            directory,
            input.force,
            bindings::SHARED_OWNER_ID,
            bindings::runtime_documents(directory, root),
            wanted,
            size,
            plan,
        )?;
    }
    sync_shared_runtimes(host, locks, directory, root, input.force, runtimes, wanted, size, plan)?;
    leftovers(host, directory, locks, input.nodes.is_empty(), selected, wanted, plan)?;
    cli_sync::emit_cli_effects(host, root, cli_run.tasks, cli_run.seed_png_metas, &mut plan.effects)?;
    Ok(())
}
