//! PNG IHDR dimension check, pure-Rust IDAT alpha decoder, and `visualBounds` measurement.
use super::Rect;
use crate::paths::invalid;
use miniz_oxide::inflate::decompress_to_vec_zlib_with_limit;
use plugin_guest::HostError;
use serde::{Deserialize, Serialize};

const SIGNATURE: &[u8; 8] = b"\x89PNG\r\n\x1a\n";
const MAX_DIMENSION: u32 = 16_384;
const MAX_PIXELS: usize = 64_000_000;
const MAX_DECOMPRESSED: usize = 260_000_000;
/// Matches WeaveForge `ui_kit_model::raster::content_box` (`alpha <= 8` is faint edge fringe).
const ALPHA_THRESHOLD: u8 = 8;

#[derive(Clone, Debug)]
pub struct AlphaMask {
    pub width: u32,
    pub height: u32,
    pub alpha: Vec<u8>,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct VisualBounds {
    pub x: u32,
    pub y: u32,
    pub width: u32,
    pub height: u32,
    pub center_x: f64,
    pub center_y: f64,
    pub fill_ratio: f64,
}

impl VisualBounds {
    pub fn union<'a>(bounds: impl IntoIterator<Item = &'a Self>, canvas_w: f64, canvas_h: f64) -> Option<Self> {
        let mut left = u32::MAX;
        let mut top = u32::MAX;
        let mut right = 0u32;
        let mut bottom = 0u32;
        for b in bounds {
            if b.width == 0 || b.height == 0 {
                continue;
            }
            left = left.min(b.x);
            top = top.min(b.y);
            right = right.max(b.x + b.width - 1);
            bottom = bottom.max(b.y + b.height - 1);
        }
        if left == u32::MAX {
            return None;
        }
        let width = right - left + 1;
        let height = bottom - top + 1;
        let area = if canvas_w > 0.0 && canvas_h > 0.0 {
            canvas_w * canvas_h
        } else {
            1.0
        };
        Some(Self {
            x: left,
            y: top,
            width,
            height,
            center_x: f64::from(left) + f64::from(width) / 2.0,
            center_y: f64::from(top) + f64::from(height) / 2.0,
            fill_ratio: (f64::from(width) * f64::from(height)) / area,
        })
    }
}

impl AlphaMask {
    pub fn bounds_in_rect(&self, rect: Option<Rect>) -> Option<VisualBounds> {
        let (rx, ry, rw, rh) = match rect {
            Some(r) => {
                let rx = clamp_px(r.x).min(self.width);
                let ry = clamp_px(r.y).min(self.height);
                let rw = clamp_px(r.w).min(self.width.saturating_sub(rx));
                let rh = clamp_px(r.h).min(self.height.saturating_sub(ry));
                (rx, ry, rw, rh)
            }
            None => (0, 0, self.width, self.height),
        };
        if rw == 0 || rh == 0 {
            return None;
        }
        self.scan_bounds(rx, ry, rw, rh, ALPHA_THRESHOLD)
            .or_else(|| self.scan_bounds(rx, ry, rw, rh, 0))
    }

    fn scan_bounds(&self, rx: u32, ry: u32, rw: u32, rh: u32, threshold: u8) -> Option<VisualBounds> {
        let (mut min_x, mut min_y, mut max_x, mut max_y) = (u32::MAX, u32::MAX, 0u32, 0u32);
        let stride = self.width as usize;
        for ly in 0..rh {
            let row_start = (ry + ly) as usize * stride;
            for lx in 0..rw {
                if self.alpha[row_start + (rx + lx) as usize] > threshold {
                    min_x = min_x.min(lx);
                    min_y = min_y.min(ly);
                    max_x = max_x.max(lx);
                    max_y = max_y.max(ly);
                }
            }
        }
        (min_x != u32::MAX).then(|| {
            let width = max_x - min_x + 1;
            let height = max_y - min_y + 1;
            VisualBounds {
                x: min_x,
                y: min_y,
                width,
                height,
                center_x: f64::from(min_x) + f64::from(width) / 2.0,
                center_y: f64::from(min_y) + f64::from(height) / 2.0,
                fill_ratio: (f64::from(width) * f64::from(height)) / (f64::from(rw) * f64::from(rh)),
            }
        })
    }
}

fn clamp_px(value: f64) -> u32 {
    if !value.is_finite() || value <= 0.0 {
        return 0;
    }
    let clamped = value.round().clamp(0.0, f64::from(MAX_DIMENSION)) as i32;
    u32::try_from(clamped).unwrap_or(0)
}

/// Parse `(width, height)` from a PNG's IHDR chunk.
pub fn dimensions(bytes: &[u8]) -> Result<(u32, u32), HostError> {
    Ok(parse_ihdr(bytes)?.dims)
}

/// Validate header dimensions and decode 8-bit alpha mask when IDAT pixel chunks exist.
/// Header-only stubs without IDAT yield `Ok(None)` so lightweight synthetic tests still run.
pub fn decode_alpha_optional(bytes: &[u8]) -> Result<Option<AlphaMask>, HostError> {
    let header = parse_ihdr(bytes)?;
    let (width, height) = header.dims;
    let total_pixels = (width as usize)
        .checked_mul(height as usize)
        .filter(|&p| p <= MAX_PIXELS)
        .ok_or_else(|| invalid("PNG dimensions exceed safe pixel budget"))?;

    let mut pos = 8usize;
    let mut idat = Vec::new();
    let mut trns: Option<&[u8]> = None;
    let mut saw_plte = false;
    while pos + 12 <= bytes.len() {
        let len = u32::from_be_bytes([bytes[pos], bytes[pos + 1], bytes[pos + 2], bytes[pos + 3]]) as usize;
        let kind = &bytes[pos + 4..pos + 8];
        let data_start = pos + 8;
        let data_end = data_start.saturating_add(len);
        if data_end + 4 > bytes.len() {
            return Ok(None);
        }
        let data = &bytes[data_start..data_end];
        match kind {
            b"PLTE" => saw_plte = true,
            b"tRNS" => trns = Some(data),
            b"IDAT" => idat.extend_from_slice(data),
            b"IEND" => break,
            _ => {}
        }
        pos = data_end + 4;
    }

    if idat.is_empty() || (header.color_type == 3 && !saw_plte) {
        return Ok(None);
    }
    let Ok(raw) = decompress_to_vec_zlib_with_limit(&idat, MAX_DECOMPRESSED) else {
        return Ok(None);
    };

    let mut alpha = vec![255u8; total_pixels];
    let ok = if header.interlace == 0 {
        decode_pass(&header, &raw, width, height, 0, 1, 0, 1, width, trns, &mut alpha).is_some()
    } else if header.interlace == 1 {
        decode_adam7(&header, &raw, width, height, trns, &mut alpha)
    } else {
        false
    };
    Ok(ok.then_some(AlphaMask { width, height, alpha }))
}

struct Ihdr {
    dims: (u32, u32),
    bit_depth: u8,
    color_type: u8,
    interlace: u8,
    channels: usize,
}

fn parse_ihdr(bytes: &[u8]) -> Result<Ihdr, HostError> {
    if bytes.len() < 29 || &bytes[..8] != SIGNATURE {
        return Err(invalid("expected a valid PNG file header"));
    }
    let chunk_len = u32::from_be_bytes([bytes[8], bytes[9], bytes[10], bytes[11]]);
    if chunk_len < 13 || &bytes[12..16] != b"IHDR" {
        return Err(invalid("PNG file does not start with a valid IHDR chunk"));
    }
    let width = u32::from_be_bytes([bytes[16], bytes[17], bytes[18], bytes[19]]);
    let height = u32::from_be_bytes([bytes[20], bytes[21], bytes[22], bytes[23]]);
    if width == 0 || height == 0 || width > MAX_DIMENSION || height > MAX_DIMENSION {
        return Err(invalid(format!(
            "PNG dimensions {width}x{height} are outside supported bounds (1..={MAX_DIMENSION})"
        )));
    }
    let bit_depth = bytes[24];
    let color_type = bytes[25];
    let interlace = bytes[28];
    let channels = match (color_type, bit_depth) {
        (0, 1 | 2 | 4 | 8 | 16) | (3, 1 | 2 | 4 | 8) => 1,
        (4, 8 | 16) => 2,
        (2, 8 | 16) => 3,
        (6, 8 | 16) => 4,
        _ => {
            return Err(invalid(format!(
                "unsupported PNG colorType={color_type} bitDepth={bit_depth}"
            )));
        }
    };
    Ok(Ihdr {
        dims: (width, height),
        bit_depth,
        color_type,
        interlace,
        channels,
    })
}

fn decode_adam7(header: &Ihdr, raw: &[u8], width: u32, height: u32, trns: Option<&[u8]>, alpha: &mut [u8]) -> bool {
    const PASSES: [(u32, u32, u32, u32); 7] = [
        (0, 8, 0, 8),
        (4, 8, 0, 8),
        (0, 4, 4, 8),
        (2, 4, 0, 4),
        (0, 2, 2, 4),
        (1, 2, 0, 2),
        (0, 1, 1, 2),
    ];
    let mut offset = 0usize;
    for (x0, dx, y0, dy) in PASSES {
        let pw = if width > x0 { (width - x0).div_ceil(dx) } else { 0 };
        let ph = if height > y0 { (height - y0).div_ceil(dy) } else { 0 };
        if pw == 0 || ph == 0 {
            continue;
        }
        let Some(consumed) = decode_pass(header, &raw[offset..], pw, ph, x0, dx, y0, dy, width, trns, alpha) else {
            return false;
        };
        offset += consumed;
    }
    true
}

#[allow(clippy::too_many_arguments)]
fn decode_pass(
    header: &Ihdr,
    raw: &[u8],
    pw: u32,
    ph: u32,
    x0: u32,
    dx: u32,
    y0: u32,
    dy: u32,
    full_w: u32,
    trns: Option<&[u8]>,
    alpha: &mut [u8],
) -> Option<usize> {
    let bits_per_pixel = header.channels * usize::from(header.bit_depth);
    let row_bytes = (pw as usize * bits_per_pixel).div_ceil(8);
    let filter_bpp = bits_per_pixel.div_ceil(8);
    let expected_len = (row_bytes + 1).checked_mul(ph as usize)?;
    if raw.len() < expected_len {
        return None;
    }
    let mut prev = vec![0u8; row_bytes];
    let mut curr = vec![0u8; row_bytes];

    for py in 0..ph {
        let start = py as usize * (row_bytes + 1);
        let filter = raw[start];
        let src = &raw[start + 1..start + 1 + row_bytes];
        unfilter_row(filter, filter_bpp, src, &prev, &mut curr)?;
        let dst_row = (y0 + py * dy) as usize * full_w as usize;
        for px in 0..pw {
            let a = sample_alpha(header, &curr, px as usize, trns);
            alpha[dst_row + (x0 + px * dx) as usize] = a;
        }
        prev.copy_from_slice(&curr);
    }
    Some(expected_len)
}

fn unfilter_row(filter: u8, bpp: usize, src: &[u8], prev: &[u8], curr: &mut [u8]) -> Option<()> {
    match filter {
        0 => curr.copy_from_slice(src),
        1 => {
            for (i, &x) in src.iter().enumerate() {
                let left = if i >= bpp { curr[i - bpp] } else { 0 };
                curr[i] = x.wrapping_add(left);
            }
        }
        2 => {
            for (i, &x) in src.iter().enumerate() {
                curr[i] = x.wrapping_add(prev[i]);
            }
        }
        3 => {
            for (i, &x) in src.iter().enumerate() {
                let left = if i >= bpp { curr[i - bpp] } else { 0 };
                curr[i] = x.wrapping_add(u8::midpoint(left, prev[i]));
            }
        }
        4 => {
            for (i, &x) in src.iter().enumerate() {
                let left = if i >= bpp { curr[i - bpp] } else { 0 };
                let up = prev[i];
                let up_left = if i >= bpp { prev[i - bpp] } else { 0 };
                curr[i] = x.wrapping_add(paeth(left, up, up_left));
            }
        }
        _ => return None,
    }
    Some(())
}

fn paeth(left: u8, up: u8, up_left: u8) -> u8 {
    let (a, b, c) = (i32::from(left), i32::from(up), i32::from(up_left));
    let p = a + b - c;
    let pa = (p - a).abs();
    let pb = (p - b).abs();
    let pc = (p - c).abs();
    if pa <= pb && pa <= pc {
        left
    } else if pb <= pc {
        up
    } else {
        up_left
    }
}

fn sample_alpha(header: &Ihdr, row: &[u8], px: usize, trns: Option<&[u8]>) -> u8 {
    match (header.color_type, header.bit_depth) {
        (6, 8) => row[px * 4 + 3],
        (6, 16) => row[px * 8 + 6],
        (4, 8) => row[px * 2 + 1],
        (4, 16) => row[px * 4 + 2],
        (3, 8) => trns.and_then(|t| t.get(usize::from(row[px])).copied()).unwrap_or(255),
        (3, 1 | 2 | 4) => {
            let idx = packed_sample(row, px, usize::from(header.bit_depth));
            trns.and_then(|t| t.get(idx).copied()).unwrap_or(255)
        }
        (0, 8) => match trns {
            Some(t) if t.len() >= 2 && u16::from_be_bytes([t[0], t[1]]) == u16::from(row[px]) => 0,
            _ => 255,
        },
        (0, 16) => match trns {
            Some(t) if t.len() >= 2 && row[px * 2..px * 2 + 2] == t[..2] => 0,
            _ => 255,
        },
        (0, 1 | 2 | 4) => match trns {
            Some(t)
                if t.len() >= 2
                    && u16::from_be_bytes([t[0], t[1]])
                        == packed_sample(row, px, usize::from(header.bit_depth)) as u16 =>
            {
                0
            }
            _ => 255,
        },
        (2, 8) => match trns {
            Some(t)
                if t.len() >= 6
                    && u16::from_be_bytes([t[0], t[1]]) == u16::from(row[px * 3])
                    && u16::from_be_bytes([t[2], t[3]]) == u16::from(row[px * 3 + 1])
                    && u16::from_be_bytes([t[4], t[5]]) == u16::from(row[px * 3 + 2]) =>
            {
                0
            }
            _ => 255,
        },
        (2, 16) => match trns {
            Some(t) if t.len() >= 6 && row[px * 6..px * 6 + 6] == t[..6] => 0,
            _ => 255,
        },
        _ => 255,
    }
}

fn packed_sample(row: &[u8], px: usize, depth: usize) -> usize {
    let per_byte = 8 / depth;
    let byte = row[px / per_byte];
    let shift = 8 - depth * ((px % per_byte) + 1);
    usize::from((byte >> shift) & ((1u8 << depth) - 1))
}

#[cfg(test)]
mod tests {
    use super::*;
    use miniz_oxide::deflate::compress_to_vec_zlib;

    fn encode_rgba_png(width: u32, height: u32, pixels: &[u8], filter: u8) -> Vec<u8> {
        let mut raw = Vec::new();
        for y in 0..height {
            raw.push(filter);
            let row_start = (y * width * 4) as usize;
            let row = &pixels[row_start..row_start + (width * 4) as usize];
            match filter {
                0 => raw.extend_from_slice(row),
                1 => {
                    for (i, &b) in row.iter().enumerate() {
                        let left = if i >= 4 { row[i - 4] } else { 0 };
                        raw.push(b.wrapping_sub(left));
                    }
                }
                _ => raw.extend_from_slice(row),
            }
        }
        let idat = compress_to_vec_zlib(&raw, 6);
        let mut png = Vec::from(*SIGNATURE);
        let mut ihdr = Vec::new();
        ihdr.extend_from_slice(&width.to_be_bytes());
        ihdr.extend_from_slice(&height.to_be_bytes());
        ihdr.extend_from_slice(&[8, 6, 0, 0, 0]);
        push_chunk(&mut png, b"IHDR", &ihdr);
        push_chunk(&mut png, b"IDAT", &idat);
        push_chunk(&mut png, b"IEND", &[]);
        png
    }

    fn push_chunk(out: &mut Vec<u8>, kind: &[u8; 4], data: &[u8]) {
        out.extend_from_slice(&(data.len() as u32).to_be_bytes());
        out.extend_from_slice(kind);
        out.extend_from_slice(data);
        out.extend_from_slice(&0u32.to_be_bytes());
    }

    #[test]
    fn parses_ihdr_dimensions_and_rejects_corrupt_headers() {
        let png = encode_rgba_png(4, 4, &vec![0u8; 64], 0);
        assert_eq!(dimensions(&png).unwrap(), (4, 4));
        assert!(dimensions(b"not a png").is_err());

        let mut zero = png.clone();
        zero[16..20].copy_from_slice(&0u32.to_be_bytes());
        assert!(dimensions(&zero).is_err());
    }

    #[test]
    fn decodes_rgba_alpha_and_measures_bounds_inside_rect() {
        let mut rgba = vec![0u8; 8 * 8 * 4];
        for (px, py) in [(2u32, 3u32), (5, 3), (3, 6)] {
            let idx = ((py * 8 + px) * 4) as usize;
            rgba[idx..idx + 4].copy_from_slice(&[255, 128, 64, 255]);
        }
        // Faint fringe alpha=4 should be ignored when solid alpha>8 pixels exist.
        rgba[3] = 4;

        let png = encode_rgba_png(8, 8, &rgba, 1);
        let mask = decode_alpha_optional(&png).unwrap().expect("mask");
        let full = mask.bounds_in_rect(None).expect("bounds");
        assert_eq!((full.x, full.y, full.width, full.height), (2, 3, 4, 4));
        assert!((full.center_x - 4.0).abs() < 1e-6);
        assert!((full.center_y - 5.0).abs() < 1e-6);

        let sub = mask
            .bounds_in_rect(Some(Rect {
                x: 2.0,
                y: 2.0,
                w: 4.0,
                h: 5.0,
            }))
            .expect("sub");
        assert_eq!((sub.x, sub.y, sub.width, sub.height), (0, 1, 4, 4));
    }
}
