//! `whole_map` (`whole-map-artifact/3.0`) model: tile grid layout, depth-sorted
//! parts, 8 px navigation mask decoding (`r:` LEB128 RLE and `b:` bitmap),
//! walkable rectangle merging, blocking footprints, connections, and regions.
use super::Point;
use crate::paths::{self, invalid};
use plugin_guest::HostError;
use serde::Deserialize;
use std::cmp::Ordering;
use std::collections::{BTreeMap, BTreeSet};
use std::iter::once;

pub const CELL_PX: i64 = 8;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SortMode {
    Below,
    Sorted,
    Above,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum ConnectionKind {
    Stairs,
    Ramp,
}

#[derive(Clone, Copy, Debug, Deserialize)]
pub struct CharacterSpec {
    pub radius: i64,
    pub speed: i64,
}

#[derive(Clone, Debug, Deserialize)]
pub struct NavMask {
    pub x: i64,
    pub y: i64,
    pub columns: usize,
    pub rows: usize,
    pub data: String,
}

#[derive(Clone, Debug)]
pub struct CellRect {
    pub x: i64,
    pub y: i64,
    pub width: i64,
    pub height: i64,
}

#[derive(Clone, Debug)]
pub struct NavLayer {
    pub walkable_rects: Vec<CellRect>,
}

#[derive(Clone, Debug)]
pub struct NavConnection {
    pub id: String,
    pub kind: ConnectionKind,
    pub from: String,
    pub to: String,
    pub a: Point,
    pub b: Point,
}

#[derive(Clone, Debug)]
pub struct WaterRegion {
    pub id: String,
    pub polygon: Vec<Point>,
}

#[derive(Clone, Debug)]
pub struct PlacedTile {
    pub key: String,
    pub grid_x: i64,
    pub grid_y: i64,
    pub x: i64,
    pub y: i64,
    pub width: i64,
    pub height: i64,
    pub base_file: String,
    pub mask_file: Option<String>,
}

#[derive(Clone, Debug)]
pub struct MapPart {
    pub id: String,
    pub name: String,
    pub texture_file: String,
    pub x: f64,
    pub y: f64,
    pub foot: Point,
    pub footprints: Vec<Vec<Point>>,
    pub blocking: bool,
    pub sort_mode: SortMode,
    pub draw_order: i64,
    pub layer_z: i64,
    pub walkable_rects: Vec<CellRect>,
}

#[derive(Clone, Debug)]
pub struct WholeMap {
    pub perspective: String,
    pub tile_width: i64,
    pub tile_height: i64,
    pub tiles: Vec<PlacedTile>,
    pub parts: Vec<MapPart>,
    pub nav_layers: Vec<NavLayer>,
    pub connections: Vec<NavConnection>,
    pub regions: Vec<WaterRegion>,
    pub character: CharacterSpec,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct RawManifest {
    schema: String,
    perspective: String,
    tile_width: i64,
    tile_height: i64,
    horizontal_context: i64,
    vertical_context: i64,
    tiles: Vec<RawTile>,
    parts: Vec<RawPart>,
    #[serde(default)]
    navigation: Option<RawNavigation>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct RawTile {
    grid_x: i64,
    grid_y: i64,
    state: String,
}

#[derive(Deserialize)]
struct RawRect {
    x: f64,
    y: f64,
    width: f64,
    height: f64,
}

#[derive(Deserialize)]
struct RawPartSurface {
    offset: Point,
    cells: NavMask,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct RawPart {
    id: String,
    asset_part_id: String,
    name: String,
    rect: RawRect,
    #[serde(default)]
    surface: Option<RawPartSurface>,
    #[serde(default)]
    layer_id: Option<String>,
    foot: Point,
    #[serde(default)]
    footprints: Vec<Vec<Point>>,
    blocking: bool,
    sort_mode: SortMode,
    draw_order: i64,
}

#[derive(Deserialize)]
struct RawNavigation {
    #[serde(default)]
    layers: Vec<RawNavLayer>,
    #[serde(default)]
    connections: Vec<RawNavConnection>,
    #[serde(default)]
    regions: Vec<RawRegion>,
    character: CharacterSpec,
}

#[derive(Deserialize)]
struct RawNavLayer {
    id: String,
    z: i64,
    #[serde(default)]
    cells: Option<NavMask>,
}

#[derive(Deserialize)]
struct RawAxis {
    a: Point,
    b: Point,
}

#[derive(Deserialize)]
struct RawNavConnection {
    id: String,
    kind: ConnectionKind,
    from: String,
    to: String,
    axis: RawAxis,
}

#[derive(Deserialize)]
struct RawRegion {
    id: String,
    polygon: Vec<Point>,
}

impl WholeMap {
    pub fn read(bytes: &[u8], available: &BTreeSet<String>, prefix: &str) -> Result<Self, HostError> {
        let raw: RawManifest = super::parse(bytes)?;
        if raw.schema != "whole-map-artifact/3.0" {
            return Err(invalid(format!("unsupported whole_map schema {:?}", raw.schema)));
        }
        if raw.tile_width <= 0 || raw.tile_height <= 0 {
            return Err(invalid("whole_map tileWidth and tileHeight must be positive"));
        }
        let tiles = collect_tiles(&raw, available, prefix)?;
        let (layer_z, nav_layers, connections, regions, character) = parse_navigation(raw.navigation);
        let parts = parse_parts(raw.parts, &layer_z, available, prefix)?;

        Ok(Self {
            perspective: raw.perspective,
            tile_width: raw.tile_width,
            tile_height: raw.tile_height,
            tiles,
            parts,
            nav_layers,
            connections,
            regions,
            character,
        })
    }

    pub fn texture_paths(&self) -> impl Iterator<Item = &str> {
        self.tiles
            .iter()
            .flat_map(|t| once(t.base_file.as_str()).chain(t.mask_file.as_deref()))
            .chain(self.parts.iter().map(|p| p.texture_file.as_str()))
    }
}

fn collect_tiles(raw: &RawManifest, available: &BTreeSet<String>, prefix: &str) -> Result<Vec<PlacedTile>, HostError> {
    let h_ctx = f64::from(i32::try_from(raw.horizontal_context.clamp(0, 40)).unwrap_or(0));
    let v_ctx = f64::from(i32::try_from(raw.vertical_context.clamp(0, 40)).unwrap_or(0));
    let tw = f64::from(i32::try_from(raw.tile_width).unwrap_or(i32::MAX));
    let th = f64::from(i32::try_from(raw.tile_height).unwrap_or(i32::MAX));
    #[allow(clippy::cast_possible_truncation)]
    let step_x = ((tw * (1.0 - h_ctx / 100.0)).round() as i64).max(1);
    #[allow(clippy::cast_possible_truncation)]
    let step_y = ((th * (1.0 - v_ctx / 100.0)).round() as i64).max(1);

    let mut tiles = Vec::new();
    for tile in &raw.tiles {
        let seg = format!("{}-{}", tile.grid_x, tile.grid_y);
        let base_name = format!("tile-base-{seg}.png");
        let mask_name = format!("tile-mask-{seg}.png");
        let base_rel = paths::join(prefix, &base_name);
        let has_base = available.contains(&base_rel);
        if tile.state != "split" && !has_base {
            continue;
        }
        if !has_base {
            return Err(invalid(format!(
                "whole_map tile base {base_rel:?} is missing from export lock"
            )));
        }
        let mask_rel = paths::join(prefix, &mask_name);
        tiles.push(PlacedTile {
            key: format!("{}:{}", tile.grid_x, tile.grid_y),
            grid_x: tile.grid_x,
            grid_y: tile.grid_y,
            x: tile.grid_x * step_x,
            y: tile.grid_y * step_y,
            width: raw.tile_width,
            height: raw.tile_height,
            base_file: base_name,
            mask_file: available.contains(&mask_rel).then_some(mask_name),
        });
    }
    Ok(tiles)
}

type ParsedNavigation = (
    BTreeMap<String, i64>,
    Vec<NavLayer>,
    Vec<NavConnection>,
    Vec<WaterRegion>,
    CharacterSpec,
);

fn parse_navigation(navigation: Option<RawNavigation>) -> ParsedNavigation {
    let mut layer_z = BTreeMap::new();
    let mut nav_layers = Vec::new();
    let mut connections = Vec::new();
    let mut regions = Vec::new();
    let mut character = CharacterSpec { radius: 12, speed: 180 };

    if let Some(nav) = navigation {
        character = nav.character;
        for layer in nav.layers {
            layer_z.insert(layer.id, layer.z);
            let walkable_rects = layer
                .cells
                .as_ref()
                .map(|mask| merge_walkable_rects(mask, 0, 0))
                .unwrap_or_default();
            nav_layers.push(NavLayer { walkable_rects });
        }
        for conn in nav.connections {
            connections.push(NavConnection {
                id: conn.id,
                kind: conn.kind,
                from: conn.from,
                to: conn.to,
                a: conn.axis.a,
                b: conn.axis.b,
            });
        }
        for reg in nav.regions {
            regions.push(WaterRegion {
                id: reg.id,
                polygon: reg.polygon,
            });
        }
    }
    (layer_z, nav_layers, connections, regions, character)
}

fn parse_parts(
    raw_parts: Vec<RawPart>,
    layer_z: &BTreeMap<String, i64>,
    available: &BTreeSet<String>,
    prefix: &str,
) -> Result<Vec<MapPart>, HostError> {
    let mut parts = Vec::with_capacity(raw_parts.len());
    for part in raw_parts {
        let tex_name = format!("whole-part-{}.png", segment(&part.asset_part_id));
        let tex_rel = paths::join(prefix, &tex_name);
        if !available.contains(&tex_rel) {
            return Err(invalid(format!(
                "whole_map part texture {tex_rel:?} is missing from export lock"
            )));
        }
        if !part.rect.width.is_finite()
            || part.rect.width <= 0.0
            || !part.rect.height.is_finite()
            || part.rect.height <= 0.0
        {
            return Err(invalid(format!("whole_map part {:?} has invalid bounds", part.id)));
        }
        let z = part
            .layer_id
            .as_ref()
            .and_then(|id| layer_z.get(id).copied())
            .unwrap_or(0);
        let walkable_rects = part
            .surface
            .as_ref()
            .map(|s| {
                #[allow(clippy::cast_possible_truncation)]
                let ox = (part.rect.x + s.offset.x).round() as i64;
                #[allow(clippy::cast_possible_truncation)]
                let oy = (part.rect.y + s.offset.y).round() as i64;
                merge_walkable_rects(&s.cells, ox, oy)
            })
            .unwrap_or_default();
        parts.push(MapPart {
            id: part.id,
            name: part.name,
            texture_file: tex_name,
            x: part.rect.x,
            y: part.rect.y,
            foot: part.foot,
            footprints: part.footprints,
            blocking: part.blocking,
            sort_mode: part.sort_mode,
            draw_order: part.draw_order,
            layer_z: z,
            walkable_rects,
        });
    }

    parts.sort_by(|a, b| {
        a.layer_z
            .cmp(&b.layer_z)
            .then_with(|| sort_band(a.sort_mode).cmp(&sort_band(b.sort_mode)))
            .then_with(|| {
                if a.sort_mode == SortMode::Sorted {
                    a.foot.y.total_cmp(&b.foot.y)
                } else {
                    Ordering::Equal
                }
            })
            .then_with(|| a.draw_order.cmp(&b.draw_order))
    });
    Ok(parts)
}

fn sort_band(mode: SortMode) -> i8 {
    match mode {
        SortMode::Below => -1,
        SortMode::Sorted => 0,
        SortMode::Above => 1,
    }
}

/// Mirror `cli_mirror_paths::segment` for filename matching against `row.files`.
pub fn segment(value: &str) -> String {
    let mut out = String::with_capacity(value.len().min(80));
    for ch in value.chars().take(80) {
        if ch.is_control() || matches!(ch, '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|') {
            out.push('-');
        } else {
            out.push(ch);
        }
    }
    let trimmed = out.trim_matches(|c: char| c == '.' || c.is_whitespace());
    if trimmed.is_empty() {
        "file".to_owned()
    } else {
        trimmed.to_owned()
    }
}

/// Decode `r:` (LEB128 alternating runs starting with 0) or `b:` (LSB-first bitmap)
/// navigation mask and merge adjacent walkable cells into maximal axis-aligned pixel rectangles.
pub fn merge_walkable_rects(mask: &NavMask, offset_x: i64, offset_y: i64) -> Vec<CellRect> {
    let count = mask.columns.saturating_mul(mask.rows);
    if count == 0 || mask.columns == 0 || mask.rows == 0 || count > 4_000_000 {
        return Vec::new();
    }
    let mut cells = vec![0u8; count];
    if let Some(b64) = mask.data.strip_prefix("b:") {
        let bits = decode_base64(b64).unwrap_or_default();
        for (i, cell) in cells.iter_mut().enumerate() {
            *cell = (bits.get(i >> 3).copied().unwrap_or(0) >> (i & 7)) & 1;
        }
    } else {
        let b64 = mask.data.strip_prefix("r:").unwrap_or(&mask.data);
        let bytes = decode_base64(b64).unwrap_or_default();
        let runs = decode_leb128(&bytes).unwrap_or_default();
        let mut at = 0usize;
        let mut value = 0u8;
        for run in runs {
            let end = at.saturating_add(run).min(count);
            if value == 1 && at < count {
                cells[at..end].fill(1);
            }
            at = end;
            value ^= 1;
            if at >= count {
                break;
            }
        }
    }

    // Extract horizontal runs per row, then merge matching [col_start, col_end) down rows.
    let mut active: BTreeMap<(usize, usize), usize> = BTreeMap::new();
    let mut rects = Vec::new();

    for r in 0..mask.rows {
        let mut row_runs = BTreeSet::new();
        let mut c = 0usize;
        while c < mask.columns {
            if cells[r * mask.columns + c] == 0 {
                c += 1;
                continue;
            }
            let start = c;
            while c < mask.columns && cells[r * mask.columns + c] != 0 {
                c += 1;
            }
            row_runs.insert((start, c));
        }

        let finished: Vec<_> = active
            .iter()
            .filter(|(span, _)| !row_runs.contains(span))
            .map(|(&span, &start_row)| (span, start_row))
            .collect();
        for (span, start_row) in finished {
            active.remove(&span);
            rects.push(CellRect {
                x: mask.x + offset_x + i64::try_from(span.0).unwrap_or(0) * CELL_PX,
                y: mask.y + offset_y + i64::try_from(start_row).unwrap_or(0) * CELL_PX,
                width: i64::try_from(span.1 - span.0).unwrap_or(0) * CELL_PX,
                height: i64::try_from(r - start_row).unwrap_or(0) * CELL_PX,
            });
        }
        for span in row_runs {
            active.entry(span).or_insert(r);
        }
    }

    for (span, start_row) in active {
        rects.push(CellRect {
            x: mask.x + offset_x + i64::try_from(span.0).unwrap_or(0) * CELL_PX,
            y: mask.y + offset_y + i64::try_from(start_row).unwrap_or(0) * CELL_PX,
            width: i64::try_from(span.1 - span.0).unwrap_or(0) * CELL_PX,
            height: i64::try_from(mask.rows - start_row).unwrap_or(0) * CELL_PX,
        });
    }
    rects
}

fn decode_leb128(bytes: &[u8]) -> Option<Vec<usize>> {
    let mut runs = Vec::new();
    let mut value = 0u64;
    let mut shift = 0u32;
    for &b in bytes {
        value += u64::from(b & 0x7f) << shift;
        if b & 0x80 != 0 {
            shift += 7;
            if shift > 35 {
                return None;
            }
            continue;
        }
        runs.push(value as usize);
        value = 0;
        shift = 0;
    }
    (shift == 0).then_some(runs)
}

fn decode_base64(input: &str) -> Option<Vec<u8>> {
    let mut out = Vec::with_capacity(input.len() * 3 / 4);
    let mut buf = 0u32;
    let mut bits = 0u8;
    for b in input.bytes() {
        if b.is_ascii_whitespace() || b == b'=' {
            continue;
        }
        let val = match b {
            b'A'..=b'Z' => b - b'A',
            b'a'..=b'z' => b - b'a' + 26,
            b'0'..=b'9' => b - b'0' + 52,
            b'+' => 62,
            b'/' => 63,
            _ => return None,
        };
        buf = (buf << 6) | u32::from(val);
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((buf >> bits) as u8);
            buf &= (1 << bits) - 1;
        }
    }
    Some(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decodes_both_bitmap_and_leb128_rle_navigation_masks() {
        // 3 columns x 2 rows = 6 bits -> bitmap: row0=(1,1,0)=0b011=3, row1=(1,1,1)=0b111_000 -> bits 0,1,3,4,5 = 0x3b
        let bmp = NavMask {
            x: 16,
            y: 24,
            columns: 3,
            rows: 2,
            data: "b:Ox==".to_owned(),
        };
        let rects_b = merge_walkable_rects(&bmp, 0, 0);
        // RLE: 0 zeroes, 2 ones, 1 zero, 3 ones -> [0, 2, 1, 3]
        let rle = NavMask {
            x: 16,
            y: 24,
            columns: 3,
            rows: 2,
            data: "r:AAIBAw==".to_owned(),
        };
        let rects_r = merge_walkable_rects(&rle, 0, 0);
        assert_eq!(rects_b.len(), 2);
        assert_eq!(rects_r.len(), 2);
        assert_eq!(
            (rects_b[0].x, rects_b[0].y, rects_b[0].width, rects_b[0].height),
            (16, 24, 16, 8)
        );
        assert_eq!(
            (rects_b[1].x, rects_b[1].y, rects_b[1].width, rects_b[1].height),
            (16, 32, 24, 8)
        );
    }
}
