//! A particle effect decoded from its `particle-effect/1.0` (`main.json`) document.
use super::parse;
use crate::paths::invalid;
use plugin_guest::HostError;
use serde::Deserialize;
use std::collections::BTreeSet;
use std::ops::RangeInclusive;

const SCHEMA: &str = "particle-effect/1.0";
const MAX_EMITTERS: usize = 16;
const MAX_PARTICLES: u64 = 10_000;
const CURVE_KEYS: RangeInclusive<usize> = 2..=8;
const MAX_TRIGGERS: usize = 4;

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Space {
    Planar,
    Spatial,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Blend {
    Normal,
    Additive,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Orientation {
    Random,
    Upright,
    Velocity,
}

impl Orientation {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Random => "random",
            Self::Upright => "upright",
            Self::Velocity => "velocity",
        }
    }
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
enum Builtin {
    Soft,
    Spark,
    Smoke,
    Ring,
}

impl Builtin {
    fn as_str(self) -> &'static str {
        match self {
            Self::Soft => "soft",
            Self::Spark => "spark",
            Self::Smoke => "smoke",
            Self::Ring => "ring",
        }
    }
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Document {
    schema: String,
    seed: u32,
    duration: f64,
    looping: bool,
    space: Space,
    emitters: Vec<Source>,
    #[serde(default)]
    sprites: Vec<SpriteRef>,
}

#[derive(Deserialize)]
struct SpriteRef {
    id: String,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Source {
    id: String,
    name: String,
    enabled: bool,
    rate: f64,
    burst: u32,
    delay: f64,
    lifetime: [f64; 2],
    position: [f64; 3],
    spread: [f64; 3],
    velocity: [f64; 3],
    velocity_spread: [f64; 3],
    gravity: [f64; 3],
    drag: f64,
    size: Vec<f64>,
    opacity: Vec<f64>,
    color: Vec<String>,
    blend: Blend,
    texture: Builtin,
    max_particles: u32,
    #[serde(default)]
    sprite: Option<String>,
    #[serde(default)]
    orientation: Option<Orientation>,
    #[serde(default)]
    tilt: Option<f64>,
    #[serde(default)]
    flip: Option<bool>,
    #[serde(default)]
    size_jitter: Option<f64>,
    #[serde(default)]
    stretch: Option<f64>,
    #[serde(default)]
    radial: Option<Radial>,
    #[serde(default)]
    ground: Option<Ground>,
    #[serde(default)]
    triggers: Vec<Trigger>,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Radial {
    pub speed: [f64; 2],
    pub radius: [f64; 2],
    pub cone: f64,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Ground {
    pub bounce: f64,
    pub friction: f64,
    pub kill: bool,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Event {
    Death,
    Land,
}

impl Event {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Death => "death",
            Self::Land => "land",
        }
    }
}

#[derive(Clone, Debug, Deserialize)]
pub struct Trigger {
    pub on: Event,
    pub emitter: String,
    pub count: u32,
    pub inherit: f64,
}

#[derive(Debug)]
pub struct Emitter {
    pub id: String,
    #[allow(dead_code, reason = "deserialized for diagnostics when needed")]
    pub name: String,
    pub random_state: u32,
    pub rate: f64,
    pub burst: u32,
    pub delay: f64,
    pub lifetime: [f64; 2],
    pub position: [f64; 3],
    pub spread: [f64; 3],
    pub velocity: [f64; 3],
    pub velocity_spread: [f64; 3],
    pub gravity: [f64; 3],
    pub drag: f64,
    pub size: Vec<f64>,
    pub opacity: Vec<f64>,
    pub color: Vec<String>,
    pub blend: Blend,
    pub picture: String,
    pub sprite: bool,
    pub orientation: Orientation,
    pub tilt: f64,
    pub flip: bool,
    pub size_jitter: f64,
    pub stretch: f64,
    pub radial: Option<Radial>,
    pub ground: Option<Ground>,
    pub triggers: Vec<Trigger>,
    pub max_particles: u32,
}

#[derive(Debug)]
pub struct ParticleEffect {
    pub duration: f64,
    pub looping: bool,
    pub space: Space,
    pub emitters: Vec<Emitter>,
    pub notes: Vec<String>,
}

impl ParticleEffect {
    pub fn read(bytes: &[u8]) -> Result<Self, HostError> {
        let document: Document = parse(bytes)?;
        if document.schema != SCHEMA {
            return Err(invalid(format!(
                "main.json: unsupported schema {:?}; expected {SCHEMA}",
                document.schema
            )));
        }
        if !(document.duration.is_finite() && document.duration > 0.0)
            || document.emitters.is_empty()
            || document.emitters.len() > MAX_EMITTERS
            || document
                .emitters
                .iter()
                .map(|e| u64::from(e.max_particles))
                .sum::<u64>()
                > MAX_PARTICLES
        {
            return Err(invalid(
                "main.json: duration, emitter count or total capacity is out of range",
            ));
        }
        let sprites: BTreeSet<_> = document.sprites.iter().map(|s| s.id.as_str()).collect();
        if sprites.iter().any(|id| !sprite_id(id)) {
            return Err(invalid("main.json: unsafe sprite id"));
        }
        let named: BTreeSet<String> = document.emitters.iter().map(|e| e.id.clone()).collect();
        let exported: BTreeSet<String> = document
            .emitters
            .iter()
            .filter(|e| e.enabled)
            .map(|e| e.id.clone())
            .collect();
        let mut ids = BTreeSet::new();
        let mut emitters = Vec::new();
        let mut disabled = Vec::new();
        for source in document.emitters {
            if source.id.is_empty() || !ids.insert(source.id.clone()) {
                return Err(invalid("main.json: empty or duplicate emitter id"));
            }
            validate_emitter(&source, &named)?;
            if !source.enabled {
                disabled.push(source.name);
                continue;
            }
            emitters.push(build_emitter(document.seed, source, &sprites, &exported)?);
        }
        let mut notes = Vec::new();
        if !disabled.is_empty() {
            notes.push(format!("Disabled emitters are not exported: {}.", disabled.join(", ")));
        }
        Ok(Self {
            duration: document.duration,
            looping: document.looping,
            space: document.space,
            emitters,
            notes,
        })
    }
}

fn validate_emitter(e: &Source, named: &BTreeSet<String>) -> Result<(), HostError> {
    let finite = [e.rate, e.delay, e.drag]
        .into_iter()
        .chain(e.lifetime)
        .chain(e.position)
        .chain(e.spread)
        .chain(e.velocity)
        .chain(e.velocity_spread)
        .chain(e.gravity)
        .chain(e.size.iter().copied())
        .chain(e.opacity.iter().copied())
        .chain(e.tilt)
        .chain(e.size_jitter)
        .chain(e.stretch)
        .chain(
            e.radial
                .iter()
                .flat_map(|r| r.speed.into_iter().chain(r.radius).chain([r.cone])),
        )
        .chain(e.ground.iter().flat_map(|g| [g.bounce, g.friction]))
        .chain(e.triggers.iter().map(|t| t.inherit))
        .all(f64::is_finite);
    if !finite
        || e.rate < 0.0
        || e.delay < 0.0
        || e.drag < 0.0
        || e.lifetime[0] <= 0.0
        || e.lifetime[0] > e.lifetime[1]
        || e.max_particles == 0
        || ![e.size.len(), e.opacity.len(), e.color.len()]
            .iter()
            .all(|n| CURVE_KEYS.contains(n))
        || !e.color.iter().all(|c| color(c))
        || e.radial
            .as_ref()
            .is_some_and(|r| r.speed[0] > r.speed[1] || r.radius[0] > r.radius[1])
        || e.triggers.len() > MAX_TRIGGERS
        || e.triggers
            .iter()
            .any(|t| t.count == 0 || t.emitter == e.id || !named.contains(t.emitter.as_str()))
    {
        return Err(invalid(format!("main.json: emitter {:?} is out of range", e.id)));
    }
    Ok(())
}

fn build_emitter(
    seed: u32,
    e: Source,
    sprites: &BTreeSet<&str>,
    exported: &BTreeSet<String>,
) -> Result<Emitter, HostError> {
    let picture = match &e.sprite {
        Some(id) if sprites.contains(id.as_str()) => format!("particle-sprite-{id}.png"),
        Some(id) => {
            return Err(invalid(format!("main.json: sprite {id:?} is not in sprites")));
        }
        None => format!("particle-texture-{}.png", e.texture.as_str()),
    };
    Ok(Emitter {
        random_state: random_state(seed, &e.id),
        orientation: e.orientation.unwrap_or(if e.sprite.is_some() {
            Orientation::Upright
        } else {
            Orientation::Random
        }),
        sprite: e.sprite.is_some(),
        picture,
        id: e.id,
        name: e.name,
        rate: e.rate,
        burst: e.burst,
        delay: e.delay,
        lifetime: e.lifetime,
        position: e.position,
        spread: e.spread,
        velocity: e.velocity,
        velocity_spread: e.velocity_spread,
        gravity: e.gravity,
        drag: e.drag,
        size: e.size,
        opacity: e.opacity,
        color: e.color,
        blend: e.blend,
        tilt: e.tilt.unwrap_or(0.0),
        flip: e.flip == Some(true),
        size_jitter: e.size_jitter.unwrap_or(0.0),
        stretch: e.stretch.unwrap_or(0.0),
        radial: e.radial,
        ground: e.ground,
        triggers: e
            .triggers
            .into_iter()
            .filter(|t| exported.contains(&t.emitter))
            .collect(),
        max_particles: e.max_particles,
    })
}

/// The editor's per-emitter stream seed (`simulation.ts` `random`): the
/// document seed folded with the id's UTF-16 code units.
pub fn random_state(seed: u32, id: &str) -> u32 {
    id.encode_utf16()
        .fold(seed, |state, unit| (state ^ u32::from(unit)).wrapping_mul(16_777_619))
}

fn sprite_id(id: &str) -> bool {
    !id.is_empty() && id.len() <= 40 && id.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-' || c == b'_')
}

fn color(value: &str) -> bool {
    value.len() == 7 && value.starts_with('#') && value[1..].bytes().all(|b| b.is_ascii_hexdigit())
}
