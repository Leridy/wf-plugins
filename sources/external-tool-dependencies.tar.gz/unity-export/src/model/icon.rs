//! Resolve exported `icons.json` elements, kinds, sizes, and states.
use super::{Texture, parse, report, texture};
use crate::paths::invalid;
use plugin_guest::HostError;

#[derive(Debug)]
pub struct IconState {
    pub name: String,
    pub role: Option<report::Role>,
    pub texture: Texture,
}

#[derive(Debug)]
pub struct IconEntry {
    pub name: String,
    pub kind: String,
    pub width: f64,
    pub height: f64,
    pub states: Vec<IconState>,
}

#[derive(Debug)]
pub struct IconSet {
    pub elements: Vec<IconEntry>,
}

impl IconSet {
    pub fn read(bytes: &[u8]) -> Result<Self, HostError> {
        let doc: report::Kit = parse(bytes)?;
        let mut elements = Vec::with_capacity(doc.elements.len());
        for el in doc.elements {
            if el.name.is_empty()
                || !el.size.width.is_finite()
                || el.size.width <= 0.0
                || !el.size.height.is_finite()
                || el.size.height <= 0.0
            {
                return Err(invalid("invalid icon element metadata"));
            }
            let mut states = Vec::with_capacity(el.states.len());
            for st in el.states {
                states.push(IconState {
                    name: st.name,
                    role: st.role,
                    texture: texture(&doc.images, &st.file)?,
                });
            }
            elements.push(IconEntry {
                name: el.name,
                kind: el.kind,
                width: el.size.width,
                height: el.size.height,
                states,
            });
        }
        Ok(Self { elements })
    }
}
