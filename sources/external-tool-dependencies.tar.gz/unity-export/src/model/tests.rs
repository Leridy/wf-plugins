use super::*;

#[test]
fn parses_animation_clips_and_preserves_per_clip_anchors() {
    let raw = br#"{
      "images": {
        "walk_01": { "type": "png", "path": "walk_01.png" },
        "idle_01": { "type": "strip", "path": "idle.png", "frame": { "x": 0, "y": 0, "w": 32, "h": 32 } }
      },
      "clips": [
        { "actionId": "walk", "direction": "south", "files": ["walk_01"], "durationsMs": [100], "loop": true, "anchor": { "x": 16, "y": 30 } },
        { "actionId": "idle", "direction": "source", "files": ["idle_01"], "durationsMs": [200], "loop": false, "anchor": { "x": 12, "y": 28 } }
      ]
    }"#;
    let anim = Animation::read(raw).unwrap();
    assert_eq!(anim.clips.len(), 2);
    assert_eq!(anim.clips[0].name, "walk_south");
    assert_eq!(anim.clips[0].anchor, Point { x: 16.0, y: 30.0 });
    assert_eq!(anim.clips[1].name, "idle");
    assert_eq!(anim.clips[1].frames[0].texture.region.unwrap().w, 32.0);
}

#[test]
fn parses_prop_set_states_animations_and_collisions() {
    let raw = br#"{
      "images": {
        "chest/closed.png": { "type": "png", "path": "chest/closed.png" },
        "chest/open.png": { "type": "png", "path": "chest/open.png" },
        "chest/opening/01.png": { "type": "png", "path": "chest/opening/01.png" }
      },
      "objects": [{
        "id": "chest",
        "name": "Treasure Chest",
        "canvas": { "width": 64, "height": 64 },
        "anchor": { "x": 32, "y": 56 },
        "anchorKind": "foot",
        "pixelsPerTile": 32,
        "footprintTiles": { "width": 1, "depth": 1 },
        "states": [
          { "id": "closed", "file": "chest/closed.png", "collision": [[{ "x": -16, "y": -8 }, { "x": 16, "y": -8 }, { "x": 16, "y": 4 }, { "x": -16, "y": 4 }]] },
          { "id": "open", "file": "chest/open.png", "collision": [] }
        ],
        "animations": [
          { "id": "open-chest", "from": "closed", "to": "open", "files": ["chest/opening/01.png"], "durationsMs": [125], "totalMs": 125, "loop": false }
        ]
      }],
      "collisionNote": "relative to anchor"
    }"#;
    let props = PropSet::read(raw).unwrap();
    assert_eq!(props.objects.len(), 1);
    let obj = &props.objects[0];
    assert_eq!(obj.pixels_per_tile, 32);
    assert_eq!(obj.states.len(), 2);
    assert_eq!(obj.animations.len(), 1);
    assert!(props.notes.is_empty());
}

#[test]
fn prop_set_notes_multi_state_without_transitions() {
    let raw = br#"{
      "images": { "lamp/off.png": { "type": "png", "path": "lamp/off.png" }, "lamp/on.png": { "type": "png", "path": "lamp/on.png" } },
      "objects": [{
        "id": "lamp",
        "name": "Street Lamp",
        "canvas": { "width": 32, "height": 64 },
        "anchor": { "x": 16, "y": 60 },
        "anchorKind": "foot",
        "pixelsPerTile": 32,
        "states": [
          { "id": "off", "file": "lamp/off.png", "collision": [] },
          { "id": "on", "file": "lamp/on.png", "collision": [] }
        ],
        "animations": []
      }]
    }"#;
    let props = PropSet::read(raw).unwrap();
    assert_eq!(props.notes.len(), 1);
    assert!(props.notes[0].contains("defaults to state \"off\""));
}

#[test]
fn rejects_unsafe_texture_paths_and_invalid_particle_schema() {
    let bad_anim = br#"{ "images": { "a": { "type": "png", "path": "../a.png" } }, "clips": [{ "actionId": "idle", "direction": "source", "files": ["a"], "durationsMs": [100], "loop": true, "anchor": { "x": 0, "y": 0 } }] }"#;
    assert!(Animation::read(bad_anim).is_err());

    let bad_particle = br#"{ "schema": "particle-effect/0.1", "seed": 1, "duration": 1.0, "looping": false, "space": "planar", "emitters": [] }"#;
    assert!(ParticleEffect::read(bad_particle).is_err());
}
