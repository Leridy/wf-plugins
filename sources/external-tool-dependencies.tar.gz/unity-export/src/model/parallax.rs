//! `scrolling_scene` / `scroll_map` (`map-parallax/9.0`) model: looping
//! backdrop, parallax scenery layers with `drift`/`bob`/`sway`/`repeatSpan`,
//! and optional side-level whitebox physics + art layers.
use super::whole_map::segment;
use crate::paths::{self, invalid};
use plugin_guest::HostError;
use serde::Deserialize;
use std::collections::{BTreeMap, BTreeSet};
use std::iter::once;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum LayerPlacement {
    Behind,
    Front,
}

#[derive(Clone, Copy, Debug, Default, Deserialize)]
pub struct BobMotion {
    #[serde(default)]
    pub amplitude: f64,
    #[serde(default = "default_period")]
    pub period: f64,
}

#[derive(Clone, Copy, Debug, Default, Deserialize)]
pub struct SwayMotion {
    #[serde(default)]
    pub degrees: f64,
    #[serde(default = "default_period")]
    pub period: f64,
}

fn default_period() -> f64 {
    2.0
}

#[derive(Clone, Copy, Debug, Default, Deserialize)]
pub struct SceneryMotion {
    #[serde(default)]
    pub drift: f64,
    #[serde(default)]
    pub bob: BobMotion,
    #[serde(default)]
    pub sway: SwayMotion,
}

#[derive(Clone, Copy, Debug, Deserialize)]
pub struct Bounds {
    #[serde(default)]
    pub x: f64,
    #[serde(default)]
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Backdrop {
    pub width: u32,
    #[serde(default)]
    pub speed: f64,
    #[serde(default)]
    pub drift: f64,
    pub opacity: f64,
    pub visible: bool,
    #[serde(skip)]
    pub file: String,
}

#[derive(Clone, Debug, Deserialize)]
pub struct ScenerySprite {
    pub id: String,
    #[serde(skip)]
    pub file: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SceneryItem {
    pub id: String,
    pub sprite_id: String,
    pub x: f64,
    pub y: f64,
    pub scale: f64,
    #[serde(default)]
    pub flip_x: bool,
    pub opacity: f64,
    #[serde(default)]
    pub repeat_span: Option<u32>,
    #[serde(default)]
    pub motion: SceneryMotion,
}

#[derive(Clone, Debug, Deserialize)]
pub struct SceneryLayer {
    pub name: String,
    pub placement: LayerPlacement,
    pub speed: f64,
    pub opacity: f64,
    pub visible: bool,
    pub items: Vec<SceneryItem>,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Row {
    pub x: i32,
    pub y: i32,
    #[serde(default)]
    pub width: Option<i32>,
    #[serde(default)]
    pub modules: i32,
    pub height: i32,
}

impl Row {
    pub fn resolved_width(&self) -> i32 {
        self.width.unwrap_or(self.modules * 384)
    }
}

#[derive(Clone, Debug, Deserialize)]
pub struct Solid {
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Climb {
    pub id: String,
    pub x: i32,
    pub top: i32,
    pub bottom: i32,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Hazard {
    pub kind: String,
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Slope {
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    pub direction: String,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Marker {
    pub id: String,
    pub x: i32,
    pub y: i32,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Markers {
    pub spawn: Marker,
    pub exit: Marker,
    #[serde(default)]
    pub checkpoints: Vec<Marker>,
    #[serde(default)]
    pub collectibles: Vec<Marker>,
}

#[derive(Clone, Debug, Deserialize)]
pub struct SlotKind {
    pub id: String,
    #[serde(default)]
    pub depth: String,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Slot {
    pub kind: String,
    pub x: i32,
    pub y: i32,
}

#[derive(Clone, Debug, Deserialize)]
pub struct WhiteboxCollision {
    pub bounds: Bounds,
    #[serde(default)]
    pub bodies: Vec<Bounds>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Whitebox {
    #[serde(default)]
    pub collisions: Vec<WhiteboxCollision>,
    #[serde(default)]
    pub rows: Vec<Row>,
    #[serde(default)]
    pub climbs: Vec<Climb>,
    pub markers: Markers,
    #[serde(default)]
    pub slot_kinds: Vec<SlotKind>,
    #[serde(default)]
    pub slots: Vec<Slot>,
    #[serde(default)]
    pub solids: Vec<Solid>,
    #[serde(default)]
    pub hazards: Vec<Hazard>,
    #[serde(default)]
    pub slopes: Vec<Slope>,
}

#[derive(Clone, Debug, Deserialize)]
pub struct BlockImage {
    pub x: i32,
    pub y: i32,
}

#[derive(Clone, Debug, Deserialize)]
pub struct GroupArt {
    pub image: BlockImage,
    pub file: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ObjectArt {
    pub anchor: f64,
    pub kind: String,
    pub file: String,
    pub base: f64,
}

#[derive(Clone, Debug, Deserialize)]
pub struct HazardArt {
    pub file: String,
}

#[derive(Clone, Debug, Deserialize)]
pub struct ClimbArt {
    pub file: String,
}

#[derive(Clone, Debug, Default, Deserialize)]
pub struct LevelKit {
    #[serde(default)]
    pub groups: Vec<GroupArt>,
    #[serde(default)]
    pub objects: Vec<ObjectArt>,
    #[serde(default)]
    pub climb: Option<ClimbArt>,
    #[serde(default)]
    pub hazards: Vec<HazardArt>,
}

#[derive(Clone, Debug, Deserialize)]
pub struct Level {
    pub whitebox: Whitebox,
    #[serde(default)]
    pub kit: LevelKit,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ParallaxMap {
    pub schema: String,
    pub pixel_ratio: u32,
    pub backdrop: Backdrop,
    #[serde(default)]
    pub sprites: Vec<ScenerySprite>,
    #[serde(default)]
    pub layers: Vec<SceneryLayer>,
    #[serde(default)]
    pub level: Option<Level>,
    #[serde(skip)]
    pub art_files: BTreeMap<String, String>,
}

impl ParallaxMap {
    pub fn read(bytes: &[u8], available: &BTreeSet<String>, prefix: &str) -> Result<Self, HostError> {
        let mut map: Self = super::parse(bytes)?;
        if !map.schema.starts_with("map-parallax/") {
            return Err(invalid(format!("unsupported scrolling_scene schema {:?}", map.schema)));
        }
        if map.pixel_ratio == 0 {
            return Err(invalid("scrolling_scene pixelRatio must be positive"));
        }

        let backdrop_name = "parallax-layer-backdrop.png".to_owned();
        let backdrop_rel = paths::join(prefix, &backdrop_name);
        if !available.contains(&backdrop_rel) {
            return Err(invalid(format!(
                "backdrop texture {backdrop_rel:?} is missing from export lock"
            )));
        }
        map.backdrop.file = backdrop_name;

        let mut sprite_ids = BTreeSet::new();
        for sprite in &mut map.sprites {
            let name = format!("parallax-layer-{}.png", segment(&sprite.id));
            let rel = paths::join(prefix, &name);
            if !available.contains(&rel) {
                return Err(invalid(format!("scenery sprite {rel:?} is missing from export lock")));
            }
            sprite.file = name;
            sprite_ids.insert(sprite.id.clone());
        }
        for layer in &map.layers {
            for item in &layer.items {
                if !sprite_ids.contains(&item.sprite_id) {
                    return Err(invalid(format!(
                        "scrolling_scene item {:?} references unknown sprite {:?}",
                        item.id, item.sprite_id
                    )));
                }
            }
        }

        if let Some(level) = &map.level {
            let mut files = BTreeSet::new();
            for group in &level.kit.groups {
                files.insert(group.file.as_str());
            }
            for obj in &level.kit.objects {
                files.insert(obj.file.as_str());
            }
            if let Some(climb) = &level.kit.climb {
                files.insert(climb.file.as_str());
            }
            for haz in &level.kit.hazards {
                files.insert(haz.file.as_str());
            }
            for art in files {
                let candidate = format!("side-level-art-{}", segment(art));
                let with_ext = if candidate.to_ascii_lowercase().ends_with(".png") {
                    candidate
                } else {
                    format!("{candidate}.png")
                };
                let rel = paths::join(prefix, &with_ext);
                if available.contains(&rel) {
                    map.art_files.insert(art.to_owned(), with_ext);
                } else {
                    let raw_rel = paths::join(prefix, art);
                    if available.contains(&raw_rel) {
                        map.art_files.insert(art.to_owned(), art.to_owned());
                    } else {
                        return Err(invalid(format!("side-level art {rel:?} is missing from export lock")));
                    }
                }
            }
        }

        Ok(map)
    }

    pub fn texture_paths(&self) -> impl Iterator<Item = &str> {
        once(self.backdrop.file.as_str())
            .chain(self.sprites.iter().map(|s| s.file.as_str()))
            .chain(self.art_files.values().map(String::as_str))
    }
}
