//! Schemas come from the same types used at the component boundary.
use crate::types::{Input, Output};
use plugin_api::{Capability, Description, Example, Risk};
use schemars::{JsonSchema, schema_for};
use serde_json::Value;

pub const OP: &str = "sync";

pub fn description() -> Description {
    Description {
        capabilities: vec![Capability {
            op: OP.into(),
            summary:
                "Turn exported animations, UI kits, icons, images, maps, props, particles and 3D assets into Unity assets, prefabs and C#/xLua bindings"
                    .into(),
            when: "After wf export, configure sprite .meta sheets/pivots/9-slice borders, generate wf-bindings.json \
                   and WfBindings.cs with PNG alpha visualBounds, and create AnimationClips, AnimatorControllers, UGUI \
                   prefabs, Tilemaps, WholeMap / Parallax prefabs, prop prefabs, particle effect prefabs, or 3D GLB \
                   wrapper prefabs. The export directory must live inside a Unity project's Assets/ folder."
                .into(),
            risk: Risk::Write,
            input: schema::<Input>(),
            output: Some(schema::<Output>()),
            examples: vec![
                Example {
                    args: "sync".into(),
                    note: "sync every node in the export lock".into(),
                },
                Example {
                    args: "sync --nodes '#75' --nodes '#81'".into(),
                    note: "sync only these exported nodes".into(),
                },
            ],
            implements: None,
        }],
    }
}

fn schema<T: JsonSchema>() -> Value {
    serde_json::to_value(schema_for!(T)).expect("a schema serializes")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn one_write_capability_with_strict_typed_input() {
        let d = description();
        assert_eq!(d.capabilities.len(), 1);
        let c = &d.capabilities[0];
        assert_eq!(c.risk, Risk::Write);
        assert_eq!(c.input["additionalProperties"], false);
        assert_eq!(c.input["properties"]["nodes"]["type"], "array");
        assert!(c.output.as_ref().unwrap()["properties"].get("table").is_some());
        assert!(c.implements.is_none());
    }
}
