//! The sync capability's public input and result; effects stay with the host.
use plugin_api::Effect;
use plugin_protocols::ui::TableData;
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};

#[derive(Debug, Default, Deserialize, JsonSchema, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Input {
    /// Node addresses (#N, path or wf://id); empty selects every exported node.
    #[serde(default)]
    pub nodes: Vec<String>,
    /// Project-relative export directory; omit to use the mirror's configuration.
    #[serde(default)]
    pub directory: Option<String>,
    /// Replace user-edited generated files too; the host asks before overwriting.
    #[serde(default)]
    pub force: bool,
}

#[derive(Debug, Default, Deserialize, JsonSchema, Serialize)]
pub struct Output {
    /// Client result view: node, status, resource file count and main prefab path.
    pub table: TableData,
    pub nodes: Vec<Node>,
    /// Unedited generated files no longer used by these exports.
    pub deleted: Vec<String>,
    /// Limits of discovery, including host listings cut short.
    pub warnings: Vec<String>,
}

#[derive(Debug, Deserialize, JsonSchema, Serialize)]
pub struct Node {
    pub id: String,
    pub number: u64,
    pub path: String,
    pub node_type: String,
    pub status: Status,
    pub files: Vec<File>,
    /// Project-relative path of the primary prefab to open or instantiate; null when none.
    pub main_prefab: Option<String>,
    /// Every UI widget or prop object in sidecar order; skipped entries have no prefab.
    pub elements: Vec<Element>,
    pub reasons: Vec<String>,
}

#[derive(Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
pub struct Element {
    /// Original element or object name, as exported.
    pub name: String,
    /// Unity project asset path (`Assets/...`), or null when skipped.
    pub prefab: Option<String>,
}

#[derive(Debug, Deserialize, JsonSchema, Serialize)]
pub struct File {
    pub path: String,
    pub resource: String,
    pub status: Status,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Status {
    Written,
    Updated,
    Unchanged,
    Skipped,
    Kept,
}

#[derive(Debug)]
pub struct Plan {
    pub output: Output,
    pub effects: Vec<Effect>,
}
