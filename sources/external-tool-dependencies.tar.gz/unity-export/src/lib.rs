//! Converts the local mirror's ready exports into Unity assets and prefabs.
//! Reading, modeling, writing Unity files and planning effects remain separate boundaries.
#[cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "description is called by wasm glue")
)]
mod cli_sync;
#[cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "description is called by wasm glue")
)]
mod describe;
mod gather;
mod gather_world;
mod model;
mod paths;
mod reconcile;
mod table;
mod types;
mod unity;

pub use gather::sync;
pub use types::{Element, File, Input, Node, Output, Plan, Status};

#[cfg(target_arch = "wasm32")]
mod component;
#[cfg(test)]
mod testing;
