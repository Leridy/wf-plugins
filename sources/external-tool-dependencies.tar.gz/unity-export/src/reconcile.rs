//! Ownership is proven by a complete stamp header/footer and an unchanged body hash.
use crate::{paths, types::Status};
use plugin_api::Effect;
use plugin_guest::{Host, HostError};
use sha2::{Digest, Sha256};
use std::fmt::Write;
use std::str::from_utf8;

const CODE_PREFIX: &str = "// wf unity-export ";
const YAML_PREFIX: &str = "# wf unity-export ";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum StampFormat {
    /// Leading line-1 `// wf unity-export ...` for C# and shader sources.
    Code,
    /// Trailing `# wf unity-export ...` line for `.meta` and Unity YAML assets so line 1 stays `fileFormatVersion: 2` or `%YAML 1.1`.
    TrailingComment,
}

/// Computes lowercase SHA-256 hex digest for canonical byte inputs.
pub fn sha256_hex(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    let mut hex = String::with_capacity(digest.len() * 2);
    for b in digest {
        write!(hex, "{b:02x}").expect("write");
    }
    hex
}

pub fn stamped(id: &str, version: u64, body: &str, kind: StampFormat) -> Vec<u8> {
    let body = if body.ends_with('\n') {
        body.to_owned()
    } else {
        format!("{body}\n")
    };
    let digest = sha256_hex(body.as_bytes());
    match kind {
        StampFormat::Code => format!("{CODE_PREFIX}{id} v{version} sha256={digest}\n{body}").into_bytes(),
        StampFormat::TrailingComment => format!("{body}{YAML_PREFIX}{id} v{version} sha256={digest}\n").into_bytes(),
    }
}

/// Parsed WeaveForge ownership header/footer from a generated Unity file.
#[derive(Debug, Eq, PartialEq)]
pub struct Stamp<'a> {
    pub id: &'a str,
    pub version: u64,
    pub src: Option<&'a str>,
}

/// Parses and validates a generated Unity file's ownership stamp (`//` or `#`).
pub fn parse_stamp(bytes: &[u8]) -> Option<Stamp<'_>> {
    let text = from_utf8(bytes).ok()?;
    if let Some((header, body)) = text.split_once('\n')
        && let Some(rest) = header.strip_prefix(CODE_PREFIX)
        && let Some(stamp) = verify_stamp(rest, body)
    {
        return Some(stamp);
    }
    let trimmed = text.strip_suffix('\n')?;
    let (body_without_nl, footer) = trimmed.rsplit_once('\n')?;
    let rest = footer.strip_prefix(YAML_PREFIX)?;
    // Re-attach the trailing newline included in the body digest at stamp time.
    let body_len = body_without_nl.len() + 1;
    let body = &text[..body_len];
    verify_stamp(rest, body)
}

/// The owner of an unedited generated file. Version and digest must be complete.
pub fn owner(bytes: &[u8]) -> Option<&str> {
    parse_stamp(bytes).map(|stamp| stamp.id)
}

fn verify_stamp<'a>(rest: &'a str, body: &str) -> Option<Stamp<'a>> {
    let mut words = rest.split(' ');
    let id = words.next()?;
    if id.is_empty() || !id.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-') {
        return None;
    }
    let version = words.next()?.strip_prefix('v')?.parse::<u64>().ok()?;
    let hash = words.next()?.strip_prefix("sha256=")?;
    let src = match words.next() {
        None => None,
        Some(word) => {
            let src = word.strip_prefix("src=")?;
            if src.is_empty() || !src.bytes().all(|c| c.is_ascii_hexdigit()) || words.next().is_some() {
                return None;
            }
            Some(src)
        }
    };
    if hash != sha256_hex(body.as_bytes()) {
        return None;
    }
    Some(Stamp { id, version, src })
}

/// Reconciles one CLI-generated Unity asset or `.meta` path on disk without emitting `WriteFile`.
pub fn cli_file(host: &dyn Host, path: &str, version: u64, src_hash: &str, force: bool) -> Result<Status, HostError> {
    paths::relative(path)?;
    let existing = match host.read(path) {
        Ok(bytes) => Some(bytes),
        Err(e) if e.not_found() => None,
        Err(e) => return Err(e),
    };
    Ok(match existing.as_deref() {
        None => Status::Written,
        Some(old) => match parse_stamp(old) {
            None if !force => Status::Kept,
            Some(stamp) if stamp.version == version && stamp.src == Some(src_hash) => Status::Unchanged,
            _ => Status::Updated,
        },
    })
}

pub fn file(
    host: &dyn Host,
    path: &str,
    bytes: Vec<u8>,
    force: bool,
    effects: &mut Vec<Effect>,
) -> Result<Status, HostError> {
    let existing = match host.read(path) {
        Ok(bytes) => Some(bytes),
        Err(e) if e.not_found() => None,
        Err(e) => return Err(e),
    };
    let status = match &existing {
        None => Status::Written,
        Some(old) if !force && owner(old).is_none() => return Ok(Status::Kept),
        Some(old) if *old == bytes => return Ok(Status::Unchanged),
        Some(_) => Status::Updated,
    };
    paths::relative(path)?;
    effects.push(Effect::WriteFile {
        path: path.into(),
        bytes,
        overwrite: existing.is_some(),
    });
    Ok(status)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn code_and_trailing_comment_stamps_detect_user_edits() {
        for kind in [StampFormat::Code, StampFormat::TrailingComment] {
            let bytes = stamped("node-1", 3, "fileFormatVersion: 2\nguid: abc\n", kind);
            assert_eq!(owner(&bytes), Some("node-1"));

            let mut edited = bytes.clone();
            edited.splice(0..0, b"// user edit\n".iter().copied());
            assert_eq!(owner(&edited), None);

            let mut stripped = String::from_utf8(bytes).unwrap();
            stripped.push_str("# edited\n");
            assert_eq!(owner(stripped.as_bytes()), None);
        }
    }
}
