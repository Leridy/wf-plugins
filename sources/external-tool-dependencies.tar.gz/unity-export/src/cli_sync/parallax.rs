//! CLI sync task planner for scrolling / parallax map nodes.
use super::assets::{is_multiple, points_to_poly};
use super::specs::{
    ParallaxBoxSpec, ParallaxLevelSpriteSpec, ParallaxMarkerSpec, ParallaxPrefabTask, ParallaxSpriteSpec,
    ParallaxTriggerSpec, PolyPathSpec,
};
use super::worlds::PPU;
use super::{CliAssetTarget, CliTargetKind, PlannedUnityNode, init_planned};
use crate::{
    model::{ParallaxMap, Point, parallax::LayerPlacement, parallax::Whitebox},
    paths,
    unity::{
        ExportTarget,
        animation::{join_rel, rel_prefix},
        texture::{FilterMode, ResolvedSprites, SliceSpec, SpriteKey, TextureRegistry},
    },
};
use std::collections::BTreeMap;

pub fn plan_parallax(
    map: &ParallaxMap,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    stem: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
) -> PlannedUnityNode {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let (bd_key, sprite_keys, art_keys) = register_parallax_textures(&mut registry, map);
    let (resolved, tex_specs, _) = registry.build_cli(target.node_dir, target.root, target.directory);
    let mut node = init_planned(target, id, version, tex_specs);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);

    let bd_info = resolved.slice_info(&bd_key);
    let backdrop = ParallaxSpriteSpec {
        name: "Backdrop".into(),
        front: false,
        visible: map.backdrop.visible,
        pos_x: 0.0,
        pos_y: 0.0,
        scale_x: 1.0,
        scale_y: 1.0,
        tex_asset_path: bd_info.asset_path.clone(),
        multiple: is_multiple(&node.task.textures, &bd_info.asset_path),
        sprite_name: bd_info.sprite_name.clone(),
        flip_x: false,
        opacity: map.backdrop.opacity,
        order: -100,
        speed: map.backdrop.speed,
        drift: map.backdrop.drift,
        bob_amp: 0.0,
        bob_period: 2.0,
        sway_deg: 0.0,
        sway_period: 2.0,
        repeat_span: f64::from(map.backdrop.width),
    };

    let items = build_parallax_items(map, &sprite_keys, &resolved, &node);
    let (level_sprites, level_boxes, level_polys, level_triggers, level_markers) =
        build_parallax_level(map, &art_keys, &resolved, &node);

    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &prefab_rel));
    let px_idx = node.task.parallax_prefabs.len();
    node.task.parallax_prefabs.push(ParallaxPrefabTask {
        write: false,
        asset_path: prefab_asset,
        display_name: display_name.to_owned(),
        backdrop,
        items,
        has_level: map.level.is_some(),
        level_sprites,
        level_boxes,
        level_polys,
        level_triggers,
        level_markers,
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: prefab_rel,
        main_prefab: true,
        kind: CliTargetKind::ParallaxPrefab(px_idx),
    });
    node
}

fn register_parallax_textures<'a>(
    registry: &mut TextureRegistry,
    map: &'a ParallaxMap,
) -> (SpriteKey, BTreeMap<&'a str, SpriteKey>, BTreeMap<&'a str, SpriteKey>) {
    let ppu_scaled = PPU * f64::from(map.pixel_ratio.max(1));
    let bd_key = registry.register(
        &map.backdrop.file,
        "backdrop",
        SliceSpec {
            rect: None,
            pivot: [0.0, 1.0],
            border: [0.0; 4],
            ppu: ppu_scaled,
            filter: FilterMode::Bilinear,
        },
    );
    let sprite_keys = map
        .sprites
        .iter()
        .map(|s| {
            (
                s.id.as_str(),
                registry.register(
                    &s.file,
                    &s.id,
                    SliceSpec {
                        rect: None,
                        pivot: [0.5, 0.5],
                        border: [0.0; 4],
                        ppu: ppu_scaled,
                        filter: FilterMode::Bilinear,
                    },
                ),
            )
        })
        .collect();
    let art_keys = map
        .art_files
        .iter()
        .map(|(orig, resolved_name)| {
            (
                orig.as_str(),
                registry.register(
                    resolved_name,
                    orig,
                    SliceSpec {
                        rect: None,
                        pivot: [0.0, 1.0],
                        border: [0.0; 4],
                        ppu: ppu_scaled,
                        filter: FilterMode::Bilinear,
                    },
                ),
            )
        })
        .collect();
    (bd_key, sprite_keys, art_keys)
}

fn build_parallax_items(
    map: &ParallaxMap,
    sprite_keys: &BTreeMap<&str, SpriteKey>,
    resolved: &ResolvedSprites,
    node: &PlannedUnityNode,
) -> Vec<ParallaxSpriteSpec> {
    let mut items = Vec::new();
    let mut order = -50i32;
    for layer in &map.layers {
        let base = match layer.placement {
            LayerPlacement::Behind => -20,
            LayerPlacement::Front => 20,
        };
        order += 1;
        for (ii, it) in layer.items.iter().enumerate() {
            let info = resolved.slice_info(&sprite_keys[it.sprite_id.as_str()]);
            items.push(ParallaxSpriteSpec {
                name: format!("{}_{}", layer.name, ii + 1),
                front: layer.placement == LayerPlacement::Front,
                visible: layer.visible,
                pos_x: it.x / PPU,
                pos_y: -it.y / PPU,
                scale_x: it.scale,
                scale_y: it.scale,
                tex_asset_path: info.asset_path.clone(),
                multiple: is_multiple(&node.task.textures, &info.asset_path),
                sprite_name: info.sprite_name.clone(),
                flip_x: it.flip_x,
                opacity: (layer.opacity * it.opacity).clamp(0.0, 1.0),
                order: base + order,
                speed: layer.speed,
                drift: it.motion.drift,
                bob_amp: it.motion.bob.amplitude,
                bob_period: it.motion.bob.period,
                sway_deg: it.motion.sway.degrees,
                sway_period: it.motion.sway.period,
                repeat_span: f64::from(it.repeat_span.unwrap_or(0)),
            });
        }
    }
    items
}

type ParallaxLevelSpecs = (
    Vec<ParallaxLevelSpriteSpec>,
    Vec<ParallaxBoxSpec>,
    Vec<PolyPathSpec>,
    Vec<ParallaxTriggerSpec>,
    Vec<ParallaxMarkerSpec>,
);

fn build_parallax_level(
    map: &ParallaxMap,
    art_keys: &BTreeMap<&str, SpriteKey>,
    resolved: &ResolvedSprites,
    node: &PlannedUnityNode,
) -> ParallaxLevelSpecs {
    let mut level_sprites = Vec::new();
    let mut level_boxes = Vec::new();
    let mut level_polys = Vec::new();
    let mut level_triggers = Vec::new();
    let mut level_markers = Vec::new();
    if let Some(lv) = &map.level {
        for (i, g) in lv.kit.groups.iter().enumerate() {
            if let Some(key) = art_keys.get(g.file.as_str()) {
                let info = resolved.slice_info(key);
                level_sprites.push(ParallaxLevelSpriteSpec {
                    name: format!("Terrain_{}", i + 1),
                    pos_x: f64::from(g.image.x) / PPU,
                    pos_y: -f64::from(g.image.y) / PPU,
                    tex_asset_path: info.asset_path.clone(),
                    multiple: is_multiple(&node.task.textures, &info.asset_path),
                    sprite_name: info.sprite_name.clone(),
                    order: 0,
                });
            }
        }
        for (i, slot) in lv.whitebox.slots.iter().enumerate() {
            if let Some(art) = lv.kit.objects.iter().find(|o| o.kind == slot.kind)
                && let Some(key) = art_keys.get(art.file.as_str())
            {
                let info = resolved.slice_info(key);
                let sort = lv
                    .whitebox
                    .slot_kinds
                    .iter()
                    .find(|k| k.id == slot.kind)
                    .map_or(1, |k| if k.depth == "front" { 10 } else { -1 });
                level_sprites.push(ParallaxLevelSpriteSpec {
                    name: format!("Slot_{}", i + 1),
                    pos_x: (f64::from(slot.x) - art.anchor) / PPU,
                    pos_y: -(f64::from(slot.y) - art.base) / PPU,
                    tex_asset_path: info.asset_path.clone(),
                    multiple: is_multiple(&node.task.textures, &info.asset_path),
                    sprite_name: info.sprite_name.clone(),
                    order: sort,
                });
            }
        }
        collect_parallax_physics(&lv.whitebox, &mut level_boxes, &mut level_polys);
        collect_parallax_triggers_and_markers(&lv.whitebox, &mut level_triggers, &mut level_markers);
    }
    (level_sprites, level_boxes, level_polys, level_triggers, level_markers)
}

fn collect_parallax_physics(wb: &Whitebox, boxes: &mut Vec<ParallaxBoxSpec>, polys: &mut Vec<PolyPathSpec>) {
    if wb.collisions.is_empty() {
        for solid in &wb.solids {
            boxes.push(ParallaxBoxSpec {
                cx: (f64::from(solid.x) + f64::from(solid.width) * 0.5) / PPU,
                cy: -(f64::from(solid.y) + f64::from(solid.height) * 0.5) / PPU,
                w: f64::from(solid.width.max(1)) / PPU,
                h: f64::from(solid.height.max(1)) / PPU,
            });
        }
        for row in &wb.rows {
            let rw = row.resolved_width().max(1);
            boxes.push(ParallaxBoxSpec {
                cx: (f64::from(row.x) + f64::from(rw) * 0.5) / PPU,
                cy: -(f64::from(row.y) + f64::from(row.height) * 0.5) / PPU,
                w: f64::from(rw) / PPU,
                h: f64::from(row.height.max(1)) / PPU,
            });
        }
        for sl in &wb.slopes {
            let left = f64::from(sl.x);
            let right = f64::from(sl.x + sl.width);
            let top = f64::from(sl.y);
            let bottom = f64::from(sl.y + sl.height);
            let (ly, ry) = if sl.direction == "up" {
                (bottom, top)
            } else {
                (top, bottom)
            };
            polys.push(points_to_poly(
                &[
                    Point { x: left, y: bottom },
                    Point { x: left, y: ly },
                    Point { x: right, y: ry },
                    Point { x: right, y: bottom },
                ],
                PPU,
            ));
        }
    } else {
        for col in &wb.collisions {
            if col.bodies.is_empty() {
                boxes.push(ParallaxBoxSpec {
                    cx: (col.bounds.x + col.bounds.width * 0.5) / PPU,
                    cy: -(col.bounds.y + col.bounds.height * 0.5) / PPU,
                    w: col.bounds.width.max(1.0) / PPU,
                    h: col.bounds.height.max(1.0) / PPU,
                });
            } else {
                for b in &col.bodies {
                    boxes.push(ParallaxBoxSpec {
                        cx: (col.bounds.x + b.x + b.width * 0.5) / PPU,
                        cy: -(col.bounds.y + b.y + b.height * 0.5) / PPU,
                        w: b.width.max(1.0) / PPU,
                        h: b.height.max(1.0) / PPU,
                    });
                }
            }
        }
    }
}

fn collect_parallax_triggers_and_markers(
    wb: &Whitebox,
    triggers: &mut Vec<ParallaxTriggerSpec>,
    markers: &mut Vec<ParallaxMarkerSpec>,
) {
    for (i, h) in wb.hazards.iter().enumerate() {
        let name = if h.kind.is_empty() {
            format!("Hazard_{}", i + 1)
        } else {
            format!("Hazard_{}_{}", h.kind, i + 1)
        };
        triggers.push(ParallaxTriggerSpec {
            name,
            cx: (f64::from(h.x) + f64::from(h.width) * 0.5) / PPU,
            cy: -(f64::from(h.y) + f64::from(h.height) * 0.5) / PPU,
            w: f64::from(h.width.max(1)) / PPU,
            h: f64::from(h.height.max(1)) / PPU,
        });
    }
    for c in &wb.climbs {
        let hp = f64::from((c.bottom - c.top).abs().max(1));
        let cy = f64::from(c.top.min(c.bottom)) + hp * 0.5;
        triggers.push(ParallaxTriggerSpec {
            name: format!("Climb_{}", c.id),
            cx: f64::from(c.x) / PPU,
            cy: -cy / PPU,
            w: 32.0 / PPU,
            h: hp / PPU,
        });
    }
    markers.push(ParallaxMarkerSpec {
        name: "Spawn".into(),
        x: f64::from(wb.markers.spawn.x) / PPU,
        y: -f64::from(wb.markers.spawn.y) / PPU,
    });
    markers.push(ParallaxMarkerSpec {
        name: "Exit".into(),
        x: f64::from(wb.markers.exit.x) / PPU,
        y: -f64::from(wb.markers.exit.y) / PPU,
    });
    for cp in &wb.markers.checkpoints {
        markers.push(ParallaxMarkerSpec {
            name: format!("Checkpoint_{}", cp.id),
            x: f64::from(cp.x) / PPU,
            y: -f64::from(cp.y) / PPU,
        });
    }
    for col in &wb.markers.collectibles {
        markers.push(ParallaxMarkerSpec {
            name: format!("Collectible_{}", col.id),
            x: f64::from(col.x) / PPU,
            y: -f64::from(col.y) / PPU,
        });
    }
}
