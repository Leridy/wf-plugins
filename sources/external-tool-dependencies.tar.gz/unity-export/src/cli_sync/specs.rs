//! Typed DTOs serialized to `Assets/WfTmpSync/manifest.json` (camelCase, matching `JsonUtility`).
use crate::unity::texture::{CliSliceSpec, CliTextureSpec};
use serde::Serialize;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Manifest {
    pub tasks: Vec<SyncTask>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SyncTask {
    pub id: String,
    pub version: u64,
    pub src_hash: String,
    pub textures: Vec<TextureTask>,
    pub clips: Vec<ClipTask>,
    pub controllers: Vec<ControllerTask>,
    pub tile_assets: Vec<TileAssetTask>,
    pub materials: Vec<MaterialTask>,
    pub anim_prefabs: Vec<AnimPrefabTask>,
    pub prop_prefabs: Vec<PropPrefabTask>,
    pub tilemap_prefabs: Vec<TilemapPrefabTask>,
    pub ui_prefabs: Vec<UiPrefabTask>,
    pub particle_prefabs: Vec<ParticlePrefabTask>,
    pub whole_map_prefabs: Vec<WholeMapPrefabTask>,
    pub parallax_prefabs: Vec<ParallaxPrefabTask>,
    pub model3d_prefabs: Vec<Model3dPrefabTask>,
    pub scene3d_prefabs: Vec<Scene3dPrefabTask>,
}

impl SyncTask {
    pub fn empty(id: String, version: u64, src_hash: String) -> Self {
        Self {
            id,
            version,
            src_hash,
            textures: Vec::new(),
            clips: Vec::new(),
            controllers: Vec::new(),
            tile_assets: Vec::new(),
            materials: Vec::new(),
            anim_prefabs: Vec::new(),
            prop_prefabs: Vec::new(),
            tilemap_prefabs: Vec::new(),
            ui_prefabs: Vec::new(),
            particle_prefabs: Vec::new(),
            whole_map_prefabs: Vec::new(),
            parallax_prefabs: Vec::new(),
            model3d_prefabs: Vec::new(),
            scene3d_prefabs: Vec::new(),
        }
    }
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TextureTask {
    pub write: bool,
    pub asset_path: String,
    pub ppu: f64,
    pub filter_mode: u8,
    pub multiple: bool,
    pub slices: Vec<SliceSpec>,
}

impl TextureTask {
    pub fn from_cli(spec: CliTextureSpec, write: bool) -> Self {
        Self {
            write,
            asset_path: spec.asset_path,
            ppu: spec.ppu,
            filter_mode: spec.filter_mode,
            multiple: spec.multiple,
            slices: spec.slices.into_iter().map(SliceSpec::from_cli).collect(),
        }
    }
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SliceSpec {
    pub name: String,
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
    pub pivot_x: f64,
    pub pivot_y: f64,
    pub border_l: f64,
    pub border_b: f64,
    pub border_r: f64,
    pub border_t: f64,
    pub sprite_id: String,
    pub internal_id: i64,
}

impl SliceSpec {
    fn from_cli(s: CliSliceSpec) -> Self {
        Self {
            name: s.name,
            x: s.x,
            y: s.y,
            w: s.w,
            h: s.h,
            pivot_x: s.pivot[0],
            pivot_y: s.pivot[1],
            border_l: s.border[0],
            border_b: s.border[1],
            border_r: s.border[2],
            border_t: s.border[3],
            sprite_id: s.sprite_id,
            internal_id: s.internal_id,
        }
    }
}

#[derive(Default, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SpriteRefSpec {
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub sliced: bool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClipTask {
    pub write: bool,
    pub asset_path: String,
    pub state_name: String,
    pub sample_rate: f64,
    pub looped: bool,
    pub frames: Vec<ClipFrameSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ClipFrameSpec {
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub duration_ms: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ControllerTask {
    pub write: bool,
    pub asset_path: String,
    pub states: Vec<ControllerStateSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ControllerStateSpec {
    pub name: String,
    pub clip_asset_path: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TileAssetTask {
    pub write: bool,
    pub asset_path: String,
    pub name: String,
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct MaterialTask {
    pub write: bool,
    pub asset_path: String,
    pub name: String,
    pub shader_asset_path: String,
    pub mask_tex_asset_path: String,
    pub width: i32,
    pub height: i32,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AnimPrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub display_name: String,
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub ctrl_asset_path: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PropPrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub name: String,
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub ctrl_asset_path: String,
    pub root_polys: Vec<PolyPathSpec>,
    pub state_colliders: Vec<PropStateColliderSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PropStateColliderSpec {
    pub name: String,
    pub active: bool,
    pub polys: Vec<PolyPathSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TilemapPrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub display_name: String,
    pub isometric: bool,
    pub cell_height: f64,
    pub layers: Vec<TilemapLayerSpec>,
    pub sprites: Vec<TilemapSpriteSpec>,
    pub obstacles: Vec<TilemapObsSpec>,
    pub walkable: Vec<TilemapObsSpec>,
    pub has_spawn: bool,
    pub spawn_x: f64,
    pub spawn_y: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TilemapLayerSpec {
    pub name: String,
    pub order: i32,
    pub shift_x: f64,
    pub shift_y: f64,
    pub cells: Vec<TilemapCellSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TilemapCellSpec {
    pub x: i32,
    pub y: i32,
    pub tile_asset_path: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TilemapSpriteSpec {
    pub name: String,
    pub pos_x: f64,
    pub pos_y: f64,
    pub rot_deg: f64,
    pub vis_x: f64,
    pub vis_y: f64,
    pub scale_x: f64,
    pub scale_y: f64,
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub flip_x: bool,
    pub opacity: f64,
    pub order: i32,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TilemapObsSpec {
    pub name: String,
    pub poly: PolyPathSpec,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Vec2Spec {
    pub x: f64,
    pub y: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Vec3Spec {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PolyPathSpec {
    pub points: Vec<Vec2Spec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct UiPrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub name: String,
    pub kind: String,
    pub width: f64,
    pub height: f64,
    pub rest: SpriteRefSpec,
    pub hover: SpriteRefSpec,
    pub pressed: SpriteRefSpec,
    pub disabled: SpriteRefSpec,
    pub on_sprite: SpriteRefSpec,
    pub thumb_rest: SpriteRefSpec,
    pub thumb_hover: SpriteRefSpec,
    pub thumb_disabled: SpriteRefSpec,
    pub has_content: bool,
    pub content: Vec<f64>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ParticlePrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub display_name: String,
    pub shader_asset_path: String,
    pub duration: f64,
    pub looping: bool,
    pub planar: bool,
    pub emitters: Vec<ParticleEmitterSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
#[expect(clippy::struct_excessive_bools, reason = "matches Unity C# JsonUtility DTO fields")]
pub struct ParticleEmitterSpec {
    pub id: String,
    pub random_state: u32,
    pub rate: f64,
    pub burst: u32,
    pub delay: f64,
    pub lifetime_min: f64,
    pub lifetime_max: f64,
    pub position: Vec3Spec,
    pub spread: Vec3Spec,
    pub velocity: Vec3Spec,
    pub velocity_spread: Vec3Spec,
    pub gravity: Vec3Spec,
    pub drag: f64,
    pub size: Vec<f64>,
    pub opacity: Vec<f64>,
    pub colors: Vec<String>,
    pub additive: bool,
    pub tex_asset_path: String,
    pub fit_x: f64,
    pub fit_y: f64,
    pub orientation: String,
    pub tilt: f64,
    pub flip: bool,
    pub size_jitter: f64,
    pub stretch: f64,
    pub has_radial: bool,
    pub radial_speed_min: f64,
    pub radial_speed_max: f64,
    pub radial_radius_min: f64,
    pub radial_radius_max: f64,
    pub radial_cone: f64,
    pub has_ground: bool,
    pub ground_bounce: f64,
    pub ground_friction: f64,
    pub ground_kill: bool,
    pub triggers: Vec<ParticleTriggerSpec>,
    pub max_particles: u32,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ParticleTriggerSpec {
    pub on: String,
    pub emitter: String,
    pub count: u32,
    pub inherit: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WholeMapPrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub display_name: String,
    pub perspective: String,
    pub tile_width: i64,
    pub tile_height: i64,
    pub character_radius: i64,
    pub character_speed: i64,
    pub nav_rects: Vec<WholeNavRectSpec>,
    pub connections: Vec<WholeNavConnSpec>,
    pub tiles: Vec<WholeTileSpec>,
    pub parts: Vec<WholePartSpec>,
    pub colliders: Vec<WholeColliderSpec>,
    pub regions: Vec<WholeRegionSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WholeNavRectSpec {
    pub x: i64,
    pub y: i64,
    pub width: i64,
    pub height: i64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WholeNavConnSpec {
    pub id: String,
    pub kind: String,
    pub from: String,
    pub to: String,
    pub ax: f64,
    pub ay: f64,
    pub bx: f64,
    pub by: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WholeTileSpec {
    pub name: String,
    pub pos_x: f64,
    pub pos_y: f64,
    pub scale_x: f64,
    pub scale_y: f64,
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub order: i32,
    pub mat_asset_path: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WholePartSpec {
    pub name: String,
    pub band: &'static str,
    pub pos_x: f64,
    pub pos_y: f64,
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub order: i32,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WholeColliderSpec {
    pub polys: Vec<PolyPathSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WholeRegionSpec {
    pub name: String,
    pub poly: PolyPathSpec,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ParallaxPrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub display_name: String,
    pub backdrop: ParallaxSpriteSpec,
    pub items: Vec<ParallaxSpriteSpec>,
    pub has_level: bool,
    pub level_sprites: Vec<ParallaxLevelSpriteSpec>,
    pub level_boxes: Vec<ParallaxBoxSpec>,
    pub level_polys: Vec<PolyPathSpec>,
    pub level_triggers: Vec<ParallaxTriggerSpec>,
    pub level_markers: Vec<ParallaxMarkerSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
#[expect(clippy::struct_excessive_bools, reason = "matches Unity C# JsonUtility DTO fields")]
pub struct ParallaxSpriteSpec {
    pub name: String,
    pub front: bool,
    pub visible: bool,
    pub pos_x: f64,
    pub pos_y: f64,
    pub scale_x: f64,
    pub scale_y: f64,
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub flip_x: bool,
    pub opacity: f64,
    pub order: i32,
    pub speed: f64,
    pub drift: f64,
    pub bob_amp: f64,
    pub bob_period: f64,
    pub sway_deg: f64,
    pub sway_period: f64,
    pub repeat_span: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ParallaxLevelSpriteSpec {
    pub name: String,
    pub pos_x: f64,
    pub pos_y: f64,
    pub tex_asset_path: String,
    pub multiple: bool,
    pub sprite_name: String,
    pub order: i32,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ParallaxBoxSpec {
    pub cx: f64,
    pub cy: f64,
    pub w: f64,
    pub h: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ParallaxTriggerSpec {
    pub name: String,
    pub cx: f64,
    pub cy: f64,
    pub w: f64,
    pub h: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ParallaxMarkerSpec {
    pub name: String,
    pub x: f64,
    pub y: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Model3dPrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub display_name: String,
    pub glb_asset_path: String,
    pub capsule_collider: bool,
    pub radius: f64,
    pub height: f64,
    pub size: Vec3Spec,
    pub center: Vec3Spec,
    pub model_height: f64,
    pub bottom: f64,
    pub bones_json: String,
    pub clips: Vec<ModelClipSpec>,
    pub sockets: Vec<ModelSocketSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelClipSpec {
    pub name: String,
    pub duration: f64,
    pub loops: bool,
    pub travel: Vec3Spec,
    pub sole_low: f64,
    pub sole_high: f64,
    pub liftoffs: u32,
    pub checks: Vec<String>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelSocketSpec {
    pub name: String,
    pub position: Vec3Spec,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Scene3dPrefabTask {
    pub write: bool,
    pub asset_path: String,
    pub display_name: String,
    pub glb_asset_path: String,
    pub blocked_doors: Vec<String>,
    pub ambient_r: f64,
    pub ambient_g: f64,
    pub ambient_b: f64,
    pub ambient_intensity: f64,
    pub fog_enabled: bool,
    pub fog_r: f64,
    pub fog_g: f64,
    pub fog_b: f64,
    pub fog_density: f64,
    pub roles: Vec<Scene3dRoleSpec>,
    pub colliders: Vec<Scene3dColSpec>,
    pub role_nodes: Vec<Scene3dRoleNodeSpec>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Scene3dRoleSpec {
    pub role: String,
    pub id: String,
    pub node_name: String,
    pub pos: Vec3Spec,
    pub forward: Vec3Spec,
    pub blocked: bool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Scene3dColSpec {
    pub name: String,
    pub center: Vec3Spec,
    pub size: Vec3Spec,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Scene3dRoleNodeSpec {
    pub name: String,
    pub center: Vec3Spec,
    pub is_trigger: bool,
    pub size: Vec3Spec,
}
