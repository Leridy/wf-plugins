//! CLI sync task planners for 3D models (`model_3d`) and 3D scenes (`scene3d_map`).
use super::specs::{
    Model3dPrefabTask, ModelClipSpec, ModelSocketSpec, Scene3dColSpec, Scene3dPrefabTask, Scene3dRoleNodeSpec,
    Scene3dRoleSpec, Vec3Spec,
};
use super::worlds::v3;
use super::{CliAssetTarget, CliTargetKind, PlannedUnityNode, init_planned};
use crate::{
    model::spatial::{Collider3d, Model3d, Scene3dMap},
    paths,
    unity::{
        ExportTarget,
        animation::{join_rel, rel_prefix},
    },
};
use std::collections::BTreeSet;

pub fn plan_model3d(
    model: &Model3d,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    stem: &str,
    display_name: &str,
) -> PlannedUnityNode {
    let mut node = init_planned(target, id, version, Vec::new());
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let glb_rel = join_rel(dir_rel_prefix, &model.glb_file);
    let glb_asset_path = paths::asset_path(target.root, &paths::join(target.directory, &glb_rel));
    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &prefab_rel));
    let (capsule_collider, radius, height, size, center) = match model.collider {
        Collider3d::Capsule { radius, height, center } => (
            true,
            radius.max(0.05),
            height.max(radius * 2.0).max(0.1),
            [0.0; 3],
            [-center[0], center[1], center[2]],
        ),
        Collider3d::Box { size, center } => (
            false,
            0.0,
            0.0,
            [size[0].max(0.05), size[1].max(0.05), size[2].max(0.05)],
            [-center[0], center[1], center[2]],
        ),
    };
    let clips = model
        .clips
        .iter()
        .map(|c| {
            let tr = c.travel.unwrap_or([0.0; 3]);
            ModelClipSpec {
                name: c.name.clone(),
                duration: c.duration,
                loops: c.loops.unwrap_or(false),
                travel: Vec3Spec {
                    x: -tr[0],
                    y: tr[1],
                    z: tr[2],
                },
                sole_low: c.sole_low.unwrap_or(0.0),
                sole_high: c.sole_high.unwrap_or(0.0),
                liftoffs: c.liftoffs.unwrap_or(0),
                checks: c.checks.clone(),
            }
        })
        .collect();
    let sockets = model
        .sockets
        .iter()
        .map(|s| ModelSocketSpec {
            name: s.name.clone(),
            position: Vec3Spec {
                x: -s.position[0],
                y: s.position[1],
                z: s.position[2],
            },
        })
        .collect();
    let m_idx = node.task.model3d_prefabs.len();
    node.task.model3d_prefabs.push(Model3dPrefabTask {
        write: false,
        asset_path: prefab_asset,
        display_name: display_name.to_owned(),
        glb_asset_path,
        capsule_collider,
        radius,
        height,
        size: v3(size),
        center: v3(center),
        model_height: model.height,
        bottom: model.bottom,
        bones_json: serde_json::to_string(&model.bones).unwrap_or_else(|_| "{}".into()),
        clips,
        sockets,
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: prefab_rel,
        main_prefab: true,
        kind: CliTargetKind::Model3dPrefab(m_idx),
    });
    node
}

pub fn plan_scene3d(
    scene: &Scene3dMap,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    stem: &str,
    display_name: &str,
) -> PlannedUnityNode {
    let mut node = init_planned(target, id, version, Vec::new());
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let glb_rel = join_rel(dir_rel_prefix, &scene.glb_file);
    let glb_asset_path = paths::asset_path(target.root, &paths::join(target.directory, &glb_rel));
    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &prefab_rel));
    let blocked_set: BTreeSet<&str> = scene.blocked_doors.iter().map(String::as_str).collect();
    let amb = scene.environment.ambient_color.unwrap_or([0.5, 0.5, 0.5]);
    let fog_c = scene.environment.fog_color.unwrap_or([0.5, 0.5, 0.5]);
    let roles = build_scene3d_roles(scene, &blocked_set);
    let colliders = scene
        .colliders
        .iter()
        .map(|bx| Scene3dColSpec {
            name: bx.name.clone(),
            center: Vec3Spec {
                x: -bx.center[0],
                y: bx.center[1],
                z: bx.center[2],
            },
            size: v3(bx.size),
        })
        .collect();
    let role_nodes = build_scene3d_role_nodes(scene);
    let s_idx = node.task.scene3d_prefabs.len();
    node.task.scene3d_prefabs.push(Scene3dPrefabTask {
        write: false,
        asset_path: prefab_asset,
        display_name: display_name.to_owned(),
        glb_asset_path,
        blocked_doors: scene.blocked_doors.clone(),
        ambient_r: amb[0],
        ambient_g: amb[1],
        ambient_b: amb[2],
        ambient_intensity: scene.environment.ambient_intensity,
        fog_enabled: scene.environment.fog_color.is_some(),
        fog_r: fog_c[0],
        fog_g: fog_c[1],
        fog_b: fog_c[2],
        fog_density: scene.environment.fog_density,
        roles,
        colliders,
        role_nodes,
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: prefab_rel,
        main_prefab: true,
        kind: CliTargetKind::Scene3dPrefab(s_idx),
    });
    node
}

fn build_scene3d_roles(scene: &Scene3dMap, blocked_set: &BTreeSet<&str>) -> Vec<Scene3dRoleSpec> {
    scene
        .roles
        .iter()
        .map(|r| Scene3dRoleSpec {
            role: r.role.clone(),
            id: r.id.clone().unwrap_or_default(),
            node_name: r.node.clone().unwrap_or_default(),
            pos: Vec3Spec {
                x: -r.position[0],
                y: r.position[1],
                z: r.position[2],
            },
            forward: Vec3Spec {
                x: -r.forward[0],
                y: r.forward[1],
                z: r.forward[2],
            },
            blocked: r.role == "door"
                && (r.id.as_deref().is_some_and(|i| blocked_set.contains(i))
                    || r.node.as_deref().is_some_and(|n| blocked_set.contains(n))),
        })
        .collect()
}

fn build_scene3d_role_nodes(scene: &Scene3dMap) -> Vec<Scene3dRoleNodeSpec> {
    scene
        .roles
        .iter()
        .map(|r| {
            let label = r.id.as_deref().or(r.node.as_deref()).unwrap_or(&r.role).to_owned();
            if let (Some(min), Some(max)) = (r.min, r.max) {
                Scene3dRoleNodeSpec {
                    name: label,
                    center: Vec3Spec {
                        x: -f64::midpoint(min[0], max[0]),
                        y: f64::midpoint(min[1], max[1]),
                        z: f64::midpoint(min[2], max[2]),
                    },
                    is_trigger: true,
                    size: Vec3Spec {
                        x: (max[0] - min[0]).abs().max(0.1),
                        y: (max[1] - min[1]).abs().max(0.1),
                        z: (max[2] - min[2]).abs().max(0.1),
                    },
                }
            } else {
                Scene3dRoleNodeSpec {
                    name: label,
                    center: Vec3Spec {
                        x: -r.position[0],
                        y: r.position[1],
                        z: r.position[2],
                    },
                    is_trigger: false,
                    size: Vec3Spec { x: 0.1, y: 0.1, z: 0.1 },
                }
            }
        })
        .collect()
}
