//! CLI sync task dispatch and planners for particle and whole-map nodes.
use super::assets::{is_multiple, points_to_poly};
use super::parallax::plan_parallax;
use super::spatial::{plan_model3d, plan_scene3d};
use super::specs::{
    MaterialTask, ParticleEmitterSpec, ParticlePrefabTask, ParticleTriggerSpec, PolyPathSpec, Vec3Spec,
    WholeColliderSpec, WholeMapPrefabTask, WholeNavConnSpec, WholeNavRectSpec, WholePartSpec, WholeRegionSpec,
    WholeTileSpec,
};
use super::{CliAssetTarget, CliTargetKind, PlannedUnityNode, init_planned};
use crate::{
    gather_world::{SharedKind, SharedRuntimes, load_textures},
    model::{
        Blend, Model3d, ParallaxMap, ParticleEffect, Scene3dMap, Space, WholeMap,
        particle::Emitter,
        whole_map::{CellRect, ConnectionKind, SortMode},
    },
    paths,
    types::Node,
    unity::{
        ExportTarget,
        animation::{join_rel, rel_prefix},
        particle,
        texture::{FilterMode, ResolvedSprites, SliceSpec, SpriteKey, TextureRegistry},
        whole_map,
    },
};
use plugin_api::platform::LockedRow;
use plugin_guest::{Host, HostError};
use std::{
    collections::{BTreeMap, BTreeSet},
    iter::once,
};

pub(super) const PPU: f64 = 100.0;

#[allow(clippy::too_many_arguments)]
pub fn plan_world_or_fx(
    host: &dyn Host,
    row: &LockedRow,
    target: ExportTarget<'_>,
    prefix: &str,
    stem: &str,
    raw_name: &str,
    kind: &str,
    sidecar: &str,
    bytes: &[u8],
    locked: &BTreeSet<String>,
    runtimes: &mut SharedRuntimes,
    result: &mut Node,
) -> Result<PlannedUnityNode, HostError> {
    if sidecar == "main.json" && kind == "whole_map" {
        let map = WholeMap::read(bytes, locked, prefix)?;
        let (dims, _) = load_textures(host, row, target.directory, prefix, map.texture_paths(), true, false)?;
        runtimes.insert(SharedKind::WholeMap);
        Ok(plan_whole_map(
            &map,
            target,
            &row.id,
            row.version,
            stem,
            raw_name,
            &dims,
        ))
    } else if sidecar == "main.json" && matches!(kind, "scrolling_scene" | "scroll_map") {
        let map = ParallaxMap::read(bytes, locked, prefix)?;
        let (dims, _) = load_textures(host, row, target.directory, prefix, map.texture_paths(), true, false)?;
        runtimes.insert(SharedKind::Parallax);
        Ok(plan_parallax(&map, target, &row.id, row.version, stem, raw_name, &dims))
    } else if sidecar == "main.json" {
        let effect = ParticleEffect::read(bytes)?;
        let (dims, _) = load_textures(
            host,
            row,
            target.directory,
            prefix,
            effect.emitters.iter().map(|e| e.picture.as_str()),
            true,
            false,
        )?;
        result.reasons.extend(effect.notes.clone());
        runtimes.insert(SharedKind::Particle);
        Ok(plan_particle(
            &effect,
            target,
            &row.id,
            row.version,
            stem,
            raw_name,
            &dims,
        ))
    } else if sidecar == "engine-scene.glb" {
        let scene = Scene3dMap::read(bytes, "engine-scene.glb".to_owned())?;
        result.reasons.extend(scene.notes.clone());
        runtimes.insert(SharedKind::Spatial);
        Ok(plan_scene3d(&scene, target, &row.id, row.version, stem, raw_name))
    } else {
        let glb_name = "main.glb";
        load_textures(host, row, target.directory, prefix, once(glb_name), false, false)?;
        let glb_bytes = host.read(&paths::join(target.node_dir, glb_name))?;
        let model = Model3d::read(bytes, &glb_bytes, glb_name.to_owned())?;
        runtimes.insert(SharedKind::Spatial);
        Ok(plan_model3d(&model, target, &row.id, row.version, stem, raw_name))
    }
}

pub fn plan_particle(
    effect: &ParticleEffect,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    stem: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
) -> PlannedUnityNode {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    for e in &effect.emitters {
        registry.register(
            &e.picture,
            &e.id,
            SliceSpec {
                rect: None,
                pivot: [0.5, 0.5],
                border: [0.0; 4],
                ppu: PPU,
                filter: FilterMode::Bilinear,
            },
        );
    }
    let (_, tex_specs, _) = registry.build_cli(target.node_dir, target.root, target.directory);
    let mut node = init_planned(target, id, version, tex_specs);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let shader_asset_path = paths::asset_path(target.root, &paths::join(target.directory, particle::SHADER_PATH));
    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &prefab_rel));

    let emitters = effect
        .emitters
        .iter()
        .map(|e| build_particle_emitter(e, target, dims))
        .collect();

    let p_idx = node.task.particle_prefabs.len();
    node.task.particle_prefabs.push(ParticlePrefabTask {
        write: false,
        asset_path: prefab_asset,
        display_name: display_name.to_owned(),
        shader_asset_path,
        duration: effect.duration,
        looping: effect.looping,
        planar: effect.space == Space::Planar,
        emitters,
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: prefab_rel,
        main_prefab: true,
        kind: CliTargetKind::ParticlePrefab(p_idx),
    });
    node
}

fn build_particle_emitter(
    e: &Emitter,
    target: ExportTarget<'_>,
    dims: &BTreeMap<String, (u32, u32)>,
) -> ParticleEmitterSpec {
    let fit = if e.sprite {
        let (w, h) = dims[&e.picture];
        let (wf, hf) = (f64::from(w), f64::from(h));
        let inner = 248.0 / 256.0;
        let max_d = wf.max(hf);
        [wf / max_d * inner, hf / max_d * inner]
    } else {
        [1.0, 1.0]
    };
    let tex_asset_path = paths::asset_path(target.root, &paths::join(target.node_dir, &e.picture));
    let radial = e.radial.as_ref();
    let ground = e.ground.as_ref();
    ParticleEmitterSpec {
        id: e.id.clone(),
        random_state: e.random_state,
        rate: e.rate,
        burst: e.burst,
        delay: e.delay,
        lifetime_min: e.lifetime[0],
        lifetime_max: e.lifetime[1],
        position: v3(e.position),
        spread: v3(e.spread),
        velocity: v3(e.velocity),
        velocity_spread: v3(e.velocity_spread),
        gravity: v3(e.gravity),
        drag: e.drag,
        size: e.size.clone(),
        opacity: e.opacity.clone(),
        colors: e.color.clone(),
        additive: e.blend == Blend::Additive,
        tex_asset_path,
        fit_x: fit[0],
        fit_y: fit[1],
        orientation: e.orientation.as_str().to_owned(),
        tilt: e.tilt,
        flip: e.flip,
        size_jitter: e.size_jitter,
        stretch: e.stretch,
        has_radial: radial.is_some(),
        radial_speed_min: radial.map_or(0.0, |r| r.speed[0]),
        radial_speed_max: radial.map_or(0.0, |r| r.speed[1]),
        radial_radius_min: radial.map_or(0.0, |r| r.radius[0]),
        radial_radius_max: radial.map_or(0.0, |r| r.radius[1]),
        radial_cone: radial.map_or(0.0, |r| r.cone),
        has_ground: ground.is_some(),
        ground_bounce: ground.map_or(0.0, |g| g.bounce),
        ground_friction: ground.map_or(0.0, |g| g.friction),
        ground_kill: ground.is_some_and(|g| g.kill),
        triggers: e
            .triggers
            .iter()
            .map(|t| ParticleTriggerSpec {
                on: t.on.as_str().to_owned(),
                emitter: t.emitter.clone(),
                count: t.count,
                inherit: t.inherit,
            })
            .collect(),
        max_particles: e.max_particles,
    }
}

pub fn plan_whole_map(
    map: &WholeMap,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    stem: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
) -> PlannedUnityNode {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let (tile_keys, mask_keys, part_keys) = register_whole_map_textures(&mut registry, map, dims);
    let (resolved, tex_specs, _) = registry.build_cli(target.node_dir, target.root, target.directory);
    let mut node = init_planned(target, id, version, tex_specs);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let tiles = build_whole_tiles(
        map,
        target,
        stem,
        dir_rel_prefix,
        dims,
        &tile_keys,
        &mask_keys,
        &resolved,
        &mut node,
    );
    let parts = build_whole_parts(map, &part_keys, &resolved, &node);
    let (nav_rects, connections, colliders, regions) = build_whole_nav(map);

    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &prefab_rel));
    let w_idx = node.task.whole_map_prefabs.len();
    node.task.whole_map_prefabs.push(WholeMapPrefabTask {
        write: false,
        asset_path: prefab_asset,
        display_name: display_name.to_owned(),
        perspective: map.perspective.clone(),
        tile_width: map.tile_width,
        tile_height: map.tile_height,
        character_radius: map.character.radius,
        character_speed: map.character.speed,
        nav_rects,
        connections,
        tiles,
        parts,
        colliders,
        regions,
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: prefab_rel,
        main_prefab: true,
        kind: CliTargetKind::WholeMapPrefab(w_idx),
    });
    node
}

fn register_whole_map_textures(
    registry: &mut TextureRegistry,
    map: &WholeMap,
    dims: &BTreeMap<String, (u32, u32)>,
) -> (Vec<SpriteKey>, Vec<Option<SpriteKey>>, Vec<SpriteKey>) {
    let mut tile_keys = Vec::with_capacity(map.tiles.len());
    let mut mask_keys = Vec::with_capacity(map.tiles.len());
    for tile in &map.tiles {
        let bk = registry.register(
            &tile.base_file,
            &format!("tile_{}_{}", tile.grid_x, tile.grid_y),
            SliceSpec {
                rect: None,
                pivot: [0.0, 1.0],
                border: [0.0; 4],
                ppu: PPU,
                filter: FilterMode::Bilinear,
            },
        );
        let mk = tile.mask_file.as_deref().map(|mask| {
            registry.register(
                mask,
                &format!("mask_{}_{}", tile.grid_x, tile.grid_y),
                SliceSpec {
                    rect: None,
                    pivot: [0.0, 1.0],
                    border: [0.0; 4],
                    ppu: PPU,
                    filter: FilterMode::Point,
                },
            )
        });
        tile_keys.push(bk);
        mask_keys.push(mk);
    }
    let part_keys = map
        .parts
        .iter()
        .map(|part| {
            let (pw, ph) = dims.get(&part.texture_file).copied().unwrap_or((1, 1));
            let px = ((part.foot.x - part.x) / f64::from(pw.max(1))).clamp(0.0, 1.0);
            let py = (1.0 - (part.foot.y - part.y) / f64::from(ph.max(1))).clamp(0.0, 1.0);
            registry.register(
                &part.texture_file,
                &part.id,
                SliceSpec {
                    rect: None,
                    pivot: [px, py],
                    border: [0.0; 4],
                    ppu: PPU,
                    filter: FilterMode::Bilinear,
                },
            )
        })
        .collect();
    (tile_keys, mask_keys, part_keys)
}

#[allow(clippy::too_many_arguments)]
fn build_whole_tiles(
    map: &WholeMap,
    target: ExportTarget<'_>,
    stem: &str,
    dir_rel_prefix: &str,
    dims: &BTreeMap<String, (u32, u32)>,
    tile_keys: &[SpriteKey],
    mask_keys: &[Option<SpriteKey>],
    resolved: &ResolvedSprites,
    node: &mut PlannedUnityNode,
) -> Vec<WholeTileSpec> {
    let shader_asset_path = paths::asset_path(target.root, &paths::join(target.directory, whole_map::SHADER_PATH));
    let mut tiles = Vec::with_capacity(map.tiles.len());
    for (idx, tile) in map.tiles.iter().enumerate() {
        let (pw, ph) = dims.get(&tile.base_file).copied().unwrap_or((1, 1));
        let tw = i32::try_from(tile.width.max(1)).unwrap_or(1);
        let th = i32::try_from(tile.height.max(1)).unwrap_or(1);
        let mat_asset_path = if let Some(mk) = &mask_keys[idx] {
            let mat_name = format!("{stem}_Tile_{}_{}", tile.grid_x, tile.grid_y);
            let mat_rel = join_rel(dir_rel_prefix, &format!("{mat_name}.mat"));
            let mat_asset = paths::asset_path(target.root, &paths::join(target.directory, &mat_rel));
            let mask_info = resolved.slice_info(mk);
            let m_idx = node.task.materials.len();
            node.task.materials.push(MaterialTask {
                write: false,
                asset_path: mat_asset.clone(),
                name: mat_name,
                shader_asset_path: shader_asset_path.clone(),
                mask_tex_asset_path: mask_info.asset_path.clone(),
                width: tw,
                height: th,
            });
            node.asset_targets.push(CliAssetTarget {
                rel_path: mat_rel,
                main_prefab: false,
                kind: CliTargetKind::Material(m_idx),
            });
            mat_asset
        } else {
            String::new()
        };
        let base_info = resolved.slice_info(&tile_keys[idx]);
        let tx = i32::try_from(tile.x).unwrap_or(0);
        let ty = i32::try_from(tile.y).unwrap_or(0);
        tiles.push(WholeTileSpec {
            name: format!("Tile_{}_{}", tile.grid_x, tile.grid_y),
            pos_x: f64::from(tx) / PPU,
            pos_y: -f64::from(ty) / PPU,
            scale_x: f64::from(tw) / f64::from(pw.max(1)),
            scale_y: f64::from(th) / f64::from(ph.max(1)),
            tex_asset_path: base_info.asset_path.clone(),
            multiple: is_multiple(&node.task.textures, &base_info.asset_path),
            sprite_name: base_info.sprite_name.clone(),
            order: -2000 + i32::try_from(idx).unwrap_or(0),
            mat_asset_path,
        });
    }
    tiles
}

fn build_whole_parts(
    map: &WholeMap,
    part_keys: &[SpriteKey],
    resolved: &ResolvedSprites,
    node: &PlannedUnityNode,
) -> Vec<WholePartSpec> {
    map.parts
        .iter()
        .enumerate()
        .map(|(i, part)| {
            let (band, order_base) = match part.sort_mode {
                SortMode::Below => ("Below", -1000),
                SortMode::Sorted => ("Sorted", 0),
                SortMode::Above => ("Above", 1000),
            };
            let info = resolved.slice_info(&part_keys[i]);
            WholePartSpec {
                name: part.name.clone(),
                band,
                pos_x: part.foot.x / PPU,
                pos_y: -part.foot.y / PPU,
                tex_asset_path: info.asset_path.clone(),
                multiple: is_multiple(&node.task.textures, &info.asset_path),
                sprite_name: info.sprite_name.clone(),
                order: order_base + i32::try_from(i).unwrap_or(0),
            }
        })
        .collect()
}

type WholeNavParts = (
    Vec<WholeNavRectSpec>,
    Vec<WholeNavConnSpec>,
    Vec<WholeColliderSpec>,
    Vec<WholeRegionSpec>,
);

fn build_whole_nav(map: &WholeMap) -> WholeNavParts {
    let mut rects: Vec<&CellRect> = map.nav_layers.iter().flat_map(|l| &l.walkable_rects).collect();
    for p in &map.parts {
        rects.extend(&p.walkable_rects);
    }
    let nav_rects = rects
        .into_iter()
        .map(|r| WholeNavRectSpec {
            x: r.x,
            y: r.y,
            width: r.width,
            height: r.height,
        })
        .collect();
    let connections = map
        .connections
        .iter()
        .map(|c| WholeNavConnSpec {
            id: c.id.clone(),
            kind: match c.kind {
                ConnectionKind::Stairs => "stairs",
                ConnectionKind::Ramp => "ramp",
            }
            .to_owned(),
            from: c.from.clone(),
            to: c.to.clone(),
            ax: c.a.x,
            ay: c.a.y,
            bx: c.b.x,
            by: c.b.y,
        })
        .collect();
    let colliders = map
        .parts
        .iter()
        .filter(|p| p.blocking)
        .filter_map(|p| {
            let polys: Vec<PolyPathSpec> = p
                .footprints
                .iter()
                .filter(|ring| ring.len() >= 3)
                .map(|ring| points_to_poly(ring, PPU))
                .collect();
            (!polys.is_empty()).then_some(WholeColliderSpec { polys })
        })
        .collect();
    let regions = map
        .regions
        .iter()
        .filter(|r| r.polygon.len() >= 3)
        .map(|r| WholeRegionSpec {
            name: format!("Water_{}", r.id),
            poly: points_to_poly(&r.polygon, PPU),
        })
        .collect();
    (nav_rects, connections, colliders, regions)
}

pub(super) fn v3(a: [f64; 3]) -> Vec3Spec {
    Vec3Spec {
        x: a[0],
        y: a[1],
        z: a[2],
    }
}
