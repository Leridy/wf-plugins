//! Unity CLI task planning, Unity Editor lockfile detection (`Temp/UnityLockfile`),
//! deterministic `.png.meta` GUID seeding, and host-managed temporary script cleanup.
pub mod assets;
pub mod parallax;
pub mod spatial;
mod specs;
pub mod tilemap;
pub mod worlds;

use crate::{
    gather_world::{SharedRuntimes, ensure_not_locked, load_textures},
    model::{Animation, IconSet, Kit, PropSet, TileMap},
    paths::{self, invalid},
    reconcile,
    types::{Element, File, Node, Status},
    unity::{ExportTarget, bindings::NodeBindingData, texture::CliTextureSpec},
};
use plugin_api::{
    Effect, Failure,
    platform::{LockedRow, LocksOutput},
};
use plugin_guest::{Host, HostError};
use specs::{Manifest, SyncTask, TextureTask};
use std::{collections::BTreeSet, mem};

pub type CliReconcileResult = (Option<SyncTask>, Vec<(String, String)>);

pub const WF_SYNC_RUNNER_CS: &str = include_str!("../unity/WfSyncRunner.cs");
pub const WF_SYNC_WORLD_CS: &str = include_str!("../unity/WfSyncWorld.cs");

const TMP_RUNNER_CS: &str = "Assets/WfTmpSync/WfSyncRunner.cs";
const TMP_RUNNER_META: &str = "Assets/WfTmpSync/WfSyncRunner.cs.meta";
const TMP_WORLD_CS: &str = "Assets/WfTmpSync/WfSyncWorld.cs";
const TMP_WORLD_META: &str = "Assets/WfTmpSync/WfSyncWorld.cs.meta";
const TMP_MANIFEST_JSON: &str = "Assets/WfTmpSync/manifest.json";
const TMP_MANIFEST_META: &str = "Assets/WfTmpSync/manifest.json.meta";
const TMP_DIR_META: &str = "Assets/WfTmpSync.meta";

/// Checks if `Temp/UnityLockfile` exists under the Unity project root.
pub fn unity_project_locked(host: &dyn Host, root: &str) -> Result<bool, HostError> {
    match host.read(&paths::join(root, "Temp/UnityLockfile")) {
        Ok(_) => Ok(true),
        Err(e) if e.not_found() => Ok(false),
        Err(e) => Err(e),
    }
}

/// Checks whether the project's `Packages/manifest.json` declares `com.unity.ugui`.
pub fn packages_has_ugui(host: &dyn Host, root: &str) -> Result<bool, HostError> {
    match host.read(&paths::join(root, "Packages/manifest.json")) {
        Ok(bytes) => Ok(String::from_utf8_lossy(&bytes).contains("\"com.unity.ugui\"")),
        Err(e) if e.not_found() => Ok(false),
        Err(e) => Err(e),
    }
}

pub(crate) enum CliTargetKind {
    Clip(usize),
    Controller(usize),
    TileAsset(usize),
    Material(usize),
    AnimPrefab(usize),
    PropPrefab(usize),
    TilemapPrefab(usize),
    UiPrefab(usize),
    ParticlePrefab(usize),
    WholeMapPrefab(usize),
    ParallaxPrefab(usize),
    Model3dPrefab(usize),
    Scene3dPrefab(usize),
}

pub(crate) struct CliAssetTarget {
    /// Path relative to `directory` (without `.meta`).
    pub rel_path: String,
    pub main_prefab: bool,
    pub kind: CliTargetKind,
}

/// All CLI-planned targets and bindings for one node.
pub struct PlannedUnityNode {
    pub task: SyncTask,
    pub tex_specs: Vec<CliTextureSpec>,
    pub asset_targets: Vec<CliAssetTarget>,
    pub elements: Vec<Element>,
    pub notes: Vec<String>,
    pub binding: NodeBindingData,
}

pub(crate) fn init_planned(
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    tex_specs: Vec<CliTextureSpec>,
) -> PlannedUnityNode {
    let mut task = SyncTask::empty(id.to_owned(), version, String::new());
    task.textures = tex_specs
        .iter()
        .cloned()
        .map(|s| TextureTask::from_cli(s, false))
        .collect();
    let _ = target;
    PlannedUnityNode {
        task,
        tex_specs,
        asset_targets: Vec::new(),
        elements: Vec::new(),
        notes: Vec::new(),
        binding: NodeBindingData::default(),
    }
}

/// Reconciles all CLI targets for one node and appends a task + `.png.meta` seeds if any asset needs updating.
#[expect(
    clippy::too_many_arguments,
    reason = "reconcile tracks locks, wanted paths, seeds, and node output"
)]
pub fn reconcile_cli_node(
    host: &dyn Host,
    directory: &str,
    root: &str,
    locks: &LocksOutput,
    row: &LockedRow,
    force: bool,
    mut planned: PlannedUnityNode,
    wanted: &mut BTreeSet<String>,
    files: &mut Vec<File>,
    main_prefab: &mut Option<String>,
    reasons: &mut Vec<String>,
) -> Result<CliReconcileResult, HostError> {
    let mut seed_png_metas = Vec::new();
    let canonical = serde_json::to_vec(&(WF_SYNC_RUNNER_CS, WF_SYNC_WORLD_CS, &row.id, row.version, &planned.task))
        .map_err(|e| HostError::new(Failure::Internal, format!("CLI hash error: {e}")))?;
    let src_hash = reconcile::sha256_hex(&canonical);
    planned.task.src_hash.clone_from(&src_hash);

    let mut any_write = false;
    for (idx, spec) in planned.tex_specs.iter().enumerate() {
        let path = paths::join(directory, &spec.meta_rel_path);
        if !wanted.insert(path.clone()) {
            return Err(invalid(format!("generated paths collide: {path}")));
        }
        ensure_not_locked(locks, directory, &path)?;
        let st = reconcile::cli_file(host, &path, row.version, &src_hash, force)?;
        let write = matches!(st, Status::Written | Status::Updated);
        planned.task.textures[idx].write = write;
        any_write |= write;
        if st == Status::Written {
            seed_png_metas.push((path.clone(), spec.guid.clone()));
        }
        if st == Status::Kept {
            reasons.push(format!(
                "{path}: user-owned or edited file kept; use --force to replace it."
            ));
        }
        files.push(File {
            resource: format!("{}.meta", spec.asset_path),
            path,
            status: st,
        });
    }

    for tgt in &planned.asset_targets {
        let rel = paths::join(directory, &tgt.rel_path);
        let meta_rel = format!("{rel}.meta");
        if !wanted.insert(rel.clone()) {
            return Err(invalid(format!("generated paths collide: {rel}")));
        }
        if !wanted.insert(meta_rel.clone()) {
            return Err(invalid(format!("generated paths collide: {meta_rel}")));
        }
        ensure_not_locked(locks, directory, &rel)?;
        ensure_not_locked(locks, directory, &meta_rel)?;

        let asset_st = reconcile::cli_file(host, &rel, row.version, &src_hash, force)?;
        let meta_st = reconcile::cli_file(host, &meta_rel, row.version, &src_hash, force)?;
        let write = matches!(asset_st, Status::Written | Status::Updated)
            || matches!(meta_st, Status::Written | Status::Updated);
        any_write |= write;
        set_target_write(&mut planned.task, &tgt.kind, write);

        let asset_res = paths::asset_path(root, &rel);
        if tgt.main_prefab {
            *main_prefab = Some(asset_res.clone());
        }
        for (p, r, st) in [
            (rel, asset_res, asset_st),
            (
                meta_rel,
                format!(
                    "{}.meta",
                    paths::asset_path(root, &paths::join(directory, &tgt.rel_path))
                ),
                meta_st,
            ),
        ] {
            if st == Status::Kept {
                reasons.push(format!(
                    "{p}: user-owned or edited file kept; use --force to replace it."
                ));
            }
            files.push(File {
                resource: r,
                path: p,
                status: st,
            });
        }
    }

    if any_write {
        Ok((Some(planned.task), seed_png_metas))
    } else {
        Ok((None, Vec::new()))
    }
}

fn set_target_write(task: &mut SyncTask, kind: &CliTargetKind, write: bool) {
    match *kind {
        CliTargetKind::Clip(i) => task.clips[i].write = write,
        CliTargetKind::Controller(i) => task.controllers[i].write = write,
        CliTargetKind::TileAsset(i) => task.tile_assets[i].write = write,
        CliTargetKind::Material(i) => task.materials[i].write = write,
        CliTargetKind::AnimPrefab(i) => task.anim_prefabs[i].write = write,
        CliTargetKind::PropPrefab(i) => task.prop_prefabs[i].write = write,
        CliTargetKind::TilemapPrefab(i) => task.tilemap_prefabs[i].write = write,
        CliTargetKind::UiPrefab(i) => task.ui_prefabs[i].write = write,
        CliTargetKind::ParticlePrefab(i) => task.particle_prefabs[i].write = write,
        CliTargetKind::WholeMapPrefab(i) => task.whole_map_prefabs[i].write = write,
        CliTargetKind::ParallaxPrefab(i) => task.parallax_prefabs[i].write = write,
        CliTargetKind::Model3dPrefab(i) => task.model3d_prefabs[i].write = write,
        CliTargetKind::Scene3dPrefab(i) => task.scene3d_prefabs[i].write = write,
    }
}

/// Accumulated Unity CLI batchmode state across selected nodes.
pub struct CliRun {
    pub has_ugui: bool,
    pub tasks: Vec<SyncTask>,
    pub seed_png_metas: Vec<(String, String)>,
}

impl CliRun {
    pub fn new(has_ugui: bool) -> Self {
        Self {
            has_ugui,
            tasks: Vec::new(),
            seed_png_metas: Vec::new(),
        }
    }

    /// Reconciles one planned node, records its task & seeds, and returns binding data.
    #[expect(
        clippy::too_many_arguments,
        reason = "records planned CLI files onto Node and CliRun"
    )]
    pub fn record_planned(
        &mut self,
        host: &dyn Host,
        directory: &str,
        root: &str,
        locks: &LocksOutput,
        row: &LockedRow,
        force: bool,
        mut planned: PlannedUnityNode,
        wanted: &mut BTreeSet<String>,
        result: &mut Node,
    ) -> Result<NodeBindingData, HostError> {
        if result.elements.is_empty() {
            result.elements = mem::take(&mut planned.elements);
        }
        result.reasons.extend(mem::take(&mut planned.notes));
        let binding = mem::take(&mut planned.binding);
        let (maybe_task, seeds) = reconcile_cli_node(
            host,
            directory,
            root,
            locks,
            row,
            force,
            planned,
            wanted,
            &mut result.files,
            &mut result.main_prefab,
            &mut result.reasons,
        )?;
        if let Some(t) = maybe_task {
            self.tasks.push(t);
        }
        self.seed_png_metas.extend(seeds);
        Ok(binding)
    }
}

/// Plans CLI tasks (and `.png.meta` slices) for one sidecar-backed WeaveForge node.
#[expect(clippy::too_many_arguments, reason = "dispatches every sidecar node kind uniformly")]
pub fn plan_sidecar_node(
    host: &dyn Host,
    row: &LockedRow,
    target: ExportTarget<'_>,
    prefix: &str,
    stem: &str,
    raw_name: &str,
    kind: &str,
    sidecar: &str,
    bytes: &[u8],
    has_ugui: bool,
    runtimes: &mut SharedRuntimes,
    result: &mut Node,
) -> Result<PlannedUnityNode, HostError> {
    let locked: BTreeSet<String> = row.files.iter().cloned().collect();
    if matches!(sidecar, "main.json" | "engine-scene.glb" | "model.json") {
        return worlds::plan_world_or_fx(
            host, row, target, prefix, stem, raw_name, kind, sidecar, bytes, &locked, runtimes, result,
        );
    }
    plan_asset_sidecar(
        host, row, target, prefix, stem, raw_name, sidecar, bytes, has_ugui, result,
    )
}

#[expect(clippy::too_many_arguments, reason = "decodes typed asset sidecars cleanly")]
fn plan_asset_sidecar(
    host: &dyn Host,
    row: &LockedRow,
    target: ExportTarget<'_>,
    prefix: &str,
    stem: &str,
    raw_name: &str,
    sidecar: &str,
    bytes: &[u8],
    has_ugui: bool,
    result: &mut Node,
) -> Result<PlannedUnityNode, HostError> {
    if sidecar == "animation.json" {
        let anim = Animation::read(bytes)?;
        let (dims, masks) = load_textures(
            host,
            row,
            target.directory,
            prefix,
            anim.clips
                .iter()
                .flat_map(|c| &c.frames)
                .map(|f| f.texture.path.as_str()),
            true,
            true,
        )?;
        Ok(assets::plan_animation(
            &anim,
            target,
            &row.id,
            row.version,
            stem,
            raw_name,
            &dims,
            &masks,
        ))
    } else if sidecar == "tilemap.json" {
        let map = TileMap::read(bytes)?;
        load_textures(
            host,
            row,
            target.directory,
            prefix,
            map.textures.values().map(|t| t.file.as_str()),
            false,
            false,
        )?;
        Ok(tilemap::plan_tilemap(
            &map,
            target,
            &row.id,
            row.version,
            stem,
            raw_name,
        ))
    } else if sidecar == "props.json" {
        let prop_set = PropSet::read(bytes)?;
        let (dims, masks) = load_textures(
            host,
            row,
            target.directory,
            prefix,
            prop_set.objects.iter().flat_map(|o| {
                o.states.iter().map(|s| s.texture.path.as_str()).chain(
                    o.animations
                        .iter()
                        .flat_map(|a| a.textures.iter().map(|t| t.path.as_str())),
                )
            }),
            true,
            true,
        )?;
        result.reasons.extend(prop_set.notes.clone());
        Ok(assets::plan_prop(
            &prop_set,
            target,
            &row.id,
            row.version,
            &dims,
            &masks,
        ))
    } else if sidecar == "icons.json" {
        let icons = IconSet::read(bytes)?;
        let (dims, masks) = load_textures(
            host,
            row,
            target.directory,
            prefix,
            icons
                .elements
                .iter()
                .flat_map(|e| &e.states)
                .map(|s| s.texture.path.as_str()),
            true,
            true,
        )?;
        Ok(assets::plan_icon(&icons, target, &row.id, row.version, &dims, &masks))
    } else {
        let kit = Kit::read(bytes)?;
        let (dims, masks) = load_textures(
            host,
            row,
            target.directory,
            prefix,
            kit.widgets
                .iter()
                .flat_map(|w| &w.states)
                .map(|s| s.texture.path.as_str()),
            true,
            true,
        )?;
        result.reasons.extend(kit.notes.clone());
        Ok(assets::plan_ui(
            &kit,
            target,
            &row.id,
            row.version,
            has_ugui,
            &dims,
            &masks,
        ))
    }
}

/// Emits `.png.meta` seeds, temp `Assets/WfTmpSync/*` files, host cleanup registrations, and Unity batchmode `Exec`.
pub fn emit_cli_effects(
    host: &dyn Host,
    root: &str,
    tasks: Vec<SyncTask>,
    seed_png_metas: Vec<(String, String)>,
    effects: &mut Vec<Effect>,
) -> Result<(), HostError> {
    if tasks.is_empty() {
        return Ok(());
    }
    for (meta_path, guid) in seed_png_metas {
        effects.push(Effect::WriteFile {
            path: meta_path,
            bytes: format!("fileFormatVersion: 2\nguid: {guid}\n").into_bytes(),
            overwrite: false,
        });
    }

    let manifest_bytes = serde_json::to_vec(&Manifest { tasks }).map_err(|e| {
        HostError::new(
            Failure::Internal,
            format!("failed to serialize Unity CLI manifest: {e}"),
        )
    })?;

    for tmp in [
        TMP_RUNNER_CS,
        TMP_RUNNER_META,
        TMP_WORLD_CS,
        TMP_WORLD_META,
        TMP_MANIFEST_JSON,
        TMP_MANIFEST_META,
        TMP_DIR_META,
    ] {
        host.cleanup_after_exec(&paths::join(root, tmp))?;
    }

    effects.push(Effect::WriteFile {
        path: paths::join(root, TMP_RUNNER_CS),
        bytes: WF_SYNC_RUNNER_CS.as_bytes().to_vec(),
        overwrite: true,
    });
    effects.push(Effect::WriteFile {
        path: paths::join(root, TMP_WORLD_CS),
        bytes: WF_SYNC_WORLD_CS.as_bytes().to_vec(),
        overwrite: true,
    });
    effects.push(Effect::WriteFile {
        path: paths::join(root, TMP_MANIFEST_JSON),
        bytes: manifest_bytes,
        overwrite: true,
    });

    let project_arg = if root.is_empty() {
        ".".to_owned()
    } else {
        root.to_owned()
    };
    effects.push(Effect::Exec {
        tool: "unity".into(),
        args: vec![
            "-batchmode".into(),
            "-quit".into(),
            "-nographics".into(),
            "-projectPath".into(),
            project_arg,
            "-executeMethod".into(),
            "WeaveForge.Editor.WfSyncRunner.Run".into(),
            "-logFile".into(),
            "-".into(),
        ],
        reason: "Configure TextureImporters and generate Unity assets and prefabs via Unity CLI".into(),
    });
    Ok(())
}
