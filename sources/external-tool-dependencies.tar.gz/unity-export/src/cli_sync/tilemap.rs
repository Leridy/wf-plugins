//! CLI sync task planner for `tilemap` nodes.
use super::assets::{is_multiple, points_to_poly};
use super::specs::{
    TileAssetTask, TilemapCellSpec, TilemapLayerSpec, TilemapObsSpec, TilemapPrefabTask, TilemapSpriteSpec,
};
use super::{CliAssetTarget, CliTargetKind, PlannedUnityNode, init_planned};
use crate::{
    model::{Orientation, TileMap},
    paths,
    unity::{
        ExportTarget,
        animation::{join_rel, rel_prefix, unique_name},
        texture::{ResolvedSprites, SpriteKey, TextureRegistry},
        tilemap::{ground_shift, register_map_sprites, unity_cell},
    },
};
use std::collections::{BTreeMap, BTreeSet};

pub fn plan_tilemap(
    map: &TileMap,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    stem: &str,
    display_name: &str,
) -> PlannedUnityNode {
    let mut dims = BTreeMap::new();
    for tex in map.textures.values() {
        let dim = |v: f64| u32::try_from((v.round().max(1.0) as i64).min(i64::from(u32::MAX))).unwrap_or(u32::MAX);
        dims.insert(tex.file.clone(), (dim(tex.width), dim(tex.height)));
    }
    let ppu = map.tile_width;
    let mut registry = TextureRegistry::new(target.node_prefix, &dims);
    let (ground_keys, sprite_keys) = register_map_sprites(map, ppu, &mut registry);
    let (resolved, tex_specs, mut notes) = registry.build_cli(target.node_dir, target.root, target.directory);
    let mut node = init_planned(target, id, version, tex_specs);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);

    if !map.terrains.is_empty() {
        notes.push(format!(
            "Slice regions for {} terrain variant table(s) are written to .png.meta; \
             terrains are baked in Ground layers and terrain metadata stays in tilemap.json.",
            map.terrains.len()
        ));
    }

    let tile_assets = register_tile_assets(&ground_keys, &resolved, target, dir_rel_prefix, &mut node);
    let cell_h = map.tile_height / ppu;
    let is_iso = map.orientation == Orientation::Isometric;
    let (layers, ground_sort_base) = build_tile_layers(map, &ground_keys, &tile_assets, &resolved, cell_h, ppu, is_iso);
    let sprites = build_tile_sprites(map, &sprite_keys, &resolved, &node, ppu, ground_sort_base);
    let obstacles = map
        .obstacles
        .iter()
        .enumerate()
        .filter(|(_, o)| o.points.len() >= 3)
        .map(|(idx, o)| TilemapObsSpec {
            name: format!("Obstacle_{}_{}", idx + 1, paths::filename(&o.kind)),
            poly: points_to_poly(&o.points, ppu),
        })
        .collect();
    let walkable = map
        .walkable
        .iter()
        .enumerate()
        .filter(|(_, p)| p.len() >= 2)
        .map(|(idx, p)| TilemapObsSpec {
            name: format!("WalkableBounds_{}", idx + 1),
            poly: points_to_poly(p, ppu),
        })
        .collect();

    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &prefab_rel));
    let tm_idx = node.task.tilemap_prefabs.len();
    node.task.tilemap_prefabs.push(TilemapPrefabTask {
        write: false,
        asset_path: prefab_asset,
        display_name: display_name.to_owned(),
        isometric: is_iso,
        cell_height: cell_h,
        layers,
        sprites,
        obstacles,
        walkable,
        has_spawn: map.spawn.is_some(),
        spawn_x: map.spawn.map_or(0.0, |p| p.x / ppu),
        spawn_y: map.spawn.map_or(0.0, |p| -p.y / ppu),
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: prefab_rel,
        main_prefab: true,
        kind: CliTargetKind::TilemapPrefab(tm_idx),
    });
    node.notes = notes;
    node
}

fn register_tile_assets(
    ground_keys: &[SpriteKey],
    resolved: &ResolvedSprites,
    target: ExportTarget<'_>,
    dir_rel_prefix: &str,
    node: &mut PlannedUnityNode,
) -> BTreeMap<(String, i64), String> {
    let mut tile_assets = BTreeMap::new();
    for key in ground_keys {
        let info = resolved.slice_info(key);
        let dedup_key = (info.tex_guid.clone(), info.internal_id);
        if tile_assets.contains_key(&dedup_key) {
            continue;
        }
        let idx = tile_assets.len() + 1;
        let name = format!("Tile_{}_{idx}", paths::filename(&info.sprite_name));
        let rel_asset = join_rel(dir_rel_prefix, &format!("tiles/{name}.asset"));
        let asset_path = paths::asset_path(target.root, &paths::join(target.directory, &rel_asset));
        let t_idx = node.task.tile_assets.len();
        node.task.tile_assets.push(TileAssetTask {
            write: false,
            asset_path: asset_path.clone(),
            name,
            tex_asset_path: info.asset_path.clone(),
            multiple: is_multiple(&node.task.textures, &info.asset_path),
            sprite_name: info.sprite_name.clone(),
        });
        node.asset_targets.push(CliAssetTarget {
            rel_path: rel_asset,
            main_prefab: false,
            kind: CliTargetKind::TileAsset(t_idx),
        });
        tile_assets.insert(dedup_key, asset_path);
    }
    tile_assets
}

fn build_tile_layers(
    map: &TileMap,
    ground_keys: &[SpriteKey],
    tile_assets: &BTreeMap<(String, i64), String>,
    resolved: &ResolvedSprites,
    cell_h: f64,
    ppu: f64,
    is_iso: bool,
) -> (Vec<TilemapLayerSpec>, i32) {
    let mut levels: BTreeMap<u32, Vec<usize>> = BTreeMap::new();
    for (idx, tile) in map.ground.iter().enumerate() {
        levels.entry(tile.level).or_default().push(idx);
    }
    let mut ground_sort_base = 0_i32;
    let mut layers = Vec::with_capacity(levels.len());
    for (level, indices) in levels {
        let shift = ground_shift(&map.ground[indices[0]], 1.0, cell_h, ppu, is_iso);
        let cells = indices
            .into_iter()
            .map(|idx| {
                let tile = &map.ground[idx];
                let [cx, cy] = unity_cell(tile.cell, is_iso);
                let info = resolved.slice_info(&ground_keys[idx]);
                let dedup_key = (info.tex_guid.clone(), info.internal_id);
                TilemapCellSpec {
                    x: i32::try_from(cx).unwrap_or(0),
                    y: i32::try_from(cy).unwrap_or(0),
                    tile_asset_path: tile_assets[&dedup_key].clone(),
                }
            })
            .collect();
        layers.push(TilemapLayerSpec {
            name: format!("Ground_{level}"),
            order: level.cast_signed(),
            shift_x: shift[0],
            shift_y: shift[1],
            cells,
        });
        ground_sort_base = level.cast_signed() + 1;
    }
    (layers, ground_sort_base)
}

fn build_tile_sprites(
    map: &TileMap,
    sprite_keys: &[SpriteKey],
    resolved: &ResolvedSprites,
    node: &PlannedUnityNode,
    ppu: f64,
    ground_sort_base: i32,
) -> Vec<TilemapSpriteSpec> {
    let mut used_names = BTreeSet::new();
    map.sprites
        .iter()
        .enumerate()
        .map(|(idx, sp)| {
            let uname = unique_name(&mut used_names, &paths::filename(&sp.id));
            let tex = &map.textures[&sp.texture];
            let (src_w, src_h) = sp.source.map_or((tex.width, tex.height), |s| (s.width, s.height));
            let info = resolved.slice_info(&sprite_keys[idx]);
            TilemapSpriteSpec {
                name: uname,
                pos_x: sp.position.x / ppu,
                pos_y: -sp.position.y / ppu,
                rot_deg: -sp.rotation,
                vis_x: (sp.rect.x + sp.rect.width * 0.5) / ppu,
                vis_y: -(sp.rect.y + sp.rect.height * 0.5) / ppu,
                scale_x: sp.rect.width / src_w,
                scale_y: sp.rect.height / src_h,
                tex_asset_path: info.asset_path.clone(),
                multiple: is_multiple(&node.task.textures, &info.asset_path),
                sprite_name: info.sprite_name.clone(),
                flip_x: sp.flip_x,
                opacity: sp.opacity,
                order: ground_sort_base + i32::try_from(idx).unwrap_or(i32::MAX),
            }
        })
        .collect()
}
