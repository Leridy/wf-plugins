//! CLI sync task planners for image, icon, ui, animation, prop, and tilemap nodes.
use super::specs::{
    AnimPrefabTask, ClipFrameSpec, ClipTask, ControllerStateSpec, ControllerTask, PolyPathSpec, PropPrefabTask,
    PropStateColliderSpec, SpriteRefSpec, UiPrefabTask, Vec2Spec,
};
use super::{CliAssetTarget, CliTargetKind, PlannedUnityNode, init_planned};
use crate::{
    model::{AlphaMask, Animation, IconSet, Kit, Point, PropSet, Style, WidgetKind, prop::PropObject, ui::Widget},
    paths,
    types::Element,
    unity::{
        ExportTarget,
        animation::{build_clip_binding, join_rel, register_clips, rel_prefix, texture_frame_size, unique_name},
        bindings::{NodeBindingData, SpriteTable},
        icon::{build_icon_binding, register_icons},
        image::{build_image_binding, register_images},
        prop::{build_prop_binding, register_prop_sprites},
        texture::{ResolvedSprites, SpriteKey, TextureRegistry},
        ui::{RawStyle, build_element_binding, register_widgets},
    },
};
use std::collections::{BTreeMap, BTreeSet};

pub fn plan_image(
    rel_files: &[String],
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    dims: &BTreeMap<String, (u32, u32)>,
    masks: &BTreeMap<String, AlphaMask>,
) -> PlannedUnityNode {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let (png_keys, other_images) = register_images(rel_files, dims, &mut registry);
    let (resolved, tex_specs, notes) = registry.build_cli(target.node_dir, target.root, target.directory);
    let mut node = init_planned(target, id, version, tex_specs);
    node.notes = notes;
    node.binding = build_image_binding(target.directory, target.root, &png_keys, other_images, &resolved, masks);
    node
}

pub fn plan_icon(
    icons: &IconSet,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    dims: &BTreeMap<String, (u32, u32)>,
    masks: &BTreeMap<String, AlphaMask>,
) -> PlannedUnityNode {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let keys = register_icons(icons, &mut registry);
    let (resolved, tex_specs, notes) = registry.build_cli(target.node_dir, target.root, target.directory);
    let (elements, binding) = build_icon_binding(icons, &keys, &resolved, masks);
    let mut node = init_planned(target, id, version, tex_specs);
    node.elements = elements;
    node.notes = notes;
    node.binding = binding;
    node
}

#[allow(clippy::too_many_arguments)]
pub fn plan_animation(
    anim: &Animation,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    stem: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
    masks: &BTreeMap<String, AlphaMask>,
) -> PlannedUnityNode {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let clip_keys = register_clips(&mut registry, anim, dims);
    let (resolved, tex_specs, mut notes) = registry.build_cli(target.node_dir, target.root, target.directory);
    let mut node = init_planned(target, id, version, tex_specs);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let mut table = SpriteTable::new(&resolved, masks);
    let mut clip_file_names = BTreeSet::new();
    let mut binding_clips = Vec::with_capacity(anim.clips.len());
    let mut states = Vec::with_capacity(anim.clips.len());

    for (clip, keys) in anim.clips.iter().zip(&clip_keys) {
        let anim_base = unique_name(&mut clip_file_names, &paths::filename(&clip.name));
        let rel_anim = join_rel(dir_rel_prefix, &format!("clips/{anim_base}.anim"));
        let clip_asset = paths::asset_path(target.root, &paths::join(target.directory, &rel_anim));
        let durations: Vec<f64> = clip.frames.iter().map(|f| f.duration_ms).collect();
        let min_ms = durations.iter().copied().fold(f64::INFINITY, f64::min);
        let sample_rate = (1000.0 / min_ms).clamp(1.0, 120.0);
        let frames = keys
            .iter()
            .zip(&durations)
            .map(|((k, _), &ms)| {
                let info = resolved.slice_info(k);
                ClipFrameSpec {
                    tex_asset_path: info.asset_path.clone(),
                    multiple: is_multiple(&node.task.textures, &info.asset_path),
                    sprite_name: info.sprite_name.clone(),
                    duration_ms: ms,
                }
            })
            .collect();
        let clip_idx = node.task.clips.len();
        node.task.clips.push(ClipTask {
            write: false,
            asset_path: clip_asset.clone(),
            state_name: clip.name.clone(),
            sample_rate,
            looped: clip.looped,
            frames,
        });
        node.asset_targets.push(CliAssetTarget {
            rel_path: rel_anim,
            main_prefab: false,
            kind: CliTargetKind::Clip(clip_idx),
        });
        states.push(ControllerStateSpec {
            name: clip.name.clone(),
            clip_asset_path: clip_asset.clone(),
        });
        let (fw, fh) = texture_frame_size(&clip.frames[0].texture, dims);
        binding_clips.push(build_clip_binding(
            clip,
            keys,
            clip_asset,
            durations,
            (fw, fh),
            &mut table,
        ));
    }

    let ctrl_rel = join_rel(dir_rel_prefix, &format!("{stem}.controller"));
    let ctrl_asset = paths::asset_path(target.root, &paths::join(target.directory, &ctrl_rel));
    let ctrl_idx = node.task.controllers.len();
    node.task.controllers.push(ControllerTask {
        write: false,
        asset_path: ctrl_asset.clone(),
        states,
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: ctrl_rel,
        main_prefab: false,
        kind: CliTargetKind::Controller(ctrl_idx),
    });

    let first_info = resolved.slice_info(&clip_keys[0][0].0);
    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &prefab_rel));
    let p_idx = node.task.anim_prefabs.len();
    node.task.anim_prefabs.push(AnimPrefabTask {
        write: false,
        asset_path: prefab_asset,
        display_name: display_name.to_owned(),
        tex_asset_path: first_info.asset_path.clone(),
        multiple: is_multiple(&node.task.textures, &first_info.asset_path),
        sprite_name: first_info.sprite_name.clone(),
        ctrl_asset_path: ctrl_asset,
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: prefab_rel,
        main_prefab: true,
        kind: CliTargetKind::AnimPrefab(p_idx),
    });
    let _ = &mut notes;
    node.notes = notes;
    node.binding = NodeBindingData {
        sprites: table.sprites,
        clips: binding_clips,
        ..NodeBindingData::default()
    };
    node
}

pub fn plan_ui(
    kit: &Kit,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    has_ugui: bool,
    dims: &BTreeMap<String, (u32, u32)>,
    masks: &BTreeMap<String, AlphaMask>,
) -> PlannedUnityNode {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let registered = register_widgets(&mut registry, kit);
    let (resolved, tex_specs, mut notes) = registry.build_cli(target.node_dir, target.root, target.directory);
    if kit.widgets.is_empty() {
        let mut node = init_planned(target, id, version, Vec::new());
        node.elements = kit
            .elements
            .iter()
            .map(|name| Element {
                name: name.clone(),
                prefab: None,
            })
            .collect();
        node.notes = notes;
        return node;
    }
    let mut node = init_planned(target, id, version, tex_specs);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let mut table = SpriteTable::new(&resolved, masks);
    let mut used_names = BTreeSet::new();
    let mut widget_prefabs = BTreeMap::new();
    let mut binding_elements = Vec::with_capacity(registered.len());
    let mut is_first = true;

    for reg in &registered {
        let widget = &kit.widgets[reg.widget_index];
        let stem = unique_name(&mut used_names, &paths::filename(&widget.name));
        let rel_prefab = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
        let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &rel_prefab));

        if has_ugui {
            widget_prefabs.insert(widget.element, prefab_asset.clone());
            binding_elements.push(build_element_binding(
                widget,
                prefab_asset.clone(),
                &reg.states,
                &mut table,
            ));
            let ui_idx = node.task.ui_prefabs.len();
            node.task.ui_prefabs.push(build_ui_prefab_task(
                prefab_asset,
                widget,
                &reg.states,
                &resolved,
                &node.task.textures,
            ));
            node.asset_targets.push(CliAssetTarget {
                rel_path: rel_prefab,
                main_prefab: is_first,
                kind: CliTargetKind::UiPrefab(ui_idx),
            });
            is_first = false;
        } else {
            binding_elements.push(build_element_binding(widget, String::new(), &reg.states, &mut table));
        }
    }
    if !has_ugui {
        notes.push(
            "Package com.unity.ugui is not in Packages/manifest.json; UI prefabs were skipped \
             (sprite slices and wf-bindings.json were still generated)."
                .to_owned(),
        );
    }

    node.elements = kit
        .elements
        .iter()
        .enumerate()
        .map(|(idx, name)| Element {
            name: name.clone(),
            prefab: widget_prefabs.get(&idx).cloned(),
        })
        .collect();
    node.notes = notes;
    node.binding = NodeBindingData {
        sprites: table.sprites,
        elements: binding_elements,
        ..NodeBindingData::default()
    };
    node
}

fn build_ui_prefab_task(
    asset_path: String,
    widget: &Widget,
    states: &[RawStyle],
    resolved: &ResolvedSprites,
    textures: &[super::specs::TextureTask],
) -> UiPrefabTask {
    let sp_of = |st: Style| -> SpriteRefSpec {
        states
            .iter()
            .find(|s| s.style == st)
            .map_or_else(SpriteRefSpec::default, |s| {
                let info = resolved.slice_info(&s.key);
                SpriteRefSpec {
                    tex_asset_path: info.asset_path.clone(),
                    multiple: is_multiple(textures, &info.asset_path),
                    sprite_name: info.sprite_name.clone(),
                    sliced: s.sliced,
                }
            })
    };
    let rest_st = states.iter().find(|s| s.style == Style::Rest).unwrap_or(&states[0]);
    let rest_info = resolved.slice_info(&rest_st.key);
    let rest = SpriteRefSpec {
        tex_asset_path: rest_info.asset_path.clone(),
        multiple: is_multiple(textures, &rest_info.asset_path),
        sprite_name: rest_info.sprite_name.clone(),
        sliced: rest_st.sliced,
    };
    let on_style = match widget.kind {
        WidgetKind::Bar | WidgetKind::Slide => Style::Fill,
        _ => Style::Pressed,
    };
    let on_sp = states
        .iter()
        .find(|s| s.style == on_style || s.style == Style::HoverPressed)
        .map_or_else(SpriteRefSpec::default, |s| {
            let info = resolved.slice_info(&s.key);
            SpriteRefSpec {
                tex_asset_path: info.asset_path.clone(),
                multiple: is_multiple(textures, &info.asset_path),
                sprite_name: info.sprite_name.clone(),
                sliced: s.sliced,
            }
        });
    let content = rest_st
        .content
        .map_or_else(Vec::new, |m| vec![m.left, m.right, m.top, m.bottom]);
    UiPrefabTask {
        write: false,
        asset_path,
        name: widget.name.clone(),
        kind: format!("{:?}", widget.kind).to_ascii_lowercase(),
        width: widget.size.0,
        height: widget.size.1,
        rest,
        hover: sp_of(Style::Hover),
        pressed: sp_of(Style::Pressed),
        disabled: sp_of(Style::Disabled),
        on_sprite: on_sp,
        thumb_rest: sp_of(Style::Thumb),
        thumb_hover: sp_of(Style::ThumbHover),
        thumb_disabled: sp_of(Style::ThumbDisabled),
        has_content: !content.is_empty(),
        content,
    }
}

pub fn plan_prop(
    props: &PropSet,
    target: ExportTarget<'_>,
    id: &str,
    version: u64,
    dims: &BTreeMap<String, (u32, u32)>,
    masks: &BTreeMap<String, AlphaMask>,
) -> PlannedUnityNode {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let (state_keys, anim_keys) = register_prop_sprites(&mut registry, props);
    let (resolved, tex_specs, notes) = registry.build_cli(target.node_dir, target.root, target.directory);
    let mut node = init_planned(target, id, version, tex_specs);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let mut table = SpriteTable::new(&resolved, masks);
    let mut used_prefab_names = BTreeSet::new();
    let mut used_anim_names = BTreeSet::new();
    let mut elements = Vec::with_capacity(props.objects.len());
    let mut binding_props = Vec::with_capacity(props.objects.len());

    for (obj_idx, obj) in props.objects.iter().enumerate() {
        let obj_stem = unique_name(&mut used_prefab_names, &paths::filename(&obj.name));
        let (ctrl_asset, clip_assets) = build_prop_animations(
            obj,
            &obj_stem,
            target,
            dir_rel_prefix,
            &anim_keys[obj_idx],
            &resolved,
            &mut used_anim_names,
            &mut node,
        );
        let prefab_asset = push_prop_prefab(
            obj,
            obj_idx,
            &obj_stem,
            dir_rel_prefix,
            target,
            ctrl_asset,
            &state_keys[obj_idx],
            &resolved,
            &mut elements,
            &mut node,
        );
        binding_props.push(build_prop_binding(
            obj,
            prefab_asset,
            &state_keys[obj_idx],
            &anim_keys[obj_idx],
            clip_assets,
            &mut table,
        ));
    }

    node.elements = elements;
    node.notes = notes;
    node.binding = NodeBindingData {
        sprites: table.sprites,
        props: binding_props,
        ..NodeBindingData::default()
    };
    node
}

#[allow(clippy::too_many_arguments)]
fn build_prop_animations(
    obj: &PropObject,
    obj_stem: &str,
    target: ExportTarget<'_>,
    dir_rel_prefix: &str,
    anim_keys: &[Vec<SpriteKey>],
    resolved: &ResolvedSprites,
    used_anim_names: &mut BTreeSet<String>,
    node: &mut PlannedUnityNode,
) -> (String, Vec<String>) {
    let mut ctrl_states = Vec::new();
    let mut clip_assets = Vec::new();
    for (tr, keys) in obj.animations.iter().zip(anim_keys) {
        let clip_stem = unique_name(used_anim_names, &paths::filename(&format!("{obj_stem}_{}", tr.id)));
        let rel_anim = join_rel(dir_rel_prefix, &format!("clips/{clip_stem}.anim"));
        let clip_asset = paths::asset_path(target.root, &paths::join(target.directory, &rel_anim));
        clip_assets.push(clip_asset.clone());
        let min_ms = tr
            .durations_ms
            .iter()
            .copied()
            .filter(|d| *d > 0.0)
            .fold(f64::INFINITY, f64::min);
        let sample_rate = if min_ms.is_finite() {
            (1000.0 / min_ms).clamp(1.0, 120.0)
        } else {
            12.0
        };
        let frames = keys
            .iter()
            .enumerate()
            .map(|(i, k)| {
                let info = resolved.slice_info(k);
                let duration_ms = tr
                    .durations_ms
                    .get(i)
                    .copied()
                    .filter(|d| *d > 0.0)
                    .unwrap_or(1000.0 / 12.0);
                ClipFrameSpec {
                    tex_asset_path: info.asset_path.clone(),
                    multiple: is_multiple(&node.task.textures, &info.asset_path),
                    sprite_name: info.sprite_name.clone(),
                    duration_ms,
                }
            })
            .collect();
        let c_idx = node.task.clips.len();
        node.task.clips.push(ClipTask {
            write: false,
            asset_path: clip_asset.clone(),
            state_name: tr.id.clone(),
            sample_rate,
            looped: tr.looped,
            frames,
        });
        node.asset_targets.push(CliAssetTarget {
            rel_path: rel_anim,
            main_prefab: false,
            kind: CliTargetKind::Clip(c_idx),
        });
        ctrl_states.push(ControllerStateSpec {
            name: tr.id.clone(),
            clip_asset_path: clip_asset,
        });
    }
    let ctrl_asset = if ctrl_states.is_empty() {
        String::new()
    } else {
        let ctrl_rel = join_rel(dir_rel_prefix, &format!("{obj_stem}.controller"));
        let ca = paths::asset_path(target.root, &paths::join(target.directory, &ctrl_rel));
        let c_idx = node.task.controllers.len();
        node.task.controllers.push(ControllerTask {
            write: false,
            asset_path: ca.clone(),
            states: ctrl_states,
        });
        node.asset_targets.push(CliAssetTarget {
            rel_path: ctrl_rel,
            main_prefab: false,
            kind: CliTargetKind::Controller(c_idx),
        });
        ca
    };
    (ctrl_asset, clip_assets)
}

#[allow(clippy::too_many_arguments)]
fn push_prop_prefab(
    obj: &PropObject,
    obj_idx: usize,
    obj_stem: &str,
    dir_rel_prefix: &str,
    target: ExportTarget<'_>,
    ctrl_asset_path: String,
    state_keys: &[SpriteKey],
    resolved: &ResolvedSprites,
    elements: &mut Vec<Element>,
    node: &mut PlannedUnityNode,
) -> String {
    let ppu = f64::from(obj.pixels_per_tile);
    let prefab_rel = join_rel(dir_rel_prefix, &format!("{obj_stem}.prefab"));
    let prefab_asset = paths::asset_path(target.root, &paths::join(target.directory, &prefab_rel));
    elements.push(Element {
        name: obj.name.clone(),
        prefab: Some(prefab_asset.clone()),
    });
    let first_info = resolved.slice_info(&state_keys[0]);
    let root_polys = if obj.states.len() == 1 && !obj.states[0].collision.is_empty() {
        obj.states[0].collision.iter().map(|p| points_to_poly(p, ppu)).collect()
    } else {
        Vec::new()
    };
    let state_colliders = if obj.states.len() > 1 {
        obj.states
            .iter()
            .enumerate()
            .filter(|(_, st)| !st.collision.is_empty())
            .map(|(i, st)| PropStateColliderSpec {
                name: format!("State_{}_Collider", st.id),
                active: i == 0,
                polys: st.collision.iter().map(|p| points_to_poly(p, ppu)).collect(),
            })
            .collect()
    } else {
        Vec::new()
    };
    let p_idx = node.task.prop_prefabs.len();
    node.task.prop_prefabs.push(PropPrefabTask {
        write: false,
        asset_path: prefab_asset.clone(),
        name: obj.name.clone(),
        tex_asset_path: first_info.asset_path.clone(),
        multiple: is_multiple(&node.task.textures, &first_info.asset_path),
        sprite_name: first_info.sprite_name.clone(),
        ctrl_asset_path,
        root_polys,
        state_colliders,
    });
    node.asset_targets.push(CliAssetTarget {
        rel_path: prefab_rel,
        main_prefab: obj_idx == 0,
        kind: CliTargetKind::PropPrefab(p_idx),
    });
    prefab_asset
}

pub(crate) fn is_multiple(textures: &[super::specs::TextureTask], asset_path: &str) -> bool {
    textures
        .iter()
        .find(|t| t.asset_path == asset_path)
        .is_some_and(|t| t.multiple)
}

pub(crate) fn points_to_poly(pts: &[Point], scale: f64) -> PolyPathSpec {
    PolyPathSpec {
        points: pts
            .iter()
            .map(|p| Vec2Spec {
                x: p.x / scale,
                y: -p.y / scale,
            })
            .collect(),
    }
}
