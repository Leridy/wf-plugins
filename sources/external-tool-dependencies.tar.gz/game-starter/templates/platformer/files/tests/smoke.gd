# Run from a rendered project after --headless --import.
extends SceneTree

var failures := 0

func _initialize() -> void:
	_run.call_deferred()

func _check(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		printerr("FAIL: " + message)

func _frames(count: int) -> void:
	for frame in range(count):
		await physics_frame
		await process_frame

func _move_to(game: Node, target_x: float, jump: bool = false) -> void:
	Input.action_press("ui_right")
	if jump:
		Input.action_press("ui_accept")
	for frame in range(100):
		await _frames(1)
		if game.player.position.x >= target_x:
			break
	Input.action_release("ui_right")
	Input.action_release("ui_accept")
	_check(game.player.position.x >= target_x, "input traversal reaches x=%d" % int(target_x))

func _run() -> void:
	var watchdog := create_timer(20.0)
	watchdog.timeout.connect(func() -> void:
		printerr("FAIL: smoke test timed out")
		quit(1)
	)
	var scene: PackedScene = load("res://scenes/main.tscn")
	if scene == null:
		printerr("FAIL: main scene could not load")
		quit(1)
		return
	var game = scene.instantiate()
	root.add_child(game)
	await _frames(20)
	var dimensions := FileAccess.get_file_as_string("res://settings/resolution.txt").strip_edges().split("x")
	var expected := Vector2i(int(dimensions[0]), int(dimensions[1]))
	_check(root.content_scale_size == expected, "selected viewport resolution")
	_check(root.title == FileAccess.get_file_as_string("res://settings/project_name.txt").trim_suffix("\n"), "project title")
	_check(game.player.is_on_floor(), "player starts on solid ground")
	_check(game.hud.get_node("Deaths").text == "Deaths: 0", "initial HUD")
	for mapping in [["ui_left", KEY_A], ["ui_right", KEY_D], ["ui_accept", KEY_W], ["ui_accept", KEY_UP], ["ui_accept", KEY_SPACE]]:
		var event := InputEventKey.new()
		event.physical_keycode = mapping[1]
		_check(InputMap.action_has_event(mapping[0], event), "keyboard binding %s" % mapping[1])
	var start_x: float = game.player.position.x
	Input.action_press("ui_right")
	await _frames(12)
	Input.action_release("ui_right")
	_check(game.player.position.x > start_x + 10.0, "right input moves the player")
	_check(game.player.get_node("Art").state == "run", "run visual state")
	var start_y: float = game.player.position.y
	Input.action_press("ui_accept")
	await _frames(4)
	Input.action_release("ui_accept")
	_check(game.player.position.y < start_y - 5.0, "jump input raises the player")
	_check(game.player.velocity.y < 0.0, "jump has upward velocity")
	_check(game.player.get_node("Art").state == "jump", "jump visual state")
	await _frames(50)
	_check(game.player.is_on_floor(), "player lands after jumping")
	var old_player: int = game.player.get_instance_id()
	var old_world: int = game.world.get_instance_id()
	# Place the player in the gap: gravity must trigger the actual fall death path.
	game.player.position = Vector2(124, 184)
	game.player.velocity = Vector2.ZERO
	await _frames(40)
	_check(game.deaths == 1, "fall counts exactly one death")
	_check(game.player.get_instance_id() != old_player, "fall recreates the player")
	_check(game.world.get_instance_id() != old_world, "fall restarts the whole level")
	_check(game.player.position.distance_to(Vector2(26, 145)) < 2.0, "fall restores spawn")
	_check(game.player.is_on_floor(), "restarted player lands on spawn platform")
	_check(game.hud.get_node("Deaths").text == "Deaths: 1", "HUD survives restart")
	# Enter a real Area2D rather than calling the death handler directly.
	old_player = game.player.get_instance_id()
	game.player.position = Vector2(208, 140)
	await _frames(30)
	_check(game.deaths == 2, "hazard counts exactly one death")
	_check(game.player.get_instance_id() != old_player, "hazard recreates the player")
	_check(game.hud.get_node("Deaths").text == "Deaths: 2", "hazard HUD count")
	start_x = game.player.position.x
	Input.action_press("ui_right")
	await _frames(8)
	Input.action_release("ui_right")
	_check(game.player.position.x > start_x + 5.0, "input works after restart")
	game.player.position = Vector2(294, 140)
	await _frames(10)
	_check(game.hud.get_node("Finished").visible, "reaching the flag shows completion")
	var restart := InputEventAction.new()
	restart.action = "restart"
	restart.pressed = true
	Input.parse_input_event(restart)
	await _frames(20)
	restart = InputEventAction.new()
	restart.action = "restart"
	restart.pressed = false
	Input.parse_input_event(restart)
	_check(not game.hud.get_node("Finished").visible, "manual replay clears completion")
	_check(game.deaths == 2, "manual replay preserves deaths")
	_check(game.player.position.distance_to(Vector2(26, 145)) < 2.0, "manual replay restores spawn")
	# Finish a full run using only input: no teleport, handler call, or physics bypass.
	await _move_to(game, 102.0)
	await _move_to(game, 162.0, true)
	await _frames(8)
	_check(game.player.is_on_floor(), "land across the gap")
	await _move_to(game, 184.0)
	await _move_to(game, 240.0, true)
	await _frames(8)
	_check(game.player.is_on_floor(), "land beyond the spikes")
	await _move_to(game, 294.0)
	await _frames(4)
	_check(game.deaths == 2, "input-only completion adds no deaths")
	_check(game.hud.get_node("Finished").visible, "input-only run reaches the flag")
	if failures == 0:
		print("PASS: %dx%d title, keys, move, jump, land, fall, hazard, restart, HUD, goal, replay, input-only completion" % [expected.x, expected.y])
	game.queue_free()
	await process_frame
	quit(0 if failures == 0 else 1)
