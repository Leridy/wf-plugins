# Visual slot only: the controller owns physics and calls set_state each frame.
extends Node2D

var state := "idle"
var facing := 1.0
var phase := 0.0

func set_state(next_state: String, horizontal_speed: float) -> void:
	state = next_state
	if horizontal_speed != 0.0:
		facing = signf(horizontal_speed)

func _process(delta: float) -> void:
	phase += delta * 18.0
	queue_redraw()

func _draw() -> void:
	var tint := Color("64e4ce")
	if state == "jump":
		tint = Color("a8f0ff")
	draw_rect(Rect2(-5, -7, 10, 12), tint)
	draw_rect(Rect2(facing * 2 - 1, -4, 2, 3), Color("142238"))
	var stride := 0.0
	if state == "run":
		stride = sin(phase) * 2.0
	draw_rect(Rect2(-4, 4 + stride, 3, 3), tint)
	draw_rect(Rect2(1, 4 - stride, 3, 3), tint)
