# Replace this scene with tiles; preserve the Hazard and Goal Area2D nodes.
extends Node2D

const PLATFORMS: Array[Rect2] = [
	Rect2(0, 152, 112, 28), Rect2(144, 152, 176, 28),
]
const HAZARD := Rect2(200, 144, 16, 8)
const GOAL := Rect2(288, 124, 16, 28)

func _ready() -> void:
	for rect in PLATFORMS:
		var platform := StaticBody2D.new()
		platform.position = rect.get_center()
		platform.add_child(_collision(rect.size))
		add_child(platform)
	_area("Hazard", HAZARD)
	_area("Goal", GOAL)

func _collision(size: Vector2) -> CollisionShape2D:
	var shape := RectangleShape2D.new()
	shape.size = size
	var collision := CollisionShape2D.new()
	collision.shape = shape
	return collision

func _area(area_name: String, rect: Rect2) -> void:
	var area := Area2D.new()
	area.name = area_name
	area.position = rect.get_center()
	area.collision_layer = 0
	area.collision_mask = 1
	area.add_child(_collision(rect.size))
	add_child(area)

func _draw() -> void:
	for x in range(8, 320, 24):
		draw_circle(Vector2(x, 65 + (x % 37)), 1, Color("34415c"))
	for rect in PLATFORMS:
		draw_rect(rect, Color("34415c"))
		draw_rect(Rect2(rect.position, Vector2(rect.size.x, 3)), Color("78a6b0"))
		for x in range(int(rect.position.x) + 8, int(rect.end.x), 16):
			draw_line(Vector2(x, rect.position.y + 5), Vector2(x, rect.end.y), Color("29364c"))
	for x in [200, 208]:
		draw_colored_polygon(PackedVector2Array([
			Vector2(x, 152), Vector2(x + 4, 143), Vector2(x + 8, 152),
		]), Color("ff7285"))
	draw_line(Vector2(294, 124), Vector2(294, 152), Color("d9e4ee"), 2)
	draw_colored_polygon(PackedVector2Array([
		Vector2(295, 124), Vector2(308, 129), Vector2(295, 134),
	]), Color("ffe099"))
