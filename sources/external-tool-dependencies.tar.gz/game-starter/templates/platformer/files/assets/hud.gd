extends Control

func set_deaths(count: int) -> void:
	$Deaths.text = "Deaths: %d" % count

func set_finished(finished: bool) -> void:
	$Finished.visible = finished
