extends CharacterBody2D

signal died

const SPEED := 84.0
const JUMP_SPEED := -205.0
const GRAVITY := 640.0
const FALL_LIMIT := 208.0
var dead := false

func _physics_process(delta: float) -> void:
	if dead:
		return
	velocity.x = Input.get_axis("ui_left", "ui_right") * SPEED
	velocity.y += GRAVITY * delta
	if is_on_floor() and Input.is_action_just_pressed("ui_accept"):
		velocity.y = JUMP_SPEED
	move_and_slide()
	position.x = clampf(position.x, 6.0, 314.0)
	var state := "idle"
	if not is_on_floor():
		state = "jump"
	elif absf(velocity.x) > 0.0:
		state = "run"
	$Art.set_state(state, velocity.x)
	if position.y > FALL_LIMIT:
		die()

func die() -> void:
	if dead:
		return
	dead = true
	velocity = Vector2.ZERO
	died.emit()
