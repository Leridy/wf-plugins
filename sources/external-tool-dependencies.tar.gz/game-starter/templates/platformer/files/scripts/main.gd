extends Node2D

const LEVEL := preload("res://assets/level.tscn")
const PLAYER := preload("res://scenes/player.tscn")
const HUD := preload("res://assets/hud.tscn")
const SPAWN := Vector2(26, 140)

var deaths := 0
var restarting := false
var world: Node2D
var player: CharacterBody2D
var hud: Control
var resolution: Vector2i

func _ready() -> void:
	var size_text := FileAccess.get_file_as_string("res://settings/resolution.txt").strip_edges()
	var dimensions := size_text.split("x")
	resolution = Vector2i(int(dimensions[0]), int(dimensions[1]))
	get_window().content_scale_size = resolution
	var title := FileAccess.get_file_as_string("res://settings/project_name.txt").trim_suffix("\n")
	get_window().title = title
	ProjectSettings.set_setting("application/config/name", title)
	_bind_keys("ui_left", [KEY_A])
	_bind_keys("ui_right", [KEY_D])
	_bind_keys("ui_accept", [KEY_W, KEY_UP, KEY_SPACE])
	_bind_keys("restart", [KEY_R])
	var camera := Camera2D.new()
	camera.position = Vector2(160, 90)
	camera.zoom = Vector2.ONE * (float(resolution.x) / 320.0)
	add_child(camera)
	var overlay := CanvasLayer.new()
	add_child(overlay)
	hud = HUD.instantiate()
	hud.scale = camera.zoom
	overlay.add_child(hud)
	_start_level()

func _bind_keys(action: StringName, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for key: int in keys:
		var event := InputEventKey.new()
		event.physical_keycode = key
		if not InputMap.action_has_event(action, event):
			InputMap.action_add_event(action, event)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("restart") and not restarting:
		restarting = true
		_start_level.call_deferred()

func _start_level() -> void:
	if is_instance_valid(world):
		remove_child(world)
		world.queue_free()
	world = Node2D.new()
	world.name = "World"
	add_child(world)
	var level := LEVEL.instantiate()
	world.add_child(level)
	player = PLAYER.instantiate()
	player.position = SPAWN
	player.died.connect(_on_death)
	world.add_child(player)
	level.get_node("Hazard").body_entered.connect(_on_hazard)
	level.get_node("Goal").body_entered.connect(_on_goal)
	hud.set_deaths(deaths)
	hud.set_finished(false)
	restarting = false

func _on_death() -> void:
	if restarting:
		return
	restarting = true
	deaths += 1
	_start_level.call_deferred()

func _on_hazard(body: Node2D) -> void:
	if body == player:
		player.die()

func _on_goal(body: Node2D) -> void:
	if body == player:
		hud.set_finished(true)
