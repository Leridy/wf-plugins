The executable smoke test is `../templates/platformer/files/tests/smoke.gd`.
It ships inside the generated project so Godot can resolve `res://` scenes and
scripts. After rendering the template and importing it, run:

```sh
godot --headless --path /absolute/path/to/rendered-project --script res://tests/smoke.gd
```

It checks the chosen resolution/title, key bindings, movement, jump and landing,
visual states, falling death, real hazard overlap, whole-level/player replacement,
spawn position, continued input, death HUD, goal, and manual replay. It also completes a full run to the flag using input only. A failed
assertion or timeout exits with status 1. Run it for both resolution choices.
