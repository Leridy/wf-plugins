# Game starter

A data-only official plugin contributing `wf.template/1` at
`templates/platformer`. The runtime will expose it as
`game-starter.platformer`; this plugin has no WebAssembly component or Cargo
package. Runtime template execution is implemented in a separate lane.

The Godot 4.7 template is a complete small platformer with procedural placeholder
art: move, jump across the gap, avoid pink spikes, and reach the flag. Falling or
touching spikes restarts the whole level and increments the deaths HUD. Reach
the flag for a completion message; press R to replay (deaths are retained for
this game session). Nothing is downloaded.

| Parameter | Kind | Default | Effect |
| --- | --- | --- | --- |
| `project_name` | text, maximum 64 characters | `Platformer` | Game window title and application name at startup |
| `resolution` | choice: `320x180`, `640x360` | `320x180` | Internal viewport size; camera/HUD scale to keep identical framing |

The initial window is 960 × 540. The editor project has a fixed fallback name
and size; startup reads `settings/project_name.txt` and `settings/resolution.txt`.
These plain text files are the only template substitution sites. Names containing
quotes or backslashes never enter GDScript or Godot resource syntax.

Controls: Left/Right or A/D to move; Space, W, Up, or the default `ui_accept`
(Enter/controller accept) to jump; R to restart. Godot's default `ui_left` and
`ui_right` bindings remain available, including controller input.

## Required Godot editor

Requires stable Godot **>=4.7.0, <5.0.0**, matching this template's declared
`godot@4.7` engine. Godot 3, earlier Godot 4 releases and preview builds are
rejected. This release needs the development client with external-tool version
checks and registry discovery; older clients reject its manifest.

After installation, select an editor in the environment setup card and choose
**Confirm and configure**. The client runs only `--headless --version` for this
check. Discovery uses common installation paths, PATH and optional Windows
App Paths registry entries. Portable installations can be added manually.
A valid default and version receipt are required for all template operations,
including previews. Setup does not authorize the later project import.

Creating the template still plans the existing `--headless --import` post step.
It runs through the app runtime after approval, using the configured editor.
A dry run starts no process. The import can execute project code and remains a
high-risk operation. The `headless` feature indicates version eligibility only.

## Replaceable asset slots

| Slot | Single entry path in generated project | Contract |
| --- | --- | --- |
| player (`frame_animation`: idle/run/jump) | `res://assets/player.tscn` | Node2D root with `set_state(state: String, horizontal_speed: float)`; art centered on a 10 × 14 player. Physics stays in `scenes/player.tscn`. An AnimatedSprite2D wrapper can implement the same method. |
| level (`tilemap`) | `res://assets/level.tscn` | Node2D root, solid collision on layer 1, direct `Hazard` and `Goal` Area2D children monitoring layer 1. May contain TileMapLayer nodes; keep spawn `(26, 140)` clear and a floor beneath it. Logical level bounds are 320 × 180. |
| hud (`ui`) | `res://assets/hud.tscn` | Control root in 320 × 180 coordinates with `set_deaths(count: int)` and `set_finished(finished: bool)`; main owns scaling and the CanvasLayer. |

Each entry scene has an adjacent script holding its placeholder implementation.
The runtime reports these slots as resource hints; this template does not create
workspace nodes or automatically replace art.

## Import, play, and test

Render by copying `templates/platformer/files/` to a scratch project and replacing
only declared `{{param_key}}` tokens in UTF-8 text with parameter values (copy
binary files unchanged). Do not run the unsubstituted source directory directly.
The declared post step runs in the rendered project directory:

```sh
godot --headless --import
```

With the installed macOS executable, equivalent commands from any directory are:

```sh
/opt/homebrew/bin/godot --headless --path /private/tmp/my-platformer --import
/opt/homebrew/bin/godot --path /private/tmp/my-platformer
/opt/homebrew/bin/godot --headless --path /private/tmp/my-platformer --script res://tests/smoke.gd
```

The smoke script lives inside `files/tests/` so Godot can load it through `res://`.
It simulates movement/jump, triggers falling and hazard deaths through physics,
and checks level restart, persistent HUD, goal, replay, resolution, and title.
An additional input-only run crosses the gap and spikes to reach the flag.
Failures exit nonzero; a 20-second watchdog catches stalled tests. Run import
and smoke separately for both resolution values. Verified with Godot
`4.7.1.stable.official.a13da4feb`; see the lane result note for exact run output.
