# godot-export

The official `wf` plugin that turns ready exports into Godot 4 resources.
`wf godot-export sync` reads the local mirror and exported sidecars, then plans
Godot headless import and resource generation. The runtime previews the effects,
asks for approval and executes the confirmed Godot editor.

## External Godot dependency (0.5.0)

Requires stable **Godot >=4.3.0, <5.0.0** and plugin API 0.1.4. The manifest
provides macOS/Windows/PATH discovery, optional Windows App Paths registry hints,
and a fixed `--headless --version` query. In the current development client,
confirm a Godot path, check its version for this plugin, and select a default.
Until then all operations are unavailable, even previews. Existing path-only
configurations need a version check after this update.

New operations:

- `wf godot-export headless-import`: import the project's resources without a window.
- `wf godot-export headless-run --frames 60`: run its main scene for a bounded
  number of engine iterations; optionally choose `--scene scenes/main.tscn`.

Both accept `--directory` for a nested Godot project and `--dry-run` for preview.
All three capabilities declare high risk because they may execute Godot/project
code. Full setup, examples, limitations and a client acceptance checklist are in
[docs/headless.md](docs/headless.md), also bundled as `godot-export/headless`.

## Use

Put the configured export directory inside a Godot project, then run:

```sh
wf export '#75' '#81'
wf godot-export sync --nodes '#75' --nodes '#81' --dry-run
wf godot-export sync --nodes '#75' --nodes '#81'
```

Omit `--nodes` to sync every node in the export lock. Repeat `--nodes` for
addresses (`#N`, a node path or `wf://id`); the frozen plugin CLI exposes
schema fields as flags. `--directory assets/alternate` selects another export
lock. The nearest `project.godot` above that directory defines `res://`.

Generated files sit next to the node's sidecar. Instance the `.tscn` to play
its first animation immediately; assign a generated Theme to a Control and
choose the element's theme type variation. Instance a particle `.tscn` where
the effect should play; it starts on `_ready`. Flip variations use Button;
set the consuming Button's `toggle_mode` in your own scene.

## Client actions and result view

In a Workspace mirror, the node menu offers **Export as Godot resources** for
frame animations, character effects, UI kits and tile maps. **Re-export,
overwriting edits…** binds `force = true`; overwrites and deletions use the
host's existing HighRisk confirmation. Both actions sync the selected nodes.

The result table lists each node, its status, resource file count and
project-relative main scene path. Click a path to copy it; exports without
a scene leave that cell blank. Counts include unchanged and preserved files, not just writes.
Each node's `main_scene` output is that project-relative path (or `null`);
the form's writer designates it independently of file order.
Unexported selections appear as warning rows with **Run wf export**; their
structured reasons include the node's export command. They do not prevent
other selected exports from converting, and their old resources are preserved.
Genuinely missing nodes and invalid export inputs still fail the call.

## Mapping

| Export | Resources |
| --- | --- |
| `frame_animation`, `character_effect`: frames, strips, atlas | `<name>.sprite_frames.tres` and `<name>.tscn` (AnimatedSprite2D) |
| `ui`: pieces, atlas | `<name>.theme.tres` (Theme) |
| `tilemap`: source (with the `tilemap.json` that `wf export` writes) | `<name>.tileset.tres` (TileSet) and `<name>.tscn` (the map) |
| `particle_effect`: source (`main.json` and its pictures) | `<name>.tscn` (Node2D that plays the effect; 2D only) |
| Directly importable files and unsupported families | `skipped`, with a reason |

Each clip retains its order, loop flag and frame durations. Its name is
`actionId_direction`, or just `actionId` for `source`. Fractional milliseconds
are preserved: speed is `1000 / shortest_frame_ms`, and each frame's duration
is its milliseconds divided by that same base. Strips and atlases use
AtlasTexture regions; each PNG/page is declared once per resource. The scene
uses `centered = false`, the negative first anchor as its offset, and autoplay.
Different clip anchors are reported because the scene has one fixed offset.
Collision boxes and events are not exported.

| UI widget | Base | Mapping |
| --- | --- | --- |
| press | Button | rest → normal, hover, pressed, disabled; empty focus |
| flip | Button | off → normal, off_hover → hover, on → pressed, on_hover → hover_pressed, off_disabled → disabled |
| bar | ProgressBar | track → background, largest-amount widget fill → fill (ties: last in order), using its own slice borders |
| slide | HSlider | track → slider, fill → grabber_area; thumb/hover/disabled → grabber icons |
| switch, ring, stick, parts, states | none | Reported as skipped elements; use their textures directly |

Variation names follow the approved fallback order:

1. ASCII letters/digits from the original element name, in PascalCase, if the
   result starts with a letter.
2. The element kind in PascalCase, if the kind is ASCII and yields a valid name.
3. The base type plus the element's 1-based position in the sidecar, such as
   `Button4`.

Collisions receive a suffix starting at 2. Godot's built-in class names are
reserved too: kind `button` becomes `Button2`, followed by `Button3`. The
Godot 4.7.1 ClassDB snapshot in `src/godot/builtin_types.txt` is generated by
`tests/godot/builtin_types.gd`; it is data, not a dependency on a Godot install.
No Unicode code-point escapes or transliteration are used.

Each node's `elements` output lists every original `name` with its planned
`variation`, in sidecar order. Skipped elements have `variation: null`.
For example, `主操作按钮` → `Button2` and `待选订单行` → `ListItem`. A `kept`
file still reports the planned mapping; the user's edited resource is preserved.

Slice borders become texture margins (zero for fixed states); `text_safe`
in the actual sidecar becomes content margins measured from the image edges.
Without `text_safe`, Godot uses its default content-margin behavior. Additional
state roles such as lasting, cover and thumb_pressed have no mapping in this
version. A kit with no mapped elements is skipped and produces no empty Theme.

### Tile maps

`wf export` resolves a tile map with the editor's own kernel (`tile-map-model`)
into `tilemap.json`: terrain tiles on dual-grid display cells, blocks, walls and
objects in the editor's drawing order, collision polygons and the spawn, in map
pixels. Nothing is solved again here, so the game shows the tiles the editor shows.

- The TileSet has one atlas source per terrain atlas, a tile for every aligned
  `tileWidth × tileHeight` region a terrain uses, and isometric maps use
  `TILE_SHAPE_ISOMETRIC` with `TILE_LAYOUT_DIAMOND_DOWN`. Its
  `metadata/wf_terrains` lists each terrain's tiles by corner mask
  (NW/NE/SE/SW = 1/2/4/8) as `Vector3i(source, atlas x, atlas y)`, for painting
  terrain at runtime.
- The scene's `Ground<N>` TileMapLayers hold the terrain, one per overlay level,
  shifted half a cell onto the display points. `Scene` (y-sorted) holds each
  block, wall and object as a Sprite2D standing on its foot; add characters to
  it so buildings and trees cover them correctly. `Collision` is a
  StaticBody2D with one CollisionPolygon2D per obstacle (`metadata/wf_kind`:
  terrain, tile, wall or object) and segment outlines of the walkable ground.
  `Spawn` is a Marker2D. Sprites keep the map's id in `metadata/wf_id`.
- Terrain tiles that are not whole aligned atlas tiles are left out and
  reported; the generator's atlases are always aligned.

### Particle effects

The scene's root is a Node2D with a built-in script that replays the
weaveForge simulation (`packages/editors/src/particle/simulation.ts`) exactly:
fixed 1/60 s steps, each emitter's own random stream drawing the same numbers
in the same order, per-cycle burst plus per-second rate over
`[delay, duration)`, radial bursts, gravity then exponential drag, ground
contact on y = 0 (bounce, friction, rest, or dying on landing), triggered
emitters born where particles die or first land, lifetime ranges and the
`velocity` / `upright` / `random` orientation, tilt, flip and size jitter.
`tests/godot/verify_particles.gd` checks every particle against the editor to
1e-9. Drawing follows the editor's renderer: quads `size` units wide, size,
opacity and colour keys spaced evenly over each particle's life (colours in
linear space), speed-stretched quads that trail their particle and turn to its
motion, generated pictures fitted into the
editor's 256 px cell with mipmaps, normal particles on the `Normal` child and
additive ones on `Additive` above them.

| Property or method | Use |
| --- | --- |
| `pixels_per_unit` (100) | Document units to pixels; 100 is the editor's 2D view at 100% zoom |
| `autoplay` (true), `play()`, `stop()` | Restart from the seed, or clear without `finished` |
| `emitting` | Set false to stop births; live particles finish their lives |
| `finished`, `free_when_finished` | A one-shot effect (or one that stopped emitting) has no particles left |
| `aim(direction)` | Turn the node so the document's +Y points along `direction` |
| `advance(seconds)` | Step without frames, for seeking or tests |

Document +Y is up; units become pixels with Y flipped. `modulate` tints the
whole effect. A stall longer than 15 steps drops time instead of catching up.
The script is `@tool`, so the scene plays in the Godot editor, where a finished
effect restarts as in the weaveForge preview.

The engine's built-in particle nodes were not used: `CPUParticles2D` and
`GPUParticles2D` have no per-particle exponential drag, no lifetime range, no
random stream matching the editor, one texture and blend mode per node, and
no seed-identical bursts per cycle. A `spatial` effect becomes the same 2D
scene showing its front (XY) view, with Z only ordering normal particles; no
3D scene is generated. Disabled emitters are left out. Blending happens in
Godot's 2D colour space rather than the editor's WebGPU pipeline, so tinted
generated pictures and stacked additive light can differ slightly.

## Re-exporting

Each file begins with `; wf godot-export <id> v<version> sha256=<body hash>`.
A valid header and matching body hash identify an unedited generated file.
Identical files produce no effect. Changed generated files are replaced;
headerless, edited or non-UTF-8 files are `kept`. `--force` replaces those too.
Saving a generated resource in Godot may remove its header, making it a user
file on the next run.

Unedited generated files left by a layout/name change or a node removed from
the export lock are deleted. An explicitly selected run cleans only its selected
node IDs; an all-node run also cleans removed IDs. Export-owned files are never
deleted by this plugin. Edited leftovers survive even with `--force`.
Overwrites and deletes use the host's HighRisk stop-then-`--yes` confirmation.
The output lists both a node status and individual file statuses, so a `kept`
node can still have another file written or updated.

Read permission is `**` plus `platform = "read"`. Hidden directories are out
of reach. Unsafe texture paths, missing/unlocked textures, malformed sidecars,
invalid timing or margins fail the call before any effects are applied.
Sidecars are limited to 4 MiB and generated content to 12 MiB per invocation;
sync fewer nodes when the output limit is reached. Leftover discovery is
limited by the host's 10,000-file listing and VCS ignore rules; a cut listing
is reported. VCS-ignored stale files may require manual cleanup.

## Build and verify

It depends on [`plugin-kit`](https://gitlab.xqhuyu.cn/996-ugc/wf-plugins/plugin-kit)
by path, so clone that repository beside this one first:

```sh
git clone ssh://git@gitlab.xqhuyu.cn:10022/996-ugc/wf-plugins/plugin-kit.git ../plugin-kit
```

This crate has its own workspace, lock and wasm target:

```sh
cargo clippy
cargo clippy --target wasm32-wasip2
cargo test
cargo build --release --target wasm32-wasip2
wf plugin link .                 # stop, then repeat with --yes
# From the game project:
wf plugin trust godot-export     # stop, then repeat with --yes
wf godot-export sync --help
```

`tests/cases/` contains eleven minimal export corpora with tiny PNGs and
sidecars tested against CLI task planning and real Godot headless round-trips. Four cases retain trimmed real sidecars
(including the unchanged `main.json` of a real looping particle effect);
the others cover strips, multipage atlas, every widget mapping, margins and
all naming fallbacks, engine-name collisions, per-element output mappings and
a spatial particle effect with a built-in texture, curve keys, a radial burst, stretch, ground bounce, triggers and a disabled emitter (whose trigger is dropped). The in-memory Host also verifies reruns, edits, force,
version changes, leftover deletion, node selection and missing inputs.
`tests/memory.rs` measures a 30,000-frame sidecar against a 128 MiB budget.
No server or node-card crate is linked into this plugin.

The headless acceptance script reads expectations independently from exported
sidecars. After exporting and syncing real nodes in a **scratch copy** of a
mirror, run from the repository root:

```sh
python3 tests/godot/prepare.py /path/to/game --nodes 75 81
cp tests/godot/verify.gd /path/to/game/verify.gd
perl -e 'alarm 90; exec @ARGV' godot --headless --path /path/to/game --import --quit
perl -e 'alarm 90; exec @ARGV' godot --headless --path /path/to/game --script res://verify.gd
```

Pass `--directory assets/alternate` to the preparation script for another lock.

For particle effects, generate the editor's reference and compare (Bun runs
the TypeScript simulation of a WeaveForge checkout directly):

```sh
WEAVEFORGE=/path/to/weaveforge bun tests/godot/particles.ts /path/to/game
cp tests/godot/verify_particles.gd /path/to/game/
perl -e 'alarm 90; exec @ARGV' godot --headless --path /path/to/game --script res://verify_particles.gd
```
The verification checks scene loading/instantiation, autoplay and advancing
frames, all clip speeds/durations/loop flags, anchors, Theme variations,
StyleBoxTexture margins, content margins, textures, atlas regions and icons.
A failure returns exit code 1. Godot needs its normal user-data/settings
permissions; `--log-file /scratch/run.log` can redirect engine logs.

The component is not committed. Build it from source when packaging an
official release, and bump the plugin version whenever its bytes change.
