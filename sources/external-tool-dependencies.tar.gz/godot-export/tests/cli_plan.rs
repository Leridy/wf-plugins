//! Tests CLI-only routing, idempotent `src=` stamps, temp cleanup registration,
//! user-edit preservation, and real Godot headless round-trips.
mod common;

use common::Fake;
use plugin_api::Effect;
use sha2::{Digest, Sha256};
use wf_godot_export::{Input, Status, sync};

fn stamp_with_src(id: &str, version: u64, body: &str, src_hash: &str) -> Vec<u8> {
    format!(
        "; wf godot-export {id} v{version} sha256={:x} src={src_hash}\n{body}",
        Sha256::digest(body.as_bytes())
    )
    .into_bytes()
}

#[test]
fn auto_mode_plans_godot_cli_and_cleanup_then_reruns_unchanged() {
    let mut host = Fake::case("ui-pieces");
    host.tools.insert("godot".into());

    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Written);
    let target_path = plan.output.nodes[0].files[0].path.clone();

    let writes: Vec<&str> = plan
        .effects
        .iter()
        .filter_map(|e| match e {
            Effect::WriteFile { path, overwrite, .. } => {
                assert!(!overwrite);
                Some(path.as_str())
            }
            _ => None,
        })
        .collect();
    assert_eq!(writes, vec!["wf_tmp/godot_sync.json", "wf_tmp/godot_sync.gd"]);

    let execs: Vec<(&str, &[String])> = plan
        .effects
        .iter()
        .filter_map(|e| match e {
            Effect::Exec { tool, args, .. } => Some((tool.as_str(), args.as_slice())),
            _ => None,
        })
        .collect();
    assert_eq!(execs.len(), 2);
    assert_eq!(execs[0].0, "godot");
    assert!(execs[0].1.contains(&"--import".to_owned()));
    assert!(execs[1].1.contains(&"--script".to_owned()));
    assert!(execs[1].1.contains(&"res://wf_tmp/godot_sync.gd".to_owned()));

    assert_eq!(
        host.cleanup.borrow().as_slice(),
        &[
            "wf_tmp/godot_sync.json",
            "wf_tmp/godot_sync.gd",
            "wf_tmp/godot_sync.gd.uid"
        ]
    );

    // Simulate extracting src_hash from manifest + Godot saving stamped resource, then rerun.
    let manifest_bytes = plan
        .effects
        .iter()
        .find_map(|e| match e {
            Effect::WriteFile { path, bytes, .. } if path == "wf_tmp/godot_sync.json" => Some(bytes),
            _ => None,
        })
        .unwrap();
    let manifest: serde_json::Value = serde_json::from_slice(manifest_bytes).unwrap();
    let task = &manifest["tasks"][0];
    let src_hash = task["src_hash"].as_str().unwrap();
    let id = task["id"].as_str().unwrap();
    let version = task["version"].as_u64().unwrap();

    host.apply(plan.effects);
    assert!(!host.files.contains_key("wf_tmp/godot_sync.json"));
    assert!(!host.files.contains_key("wf_tmp/godot_sync.gd"));

    host.files
        .insert(target_path, stamp_with_src(id, version, "[gd_resource]\n", src_hash));
    host.cleanup.borrow_mut().clear();

    let rerun = sync(&host, &Input::default()).unwrap();
    assert_eq!(rerun.output.nodes[0].status, Status::Unchanged);
    assert!(rerun.effects.is_empty());
    assert!(host.cleanup.borrow().is_empty());
}

#[test]
fn sync_always_plans_godot_cli_even_without_tool_hint() {
    let host = Fake::case("real-frames");
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Written);
    assert!(
        plan.effects
            .iter()
            .any(|e| matches!(e, Effect::Exec { tool, .. } if tool == "godot"))
    );
    assert!(!host.cleanup.borrow().is_empty());
}

#[test]
fn cli_mode_preserves_user_edited_files_and_only_requests_unkept_targets() {
    let mut host = Fake::case("real-frames");
    host.tools.insert("godot".into());

    let first = sync(&host, &Input::default()).unwrap();
    let sf_path = first.output.nodes[0].files[0].path.clone();
    let scene_path = first.output.nodes[0].files[1].path.clone();

    let manifest_bytes = first
        .effects
        .iter()
        .find_map(|e| match e {
            Effect::WriteFile { path, bytes, .. } if path == "wf_tmp/godot_sync.json" => Some(bytes),
            _ => None,
        })
        .unwrap();
    let manifest: serde_json::Value = serde_json::from_slice(manifest_bytes).unwrap();
    let task = &manifest["tasks"][0];
    let src_hash = task["src_hash"].as_str().unwrap();
    let id = task["id"].as_str().unwrap();
    let version = task["version"].as_u64().unwrap();

    // SpriteFrames matches src_hash -> Unchanged; scene hand-edited -> Kept.
    host.files
        .insert(sf_path, stamp_with_src(id, version, "[gd_resource]\n", src_hash));
    host.files
        .insert(scene_path.clone(), b"[gd_scene]\n# user edit\n".to_vec());

    let next = sync(&host, &Input::default()).unwrap();
    assert_eq!(next.output.nodes[0].files[0].status, Status::Unchanged);
    assert_eq!(next.output.nodes[0].files[1].status, Status::Kept);
    assert_eq!(next.output.nodes[0].status, Status::Kept);
    assert!(next.effects.is_empty());

    // Forced rerun rewrites scene while leaving unchanged sprite_frames write=false.
    let forced = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    let m2: serde_json::Value = serde_json::from_slice(
        forced
            .effects
            .iter()
            .find_map(|e| match e {
                Effect::WriteFile { path, bytes, .. } if path == "wf_tmp/godot_sync.json" => Some(bytes),
                _ => None,
            })
            .unwrap(),
    )
    .unwrap();
    let spec = &m2["tasks"][0]["spec"];
    assert_eq!(spec["sprite_frames_target"]["write"], false);
    assert_eq!(spec["scene_target"]["write"], true);
    assert!(!forced.effects.is_empty());
    assert!(!scene_path.is_empty(), "sanity check: forced overwrites {scene_path}");
}

struct TempDir(std::path::PathBuf);
impl TempDir {
    fn new(name: &str) -> Self {
        let dir = std::env::temp_dir().join(format!("wf_godot_e2e_{}_{name}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        Self(dir)
    }
}
impl Drop for TempDir {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}

struct DiskHost<'a> {
    root: &'a std::path::Path,
    base: &'a Fake,
    cleanup: std::cell::RefCell<Vec<String>>,
}
impl<'a> plugin_guest::Host for DiskHost<'a> {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = globset::Glob::new(glob).unwrap().compile_matcher();
        common::files(self.root)
            .into_keys()
            .filter(|p| matcher.is_match(p))
            .collect()
    }
    fn read(&self, path: &str) -> Result<Vec<u8>, plugin_guest::HostError> {
        std::fs::read(self.root.join(path))
            .map_err(|_| plugin_guest::HostError::new(plugin_api::Failure::NotFound, path))
    }
    fn warn(&self, msg: &str) {
        eprintln!("[warn] {msg}");
    }
    fn tool_available(&self, tool: &str) -> bool {
        tool == "godot"
    }
    fn cleanup_after_exec(&self, path: &str) -> Result<(), plugin_guest::HostError> {
        self.cleanup.borrow_mut().push(path.to_owned());
        Ok(())
    }
}
impl<'a> plugin_guest::Platform for DiskHost<'a> {
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, plugin_guest::HostError> {
        self.base.call(method, input)
    }
}

#[test]
#[ignore = "requires local Godot binary"]
fn real_godot_cli_round_trips_every_fixture_case() {
    let godot = std::path::Path::new("/Applications/Godot.app/Contents/MacOS/Godot");
    assert!(godot.is_file(), "missing local Godot binary at {}", godot.display());

    let cases = [
        "real-frames",
        "ui-pieces",
        "tilemap",
        "real-particles",
        "particle-builtin",
        "whole-map",
        "scrolling-scene",
        "scene3d-map",
        "model-3d",
    ];

    for name in cases {
        let tmp = TempDir::new(name);
        let base = Fake::case(name);
        for (rel, bytes) in &base.files {
            let full = tmp.0.join(rel);
            std::fs::create_dir_all(full.parent().unwrap()).unwrap();
            std::fs::write(full, bytes).unwrap();
        }
        let disk = DiskHost {
            root: &tmp.0,
            base: &base,
            cleanup: std::cell::RefCell::new(Vec::new()),
        };

        let plan = sync(&disk, &Input::default()).unwrap();
        assert_eq!(plan.output.nodes[0].status, Status::Written, "{name}");

        let mut execs = Vec::new();
        for effect in plan.effects {
            match effect {
                Effect::WriteFile { path, bytes, .. } => {
                    let full = tmp.0.join(&path);
                    std::fs::create_dir_all(full.parent().unwrap()).unwrap();
                    std::fs::write(full, bytes).unwrap();
                }
                Effect::DeleteFile { path } => {
                    let _ = std::fs::remove_file(tmp.0.join(path));
                }
                Effect::Exec { args, .. } => execs.push(args),
                _ => panic!("unexpected effect"),
            }
        }
        for args in execs {
            let out = std::process::Command::new(godot)
                .args(&args)
                .current_dir(&tmp.0)
                .output()
                .unwrap();
            assert!(
                out.status.success(),
                "{name}: godot {:?} failed:\nstdout:\n{}\nstderr:\n{}",
                args,
                String::from_utf8_lossy(&out.stdout),
                String::from_utf8_lossy(&out.stderr),
            );
        }
        for rel in disk.cleanup.borrow_mut().drain(..) {
            let _ = std::fs::remove_file(tmp.0.join(rel));
        }
        let _ = std::fs::remove_dir(tmp.0.join("wf_tmp"));
        assert!(!tmp.0.join("wf_tmp").exists(), "{name}: wf_tmp leftover");

        // Verify generated resources load & instantiate cleanly in real Godot 4.
        let probe_gd = r#"extends SceneTree
func _initialize() -> void:
	call_deferred("_check")
func _check() -> void:
	for p in OS.get_cmdline_user_args():
		var res := ResourceLoader.load(p, "", ResourceLoader.CACHE_MODE_IGNORE)
		if res == null:
			push_error("Failed to load " + p)
			quit(1)
			return
		if res is PackedScene:
			var inst := (res as PackedScene).instantiate()
			if inst == null:
				push_error("Failed to instantiate " + p)
				quit(1)
				return
			inst.free()
	quit(0)
"#;
        std::fs::write(tmp.0.join("wf_probe.gd"), probe_gd).unwrap();
        let mut verify_args = vec![
            "--headless".to_owned(),
            "--path".to_owned(),
            ".".to_owned(),
            "--script".to_owned(),
            "res://wf_probe.gd".to_owned(),
            "--".to_owned(),
        ];
        for f in &plan.output.nodes[0].files {
            verify_args.push(f.resource.clone());
        }
        let probe_out = std::process::Command::new(godot)
            .args(&verify_args)
            .current_dir(&tmp.0)
            .output()
            .unwrap();
        assert!(
            probe_out.status.success(),
            "{name}: Godot load probe failed:\nstdout:\n{}\nstderr:\n{}",
            String::from_utf8_lossy(&probe_out.stdout),
            String::from_utf8_lossy(&probe_out.stderr),
        );
        let _ = std::fs::remove_file(tmp.0.join("wf_probe.gd"));
        let _ = std::fs::remove_file(tmp.0.join("wf_probe.gd.uid"));

        // Confirm second run is completely idempotent (Status::Unchanged, zero effects).
        let rerun = sync(&disk, &Input::default()).unwrap();
        assert_eq!(rerun.output.nodes[0].status, Status::Unchanged, "{name} rerun");
        assert!(rerun.effects.is_empty(), "{name} rerun must have 0 effects");
    }
}

#[test]
#[ignore = "requires local Godot binary"]
fn real_headless_import_and_bounded_scene_run() {
    use wf_godot_export::headless::{self, ImportInput, RunInput};
    let godot = std::path::Path::new("/Applications/Godot.app/Contents/MacOS/Godot");
    let tmp = TempDir::new("headless project");
    let game = tmp.0.join("games/My Game");
    std::fs::create_dir_all(game.join("scenes")).unwrap();
    std::fs::write(game.join("project.godot"),
        "config_version=5\n[application]\nconfig/name=\"Headless acceptance\"\nrun/main_scene=\"res://scenes/main.tscn\"\n[rendering]\nrenderer/rendering_method=\"gl_compatibility\"\n").unwrap();
    std::fs::write(game.join("scenes/main.tscn"),
        "[gd_scene load_steps=2 format=3]\n[ext_resource type=\"Script\" path=\"res://main.gd\" id=\"1\"]\n[node name=\"Main\" type=\"Node\"]\nscript = ExtResource(\"1\")\n").unwrap();
    std::fs::write(
        game.join("main.gd"),
        "extends Node\nfunc _ready():\n\tprint(\"WF_HEADLESS_SCENE_READY\")\n",
    )
    .unwrap();
    let base = Fake::default();
    let disk = DiskHost {
        root: &tmp.0,
        base: &base,
        cleanup: std::cell::RefCell::new(Vec::new()),
    };
    let directory = Some("games/My Game".to_owned());
    let import = headless::import(
        &disk,
        &ImportInput {
            directory: directory.clone(),
        },
    )
    .unwrap();
    let main = headless::run(
        &disk,
        &RunInput {
            directory: directory.clone(),
            scene: None,
            frames: 3,
        },
    )
    .unwrap();
    let scene = headless::run(
        &disk,
        &RunInput {
            directory,
            scene: Some("scenes/main.tscn".into()),
            frames: 3,
        },
    )
    .unwrap();
    for (i, plan) in [import, main, scene].into_iter().enumerate() {
        for effect in plan.effects {
            let Effect::Exec { args, .. } = effect else {
                panic!("headless operations only plan exec")
            };
            let output = std::process::Command::new(godot)
                .args(&args)
                .current_dir(&tmp.0)
                .output()
                .unwrap();
            let stdout = String::from_utf8_lossy(&output.stdout);
            let stderr = String::from_utf8_lossy(&output.stderr);
            assert!(output.status.success(), "{args:?}\n{stdout}\n{stderr}");
            assert!(!stderr.contains("ERROR:"), "{args:?}\n{stderr}");
            if i > 0 {
                assert!(stdout.contains("WF_HEADLESS_SCENE_READY"), "{stdout}");
            }
        }
    }
    assert!(game.join(".godot").is_dir());
}
