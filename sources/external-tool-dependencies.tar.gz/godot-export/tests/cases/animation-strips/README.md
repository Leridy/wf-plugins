Three frames with unequal durations (90, 150, 240 ms). One strip, three distinct regions.
Tiny solid PNGs replace the original art. expected/ is the reviewed text-format resource oracle.
