Real offline export #73, trimmed to two frames per retained clip; anchors and canvas reduced for tiny textures. Source direction has no suffix.
Tiny solid PNGs replace the original art. expected/ is the reviewed text-format resource oracle.
