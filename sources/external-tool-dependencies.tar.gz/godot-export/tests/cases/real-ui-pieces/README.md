Real offline exports #81 (two press widgets, reduced to 8x8) and #80 (体力条, track/fill-5/fill-100). The bar keeps its original 940x129 size and slice borders; largest-amount fill-100 uses 90/90, not fill-5’s 46/893. State roles and snake_case text_safe are preserved.
Tiny solid PNGs replace the original art. expected/ is the reviewed text-format resource oracle.
