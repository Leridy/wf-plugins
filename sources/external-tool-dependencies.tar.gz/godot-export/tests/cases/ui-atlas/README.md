All nine widget variants; every mapped style and icon; skipped roles and widgets; largest-amount fill wins even when listed smallest-first (ties: last in order); PascalCase collisions; fixed and sliced margins.
Tiny solid PNGs replace the original art. expected/ is the reviewed text-format resource oracle.
