Real offline export #75, trimmed to two frames per retained clip; anchors and canvas reduced for tiny textures. The second clip deliberately differs in anchor.
Tiny solid PNGs replace the original art. expected/ is the reviewed text-format resource oracle.
