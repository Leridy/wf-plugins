Approved ASCII name/kind/base fallback, mixed script names, leading digits, skipped non-ASCII kinds, engine-reserved and numeric collisions. elements.json verifies the discoverable output mapping.
Tiny solid PNGs replace the original art. expected/ is the reviewed text-format resource oracle.
