Three frames with unequal durations (90, 150, 240 ms). Two atlas pages, ordered frames.
Tiny solid PNGs replace the original art. expected/ is the reviewed text-format resource oracle.
