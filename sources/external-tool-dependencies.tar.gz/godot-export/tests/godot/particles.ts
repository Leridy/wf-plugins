/**
 * Steps every exported particle effect with the editor's own simulation and
 * writes <game>/particles.json for verify_particles.gd. The simulation is the
 * one of a WeaveForge checkout (packages/editors/src/particle/simulation.ts),
 * named by WEAVEFORGE. Run after sync:
 *
 *   WEAVEFORGE=/path/to/weaveforge bun tests/godot/particles.ts /path/to/game [assets/wf]
 */
import { existsSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, relative, resolve } from "node:path";

const weaveforge = process.env.WEAVEFORGE;
if (!weaveforge)
  throw new Error("set WEAVEFORGE to a WeaveForge checkout (its editor's simulation is the reference)");
const { PARTICLE_STEP, ParticleSimulation } = await import(
  resolve(weaveforge, "packages/editors/src/particle/simulation.ts")
);
type ParticleDocument = { emitters: { enabled: boolean }[] };
type Particle = {
  position: number[];
  velocity: number[];
  age: number;
  lifetime: number;
  rotation: number;
  flip: boolean;
  scale: number;
};

const SAMPLES = [1, 2, 10, 15, 30, 36, 60, 90, 120, 180, 240];
const [game, directory = "assets/wf"] = process.argv.slice(2);
if (!game) throw new Error("usage: particles.ts <game> [export directory]");
const lock = JSON.parse(
  readFileSync(join(game, directory, "wf.lock.json"), "utf8"),
);
const effects: Record<string, unknown> = {};
for (const node of lock.nodes as { files: string[] }[]) {
  const main = node.files.find((file) => file.endsWith("/main.json"));
  if (!main) continue;
  const folder = join(game, directory, main.slice(0, -"/main.json".length));
  const scene = readdirSync(folder).find((file) => file.endsWith(".tscn"));
  if (!scene) continue;
  const document: ParticleDocument = JSON.parse(
    readFileSync(join(folder, "main.json"), "utf8"),
  );
  const simulation = new ParticleSimulation({
    ...document,
    emitters: document.emitters.filter((emitter) => emitter.enabled),
  });
  const rows = [];
  for (let step = 1; step <= SAMPLES[SAMPLES.length - 1]; step++) {
    simulation.advance(PARTICLE_STEP);
    if (!SAMPLES.includes(step)) continue;
    // Copy now: the simulation keeps mutating its particles.
    rows.push({
      step,
      count: simulation.particles.length,
      // Every particle: triggered births append after regular emission.
      particles: simulation.particles.map((p: Particle) => ({
        position: [...p.position],
        velocity: [...p.velocity],
        age: p.age,
        lifetime: p.lifetime,
        rotation: p.rotation,
        flip: p.flip,
        scale: p.scale,
      })),
    });
  }
  effects[`res://${relative(game, join(folder, scene))}`] = rows;
}
if (!existsSync(join(game, "project.godot")))
  throw new Error("the game directory has no project.godot");
writeFileSync(join(game, "particles.json"), JSON.stringify(effects));
console.log(`${Object.keys(effects).length} effects`);
