"""Build independent Godot assertions from real exported sidecars (offline).

Run after sync. Writes only <game>/verify.json; never touches the source mirror.
"""
import argparse
import json
import pathlib
import re

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("game", type=pathlib.Path)
parser.add_argument("--nodes", nargs="+", type=int, required=True)
parser.add_argument("--directory", default="assets/wf")
args = parser.parse_args()
root = args.game.resolve()
export = root / args.directory
lock = json.loads((export / "wf.lock.json").read_text())
result = {"animations": [], "themes": []}


def resource(path):
    return "res://" + path.relative_to(root).as_posix()


def generated(directory, suffix):
    matches = list(directory.glob("*" + suffix))
    assert len(matches) == 1, (directory, suffix, matches)
    return resource(matches[0])


def pascal(name):
    return "".join(word[0].upper() + word[1:] for word in re.findall(r"[A-Za-z0-9]+", name))


def variation(element, base_type, ordinal, names):
    value = pascal(element["name"])
    if not value or not value[0].isalpha():
        value = pascal(element["kind"]) if element["kind"].isascii() else ""
    if not value or not value[0].isalpha():
        value = base_type + str(ordinal)
    name, suffix = value, 2
    while name in names:
        name, suffix = value + str(suffix), suffix + 1
    names.add(name)
    return name


slots = {
    "press": {"rest": "normal", "hover": "hover", "pressed": "pressed", "disabled": "disabled"},
    "flip": {"off": "normal", "off_hover": "hover", "on": "pressed", "on_hover": "hover_pressed", "off_disabled": "disabled"},
    "bar": {"track": "background", "fill": "fill"},
    "slide": {"track": "slider", "fill": "grabber_area", "thumb": "grabber", "thumb_hover": "grabber_highlight", "thumb_disabled": "grabber_disabled"},
}
for node in lock["nodes"]:
    if node["number"] not in args.nodes:
        continue
    for file in node["files"]:
        path = export / file
        if path.name == "animation.json":
            report = json.loads(path.read_text())
            clips = []
            for clip in report["clips"]:
                name = clip["actionId"] + ("" if clip["direction"] == "source" else "_" + clip["direction"])
                clips.append(dict(name=name, durations=clip["durationsMs"], loop=clip["loop"], anchor=clip["anchor"]))
            result["animations"].append(dict(scene=generated(path.parent, ".tscn"), clips=clips))
        if path.name == "ui.json":
            report = json.loads(path.read_text())
            variations = []
            names = set((pathlib.Path(__file__).resolve().parents[2] / "src/godot/builtin_types.txt").read_text().split())
            for ordinal, element in enumerate(report["elements"], 1):
                kind = element["widget"]["type"]
                if kind not in slots:
                    continue
                base_type = {"press":"Button", "flip":"Button", "bar":"ProgressBar", "slide":"HSlider"}[kind]
                name = variation(element, base_type, ordinal, names)
                states = []
                for state in element["states"]:
                    role = state.get("role")
                    if role not in slots[kind]:
                        continue
                    if kind == "bar" and role == "fill" and state["name"] != max(reversed(element["widget"]["fills"]), key=lambda fill: fill["amount"])["cell"]["name"]:
                        continue
                    image = report["images"][state["file"]]
                    icon = role.startswith("thumb")
                    margins = state["slice"]["borders"] if state["slice"]["mode"] != "fixed" else dict.fromkeys(["left", "right", "top", "bottom"], 0)
                    item = dict(slot=slots[kind][role], icon=icon, margins=margins, texture=resource(path.parent / image["path"]), region=image.get("frame"))
                    if state.get("text_safe"):
                        box = state["text_safe"]
                        width = image["frame"]["w"] if image.get("frame") else element["size"]["width"]
                        height = image["frame"]["h"] if image.get("frame") else element["size"]["height"]
                        item["content"] = dict(left=box["x"], right=width-box["x"]-box["w"], top=box["y"], bottom=height-box["y"]-box["h"])
                    states.append(item)
                variations.append(dict(name=name, original_name=element["name"], base=base_type, focus=kind=="press", states=states))
            result["themes"].append(dict(theme=generated(path.parent, ".theme.tres"), variations=variations))
assert result["animations"] or result["themes"], "No selected sidecars found"
(root / "verify.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(f"Prepared {len(result['animations'])} animations and {len(result['themes'])} themes from export sidecars")
