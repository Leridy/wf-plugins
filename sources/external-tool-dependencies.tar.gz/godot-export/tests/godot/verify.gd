extends SceneTree
## Headless acceptance against verify.json, independently derived from sidecars.
var failures: int = 0
var advances: int = 0
var animation_count: int = 0
var style_count: int = 0

func check(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		push_error(message)

func near(actual: float, expected: float, message: String) -> void:
	check(abs(actual - expected) <= max(0.0001, abs(expected) * 0.00001), message + " actual=" + str(actual) + " expected=" + str(expected))

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var arguments := OS.get_cmdline_user_args()
	var manifest := "res://verify.json" if arguments.is_empty() else arguments[0]
	var expected = JSON.parse_string(FileAccess.get_file_as_string(manifest))
	if not expected is Dictionary:
		push_error("Missing or invalid verification manifest")
		quit(1)
		return
	for item in expected.animations:
		var packed = load(item.scene)
		check(packed is PackedScene, "load scene " + item.scene)
		if not packed is PackedScene:
			continue
		var sprite = packed.instantiate()
		check(sprite is AnimatedSprite2D, "scene root is AnimatedSprite2D")
		if not sprite is AnimatedSprite2D:
			sprite.free()
			continue
		advances = 0
		sprite.frame_changed.connect(func(): advances += 1)
		root.add_child(sprite)
		await process_frame
		check(sprite.is_playing(), "scene autoplays " + item.scene)
		check(not sprite.centered, "sprite is not centered")
		check(String(sprite.animation) == item.clips[0].name, "first clip selected")
		near(sprite.offset.x, -item.clips[0].anchor.x, "anchor x")
		near(sprite.offset.y, -item.clips[0].anchor.y, "anchor y")
		var frames: SpriteFrames = sprite.sprite_frames
		check(frames.get_animation_names().size() == item.clips.size(), "all clips exported")
		for clip in item.clips:
			check(frames.has_animation(clip.name), "animation " + clip.name)
			if not frames.has_animation(clip.name):
				continue
			animation_count += 1
			var shortest: float = clip.durations.min()
			near(frames.get_animation_speed(clip.name), 1000.0 / shortest, "clip speed")
			check(frames.get_animation_loop(clip.name) == clip.loop, "clip loop flag")
			check(frames.get_frame_count(clip.name) == clip.durations.size(), "frame count")
			for i in range(clip.durations.size()):
				near(frames.get_frame_duration(clip.name, i), clip.durations[i] / shortest, "frame duration")
				near(1000.0 * frames.get_frame_duration(clip.name, i) / frames.get_animation_speed(clip.name), clip.durations[i], "frame milliseconds")
				check(frames.get_frame_texture(clip.name, i) is Texture2D, "frame texture")
		await create_timer(max(0.3, item.clips[0].durations[0] * 0.002)).timeout
		check(advances > 0, "animation frame advances " + item.scene)
		sprite.queue_free()
		await process_frame
	for item in expected.themes:
		var theme = load(item.theme)
		check(theme is Theme, "load theme " + item.theme)
		if not theme is Theme:
			continue
		for variation in item.variations:
			check(theme.get_type_variation_base(variation.name) == variation.base, "theme variation base " + variation.name)
			if variation.focus:
				check(theme.has_stylebox("focus", variation.name), "focus exists")
				check(theme.get_stylebox("focus", variation.name) is StyleBoxEmpty, "empty focus")
			for state in variation.states:
				var texture: Texture2D
				if state.icon:
					check(theme.has_icon(state.slot, variation.name), "slider icon exists")
					texture = theme.get_icon(state.slot, variation.name)
				else:
					check(theme.has_stylebox(state.slot, variation.name), "style exists " + state.slot)
					var style = theme.get_stylebox(state.slot, variation.name)
					check(style is StyleBoxTexture, "texture style " + state.slot)
					if not style is StyleBoxTexture:
						continue
					style_count += 1
					texture = style.texture
					for side in ["left", "right", "top", "bottom"]:
						near(style.get("texture_margin_" + side), state.margins[side], "slice margin " + side)
						if state.has("content"):
							near(style.get("content_margin_" + side), state.content[side], "content margin " + side)
				check(texture != null, "state texture loads")
				if texture == null:
					continue
				if state.region != null:
					check(texture is AtlasTexture, "atlas state texture")
					if texture is AtlasTexture:
						check(texture.atlas.resource_path == state.texture, "atlas page")
						check(texture.region == Rect2(state.region.x, state.region.y, state.region.w, state.region.h), "atlas region")
				else:
					check(texture.resource_path == state.texture, "PNG state texture path")
	print("godot-export verification: ", animation_count, " clips, ", style_count, " texture styles, ", failures, " failures")
	quit(0 if failures == 0 else 1)
