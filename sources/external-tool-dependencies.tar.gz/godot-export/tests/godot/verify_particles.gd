extends SceneTree
## Headless parity check: steps every generated particle scene and compares
## it with the editor's simulation (particles.json from particles.ts).
## Exit code 1 on any mismatch.

const EPSILON := 1e-9

var failures := 0


func check(condition: bool, message: String) -> void:
	if not condition:
		failures += 1
		push_error(message)


func _initialize() -> void:
	_verify.call_deferred()


func _verify() -> void:
	var effects: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://particles.json"))
	var samples := 0
	for path: String in effects:
		var effect: Node2D = (load(path) as PackedScene).instantiate()
		root.add_child(effect)
		effect.set_process(false)
		check(effect.is_playing(), path + ": not playing after _ready")
		var step := 0
		for row: Dictionary in effects[path]:
			while step < int(row["step"]):
				effect.advance(1.0 / 60.0)
				step += 1
			samples += 1
			var label := "%s step %d" % [path, step]
			check(effect.get_particle_count() == int(row["count"]), "%s: %d particles, editor %d" % [label, effect.get_particle_count(), row["count"]])
			if effect.get_particle_count() != int(row["count"]):
				continue
			for i in (row["particles"] as Array).size():
				var want: Dictionary = row["particles"][i]
				var got = effect._particles[i]
				var pairs := [
					[got.px, want["position"][0]], [got.py, want["position"][1]], [got.pz, want["position"][2]],
					[got.vx, want["velocity"][0]], [got.vy, want["velocity"][1]], [got.vz, want["velocity"][2]],
					[got.age, want["age"]], [got.life, want["lifetime"]],
					[got.rotation, want["rotation"]], [got.scale, want["scale"]],
				]
				for pair in pairs:
					check(absf(float(pair[0]) - float(pair[1])) <= EPSILON, "%s particle %d: %s, editor %s" % [label, i, pair[0], pair[1]])
				check(got.flip == bool(want["flip"]), "%s particle %d: flip differs" % [label, i])
		effect.free()
	print("%d effects, %d samples, %d failures" % [effects.size(), samples, failures])
	quit(1 if failures else 0)
