extends SceneTree
## Snapshot reserved Theme names from the acceptance engine, without a runtime dependency.
func _initialize() -> void:
	var names := ClassDB.get_class_list()
	names.sort()
	var output := FileAccess.open(OS.get_cmdline_user_args()[0], FileAccess.WRITE)
	for i in range(0, names.size(), 8):
		output.store_line(" ".join(names.slice(i, i + 8)))
	print("Reserved built-in types: ", names.size())
	quit()
