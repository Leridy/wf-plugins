//! The actual manifest must pass the same declaration checks as the client.
use plugin_api::{Manifest, VersionExtract, VersionStream};
use regex::Regex;
use semver::{Version, VersionReq};

#[test]
fn declares_one_required_editor_with_a_fixed_query_and_registry_hints() {
    let manifest = Manifest::parse(include_str!("../wf-plugin.toml")).unwrap();
    assert_eq!(manifest.permissions.exec, ["godot"]);
    assert_eq!(manifest.tools.len(), 1);
    let tool = &manifest.tools[0];
    assert_eq!(tool.name, "godot");
    assert!(!tool.detect.macos.is_empty());
    assert!(!tool.detect.windows.is_empty());
    assert_eq!(tool.detect.path, ["godot", "godot4"]);
    assert_eq!(tool.detect.registry.len(), 2);
    let version = tool.version.as_ref().unwrap();
    assert_eq!(version.args, ["--headless", "--version"]);
    assert_eq!(version.stream, VersionStream::Stdout);
    assert_eq!(version.features["headless"], version.require);
}

#[test]
fn accepts_supported_stable_versions_without_promoting_prereleases() {
    let manifest = Manifest::parse(include_str!("../wf-plugin.toml")).unwrap();
    let check = manifest.tools[0].version.as_ref().unwrap();
    let VersionExtract::Regex { pattern } = &check.extract else {
        panic!("expected Godot version regex")
    };
    let regex = Regex::new(pattern).unwrap();
    let requirement = VersionReq::parse(&check.require).unwrap();
    for (output, expected) in [
        ("4.3.stable.official.77dcf97d8", true),
        ("4.7.1.stable.official.a13da4feb\n", true),
        ("4.2.2.stable.official.15073afe3", false),
        ("3.6.stable.official", false),
        ("5.0.stable.official", false),
        ("4.7.beta1.official", false),
        ("4.7.1.rc1.official", false),
        ("4.7.1.stableish.official", false),
        ("version unknown", false),
    ] {
        let compatible = regex.captures(output).is_some_and(|caps| {
            let raw = &caps["version"];
            let normalized = if raw.matches('.').count() == 1 {
                format!("{raw}.0")
            } else {
                raw.into()
            };
            requirement.matches(&Version::parse(&normalized).unwrap())
        });
        assert_eq!(compatible, expected, "{output}");
    }
}
