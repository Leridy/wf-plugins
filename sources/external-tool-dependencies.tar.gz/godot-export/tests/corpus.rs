//! Real and constructed exports validated against CLI manifest planning and lifecycle rules.
mod common;
use common::Fake;
use plugin_api::Effect;
use serde_json::Value;
use std::{fs, path::Path};
use wf_godot_export::{Element, Input, Plan, Status, sync};

fn manifest_task(plan: &Plan) -> Value {
    let bytes = plan
        .effects
        .iter()
        .find_map(|e| match e {
            Effect::WriteFile { path, bytes, .. } if path == "wf_tmp/godot_sync.json" => Some(bytes),
            _ => None,
        })
        .expect("wf_tmp/godot_sync.json written");
    let manifest: Value = serde_json::from_slice(bytes).expect("valid manifest json");
    assert_eq!(manifest["tasks"].as_array().unwrap().len(), 1);
    manifest["tasks"][0].clone()
}

fn corpus(name: &str) {
    let mut host = Fake::case(name);
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Written, "{name}");

    let writes: Vec<&str> = plan
        .effects
        .iter()
        .filter_map(|e| match e {
            Effect::WriteFile { path, overwrite, .. } => {
                assert!(!overwrite, "{name}/{path}: expected overwrite=false");
                Some(path.as_str())
            }
            _ => None,
        })
        .collect();
    assert_eq!(writes, vec!["wf_tmp/godot_sync.json", "wf_tmp/godot_sync.gd"]);
    assert_eq!(
        plan.effects
            .iter()
            .filter(|e| matches!(e, Effect::Exec { tool, .. } if tool == "godot"))
            .count(),
        2
    );

    if name == "real-frames" {
        assert!(
            plan.output.nodes[0]
                .reasons
                .iter()
                .any(|r| r.contains("different anchors"))
        );
    }
    if name == "particle-builtin" {
        let reasons = &plan.output.nodes[0].reasons;
        assert!(reasons.iter().any(|r| r.contains("Unused smoke")));
        assert!(reasons.iter().any(|r| r.starts_with("Spatial effect")));
    }
    if matches!(name, "ui-pieces" | "ui-atlas") {
        for kind in ["switch", "ring", "stick", "parts", "states"] {
            assert!(
                plan.output.nodes[0]
                    .reasons
                    .iter()
                    .any(|r| r.contains(&format!("{kind} has no theme")))
            );
        }
    }
    let mapping = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/cases")
        .join(name)
        .join("elements.json");
    if mapping.exists() {
        let expected: Vec<Element> = serde_json::from_slice(&fs::read(mapping).unwrap()).unwrap();
        assert_eq!(plan.output.nodes[0].elements, expected);
    } else {
        assert!(plan.output.nodes[0].elements.is_empty());
    }
    host.apply_cli(&plan.output, plan.effects);
    let rerun = sync(&host, &Input::default()).unwrap();
    assert!(rerun.effects.is_empty(), "{name}: rerun must have 0 effects");
    assert_eq!(rerun.output.nodes[0].status, Status::Unchanged, "{name}");
}

macro_rules! case {
    ($test:ident, $name:literal) => {
        #[test]
        fn $test() {
            corpus($name);
        }
    };
}
case!(frames, "real-frames");
case!(source_direction, "real-source");
case!(strips, "animation-strips");
case!(atlas, "animation-atlas");
case!(real_ui, "real-ui-pieces");
case!(ui_pieces, "ui-pieces");
case!(ui_atlas, "ui-atlas");
case!(ui_naming, "ui-naming");
case!(tile_map, "tilemap");
case!(real_particles, "real-particles");
case!(particle_builtin, "particle-builtin");

#[test]
fn edited_and_headerless_files_are_kept_until_force() {
    let mut host = Fake::case("real-frames");
    let plan = sync(&host, &Input::default()).unwrap();
    let files = plan.output.nodes[0]
        .files
        .iter()
        .map(|f| f.path.clone())
        .collect::<Vec<_>>();
    host.apply_cli(&plan.output, plan.effects);
    host.files
        .get_mut(&files[0])
        .unwrap()
        .extend_from_slice(b"; user edit\n");
    let scene = String::from_utf8(host.files[&files[1]].clone()).unwrap();
    host.files
        .insert(files[1].clone(), scene.split_once('\n').unwrap().1.as_bytes().to_vec());
    let kept = sync(&host, &Input::default()).unwrap();
    assert_eq!(kept.output.nodes[0].status, Status::Kept);
    assert!(kept.effects.is_empty());
    let force = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    assert_eq!(force.output.nodes[0].status, Status::Updated);
    let task = manifest_task(&force);
    assert_eq!(task["spec"]["sprite_frames_target"]["write"], true);
    assert_eq!(task["spec"]["scene_target"]["write"], true);
}

#[test]
fn new_version_is_an_overwrite_even_when_spec_is_identical() {
    let mut host = Fake::case("real-source");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply_cli(&first.output, first.effects);
    host.locks.as_mut().unwrap().nodes[0].version += 1;
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Updated);
    let task = manifest_task(&plan);
    assert_eq!(task["spec"]["sprite_frames_target"]["write"], true);
    assert_eq!(task["spec"]["scene_target"]["write"], true);
}

#[test]
fn layout_changes_delete_only_unedited_leftovers() {
    let mut host = Fake::case("real-source");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply_cli(&first.output, first.effects);
    host.files
        .insert("assets/wf/hero/user.tres".into(), b"[resource]\n".to_vec());
    host.locks.as_mut().unwrap().nodes[0].path = "Actors/Renamed".into();
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.deleted.len(), 2);
    assert!(plan.output.deleted.iter().all(|p| p.contains("Hero.")));
    assert_eq!(
        plan.effects
            .iter()
            .filter(|e| matches!(e, Effect::DeleteFile { .. }))
            .count(),
        2
    );
    host.apply_cli(&plan.output, plan.effects);
    assert!(host.files.contains_key("assets/wf/hero/user.tres"));
}

#[test]
fn removed_nodes_are_cleaned_but_edited_leftovers_survive() {
    let mut host = Fake::case("real-source");
    let plan = sync(&host, &Input::default()).unwrap();
    let edited = plan.output.nodes[0].files[0].path.clone();
    host.apply_cli(&plan.output, plan.effects);
    host.files.get_mut(&edited).unwrap().push(b' ');
    host.locks.as_mut().unwrap().nodes.clear();
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.deleted.len(), 1);
    assert_ne!(plan.output.deleted[0], edited);
}

#[test]
fn selection_accepts_all_three_address_forms_and_does_not_clean_other_nodes() {
    let mut host = Fake::case("real-source");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply_cli(&first.output, first.effects);
    let template = host.files["assets/wf/hero/Hero.tscn"].clone();
    let other = String::from_utf8(template).unwrap().replace(
        "11111111-1111-4111-8111-111111111111",
        "22222222-2222-4222-8222-222222222222",
    );
    host.files.insert("assets/wf/other.tscn".into(), other.into_bytes());
    for address in ["#75", "Actors/Hero", "wf://11111111-1111-4111-8111-111111111111"] {
        let plan = sync(
            &host,
            &Input {
                nodes: vec![address.into()],
                ..Input::default()
            },
        )
        .unwrap();
        assert!(plan.effects.is_empty());
        assert_eq!(plan.output.nodes.len(), 1);
    }
    assert!(
        sync(
            &host,
            &Input {
                nodes: vec!["#999".into()],
                ..Input::default()
            }
        )
        .is_err()
    );
}

#[test]
fn missing_project_sidecar_or_texture_is_not_a_successful_delivery() {
    for path in [
        "project.godot",
        "assets/wf/hero/animation.json",
        "assets/wf/hero/spriteActions-1/source/01.png",
    ] {
        let mut host = Fake::case("real-source");
        assert!(host.files.remove(path).is_some(), "{path}");
        assert!(sync(&host, &Input::default()).is_err(), "{path}");
    }
    let mut host = Fake::case("particle-builtin");
    assert!(
        host.files
            .remove("assets/wf/fx/sparks/particle-texture-spark.png")
            .is_some()
    );
    assert!(sync(&host, &Input::default()).is_err());
}

#[test]
fn unsupported_node_types_are_reported_without_effects() {
    let mut host = Fake::case("real-source");
    for kind in [
        "word_art",
        "icon",
        "music",
        "sound_effect",
        "voice",
        "tts",
        "image",
        "skeletal_animation",
        "prop",
    ] {
        host.nodes[0].node.node_type = kind.into();
        let plan = sync(&host, &Input::default()).unwrap();
        assert_eq!(plan.output.nodes[0].status, Status::Skipped);
        assert!(!plan.output.nodes[0].reasons.is_empty());
        assert!(plan.effects.is_empty());
    }
}

fn check_new_domain(name: &str, expected_scene: &str, expected_kind: &str, snippets: &[&str]) {
    let mut host = Fake::case(name);
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Written, "{name}");
    assert_eq!(
        plan.output.nodes[0].main_scene.as_deref(),
        Some(expected_scene),
        "{name}"
    );
    let task = manifest_task(&plan);
    assert_eq!(task["kind"], expected_kind);
    let spec_text = serde_json::to_string(&task["spec"]).unwrap();
    for needle in snippets {
        assert!(
            spec_text.contains(needle),
            "{name}: missing {needle:?} in:\n{spec_text}"
        );
    }
    host.apply_cli(&plan.output, plan.effects);
    let rerun = sync(&host, &Input::default()).unwrap();
    assert!(rerun.effects.is_empty(), "{name}: rerun must be clean");
    assert_eq!(rerun.output.nodes[0].status, Status::Unchanged, "{name}");
}

#[test]
fn whole_map_plans_masked_tiles_depth_bands_and_navigation() {
    check_new_domain(
        "whole-map",
        "assets/wf/whole-map/Town.tscn",
        "whole_map",
        &["mask_shader", "nav_layers", "blocks", "connections", "regions"],
    );
}

#[test]
fn scrolling_scene_plans_parallax2d_and_level_colliders() {
    check_new_domain(
        "scrolling-scene",
        "assets/wf/scrolling-scene/Forest.tscn",
        "parallax",
        &[
            "motion_script",
            "backdrop",
            "bob_amplitude",
            "sway_degrees",
            "rects",
            "climbs",
            "hazards",
            "Spawn",
        ],
    );
}

#[test]
fn scene3d_map_plans_environment_roles_blocked_doors_and_solid_colliders() {
    let host = Fake::case("scene3d-map");
    let plan = sync(&host, &Input::default()).unwrap();
    assert!(
        plan.output.nodes[0].reasons.iter().any(|r| r.contains("Blocked doors")),
        "blocked doors note expected: {:?}",
        plan.output.nodes[0].reasons
    );
    check_new_domain(
        "scene3d-map",
        "assets/wf/scene3d-map/Citadel.tscn",
        "scene3d",
        &[
            "engine-scene.glb",
            "ambient_intensity",
            "colliders",
            "blocked",
            "\"spawn\"",
            "\"door\"",
        ],
    );
}

#[test]
fn model_3d_plans_glb_collider_sockets_and_clip_metadata() {
    check_new_domain(
        "model-3d",
        "assets/wf/model-3d/Knight.tscn",
        "model3d",
        &["main.glb", "\"capsule\"", "Socket_HandR", "travel", "\"loops\":true"],
    );
}

#[test]
fn an_entirely_skipped_kit_still_lists_its_elements_without_a_theme() {
    let mut host = Fake::case("ui-pieces");
    host.files.insert(
        "assets/wf/hero/ui.json".into(),
        r#"{
            "images": {}, "elements": [
                {"name": "面板", "kind": "panel", "size": {"width": 8, "height": 8}, "states": [], "widget": {"type": "states"}}
            ]
        }"#
        .as_bytes()
        .to_vec(),
    );
    let plan = sync(&host, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Skipped);
    assert_eq!(
        plan.output.nodes[0].elements,
        [Element {
            name: "面板".into(),
            variation: None
        }]
    );
    assert!(plan.effects.is_empty());
}
