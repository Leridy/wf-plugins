//! The unit tests' in-memory host, with typed mirror answers.
use globset::Glob;
use plugin_api::{
    Effect, Failure,
    platform::{LocksOutput, NodeInput, NodeOutput},
};
use plugin_guest::{Host, HostError, Platform};
use std::{
    cell::RefCell,
    collections::{BTreeMap, BTreeSet},
};

use sha2::{Digest, Sha256};

#[derive(Default)]
pub struct Fake {
    pub files: BTreeMap<String, Vec<u8>>,
    pub locks: Option<LocksOutput>,
    pub nodes: Vec<NodeOutput>,
    pub tools: BTreeSet<String>,
    pub cleanup: RefCell<Vec<String>>,
}
impl Fake {
    pub fn apply(&mut self, effects: Vec<Effect>) {
        for effect in effects {
            match effect {
                Effect::WriteFile { path, bytes, .. } => {
                    self.files.insert(path, bytes);
                }
                Effect::DeleteFile { path } => {
                    self.files.remove(&path);
                }
                Effect::Exec { .. } => {}
                _ => unreachable!("only writes, deletes and exec"),
            }
        }
        for path in self.cleanup.borrow_mut().drain(..) {
            self.files.remove(&path);
        }
    }

    /// Simulates a full CLI sync apply: writes/deletes/cleans temp files and materializes
    /// `src=`-stamped placeholder Godot outputs for every target marked `write: true`.
    #[allow(dead_code)]
    pub fn apply_cli(&mut self, output: &wf_godot_export::Output, effects: Vec<Effect>) {
        let manifest_bytes = effects.iter().find_map(|e| match e {
            Effect::WriteFile { path, bytes, .. } if path.ends_with("wf_tmp/godot_sync.json") => Some(bytes.clone()),
            _ => None,
        });
        self.apply(effects);
        let Some(raw) = manifest_bytes else {
            return;
        };
        let manifest: serde_json::Value = serde_json::from_slice(&raw).unwrap();
        for task in manifest["tasks"].as_array().unwrap() {
            let id = task["id"].as_str().unwrap();
            let version = task["version"].as_u64().unwrap();
            let src_hash = task["src_hash"].as_str().unwrap();
            let spec = &task["spec"];
            for key in ["sprite_frames_target", "theme_target", "tileset_target", "scene_target"] {
                let target = &spec[key];
                if target["write"].as_bool() != Some(true) {
                    continue;
                }
                let res_path = target["res_path"].as_str().unwrap();
                let disk_path = output
                    .nodes
                    .iter()
                    .flat_map(|n| &n.files)
                    .find(|f| f.resource == res_path)
                    .map(|f| f.path.clone())
                    .unwrap_or_else(|| panic!("missing output file for {res_path}"));
                let body = if disk_path.ends_with(".tscn") {
                    "[gd_scene format=3]\n"
                } else {
                    "[gd_resource format=3]\n"
                };
                let stamped = format!(
                    "; wf godot-export {id} v{version} sha256={:x} src={src_hash}\n{body}",
                    Sha256::digest(body.as_bytes())
                );
                self.files.insert(disk_path, stamped.into_bytes());
            }
        }
    }
}
impl Host for Fake {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        self.files.keys().filter(|p| matcher.is_match(p)).cloned().collect()
    }
    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.files
            .get(path)
            .cloned()
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }
    fn warn(&self, _: &str) {}
    fn tool_available(&self, tool: &str) -> bool {
        self.tools.contains(tool)
    }
    fn cleanup_after_exec(&self, path: &str) -> Result<(), HostError> {
        self.cleanup.borrow_mut().push(path.to_owned());
        Ok(())
    }
}
impl Platform for Fake {
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, HostError> {
        match method {
            "wf.mirror.locks" => self
                .locks
                .as_ref()
                .map(|locks| serde_json::to_vec(locks).unwrap())
                .ok_or_else(|| HostError::new(Failure::NotFound, "no export lock")),
            "wf.mirror.node" => {
                let query: NodeInput = serde_json::from_slice(input).unwrap();
                let node = self
                    .nodes
                    .iter()
                    .find(|n| {
                        query.address == format!("wf://{}", n.node.id)
                            || query.address == format!("#{}", n.node.number)
                            || query.address == n.node.path
                    })
                    .ok_or_else(|| HostError::new(Failure::NotFound, "node"))?;
                Ok(serde_json::to_vec(node).unwrap())
            }
            _ => unreachable!("only mirror reads"),
        }
    }
}

use std::{fs, path::Path};
impl Fake {
    pub fn case(name: &str) -> Self {
        let path = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/cases").join(name);
        Self {
            files: files(&path.join("project")),
            locks: Some(serde_json::from_slice(&fs::read(path.join("locks.json")).unwrap()).unwrap()),
            nodes: serde_json::from_slice(&fs::read(path.join("nodes.json")).unwrap()).unwrap(),
            ..Self::default()
        }
    }
}
pub fn files(root: &Path) -> BTreeMap<String, Vec<u8>> {
    fn walk(root: &Path, dir: &Path, output: &mut BTreeMap<String, Vec<u8>>) {
        for item in fs::read_dir(dir).unwrap() {
            let path = item.unwrap().path();
            if path.is_dir() {
                walk(root, &path, output);
            } else {
                output.insert(
                    path.strip_prefix(root).unwrap().to_str().unwrap().replace('\\', "/"),
                    fs::read(path).unwrap(),
                );
            }
        }
    }
    let mut output = BTreeMap::new();
    walk(root, root, &mut output);
    output
}
