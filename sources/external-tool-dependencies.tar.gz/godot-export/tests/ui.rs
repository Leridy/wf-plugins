//! The official node actions and the table they display share one contract.
mod common;

use common::Fake;
use plugin_api::{
    ConfigValue, Manifest,
    platform::NodeOutput,
    ui::{Bind, CellKind, Place, ProjectNeed, Renderer},
};
use plugin_protocols::ui::{Cell, Status as UiStatus, Tone};
use wf_godot_export::{Input, Output, Status, sync};

fn manifest() -> Manifest {
    Manifest::parse(include_str!("../wf-plugin.toml")).unwrap()
}

fn check_table(output: &Output) {
    let manifest = manifest();
    let view = &manifest.ui.views[0];
    let columns = match &view.renderer {
        Renderer::Table { columns } => Some(columns),
        _ => None,
    }
    .expect("the export result view uses a table");
    assert_eq!(view.op, "sync");
    assert_eq!(view.from.as_deref(), Some("table"));
    let kinds: Vec<_> = columns.iter().map(|column| column.kind).collect();
    assert_eq!(
        kinds,
        [CellKind::Node, CellKind::Status, CellKind::Number, CellKind::Path]
    );
    output.table.check(&kinds).unwrap();
    assert_eq!(output.table.rows.len(), output.nodes.len());
}

fn status(output: &Output, tone: Tone, text: &str) {
    check_table(output);
    assert_eq!(
        output.table.rows[0][1],
        Cell::Status(UiStatus {
            tone,
            text: text.into()
        })
    );
}

#[test]
fn node_actions_bind_selection_and_force_only_for_supported_items_in_a_mirror() {
    let manifest = manifest();
    assert_eq!(manifest.ui.actions.len(), 2);
    for (action, force) in manifest.ui.actions.iter().zip([false, true]) {
        assert_eq!(action.op, "sync");
        assert_eq!(action.place, Place::NodeMenu);
        assert_eq!(action.when.project, ProjectNeed::Mirror);
        assert!(!action.when.admits(None));
        assert!(action.when.takes(2));
        assert!(!action.when.takes(0));
        let kinds: Vec<_> = action.when.node_types.iter().map(|kind| kind.as_str()).collect();
        assert_eq!(
            kinds,
            [
                "frame_animation",
                "character_effect",
                "ui",
                "tilemap",
                "particle_effect",
                "whole_map",
                "scrolling_scene",
                "scene3d_map",
                "model_3d",
            ]
        );
        assert_eq!(action.input["nodes"], Bind::Selection);
        assert_eq!(
            action.input.get("force"),
            force.then_some(&Bind::Value(ConfigValue::Bool(true)))
        );
        assert!(action.label.zh.is_some());
    }
}

#[test]
fn every_export_form_has_a_typed_row_and_an_unchanged_rerun() {
    for (case, scene, count) in [
        ("real-frames", Some("assets/wf/hero/Hero.tscn"), 2.0),
        ("real-source", Some("assets/wf/hero/Hero.tscn"), 2.0),
        ("animation-strips", Some("assets/wf/hero/Hero.tscn"), 2.0),
        ("animation-atlas", Some("assets/wf/hero/Hero.tscn"), 2.0),
        ("ui-pieces", None, 1.0),
        ("ui-atlas", None, 1.0),
        ("tilemap", Some("assets/wf/meadow/Meadow.tscn"), 2.0),
        (
            "real-particles",
            Some("assets/wf/01a1bf2d-3bef-71b1-8253-91dd23916069/粒子_敌军传送门.tscn"),
            1.0,
        ),
        ("particle-builtin", Some("assets/wf/fx/sparks/Sparks.tscn"), 1.0),
        ("whole-map", Some("assets/wf/whole-map/Town.tscn"), 1.0),
        ("scrolling-scene", Some("assets/wf/scrolling-scene/Forest.tscn"), 1.0),
        ("scene3d-map", Some("assets/wf/scene3d-map/Citadel.tscn"), 1.0),
        ("model-3d", Some("assets/wf/model-3d/Knight.tscn"), 1.0),
    ] {
        let mut host = Fake::case(case);
        let plan = sync(&host, &Input::default()).unwrap();
        status(&plan.output, Tone::Ok, "Written");
        assert_eq!(
            plan.output.table.rows[0][0],
            Cell::Node(format!("wf://{}", host.nodes[0].node.id))
        );
        assert_eq!(plan.output.nodes[0].main_scene.as_deref(), scene, "{case}");
        assert_eq!(
            plan.output.table.rows[0][3],
            Cell::Path(scene.unwrap_or_default().into())
        );
        assert_eq!(plan.output.table.rows[0][2], Cell::Number(count));
        host.apply_cli(&plan.output, plan.effects);
        let rerun = sync(&host, &Input::default()).unwrap();
        status(&rerun.output, Tone::Neutral, "Unchanged");
        assert!(rerun.effects.is_empty());
        assert_eq!(rerun.output.nodes[0].main_scene.as_deref(), scene, "{case}");
        assert_eq!(
            rerun.output.table.rows[0][3],
            Cell::Path(scene.unwrap_or_default().into())
        );
    }
}

#[test]
fn preserved_edits_and_skipped_nodes_are_warnings_and_force_reports_updated() {
    let mut host = Fake::case("real-source");
    let plan = sync(&host, &Input::default()).unwrap();
    let path = plan.output.nodes[0].files[0].path.clone();
    host.apply_cli(&plan.output, plan.effects);
    host.files.get_mut(&path).unwrap().extend_from_slice(b"; user edit\n");
    let kept = sync(&host, &Input::default()).unwrap();
    status(&kept.output, Tone::Warn, "Edits kept");
    assert!(kept.effects.is_empty());
    let forced = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    status(&forced.output, Tone::Ok, "Updated");
    host.nodes[0].node.node_type = "music".into();
    let skipped = sync(&host, &Input::default()).unwrap();
    status(&skipped.output, Tone::Warn, "Skipped");
    assert_eq!(skipped.output.table.rows[0][2], Cell::Number(0.0));
}

#[test]
fn unexported_selection_warns_once_and_does_not_delete_its_old_resources() {
    let mut host = Fake::case("real-source");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply_cli(&first.output, first.effects);
    host.locks.as_mut().unwrap().nodes.clear();
    let before = host.files.clone();
    let plan = sync(
        &host,
        &Input {
            nodes: vec!["#75".into(), "Actors/Hero".into()],
            ..Input::default()
        },
    )
    .unwrap();
    status(&plan.output, Tone::Warn, "Run wf export");
    assert_eq!(plan.output.nodes.len(), 1);
    assert_eq!(plan.output.nodes[0].status, Status::Skipped);
    assert!(plan.output.nodes[0].reasons[0].contains("wf export '#75'"));
    assert_eq!(plan.output.table.rows[0][3], Cell::Path(String::new()));
    assert_eq!(plan.output.table.rows[0][2], Cell::Number(0.0));
    assert!(plan.output.deleted.is_empty());
    assert!(plan.effects.is_empty());
    assert_eq!(host.files, before);
}

#[test]
fn a_missing_export_does_not_prevent_other_selected_nodes_from_converting() {
    let mut host = Fake::case("real-source");
    let mut missing: Vec<NodeOutput> = serde_json::from_str(include_str!("cases/real-source/nodes.json")).unwrap();
    missing[0].node.id = "22222222-2222-4222-8222-222222222222".into();
    missing[0].node.number = 81;
    missing[0].node.path = "Actors/Other".into();
    host.nodes.extend(missing);
    let plan = sync(
        &host,
        &Input {
            nodes: vec!["#75".into(), "#81".into()],
            ..Input::default()
        },
    )
    .unwrap();
    check_table(&plan.output);
    assert_eq!(plan.output.nodes.len(), 2);
    assert_eq!(
        plan.output
            .nodes
            .iter()
            .filter(|node| node.status == Status::Written)
            .count(),
        1
    );
    assert_eq!(plan.effects.len(), 4);
}

#[test]
fn first_export_without_a_lock_warns_but_unknown_nodes_still_fail() {
    let mut host = Fake::case("real-source");
    host.locks = None;
    let plan = sync(
        &host,
        &Input {
            nodes: vec!["#75".into()],
            ..Input::default()
        },
    )
    .unwrap();
    status(&plan.output, Tone::Warn, "Run wf export");
    assert!(plan.effects.is_empty());
    assert!(sync(&host, &Input::default()).is_err());
    assert!(
        sync(
            &host,
            &Input {
                nodes: vec!["#999".into()],
                ..Input::default()
            }
        )
        .is_err()
    );
}
