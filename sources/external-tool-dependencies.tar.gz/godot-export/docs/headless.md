# Godot dependency and headless workflow

`godot-export` requires a confirmed Godot **editor**, stable version >=4.3.0 and
<5.0.0. Godot 3, 4.0–4.2 and prereleases are not accepted. TileMapLayer and
Parallax2D resource generation require Godot 4.3+. Export templates alone are
not a replacement for the editor binary.

## Configure once in the client

1. Install/update `godot-export`, then open Settings → Client → External tools → Godot.
2. Use automatic discovery, or add the executable / macOS `.app` manually.
3. Confirm a candidate, run its version check for **godot-export**, and choose it
   as the default. The fixed query is `--headless --version`; it does not import
   or run a project. An earlier receipt for another plugin does not replace this check.
4. The plugin becomes available when the default path and version receipt are valid.
   All operations, including `sync` and previews, share this dependency gate.

Discovery only inspects paths, PATH and Windows App Paths registry entries. Many
portable Windows installations have no registry entry; use Add path in that case.
A feature marked `headless` means its version is eligible, not that a project
has already passed a headless test. A changed binary or check definition requires
another version check. CLI/Agent must not approve checks on the user's behalf.

## Commands from a project directory

```sh
wf godot-export headless-import --dry-run
wf godot-export headless-import
wf godot-export headless-run --frames 60 --dry-run
wf godot-export headless-run --frames 60
```

For a Godot project nested inside the current project:

```sh
wf godot-export headless-import --directory 'games/My Game'
wf godot-export headless-run --directory 'games/My Game' --scene scenes/main.tscn --frames 120
```

`directory` is relative to the current project (default `.`), and must contain
`project.godot`. `scene` is relative to that Godot directory, without a `res://`
prefix; omit it to use the configured main scene. Run import first to prepare
resource caches. Runs always have an iteration limit of 1–600 (default 60),
which is not a wall-clock timeout; the runtime also enforces its execution limit.
There is no arbitrary script, shell, extra-arguments or unlimited-run input.

These commands return planned `Exec` effects. A dry run does not start Godot.
Execution is high-risk and follows the client's approval policy: import can run
editor plugins/tool scripts, and run executes project code. On a request for
approval, ask the user and use the standard client flow; do not bypass it.
The selected default executable is resolved by the runtime, never by plugin code.

Inspect the execution status and log after each command. Non-zero exit, timeout
or cancellation is a failed run. Godot can print script/resource errors even
with exit code 0: a smoke test is not a full validation or a visual review.

`sync` continues to plan two existing headless steps: import textures/models,
then run the bundled resource generator. Temporary generator files are cleaned
by the host. Sync still preserves user-edited outputs unless `force` is requested.

## Exercise today's client functionality

- With no default or no version receipt, installation succeeds but commands are blocked.
- Multiple Godot installations remain selectable; their checks and versions are independent.
- A stable 4.3+ default unblocks the plugin. Older/prerelease versions do not.
- Changing the default to an unchecked installation blocks it until checked.
- Cancelling execution approval starts no Godot process.
- An approved headless import/run uses the displayed default path and fixed arguments.

The development client must support the new `tools.version` and registry fields
and plugin API 0.1.4. Older clients reject this manifest. No unreleased client
version number is invented in `plugin.cli`; use the current development client
for this acceptance release.
