//! Reads the mirror and sidecars, plans Godot CLI tasks, then reconciles guarded outputs.
use crate::{
    cli_sync,
    model::{Animation, Kit, Model3d, ParallaxMap, ParticleEffect, Scene3dMap, TileMap, WholeMap},
    paths::{self, invalid},
    reconcile,
    types::{File, Input, Node, Output, Plan, Status},
};
use plugin_api::{
    Effect, Failure,
    platform::{LockedRow, LocksInput, LocksOutput, Method, NodeInput, NodeOutput},
};
use plugin_guest::{Host, HostError, Platform};
use serde::{Serialize, de::DeserializeOwned};
use std::{collections::BTreeSet, iter::once, mem::take};

const MAX_SIDECAR: usize = 4 << 20;
const MAX_GLB: usize = 32 << 20;

enum ParsedNode {
    Animation(Animation),
    WholeMap(WholeMap),
    Parallax(Box<ParallaxMap>),
    Particle(ParticleEffect),
    Scene3d(Scene3dMap),
    Model3d(Model3d),
    TileMap(TileMap),
    Kit(Kit),
}

pub fn sync(host: &dyn Platform, input: &Input) -> Result<Plan, HostError> {
    let mut plan = Plan {
        output: Output::default(),
        effects: Vec::new(),
    };
    let locks: LocksOutput = match answer(
        host,
        Method::MirrorLocks,
        &LocksInput {
            directory: input.directory.clone(),
        },
    ) {
        Ok(locks) => locks,
        Err(error) if error.kind == Failure::NotFound && !input.nodes.is_empty() => {
            // First export: there may be no lock yet. Resolving each node still
            // rejects missing mirrors and unknown addresses before reporting it.
            selection(host, input, &[], &mut plan.output)?;
            return Ok(plan);
        }
        Err(error) => return Err(error),
    };
    let directory = locks.directory.trim_end_matches('/');
    if directory != "." && !directory.is_empty() {
        paths::relative(directory)?;
    }
    let directory = if directory == "." { "" } else { directory };
    let root = paths::root(host, directory)?;
    let selected = selection(host, input, &locks.nodes, &mut plan.output)?;
    let mut wanted = BTreeSet::new();
    let mut cli_tasks = Vec::new();
    for row in locks.nodes.iter().filter(|r| selected.contains(&r.id)) {
        let node: NodeOutput = answer(
            host,
            Method::MirrorNode,
            &NodeInput {
                address: format!("wf://{}", row.id),
            },
        )?;
        let kind = node.node.node_type;
        let mut result = Node {
            id: row.id.clone(),
            number: row.number,
            path: row.path.clone(),
            node_type: kind.clone(),
            status: Status::Skipped,
            files: Vec::new(),
            main_scene: None,
            elements: Vec::new(),
            reasons: Vec::new(),
        };
        let Some(sidecar) = sidecar(&kind, &row.form) else {
            result.reasons.push(skipped(&kind).into());
            plan.output.push_node(result, Some(&row.form));
            continue;
        };
        let candidates: Vec<_> = row
            .files
            .iter()
            .filter(|f| f.rsplit('/').next() == Some(sidecar))
            .collect();
        let [sidecar_path] = candidates.as_slice() else {
            return Err(invalid(format!(
                "#{}: expected exactly one {sidecar} in the export lock",
                row.number
            )));
        };
        paths::relative(sidecar_path)?;
        let prefix = paths::parent(sidecar_path);
        let node_dir = paths::join(directory, prefix);
        let bytes = host.read(&paths::join(directory, sidecar_path))?;
        let max_bytes = if sidecar == "engine-scene.glb" {
            MAX_GLB
        } else {
            MAX_SIDECAR
        };
        if bytes.len() > max_bytes {
            return Err(invalid("sidecar exceeds size limit; export fewer entries"));
        }
        let locked: BTreeSet<String> = row.files.iter().cloned().collect();
        let stem = paths::filename(row.path.rsplit('/').next().unwrap_or("Node"));
        let parsed = parse_node(host, row, directory, prefix, &node_dir, sidecar, &kind, &bytes, &locked)?;
        let planned = match parsed {
            ParsedNode::Animation(anim) => {
                result.reasons.extend(anim.notes.clone());
                cli_sync::plan_animation(&anim, &node_dir, &root, &stem)
            }
            ParsedNode::WholeMap(map) => cli_sync::plan_whole_map(&map, &node_dir, &root, &stem),
            ParsedNode::Parallax(map) => cli_sync::plan_parallax(&map, &node_dir, &root, &stem),
            ParsedNode::Particle(effect) => {
                result.reasons.extend(effect.notes.clone());
                cli_sync::plan_particle(&effect, &node_dir, &root, &stem)
            }
            ParsedNode::Scene3d(scene) => {
                result.reasons.extend(scene.notes.clone());
                cli_sync::plan_scene3d(&scene, &node_dir, &root, &stem)
            }
            ParsedNode::Model3d(model) => cli_sync::plan_model3d(&model, &node_dir, &root, &stem),
            ParsedNode::TileMap(map) => {
                let planned = cli_sync::plan_tilemap(&map, &node_dir, &root, &stem);
                result.reasons.extend(planned.notes.clone());
                planned
            }
            ParsedNode::Kit(kit) => {
                result.reasons.extend(kit.notes.clone());
                let mut planned = cli_sync::plan_theme(&kit, &node_dir, &root, &stem);
                result.elements = take(&mut planned.elements);
                planned
            }
        };
        if let Some(task) = cli_sync::reconcile_node(
            host,
            directory,
            &locks.nodes,
            row,
            input.force,
            planned,
            &mut wanted,
            &mut result.files,
            &mut result.main_scene,
            &mut result.reasons,
        )? {
            cli_tasks.push(task);
        }
        result.status = status(&result.files);
        plan.output.push_node(result, Some(&row.form));
    }
    cli_sync::emit_cli_effects(host, &root, cli_tasks, &mut plan.effects)?;
    leftovers(
        host,
        directory,
        &locks,
        input.nodes.is_empty(),
        &selected,
        &wanted,
        &mut plan,
    )?;
    Ok(plan)
}

#[expect(
    clippy::too_many_arguments,
    reason = "node parsing checks sidecar and locked textures"
)]
fn parse_node(
    host: &dyn Host,
    row: &LockedRow,
    directory: &str,
    prefix: &str,
    node_dir: &str,
    sidecar: &str,
    kind: &str,
    bytes: &[u8],
    locked: &BTreeSet<String>,
) -> Result<ParsedNode, HostError> {
    if sidecar == "animation.json" {
        let animation = Animation::read(bytes)?;
        textures(
            host,
            row,
            directory,
            prefix,
            animation
                .clips
                .iter()
                .flat_map(|c| &c.frames)
                .map(|f| f.texture.path.as_str()),
        )?;
        Ok(ParsedNode::Animation(animation))
    } else if sidecar == "main.json" && kind == "whole_map" {
        let map = WholeMap::read(bytes, locked, prefix)?;
        textures(host, row, directory, prefix, map.texture_paths())?;
        Ok(ParsedNode::WholeMap(map))
    } else if sidecar == "main.json" && matches!(kind, "scrolling_scene" | "scroll_map") {
        let map = ParallaxMap::read(bytes, locked, prefix)?;
        textures(host, row, directory, prefix, map.texture_paths())?;
        Ok(ParsedNode::Parallax(Box::new(map)))
    } else if sidecar == "main.json" {
        let effect = ParticleEffect::read(bytes)?;
        textures(
            host,
            row,
            directory,
            prefix,
            effect.emitters.iter().map(|e| e.picture.as_str()),
        )?;
        Ok(ParsedNode::Particle(effect))
    } else if sidecar == "engine-scene.glb" {
        Ok(ParsedNode::Scene3d(Scene3dMap::read(
            bytes,
            "engine-scene.glb".to_owned(),
        )?))
    } else if sidecar == "model.json" {
        let glb_name = "main.glb";
        textures(host, row, directory, prefix, once(glb_name))?;
        let glb_bytes = host.read(&paths::join(node_dir, glb_name))?;
        Ok(ParsedNode::Model3d(Model3d::read(
            bytes,
            &glb_bytes,
            glb_name.to_owned(),
        )?))
    } else if sidecar == "tilemap.json" {
        let map = TileMap::read(bytes)?;
        textures(
            host,
            row,
            directory,
            prefix,
            map.textures.values().map(|t| t.file.as_str()),
        )?;
        Ok(ParsedNode::TileMap(map))
    } else {
        let kit = Kit::read(bytes)?;
        textures(
            host,
            row,
            directory,
            prefix,
            kit.widgets
                .iter()
                .flat_map(|w| &w.states)
                .map(|s| s.texture.path.as_str()),
        )?;
        Ok(ParsedNode::Kit(kit))
    }
}

fn sidecar(kind: &str, form: &str) -> Option<&'static str> {
    match (kind, form) {
        ("frame_animation" | "character_effect", "frames" | "strips" | "atlas") => Some("animation.json"),
        ("ui", "pieces" | "atlas") => Some("ui.json"),
        ("tilemap", "source") => Some("tilemap.json"),
        ("particle_effect" | "whole_map" | "scrolling_scene" | "scroll_map", "source") => Some("main.json"),
        ("scene3d_map", "source") => Some("engine-scene.glb"),
        ("model_3d", "source") => Some("model.json"),
        _ => None,
    }
}
fn skipped(kind: &str) -> &'static str {
    match kind {
        "word_art" | "icon" | "music" | "sound_effect" | "voice" | "tts" | "image" => {
            "Godot imports these files directly (BMFont, textures, or audio); no generated resource is needed."
        }
        "skeletal_animation" => "Spine needs the spine-godot runtime; this plugin does not generate it.",
        "prop" => "Object scenes and collision shapes are not supported yet.",
        _ => {
            "This node type or export form has no Godot conversion; export animations as frames, strips or atlas, \
             UI kits as pieces or atlas, and maps, particles or 3D assets as source."
        }
    }
}

fn status(files: &[File]) -> Status {
    for status in [Status::Kept, Status::Updated, Status::Written, Status::Unchanged] {
        if files.iter().any(|f| f.status == status) {
            return status;
        }
    }
    Status::Skipped
}

fn selection(
    host: &dyn Platform,
    input: &Input,
    rows: &[LockedRow],
    output: &mut Output,
) -> Result<BTreeSet<String>, HostError> {
    if input.nodes.is_empty() {
        return Ok(rows.iter().map(|n| n.id.clone()).collect());
    }
    let mut selected = BTreeSet::new();
    for address in &input.nodes {
        // Prefer the exported address: HEAD may have moved or deleted the node.
        let row = rows.iter().find(|n| {
            *address == n.path || *address == format!("#{}", n.number) || *address == format!("wf://{}", n.id)
        });
        let id = if let Some(row) = row {
            row.id.clone()
        } else {
            let node: NodeOutput = answer(
                host,
                Method::MirrorNode,
                &NodeInput {
                    address: address.clone(),
                },
            )?;
            if !rows.iter().any(|n| n.id == node.node.id) {
                if !output.nodes.iter().any(|n| n.id == node.node.id) {
                    output.push_node(
                        Node {
                            id: node.node.id,
                            number: node.node.number,
                            path: node.node.path,
                            node_type: node.node.node_type,
                            status: Status::Skipped,
                            files: Vec::new(),
                            main_scene: None,
                            elements: Vec::new(),
                            reasons: vec![format!(
                                "Not in this export lock; run wf export '#{}' first.",
                                node.node.number
                            )],
                        },
                        None,
                    );
                }
                continue;
            }
            node.node.id
        };
        selected.insert(id);
    }
    Ok(selected)
}

fn textures<'a>(
    host: &dyn Host,
    row: &LockedRow,
    directory: &str,
    prefix: &str,
    paths: impl Iterator<Item = &'a str>,
) -> Result<(), HostError> {
    let locked: BTreeSet<_> = row.files.iter().map(String::as_str).collect();
    for path in paths.collect::<BTreeSet<_>>() {
        let file = paths::join(prefix, path);
        if !locked.contains(file.as_str()) {
            return Err(invalid(format!("texture {file:?} is not in the node's export lock")));
        }
        let path = paths::join(directory, &file);
        if !host.list(&paths::glob(&path)).contains(&path) {
            // VCS-ignored exports can still be read by exact path.
            host.read(&path)?;
        }
    }
    Ok(())
}

fn leftovers(
    host: &dyn Host,
    directory: &str,
    locks: &LocksOutput,
    all: bool,
    selected: &BTreeSet<String>,
    wanted: &BTreeSet<String>,
    plan: &mut Plan,
) -> Result<(), HostError> {
    let pattern = paths::join(&paths::glob(directory), "**/*.{tres,tscn}");
    let listed = host.list(&pattern);
    if listed.len() >= host.list_limit() {
        plan.output
            .warnings
            .push("Generated-file discovery reached the host listing limit; some leftovers may remain.".into());
    }
    let locked: BTreeSet<_> = locks
        .nodes
        .iter()
        .flat_map(|r| &r.files)
        .map(|f| paths::join(directory, f))
        .collect();
    for path in listed {
        if wanted.contains(&path) || locked.contains(&path) {
            continue;
        }
        let bytes = host.read(&path)?;
        if let Some(id) = reconcile::owner(&bytes)
            && (all || selected.contains(id))
        {
            paths::relative(&path)?;
            plan.output.deleted.push(path.clone());
            plan.effects.push(Effect::DeleteFile { path });
        }
    }
    plan.output.deleted.sort();
    Ok(())
}

fn answer<I: Serialize, O: DeserializeOwned>(host: &dyn Platform, method: Method, input: &I) -> Result<O, HostError> {
    let input = serde_json::to_vec(input).map_err(|e| HostError::new(Failure::Internal, e.to_string()))?;
    serde_json::from_slice(&host.call(method.name(), &input)?)
        .map_err(|e| HostError::new(Failure::Internal, format!("invalid platform answer: {e}")))
}
