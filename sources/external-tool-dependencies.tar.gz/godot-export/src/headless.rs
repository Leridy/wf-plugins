//! Explicit, fixed-argument Godot operations. Only the host executes the plan.
use crate::paths;
use plugin_api::Effect;
use plugin_guest::{Host, HostError};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use std::path::Path;

#[derive(Debug, Default, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct ImportInput {
    /// Godot project directory relative to the current project; omit for its root.
    #[serde(default)]
    pub directory: Option<String>,
}

#[derive(Debug, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct RunInput {
    /// Godot project directory relative to the current project; omit for its root.
    #[serde(default)]
    pub directory: Option<String>,
    /// Scene path relative to the Godot project, e.g. scenes/main.tscn; omit for the configured main scene.
    #[serde(default)]
    pub scene: Option<String>,
    /// Stop after this many engine iterations (1–600, default 60), not seconds.
    #[serde(default = "default_frames")]
    #[schemars(range(min = 1, max = 600))]
    pub frames: u32,
}

const fn default_frames() -> u32 {
    60
}

#[derive(Debug, Serialize, JsonSchema)]
pub struct Output {
    /// Project-relative Godot directory used by the planned command.
    pub directory: String,
    /// Selected scene, or null for import / the configured main scene.
    pub scene: Option<String>,
    /// Requested iteration limit, or null for import.
    pub frames: Option<u32>,
}

pub struct Plan {
    pub output: Output,
    pub effects: Vec<Effect>,
}

fn directory(host: &dyn Host, input: Option<&str>) -> Result<String, HostError> {
    let dir = input.unwrap_or(".");
    let relative = if dir == "." { "" } else { dir };
    if !relative.is_empty() {
        paths::relative(relative)?;
    } else if dir.is_empty() {
        return Err(paths::invalid("directory must be a project-relative path or ."));
    }
    host.read(&paths::join(relative, "project.godot"))?;
    Ok(relative.into())
}

fn args(directory: &str) -> Vec<String> {
    vec![
        "--headless".into(),
        "--path".into(),
        if directory.is_empty() {
            ".".into()
        } else {
            format!("./{directory}")
        },
    ]
}

pub fn import(host: &dyn Host, input: &ImportInput) -> Result<Plan, HostError> {
    let dir = directory(host, input.directory.as_deref())?;
    let mut args = args(&dir);
    args.extend(["--import".into(), "--quit".into()]);
    Ok(Plan {
        output: Output {
            directory: if dir.is_empty() { ".".into() } else { dir },
            scene: None,
            frames: None,
        },
        effects: vec![Effect::Exec {
            tool: "godot".into(),
            args,
            reason: "Import Godot project resources without opening a window; project editor scripts may run".into(),
        }],
    })
}

pub fn run(host: &dyn Host, input: &RunInput) -> Result<Plan, HostError> {
    if !(1..=600).contains(&input.frames) {
        return Err(paths::invalid(
            "frames must be between 1 and 600; unlimited runs are not supported",
        ));
    }
    let dir = directory(host, input.directory.as_deref())?;
    let mut args = args(&dir);
    args.extend(["--quit-after".into(), input.frames.to_string()]);
    if let Some(scene) = &input.scene {
        paths::relative(scene)?;
        if !matches!(
            Path::new(scene).extension().and_then(|s| s.to_str()),
            Some("tscn" | "scn")
        ) {
            return Err(paths::invalid("scene must be a project-relative .tscn or .scn file"));
        }
        host.read(&paths::join(&dir, scene))?;
        args.push(format!("res://{scene}"));
    }
    Ok(Plan {
        output: Output {
            directory: if dir.is_empty() { ".".into() } else { dir },
            scene: input.scene.clone(),
            frames: Some(input.frames),
        },
        effects: vec![Effect::Exec {
            tool: "godot".into(),
            args,
            reason: "Run the Godot project scene without a window, stopping after the requested iterations".into(),
        }],
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing::Fake;

    fn host() -> Fake {
        let mut host = Fake::default();
        for path in [
            "project.godot",
            "games/My Game/project.godot",
            "games/My Game/scenes/main.tscn",
        ] {
            host.files.insert(path.into(), Vec::new());
        }
        host
    }

    fn command(plan: Plan) -> Vec<String> {
        assert_eq!(plan.effects.len(), 1);
        match plan.effects.into_iter().next().unwrap() {
            Effect::Exec { tool, args, .. } => {
                assert_eq!(tool, "godot");
                args
            }
            other => panic!("unexpected effect: {other:?}"),
        }
    }

    #[test]
    fn import_only_plans_fixed_headless_arguments() {
        assert_eq!(
            command(import(&host(), &ImportInput::default()).unwrap()),
            ["--headless", "--path", ".", "--import", "--quit"]
        );
    }

    #[test]
    fn run_keeps_spaces_in_single_arguments_and_always_limits_iterations() {
        let input: RunInput =
            serde_json::from_str(r#"{"directory":"games/My Game","scene":"scenes/main.tscn"}"#).unwrap();
        assert_eq!(
            command(run(&host(), &input).unwrap()),
            [
                "--headless",
                "--path",
                "./games/My Game",
                "--quit-after",
                "60",
                "res://scenes/main.tscn"
            ]
        );
        let main: RunInput = serde_json::from_str("{}").unwrap();
        assert_eq!(
            command(run(&host(), &main).unwrap()),
            ["--headless", "--path", ".", "--quit-after", "60"]
        );
    }

    #[test]
    fn invalid_paths_missing_projects_and_unlimited_runs_produce_no_plan() {
        for dir in [
            "",
            "..",
            "../outside",
            "/Applications",
            "C:/Godot",
            "game/../escape",
            ".git",
            "missing",
        ] {
            assert!(
                import(
                    &host(),
                    &ImportInput {
                        directory: Some(dir.into())
                    }
                )
                .is_err(),
                "{dir}"
            );
        }
        for scene in [
            "../outside.tscn",
            "/tmp/main.tscn",
            "res://main.tscn",
            "--script",
            "main.gd",
            "missing.tscn",
        ] {
            let input = RunInput {
                directory: None,
                scene: Some(scene.into()),
                frames: 1,
            };
            assert!(run(&host(), &input).is_err(), "{scene}");
        }
        for frames in [0, 601, u32::MAX] {
            assert!(
                run(
                    &host(),
                    &RunInput {
                        directory: None,
                        scene: None,
                        frames
                    }
                )
                .is_err()
            );
        }
        assert!(serde_json::from_str::<RunInput>(r#"{"args":["--script","evil.gd"]}"#).is_err());
        assert!(serde_json::from_str::<ImportInput>(r#"{"args":["--editor"]}"#).is_err());
    }
}
