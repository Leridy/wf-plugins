//! Converts the local mirror's ready exports into Godot resources. Reading,
//! modeling, writing text and planning effects remain separate boundaries.
#[cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "description is called by wasm glue")
)]
mod cli_sync;
#[cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "description is called by wasm glue")
)]
mod describe;
mod gather;
mod godot;
pub mod headless;
mod model;
mod paths;
mod reconcile;
mod table;
mod types;

pub use gather::sync;
pub use types::{Element, File, Input, Node, Output, Plan, Status};

#[cfg(target_arch = "wasm32")]
mod component;
#[cfg(test)]
mod testing;
