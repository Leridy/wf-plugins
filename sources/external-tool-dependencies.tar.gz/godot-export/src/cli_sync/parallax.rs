//! Translates `ParallaxMap` validated models into CLI specs.
use super::specs::{
    ParallaxArtSpec, ParallaxBackdropSpec, ParallaxClimbSpec, ParallaxHazardSpec, ParallaxItemSpec, ParallaxLayerSpec,
    ParallaxLevelSpec, ParallaxMarkerSpec, ParallaxRectSpec, ParallaxSlopeSpec, ParallaxSpec,
};
use crate::{
    godot::{doc::safe_node_name, parallax::MOTION_SCRIPT},
    model::{
        ParallaxMap,
        parallax::{LayerPlacement, Level, RepeatAxis, Whitebox},
    },
    paths,
};
use std::collections::{BTreeMap, BTreeSet};

pub(super) fn build_parallax_spec(map: &ParallaxMap, node_dir: &str, root: &str) -> ParallaxSpec {
    let sprite_res: BTreeMap<&str, String> = map
        .sprites
        .iter()
        .map(|s| (s.id.as_str(), paths::resource(root, &paths::join(node_dir, &s.file))))
        .collect();
    let bounds = map.world_bounds();
    let inv_ratio = 1.0 / f64::from(map.pixel_ratio.max(1));
    let mut has_motion = false;
    let mut used = BTreeSet::new();
    let layers = map
        .layers
        .iter()
        .enumerate()
        .map(|(idx, l)| {
            let name = safe_node_name(&l.name, idx + 1, "Layer", &mut used);
            let repeat_x = f64::from(l.items.iter().find_map(|i| i.repeat_span).unwrap_or(0));
            let items = l
                .items
                .iter()
                .map(|it| {
                    let animated =
                        it.motion.drift != 0.0 || it.motion.bob.amplitude != 0.0 || it.motion.sway.degrees != 0.0;
                    has_motion |= animated;
                    let sx = it.scale * inv_ratio * if it.flip_x { -1.0 } else { 1.0 };
                    let sy = it.scale * inv_ratio;
                    ParallaxItemSpec {
                        id: it.id.clone(),
                        tex_res: sprite_res[it.sprite_id.as_str()].clone(),
                        position: [it.x, it.y],
                        scale: [sx, sy],
                        opacity: it.opacity,
                        animated,
                        drift: it.motion.drift,
                        bob_amplitude: it.motion.bob.amplitude,
                        bob_period: it.motion.bob.period,
                        sway_degrees: it.motion.sway.degrees,
                        sway_period: it.motion.sway.period,
                    }
                })
                .collect();
            ParallaxLayerSpec {
                parent: match l.placement {
                    LayerPlacement::Behind => "BehindLayers",
                    LayerPlacement::Front => "FrontLayers",
                },
                name,
                speed: l.speed,
                repeat_x,
                visible: l.visible,
                opacity: l.opacity,
                id: l.id.clone(),
                items,
            }
        })
        .collect();
    let repeat_x = if map.backdrop.repeat_axis == RepeatAxis::X {
        f64::from(map.backdrop.width)
    } else {
        0.0
    };
    let repeat_y = if map.backdrop.repeat_axis == RepeatAxis::Y {
        f64::from(map.backdrop.height)
    } else {
        0.0
    };
    ParallaxSpec {
        motion_script: has_motion.then_some(MOTION_SCRIPT),
        progression: map.progression.clone(),
        view: map.view.clone(),
        speed: map.speed,
        pixel_ratio: map.pixel_ratio,
        inv_ratio,
        world_bounds: [bounds.x, bounds.y, bounds.width, bounds.height],
        backdrop: ParallaxBackdropSpec {
            speed: map.backdrop.speed,
            repeat_size: [repeat_x, repeat_y],
            drift: map.backdrop.drift,
            visible: map.backdrop.visible,
            tex_res: paths::resource(root, &paths::join(node_dir, &map.backdrop.file)),
            opacity: map.backdrop.opacity,
        },
        layers,
        level: map
            .level
            .as_ref()
            .map(|lv| build_parallax_level(lv, &map.art_files, node_dir, root)),
    }
}

fn build_parallax_level(
    lv: &Level,
    art_files: &BTreeMap<String, String>,
    node_dir: &str,
    root: &str,
) -> ParallaxLevelSpec {
    let wb = &lv.whitebox;
    let mut art_sprites = Vec::new();
    for (i, g) in lv.kit.groups.iter().enumerate() {
        if let Some(resolved) = art_files.get(&g.file) {
            art_sprites.push(ParallaxArtSpec {
                name: format!("Terrain{}", i + 1),
                position: [f64::from(g.image.x), f64::from(g.image.y)],
                tex_res: paths::resource(root, &paths::join(node_dir, resolved)),
                z_index: None,
            });
        }
    }
    for (i, slot) in wb.slots.iter().enumerate() {
        let Some(art) = lv.kit.objects.iter().find(|o| o.kind == slot.kind) else {
            continue;
        };
        let Some(resolved) = art_files.get(&art.file) else {
            continue;
        };
        let z = if wb
            .slot_kinds
            .iter()
            .find(|k| k.id == slot.kind)
            .is_some_and(|k| k.depth == "front")
        {
            5
        } else {
            -1
        };
        art_sprites.push(ParallaxArtSpec {
            name: format!("Slot{}", i + 1),
            position: [f64::from(slot.x) - art.anchor, f64::from(slot.y) - art.base],
            tex_res: paths::resource(root, &paths::join(node_dir, resolved)),
            z_index: Some(z),
        });
    }
    let (rects, slopes) = build_whitebox_collisions(wb);
    let climbs = wb
        .climbs
        .iter()
        .enumerate()
        .map(|(i, c)| {
            let h = f64::from((c.bottom - c.top).abs().max(1));
            ParallaxClimbSpec {
                name: format!("Climb{}", i + 1),
                id: c.id.clone(),
                center: [f64::from(c.x), f64::from(c.top.min(c.bottom)) + h * 0.5],
                height: h,
            }
        })
        .collect();
    let hazards = wb
        .hazards
        .iter()
        .enumerate()
        .map(|(i, h)| ParallaxHazardSpec {
            name: format!("Hazard{}", i + 1),
            kind: h.kind.clone(),
            center: [
                f64::from(h.x) + f64::from(h.width) * 0.5,
                f64::from(h.y) + f64::from(h.height) * 0.5,
            ],
            size: [f64::from(h.width.max(1)), f64::from(h.height.max(1))],
        })
        .collect();
    let mut markers = vec![
        ParallaxMarkerSpec {
            name: "Spawn".into(),
            position: [f64::from(wb.markers.spawn.x), f64::from(wb.markers.spawn.y)],
            id: None,
        },
        ParallaxMarkerSpec {
            name: "Exit".into(),
            position: [f64::from(wb.markers.exit.x), f64::from(wb.markers.exit.y)],
            id: None,
        },
    ];
    for (i, cp) in wb.markers.checkpoints.iter().enumerate() {
        markers.push(ParallaxMarkerSpec {
            name: format!("Checkpoint{}", i + 1),
            position: [f64::from(cp.x), f64::from(cp.y)],
            id: Some(cp.id.clone()),
        });
    }
    for (i, col) in wb.markers.collectibles.iter().enumerate() {
        markers.push(ParallaxMarkerSpec {
            name: format!("Collectible{}", i + 1),
            position: [f64::from(col.x), f64::from(col.y)],
            id: Some(col.id.clone()),
        });
    }
    ParallaxLevelSpec {
        speed: lv.physics.speed,
        jump: lv.physics.jump,
        gravity: lv.physics.gravity,
        climb: lv.physics.climb,
        character_height: lv.physics.character_height,
        collision_size: [
            f64::from(lv.physics.collision_width),
            f64::from(lv.physics.collision_height),
        ],
        art_sprites,
        rects,
        slopes,
        climbs,
        hazards,
        markers,
    }
}

fn build_whitebox_collisions(wb: &Whitebox) -> (Vec<ParallaxRectSpec>, Vec<ParallaxSlopeSpec>) {
    let mut rects = Vec::new();
    let mut slopes = Vec::new();
    if wb.collisions.is_empty() {
        for (i, row) in wb.rows.iter().enumerate() {
            let w = f64::from(row.resolved_width().max(1));
            let h = f64::from(row.height.max(1));
            rects.push(ParallaxRectSpec {
                name: format!("Row_{}", i + 1),
                center: [f64::from(row.x) + w * 0.5, f64::from(row.y) + h * 0.5],
                size: [w, h],
                one_way: true,
            });
        }
        for (i, solid) in wb.solids.iter().enumerate() {
            let w = f64::from(solid.width.max(1));
            let h = f64::from(solid.height.max(1));
            rects.push(ParallaxRectSpec {
                name: format!("Solid_{}", i + 1),
                center: [f64::from(solid.x) + w * 0.5, f64::from(solid.y) + h * 0.5],
                size: [w, h],
                one_way: false,
            });
        }
        for (i, sl) in wb.slopes.iter().enumerate() {
            let (left_y, right_y) = if sl.direction == "up" {
                (sl.y + sl.height, sl.y)
            } else {
                (sl.y, sl.y + sl.height)
            };
            let bottom = sl.y + sl.height;
            slopes.push(ParallaxSlopeSpec {
                name: format!("Slope_{}", i + 1),
                points: vec![
                    [f64::from(sl.x), f64::from(bottom)],
                    [f64::from(sl.x), f64::from(left_y)],
                    [f64::from(sl.x + sl.width), f64::from(right_y)],
                    [f64::from(sl.x + sl.width), f64::from(bottom)],
                ],
            });
        }
        return (rects, slopes);
    }
    for (i, col) in wb.collisions.iter().enumerate() {
        if col.bodies.is_empty() {
            let w = col.bounds.width.max(1.0);
            let h = col.bounds.height.max(1.0);
            rects.push(ParallaxRectSpec {
                name: format!("Col_{}", i + 1),
                center: [col.bounds.x + w * 0.5, col.bounds.y + h * 0.5],
                size: [w, h],
                one_way: false,
            });
        } else {
            for (bi, body) in col.bodies.iter().enumerate() {
                let w = body.width.max(1.0);
                let h = body.height.max(1.0);
                rects.push(ParallaxRectSpec {
                    name: format!("Col_{}_{}", i + 1, bi + 1),
                    center: [col.bounds.x + body.x + w * 0.5, col.bounds.y + body.y + h * 0.5],
                    size: [w, h],
                    one_way: false,
                });
            }
        }
    }
    (rects, slopes)
}
