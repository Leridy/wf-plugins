//! Typed manifest specs serialized for `wf_sync.gd`.
use serde::Serialize;
use serde_json::{Map, Value};
use std::collections::BTreeMap;

#[derive(Clone, Serialize)]
pub(super) struct Target {
    pub res_path: String,
    #[serde(skip)]
    pub rel_path: String,
    #[serde(skip)]
    pub suffix: &'static str,
    #[serde(skip)]
    pub main_scene: bool,
    pub write: bool,
}

pub(super) enum SpecBuilder {
    Animation(Vec<AnimClipSpec>),
    Theme(Vec<ThemeVarSpec>),
    TileMap(TileMapSpec),
    Particle2d(Particle2dSpec),
    Particle3d(Particle3dSpec),
    WholeMap(WholeMapSpec),
    Parallax(ParallaxSpec),
    Scene3d(Scene3dSpec),
    Model3d(Model3dSpec),
}

impl SpecBuilder {
    pub(super) fn canonical_json(&self) -> Result<Value, String> {
        let map_err = |e| format!("spec serialize error: {e}");
        match self {
            Self::Animation(v) => serde_json::to_value(v).map_err(map_err),
            Self::Theme(v) => serde_json::to_value(v).map_err(map_err),
            Self::TileMap(v) => serde_json::to_value(v).map_err(map_err),
            Self::Particle2d(v) => serde_json::to_value(v).map_err(map_err),
            Self::Particle3d(v) => serde_json::to_value(v).map_err(map_err),
            Self::WholeMap(v) => serde_json::to_value(v).map_err(map_err),
            Self::Parallax(v) => serde_json::to_value(v).map_err(map_err),
            Self::Scene3d(v) => serde_json::to_value(v).map_err(map_err),
            Self::Model3d(v) => serde_json::to_value(v).map_err(map_err),
        }
    }

    pub(super) fn into_godot_spec(self, targets: &[Target]) -> Result<Value, String> {
        let mut val = self.canonical_json()?;
        if !val.is_object() {
            let mut map = Map::new();
            match self {
                Self::Animation(_) => {
                    map.insert("clips".into(), val.take());
                }
                Self::Theme(_) => {
                    map.insert("variations".into(), val.take());
                }
                _ => return Err("non-object spec kind".into()),
            }
            val = Value::Object(map);
        }
        let obj = val.as_object_mut().ok_or("spec is not object")?;
        let to_val = |t: &Target| serde_json::to_value(t).map_err(|e| format!("target serialize: {e}"));
        match targets {
            [first] if first.suffix == ".theme.tres" => {
                obj.insert("theme_target".into(), to_val(first)?);
            }
            [first] => {
                obj.insert("scene_target".into(), to_val(first)?);
            }
            [first, second] if first.suffix == ".sprite_frames.tres" => {
                obj.insert("sprite_frames_target".into(), to_val(first)?);
                obj.insert("scene_target".into(), to_val(second)?);
            }
            [first, second] if first.suffix == ".tileset.tres" => {
                obj.insert("tileset_target".into(), to_val(first)?);
                obj.insert("scene_target".into(), to_val(second)?);
            }
            _ => return Err("unexpected target list for CLI task".into()),
        }
        Ok(val)
    }
}

#[derive(Serialize)]
pub(super) struct AnimClipSpec {
    pub name: String,
    pub fps: f64,
    pub looped: bool,
    pub anchor: [f64; 2],
    pub frames: Vec<AnimFrameSpec>,
}

#[derive(Serialize)]
pub(super) struct AnimFrameSpec {
    pub tex_res: String,
    pub region: Option<[f64; 4]>,
    pub duration: f64,
}

#[derive(Serialize)]
pub(super) struct ThemeVarSpec {
    pub name: String,
    pub base_type: &'static str,
    pub focus_empty: bool,
    pub states: Vec<ThemeStateSpec>,
}

#[derive(Serialize)]
pub(super) struct ThemeStateSpec {
    pub category: &'static str,
    pub slot: &'static str,
    pub tex_res: String,
    pub region: Option<[f64; 4]>,
    pub slice: [f64; 4],
    pub content: Option<[f64; 4]>,
}

#[derive(Serialize)]
pub(super) struct TileMapSpec {
    pub root_name: String,
    pub tile_width: i64,
    pub tile_height: i64,
    pub isometric: bool,
    pub offset: [f64; 2],
    pub sources: Vec<TileSourceSpec>,
    pub terrains: Vec<TileTerrainSpec>,
    pub levels: Vec<TileLevelSpec>,
    pub sprites: Vec<TileSpriteSpec>,
    pub obstacles: Vec<TileObstacleSpec>,
    pub walkable: Vec<Vec<[f64; 2]>>,
    pub spawn: Option<[f64; 2]>,
}

#[derive(Serialize)]
pub(super) struct TileSourceSpec {
    pub id: u16,
    pub tex_res: String,
    pub coords: Vec<[u16; 2]>,
}

#[derive(Serialize)]
pub(super) struct TileTerrainSpec {
    pub set: String,
    pub terrain: String,
    pub tiles: BTreeMap<String, Vec<[u16; 3]>>,
}

#[derive(Serialize)]
pub(super) struct TileLevelSpec {
    pub level: u32,
    pub opacity: f64,
    pub cells: Vec<[i64; 5]>,
}

#[derive(Serialize)]
pub(super) struct TileSpriteSpec {
    pub id: String,
    pub tex_res: String,
    pub position: [f64; 2],
    pub rotation: f64,
    pub scale: Option<[f64; 2]>,
    pub opacity: f64,
    pub offset: [f64; 2],
    pub region: Option<[f64; 4]>,
}

#[derive(Serialize)]
pub(super) struct TileObstacleSpec {
    pub kind: String,
    pub points: Vec<[f64; 2]>,
}

#[derive(Serialize)]
pub(super) struct Particle2dSpec {
    pub player_script: &'static str,
    pub duration: f64,
    pub looping: bool,
    pub planar: bool,
    pub emitters: Vec<Particle2dEmitterSpec>,
}

#[derive(Serialize)]
pub(super) struct Particle2dEmitterSpec {
    pub id: String,
    pub name: String,
    pub random_state: u32,
    pub rate: f64,
    pub burst: u32,
    pub delay: f64,
    pub lifetime: [f64; 2],
    pub position: [f64; 3],
    pub spread: [f64; 3],
    pub velocity: [f64; 3],
    pub velocity_spread: [f64; 3],
    pub gravity: [f64; 3],
    pub drag: f64,
    pub size: Vec<f64>,
    pub opacity: Vec<f64>,
    pub color: Vec<String>,
    pub additive: bool,
    pub tex_res: String,
    pub sprite: bool,
    pub orientation: &'static str,
    pub tilt: f64,
    pub flip: bool,
    pub size_jitter: f64,
    pub stretch: f64,
    pub radial: Option<ParticleRadialSpec>,
    pub ground: Option<ParticleGroundSpec>,
    pub triggers: Vec<ParticleTriggerSpec>,
    pub max_particles: u32,
}

#[derive(Serialize)]
pub(super) struct ParticleRadialSpec {
    pub speed: [f64; 2],
    pub radius: [f64; 2],
    pub cone: f64,
}

#[derive(Serialize)]
pub(super) struct ParticleGroundSpec {
    pub bounce: f64,
    pub friction: f64,
    pub kill: bool,
}

#[derive(Serialize)]
pub(super) struct ParticleTriggerSpec {
    pub on: &'static str,
    pub emitter: String,
    pub count: u32,
    pub inherit: f64,
}

#[derive(Serialize)]
pub(super) struct Particle3dSpec {
    pub one_shot: bool,
    pub has_ground: bool,
    pub emitters: Vec<Particle3dEmitterSpec>,
}

#[derive(Serialize)]
pub(super) struct Particle3dEmitterSpec {
    pub node_name: String,
    pub id: String,
    pub name: String,
    pub amount: u32,
    pub lifetime: f64,
    pub explosiveness: f64,
    pub align_velocity: bool,
    pub draw_view_depth: bool,
    pub sub_target: Option<String>,
    pub position: [f64; 3],
    pub spread: [f64; 3],
    pub gravity: [f64; 3],
    pub lifetime_randomness: Option<f64>,
    pub direction: [f64; 3],
    pub launch_spread: f64,
    pub speed_min: f64,
    pub speed_max: f64,
    pub damping: Option<f64>,
    pub angle_min: f64,
    pub angle_max: f64,
    pub curve_points: Vec<[f64; 4]>,
    pub scale_min: f64,
    pub scale_max: f64,
    pub gradient_stops: Vec<GradientStopSpec>,
    pub ground: Option<ParticleGroundSpec>,
    pub trigger: Option<Particle3dTriggerSpec>,
    pub tex_res: String,
    pub additive: bool,
}

#[derive(Serialize)]
pub(super) struct GradientStopSpec {
    pub offset: f64,
    pub color: [f64; 4],
}

#[derive(Serialize)]
pub(super) struct Particle3dTriggerSpec {
    pub on: &'static str,
    pub count: u32,
    pub keep_velocity: bool,
}

#[derive(Serialize)]
pub(super) struct WholeMapSpec {
    pub perspective: String,
    pub tile_width: i64,
    pub tile_height: i64,
    pub origin_x: i64,
    pub origin_y: i64,
    pub width: i64,
    pub height: i64,
    pub character_radius: i64,
    pub character_speed: i64,
    pub mask_shader: Option<&'static str>,
    pub tiles: Vec<WholeTileSpec>,
    pub parts: Vec<WholePartSpec>,
    pub nav_layers: Vec<WholeNavSpec>,
    pub blocks: Vec<WholeBlockSpec>,
    pub regions: Vec<WholeRegionSpec>,
    pub connections: Vec<WholeConnSpec>,
}

#[derive(Serialize)]
pub(super) struct WholeTileSpec {
    pub grid_x: i64,
    pub grid_y: i64,
    pub x: i64,
    pub y: i64,
    pub width: i64,
    pub height: i64,
    pub key: String,
    pub base_res: String,
    pub mask_res: Option<String>,
}

#[derive(Serialize)]
pub(super) struct WholePartSpec {
    pub parent: &'static str,
    pub node_name: String,
    pub id: String,
    pub tex_res: String,
    pub position: [f64; 2],
    pub offset: [f64; 2],
    pub draw_order: i64,
}

#[derive(Serialize)]
pub(super) struct WholeNavSpec {
    pub id: String,
    pub name: String,
    pub role: &'static str,
    pub z: i64,
    pub rects: Vec<[i64; 4]>,
}

#[derive(Serialize)]
pub(super) struct WholeBlockSpec {
    pub part_id: String,
    pub points: Vec<[f64; 2]>,
}

#[derive(Serialize)]
pub(super) struct WholeRegionSpec {
    pub id: String,
    pub polygon: Vec<[f64; 2]>,
}

#[derive(Serialize)]
pub(super) struct WholeConnSpec {
    pub id: String,
    pub kind: &'static str,
    pub from: String,
    pub to: String,
    pub a: [f64; 2],
    pub b: [f64; 2],
    pub zone: Vec<[f64; 2]>,
}

#[derive(Serialize)]
pub(super) struct ParallaxSpec {
    pub motion_script: Option<&'static str>,
    pub progression: String,
    pub view: String,
    pub speed: f64,
    pub pixel_ratio: u32,
    pub inv_ratio: f64,
    pub world_bounds: [f64; 4],
    pub backdrop: ParallaxBackdropSpec,
    pub layers: Vec<ParallaxLayerSpec>,
    pub level: Option<ParallaxLevelSpec>,
}

#[derive(Serialize)]
pub(super) struct ParallaxBackdropSpec {
    pub speed: f64,
    pub repeat_size: [f64; 2],
    pub drift: f64,
    pub visible: bool,
    pub tex_res: String,
    pub opacity: f64,
}

#[derive(Serialize)]
pub(super) struct ParallaxLayerSpec {
    pub parent: &'static str,
    pub name: String,
    pub speed: f64,
    pub repeat_x: f64,
    pub visible: bool,
    pub opacity: f64,
    pub id: String,
    pub items: Vec<ParallaxItemSpec>,
}

#[derive(Serialize)]
pub(super) struct ParallaxItemSpec {
    pub id: String,
    pub tex_res: String,
    pub position: [f64; 2],
    pub scale: [f64; 2],
    pub opacity: f64,
    pub animated: bool,
    pub drift: f64,
    pub bob_amplitude: f64,
    pub bob_period: f64,
    pub sway_degrees: f64,
    pub sway_period: f64,
}

#[derive(Serialize)]
pub(super) struct ParallaxLevelSpec {
    pub speed: f64,
    pub jump: f64,
    pub gravity: f64,
    pub climb: f64,
    pub character_height: i32,
    pub collision_size: [f64; 2],
    pub art_sprites: Vec<ParallaxArtSpec>,
    pub rects: Vec<ParallaxRectSpec>,
    pub slopes: Vec<ParallaxSlopeSpec>,
    pub climbs: Vec<ParallaxClimbSpec>,
    pub hazards: Vec<ParallaxHazardSpec>,
    pub markers: Vec<ParallaxMarkerSpec>,
}

#[derive(Serialize)]
pub(super) struct ParallaxArtSpec {
    pub name: String,
    pub position: [f64; 2],
    pub tex_res: String,
    pub z_index: Option<i32>,
}

#[derive(Serialize)]
pub(super) struct ParallaxRectSpec {
    pub name: String,
    pub center: [f64; 2],
    pub size: [f64; 2],
    pub one_way: bool,
}

#[derive(Serialize)]
pub(super) struct ParallaxSlopeSpec {
    pub name: String,
    pub points: Vec<[f64; 2]>,
}

#[derive(Serialize)]
pub(super) struct ParallaxClimbSpec {
    pub name: String,
    pub id: String,
    pub center: [f64; 2],
    pub height: f64,
}

#[derive(Serialize)]
pub(super) struct ParallaxHazardSpec {
    pub name: String,
    pub kind: String,
    pub center: [f64; 2],
    pub size: [f64; 2],
}

#[derive(Serialize)]
pub(super) struct ParallaxMarkerSpec {
    pub name: String,
    pub position: [f64; 2],
    pub id: Option<String>,
}

#[derive(Serialize)]
pub(super) struct Scene3dSpec {
    pub glb_res: String,
    pub blocked_doors: Vec<String>,
    pub ambient_intensity: f64,
    pub ambient_color: Option<[f64; 3]>,
    pub fog_color: Option<[f64; 3]>,
    pub fog_density: f64,
    pub colliders: Vec<Scene3dColliderSpec>,
    pub roles: Vec<Scene3dRoleSpec>,
}

#[derive(Serialize)]
pub(super) struct Scene3dColliderSpec {
    pub name: String,
    pub center: [f64; 3],
    pub size: [f64; 3],
    pub room: Option<String>,
}

#[derive(Serialize)]
pub(super) struct Scene3dRoleSpec {
    pub name: String,
    pub is_trigger: bool,
    pub role: String,
    pub id: Option<String>,
    pub center: [f64; 3],
    pub size: [f64; 3],
    pub forward: [f64; 3],
    pub blocked: bool,
    pub transform: [f64; 12],
}

#[derive(Serialize)]
pub(super) struct Model3dSpec {
    pub glb_res: String,
    pub height: f64,
    pub bottom: f64,
    pub bounds_min: [f64; 3],
    pub bounds_max: [f64; 3],
    pub bones_json: String,
    pub collider_kind: &'static str,
    pub collider_center: [f64; 3],
    pub radius: f64,
    pub collider_height: f64,
    pub size: [f64; 3],
    pub sockets: Vec<ModelSocketSpec>,
    pub clips: Vec<ModelClipSpec>,
}

#[derive(Serialize)]
pub(super) struct ModelSocketSpec {
    pub name: String,
    pub raw_name: String,
    pub position: [f64; 3],
    pub bone: Option<String>,
}

#[derive(Serialize)]
pub(super) struct ModelClipSpec {
    pub name: String,
    pub raw_name: String,
    pub duration: f64,
    pub loops: Option<bool>,
    pub travel: Option<[f64; 3]>,
    pub sole_low: Option<f64>,
    pub sole_high: Option<f64>,
    pub liftoffs: Option<u32>,
    pub checks: Vec<String>,
}
