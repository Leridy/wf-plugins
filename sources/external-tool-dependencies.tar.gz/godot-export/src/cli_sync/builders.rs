//! Translates TileMap, Particle, and WholeMap validated models into CLI specs.
use super::specs::{
    GradientStopSpec, Particle2dEmitterSpec, Particle2dSpec, Particle3dEmitterSpec, Particle3dSpec,
    Particle3dTriggerSpec, ParticleGroundSpec, ParticleRadialSpec, ParticleTriggerSpec, TileLevelSpec, TileMapSpec,
    TileObstacleSpec, TileSourceSpec, TileSpriteSpec, TileTerrainSpec, WholeBlockSpec, WholeConnSpec, WholeMapSpec,
    WholeNavSpec, WholePartSpec, WholeRegionSpec, WholeTileSpec,
};
use crate::{
    godot::{
        doc::safe_node_name,
        particle::PLAYER as PARTICLE_PLAYER,
        particle3d::{curve_points, emission, gradient_stops, launch, node_names},
        tilemap::{PreparedTileMap, node_name as tilemap_node_name, same, tidy},
        whole_map::MASK_SHADER,
    },
    model::{
        Area, Blend, Event, Orientation, ParticleEffect, Point, Space, TileMap, WholeMap,
        whole_map::{CellRect, ConnectionKind, LayerRole, SortMode},
    },
    paths,
};
use std::collections::{BTreeMap, BTreeSet};

pub(super) fn build_tilemap_spec(
    map: &TileMap,
    prepared: &PreparedTileMap,
    node_dir: &str,
    root: &str,
    stem: &str,
) -> TileMapSpec {
    let by_id: BTreeMap<u16, &String> = prepared.atlas.sources.iter().map(|(k, id)| (*id, k)).collect();
    let sources = by_id
        .into_iter()
        .map(|(id, key)| TileSourceSpec {
            id,
            tex_res: paths::resource(root, &paths::join(node_dir, &map.textures[key].file)),
            coords: prepared
                .atlas
                .tiles
                .get(&id)
                .into_iter()
                .flatten()
                .map(|&(x, y)| [x, y])
                .collect(),
        })
        .collect();
    let terrains = prepared
        .terrains
        .iter()
        .map(|t| TileTerrainSpec {
            set: t.set.clone(),
            terrain: t.terrain.clone(),
            tiles: t
                .by_mask
                .iter()
                .map(|(mask, tiles)| (mask.to_string(), tiles.clone()))
                .collect(),
        })
        .collect();
    let levels = prepared
        .levels
        .iter()
        .map(|(level, cells)| TileLevelSpec {
            level: *level,
            opacity: prepared.opacity.get(level).copied().unwrap_or(1.0),
            cells: cells
                .iter()
                .map(|([x, y], (s, ax, ay))| [*x, *y, i64::from(*s), i64::from(*ax), i64::from(*ay)])
                .collect(),
        })
        .collect();
    let sprites = map
        .sprites
        .iter()
        .map(|sp| {
            let texture = &map.textures[&sp.texture];
            let source = sp.source.unwrap_or(Area {
                x: 0.0,
                y: 0.0,
                width: texture.width,
                height: texture.height,
            });
            let (sx, sy) = (sp.rect.width / source.width, sp.rect.height / source.height);
            let flip = if sp.flip_x { -1.0 } else { 1.0 };
            let scale = if !same(sx, 1.0) || !same(sy, 1.0) || sp.flip_x {
                Some([tidy(sx * flip), tidy(sy)])
            } else {
                None
            };
            TileSpriteSpec {
                id: sp.id.clone(),
                tex_res: paths::resource(root, &paths::join(node_dir, &texture.file)),
                position: [sp.position.x, sp.position.y],
                rotation: if sp.rotation == 0.0 {
                    0.0
                } else {
                    tidy(sp.rotation.to_radians())
                },
                scale,
                opacity: sp.opacity,
                offset: [tidy(sp.rect.x / sx), tidy(sp.rect.y / sy)],
                region: sp.source.map(|_| [source.x, source.y, source.width, source.height]),
            }
        })
        .collect();
    let obstacles = map
        .obstacles
        .iter()
        .filter(|o| o.points.len() >= 3)
        .map(|o| TileObstacleSpec {
            kind: o.kind.clone(),
            points: points_xy(&o.points),
        })
        .collect();
    let walkable = map
        .walkable
        .iter()
        .filter(|ring| ring.len() >= 3)
        .map(|ring| points_xy(ring))
        .collect();
    TileMapSpec {
        root_name: tilemap_node_name(stem),
        tile_width: map.tile_width as i64,
        tile_height: map.tile_height as i64,
        isometric: map.orientation == Orientation::Isometric,
        offset: [prepared.offset.0, prepared.offset.1],
        sources,
        terrains,
        levels,
        sprites,
        obstacles,
        walkable,
        spawn: map.spawn.map(|p| [p.x, p.y]),
    }
}

pub(super) fn build_particle2d_spec(effect: &ParticleEffect, node_dir: &str, root: &str) -> Particle2dSpec {
    Particle2dSpec {
        player_script: PARTICLE_PLAYER,
        duration: effect.duration,
        looping: effect.looping,
        planar: effect.space == Space::Planar,
        emitters: effect
            .emitters
            .iter()
            .map(|e| Particle2dEmitterSpec {
                id: e.id.clone(),
                name: e.name.clone(),
                random_state: e.random_state,
                rate: e.rate,
                burst: e.burst,
                delay: e.delay,
                lifetime: e.lifetime,
                position: e.position,
                spread: e.spread,
                velocity: e.velocity,
                velocity_spread: e.velocity_spread,
                gravity: e.gravity,
                drag: e.drag,
                size: e.size.clone(),
                opacity: e.opacity.clone(),
                color: e.color.clone(),
                additive: e.blend == Blend::Additive,
                tex_res: paths::resource(root, &paths::join(node_dir, &e.picture)),
                sprite: e.sprite,
                orientation: e.orientation.as_str(),
                tilt: e.tilt,
                flip: e.flip,
                size_jitter: e.size_jitter,
                stretch: e.stretch,
                radial: e.radial.as_ref().map(|r| ParticleRadialSpec {
                    speed: r.speed,
                    radius: r.radius,
                    cone: r.cone,
                }),
                ground: e.ground.as_ref().map(|g| ParticleGroundSpec {
                    bounce: g.bounce,
                    friction: g.friction,
                    kill: g.kill,
                }),
                triggers: e
                    .triggers
                    .iter()
                    .map(|t| ParticleTriggerSpec {
                        on: t.on.as_str(),
                        emitter: t.emitter.clone(),
                        count: t.count,
                        inherit: t.inherit,
                    })
                    .collect(),
                max_particles: e.max_particles,
            })
            .collect(),
    }
}

pub(super) fn build_particle3d_spec(effect: &ParticleEffect, node_dir: &str, root: &str) -> Particle3dSpec {
    let names = node_names(&effect.emitters);
    let emitters = effect
        .emitters
        .iter()
        .zip(&names)
        .map(|(e, name)| {
            let (amount, explosiveness) = emission(e);
            let (direction, launch_spread, speed) = launch(e);
            let sub_target = e.triggers.first().and_then(|t| {
                effect
                    .emitters
                    .iter()
                    .position(|o| o.id == t.emitter)
                    .map(|i| names[i].clone())
            });
            let damping = if e.drag > 0.0 {
                Some(e.drag * (speed[0] + speed[1]) / 4.0)
            } else {
                None
            };
            let (angle_min, angle_max) = match e.orientation.as_str() {
                "random" => (-180.0, 180.0),
                _ => (-e.tilt, e.tilt),
            };
            let largest = e.size.iter().copied().fold(0.0, f64::max);
            let fill = if e.sprite { 248.0 / 256.0 } else { 1.0 };
            Particle3dEmitterSpec {
                node_name: name.clone(),
                id: e.id.clone(),
                name: e.name.clone(),
                amount,
                lifetime: e.lifetime[1],
                explosiveness,
                align_velocity: e.orientation.as_str() == "velocity",
                draw_view_depth: e.blend == Blend::Normal,
                sub_target,
                position: e.position,
                spread: e.spread,
                gravity: e.gravity,
                lifetime_randomness: if e.lifetime[0] < e.lifetime[1] {
                    Some(((1.0 - e.lifetime[0] / e.lifetime[1]) * 1e6).round() / 1e6)
                } else {
                    None
                },
                direction,
                launch_spread,
                speed_min: speed[0],
                speed_max: speed[1],
                damping,
                angle_min,
                angle_max,
                curve_points: curve_points(&e.size, largest),
                scale_min: largest * fill * (1.0 - e.size_jitter),
                scale_max: largest * fill * (1.0 + e.size_jitter),
                gradient_stops: gradient_stops(e)
                    .into_iter()
                    .map(|(offset, color)| GradientStopSpec { offset, color })
                    .collect(),
                ground: e.ground.as_ref().map(|g| ParticleGroundSpec {
                    bounce: g.bounce,
                    friction: g.friction,
                    kill: g.kill,
                }),
                trigger: e.triggers.first().map(|t| Particle3dTriggerSpec {
                    on: match t.on {
                        Event::Death => "death",
                        Event::Land => "land",
                    },
                    count: t.count,
                    keep_velocity: t.inherit >= 0.5,
                }),
                tex_res: paths::resource(root, &paths::join(node_dir, &e.picture)),
                additive: e.blend == Blend::Additive,
            }
        })
        .collect();
    Particle3dSpec {
        one_shot: !effect.looping,
        has_ground: effect.emitters.iter().any(|e| e.ground.is_some()),
        emitters,
    }
}

pub(super) fn build_whole_map_spec(map: &WholeMap, node_dir: &str, root: &str) -> WholeMapSpec {
    let has_masks = map.tiles.iter().any(|t| t.mask_file.is_some());
    let tiles = map
        .tiles
        .iter()
        .map(|t| WholeTileSpec {
            grid_x: t.grid_x,
            grid_y: t.grid_y,
            x: t.x,
            y: t.y,
            width: t.width,
            height: t.height,
            key: t.key.clone(),
            base_res: paths::resource(root, &paths::join(node_dir, &t.base_file)),
            mask_res: t
                .mask_file
                .as_ref()
                .map(|m| paths::resource(root, &paths::join(node_dir, m))),
        })
        .collect();
    let mut used = BTreeSet::new();
    let parts = map
        .parts
        .iter()
        .enumerate()
        .map(|(idx, p)| WholePartSpec {
            parent: match p.sort_mode {
                SortMode::Below => "Below",
                SortMode::Sorted => "Sorted",
                SortMode::Above => "Above",
            },
            node_name: safe_node_name(&p.name, idx + 1, "Part", &mut used),
            id: p.id.clone(),
            tex_res: paths::resource(root, &paths::join(node_dir, &p.texture_file)),
            position: [p.foot.x, p.foot.y],
            offset: [p.x - p.foot.x, p.y - p.foot.y],
            draw_order: p.draw_order,
        })
        .collect();
    let all_surface_rects: Vec<&CellRect> = map.parts.iter().flat_map(|p| &p.walkable_rects).collect();
    let nav_layers = map
        .nav_layers
        .iter()
        .enumerate()
        .filter_map(|(idx, l)| {
            let mut combined = l.walkable_rects.clone();
            if idx == 0 {
                combined.extend(all_surface_rects.iter().map(|r| (*r).clone()));
            }
            (!combined.is_empty()).then(|| WholeNavSpec {
                id: l.id.clone(),
                name: l.name.clone(),
                role: match l.role {
                    LayerRole::Ground => "ground",
                    LayerRole::Elevated => "elevated",
                    LayerRole::Under => "under",
                },
                z: l.z,
                rects: combined.into_iter().map(|r| [r.x, r.y, r.width, r.height]).collect(),
            })
        })
        .collect();
    let blocks = map
        .parts
        .iter()
        .filter(|p| p.blocking)
        .flat_map(|p| {
            p.footprints
                .iter()
                .filter(|ring| ring.len() >= 3)
                .map(|ring| WholeBlockSpec {
                    part_id: p.id.clone(),
                    points: points_xy(ring),
                })
        })
        .collect();
    let regions = map
        .regions
        .iter()
        .filter(|r| r.polygon.len() >= 3)
        .map(|r| WholeRegionSpec {
            id: r.id.clone(),
            polygon: points_xy(&r.polygon),
        })
        .collect();
    let connections = map
        .connections
        .iter()
        .filter(|c| c.zone.len() >= 3)
        .map(|c| WholeConnSpec {
            id: c.id.clone(),
            kind: match c.kind {
                ConnectionKind::Stairs => "stairs",
                ConnectionKind::Ramp => "ramp",
            },
            from: c.from.clone(),
            to: c.to.clone(),
            a: [c.a.x, c.a.y],
            b: [c.b.x, c.b.y],
            zone: points_xy(&c.zone),
        })
        .collect();
    WholeMapSpec {
        perspective: map.perspective.clone(),
        tile_width: map.tile_width,
        tile_height: map.tile_height,
        origin_x: map.origin_x,
        origin_y: map.origin_y,
        width: map.width,
        height: map.height,
        character_radius: map.character.radius,
        character_speed: map.character.speed,
        mask_shader: has_masks.then_some(MASK_SHADER),
        tiles,
        parts,
        nav_layers,
        blocks,
        regions,
        connections,
    }
}

fn points_xy(points: &[Point]) -> Vec<[f64; 2]> {
    points.iter().map(|p| [p.x, p.y]).collect()
}
