//! Godot CLI task planning: serializes validated node specs for `wf_sync.gd`,
//! tracks input hashes for idempotent runs, and plans temp cleanup via the host.
mod builders;
mod parallax;
mod specs;

use builders::{build_particle2d_spec, build_particle3d_spec, build_tilemap_spec, build_whole_map_spec};
use parallax::build_parallax_spec;
use specs::{
    AnimClipSpec, AnimFrameSpec, Model3dSpec, ModelClipSpec, ModelSocketSpec, Scene3dColliderSpec, Scene3dRoleSpec,
    Scene3dSpec, SpecBuilder, Target, ThemeStateSpec, ThemeVarSpec,
};

use crate::{
    godot::{
        doc::safe_node_name,
        spatial::basis_from_forward,
        theme::{slot, widget_plan},
        tilemap,
    },
    model::{
        Animation, Kit, Margins, Model3d, ParallaxMap, ParticleEffect, Scene3dMap, Space, TileMap, WholeMap,
        WidgetKind, spatial::Collider3d,
    },
    paths::{self, invalid},
    reconcile,
    types::{Element, File, Status},
};
use plugin_api::{Effect, Failure, platform::LockedRow};
use plugin_guest::{Host, HostError};
use serde::Serialize;
use serde_json::Value;
use std::collections::BTreeSet;

pub const WF_SYNC_GD: &str = include_str!("../godot/wf_sync.gd");
pub const MANIFEST_REL: &str = "wf_tmp/godot_sync.json";
pub const SCRIPT_REL: &str = "wf_tmp/godot_sync.gd";
pub const SCRIPT_UID_REL: &str = "wf_tmp/godot_sync.gd.uid";

/// Serialized sync manifest consumed by `wf_tmp/godot_sync.gd`.
#[derive(Serialize)]
pub struct Manifest {
    pub tasks: Vec<Task>,
}

/// One node conversion job passed to `wf_sync.gd`.
#[derive(Serialize)]
pub struct Task {
    pub kind: &'static str,
    pub id: String,
    pub version: u64,
    pub src_hash: String,
    pub spec: Value,
}

/// Prepared CLI output before reconciling files on disk.
pub struct PlannedNode {
    pub kind: &'static str,
    pub notes: Vec<String>,
    pub elements: Vec<Element>,
    targets: Vec<Target>,
    spec_fn: SpecBuilder,
}

/// Plans CLI conversion for `frame_animation` / `character_effect`.
pub fn plan_animation(anim: &Animation, node_dir: &str, root: &str, stem: &str) -> PlannedNode {
    let clips = anim
        .clips
        .iter()
        .map(|clip| {
            let base = clip.frames.iter().map(|f| f.duration_ms).fold(f64::INFINITY, f64::min);
            AnimClipSpec {
                name: clip.name.clone(),
                fps: 1000.0 / base,
                looped: clip.looped,
                anchor: [clip.anchor.x, clip.anchor.y],
                frames: clip
                    .frames
                    .iter()
                    .map(|f| AnimFrameSpec {
                        tex_res: paths::resource(root, &paths::join(node_dir, &f.texture.path)),
                        region: f.texture.region.map(|r| [r.x, r.y, r.w, r.h]),
                        duration: f.duration_ms / base,
                    })
                    .collect(),
            }
        })
        .collect();
    PlannedNode {
        kind: "animation",
        notes: anim.notes.clone(),
        elements: Vec::new(),
        targets: vec![
            make_target(node_dir, root, stem, ".sprite_frames.tres", false),
            make_target(node_dir, root, stem, ".tscn", true),
        ],
        spec_fn: SpecBuilder::Animation(clips),
    }
}

/// Plans CLI conversion for UI `Theme` resources.
pub fn plan_theme(kit: &Kit, node_dir: &str, root: &str, stem: &str) -> PlannedNode {
    let (elements, resolved) = widget_plan(kit);
    let targets = if kit.widgets.is_empty() {
        Vec::new()
    } else {
        vec![make_target(node_dir, root, stem, ".theme.tres", false)]
    };
    let variations = kit
        .widgets
        .iter()
        .zip(resolved)
        .map(|(w, (name, base_type))| ThemeVarSpec {
            name,
            base_type,
            focus_empty: matches!(w.kind, WidgetKind::Press),
            states: w
                .states
                .iter()
                .map(|st| {
                    let (category, slot_name) = slot(w.kind, st.style);
                    ThemeStateSpec {
                        category,
                        slot: slot_name,
                        tex_res: paths::resource(root, &paths::join(node_dir, &st.texture.path)),
                        region: st.texture.region.map(|r| [r.x, r.y, r.w, r.h]),
                        slice: st.slice.values(),
                        content: st.content.map(Margins::values),
                    }
                })
                .collect(),
        })
        .collect();
    PlannedNode {
        kind: "theme",
        notes: kit.notes.clone(),
        elements,
        targets,
        spec_fn: SpecBuilder::Theme(variations),
    }
}

/// Plans CLI conversion for `tilemap`.
pub fn plan_tilemap(map: &TileMap, node_dir: &str, root: &str, stem: &str) -> PlannedNode {
    let prepared = tilemap::prepare(map);
    let spec = build_tilemap_spec(map, &prepared, node_dir, root, stem);
    PlannedNode {
        kind: "tilemap",
        notes: prepared.notes,
        elements: Vec::new(),
        targets: vec![
            make_target(node_dir, root, stem, ".tileset.tres", false),
            make_target(node_dir, root, stem, ".tscn", true),
        ],
        spec_fn: SpecBuilder::TileMap(spec),
    }
}

/// Plans CLI conversion for 2D/3D `particle_effect`.
pub fn plan_particle(effect: &ParticleEffect, node_dir: &str, root: &str, stem: &str) -> PlannedNode {
    let target = vec![make_target(node_dir, root, stem, ".tscn", true)];
    if effect.space == Space::Spatial {
        return PlannedNode {
            kind: "particle3d",
            notes: effect.notes.clone(),
            elements: Vec::new(),
            targets: target,
            spec_fn: SpecBuilder::Particle3d(build_particle3d_spec(effect, node_dir, root)),
        };
    }
    PlannedNode {
        kind: "particle2d",
        notes: effect.notes.clone(),
        elements: Vec::new(),
        targets: target,
        spec_fn: SpecBuilder::Particle2d(build_particle2d_spec(effect, node_dir, root)),
    }
}

/// Plans CLI conversion for `whole_map`.
pub fn plan_whole_map(map: &WholeMap, node_dir: &str, root: &str, stem: &str) -> PlannedNode {
    PlannedNode {
        kind: "whole_map",
        notes: Vec::new(),
        elements: Vec::new(),
        targets: vec![make_target(node_dir, root, stem, ".tscn", true)],
        spec_fn: SpecBuilder::WholeMap(build_whole_map_spec(map, node_dir, root)),
    }
}

/// Plans CLI conversion for `scrolling_scene` / `scroll_map`.
pub fn plan_parallax(map: &ParallaxMap, node_dir: &str, root: &str, stem: &str) -> PlannedNode {
    PlannedNode {
        kind: "parallax",
        notes: Vec::new(),
        elements: Vec::new(),
        targets: vec![make_target(node_dir, root, stem, ".tscn", true)],
        spec_fn: SpecBuilder::Parallax(build_parallax_spec(map, node_dir, root)),
    }
}

/// Plans CLI conversion for `scene3d_map`.
pub fn plan_scene3d(scene: &Scene3dMap, node_dir: &str, root: &str, stem: &str) -> PlannedNode {
    let blocked_set: BTreeSet<&str> = scene.blocked_doors.iter().map(String::as_str).collect();
    let mut col_used = BTreeSet::new();
    let colliders = scene
        .colliders
        .iter()
        .enumerate()
        .map(|(i, bx)| Scene3dColliderSpec {
            name: safe_node_name(&bx.name, i + 1, "Solid", &mut col_used),
            center: bx.center,
            size: bx.size,
            room: bx.room.clone(),
        })
        .collect();
    let mut role_used = BTreeSet::new();
    let roles = scene
        .roles
        .iter()
        .enumerate()
        .map(|(i, r)| {
            let label = r.id.as_deref().or(r.node.as_deref()).unwrap_or(&r.role);
            let name = safe_node_name(label, i + 1, "Role", &mut role_used);
            let [fx, fy, fz] = r.forward;
            let [px, py, pz] = r.position;
            let (is_trigger, center, size) = if let (Some(min), Some(max)) = (r.min, r.max) {
                (
                    true,
                    [
                        f64::midpoint(min[0], max[0]),
                        f64::midpoint(min[1], max[1]),
                        f64::midpoint(min[2], max[2]),
                    ],
                    [
                        (max[0] - min[0]).abs().max(0.1),
                        (max[1] - min[1]).abs().max(0.1),
                        (max[2] - min[2]).abs().max(0.1),
                    ],
                )
            } else {
                (false, r.position, [0.1, 0.1, 0.1])
            };
            let basis = basis_from_forward(fx, fy, fz);
            let blocked = r.role == "door"
                && (r.id.as_deref().is_some_and(|id| blocked_set.contains(id))
                    || r.node.as_deref().is_some_and(|n| blocked_set.contains(n)));
            Scene3dRoleSpec {
                name,
                is_trigger,
                role: r.role.clone(),
                id: r.id.clone(),
                center,
                size,
                forward: r.forward,
                blocked,
                transform: [
                    basis[0], basis[3], basis[6], basis[1], basis[4], basis[7], basis[2], basis[5], basis[8], px, py,
                    pz,
                ],
            }
        })
        .collect();
    PlannedNode {
        kind: "scene3d",
        notes: scene.notes.clone(),
        elements: Vec::new(),
        targets: vec![make_target(node_dir, root, stem, ".tscn", true)],
        spec_fn: SpecBuilder::Scene3d(Scene3dSpec {
            glb_res: paths::resource(root, &paths::join(node_dir, &scene.glb_file)),
            blocked_doors: scene.blocked_doors.clone(),
            ambient_intensity: scene.environment.ambient_intensity.clamp(0.0, 10.0),
            ambient_color: scene.environment.ambient_color,
            fog_color: scene.environment.fog_color,
            fog_density: scene.environment.fog_density.max(0.0),
            colliders,
            roles,
        }),
    }
}

/// Plans CLI conversion for `model_3d`.
pub fn plan_model3d(model: &Model3d, node_dir: &str, root: &str, stem: &str) -> PlannedNode {
    let (collider_kind, collider_center, radius, collider_height, size) = match model.collider {
        Collider3d::Capsule { radius, height, center } => (
            "capsule",
            center,
            radius.max(0.05),
            height.max(radius * 2.0).max(0.1),
            [0.0; 3],
        ),
        Collider3d::Box { size, center } => (
            "box",
            center,
            0.0,
            0.0,
            [size[0].max(0.05), size[1].max(0.05), size[2].max(0.05)],
        ),
    };
    let mut sock_used = BTreeSet::new();
    let sockets = model
        .sockets
        .iter()
        .enumerate()
        .map(|(i, s)| ModelSocketSpec {
            name: safe_node_name(&s.name, i + 1, "Socket", &mut sock_used),
            raw_name: s.name.clone(),
            position: s.position,
            bone: s.bone.clone(),
        })
        .collect();
    let mut clip_used = BTreeSet::new();
    let clips = model
        .clips
        .iter()
        .enumerate()
        .map(|(i, c)| ModelClipSpec {
            name: safe_node_name(&c.name, i + 1, "Clip", &mut clip_used),
            raw_name: c.name.clone(),
            duration: c.duration,
            loops: c.loops,
            travel: c.travel,
            sole_low: c.sole_low,
            sole_high: c.sole_high,
            liftoffs: c.liftoffs,
            checks: c.checks.clone(),
        })
        .collect();
    PlannedNode {
        kind: "model3d",
        notes: Vec::new(),
        elements: Vec::new(),
        targets: vec![make_target(node_dir, root, stem, ".tscn", true)],
        spec_fn: SpecBuilder::Model3d(Model3dSpec {
            glb_res: paths::resource(root, &paths::join(node_dir, &model.glb_file)),
            height: model.height,
            bottom: model.bottom,
            bounds_min: model.bounds.min,
            bounds_max: model.bounds.max,
            bones_json: serde_json::to_string(&model.bones).unwrap_or_else(|_| "{}".to_owned()),
            collider_kind,
            collider_center,
            radius,
            collider_height,
            size,
            sockets,
            clips,
        }),
    }
}

/// Reconciles disk targets for one node and returns a CLI task if any file needs writing.
#[expect(
    clippy::too_many_arguments,
    reason = "node reconciliation needs lock, host and plan state"
)]
pub fn reconcile_node(
    host: &dyn Host,
    directory: &str,
    lock_nodes: &[LockedRow],
    row: &LockedRow,
    force: bool,
    planned: PlannedNode,
    wanted: &mut BTreeSet<String>,
    files: &mut Vec<File>,
    main_scene: &mut Option<String>,
    reasons: &mut Vec<String>,
) -> Result<Option<Task>, HostError> {
    if planned.targets.is_empty() {
        return Ok(None);
    }
    let spec_base = planned
        .spec_fn
        .canonical_json()
        .map_err(|msg| HostError::new(Failure::Internal, msg))?;
    let src_hash = compute_src_hash(planned.kind, &row.id, row.version, &spec_base);
    let mut targets = planned.targets;
    let mut needs_write = false;
    for target in &mut targets {
        if !wanted.insert(target.rel_path.clone()) {
            return Err(invalid(format!("generated paths collide: {}", target.rel_path)));
        }
        if lock_nodes
            .iter()
            .any(|r| r.files.iter().any(|f| paths::join(directory, f) == target.rel_path))
        {
            return Err(invalid(format!(
                "generated path belongs to wf export: {}",
                target.rel_path
            )));
        }
        let status = reconcile::cli_file(host, &target.rel_path, row.version, &src_hash, force)?;
        target.write = matches!(status, Status::Written | Status::Updated);
        if target.write {
            needs_write = true;
        }
        if target.main_scene {
            *main_scene = Some(target.rel_path.clone());
        }
        if status == Status::Kept {
            reasons.push(format!(
                "{}: user-owned or edited file kept; use --force to replace it.",
                target.rel_path
            ));
        }
        files.push(File {
            resource: target.res_path.clone(),
            path: target.rel_path.clone(),
            status,
        });
    }
    if !needs_write {
        return Ok(None);
    }
    let spec = planned
        .spec_fn
        .into_godot_spec(&targets)
        .map_err(|msg| HostError::new(Failure::Internal, msg))?;
    Ok(Some(Task {
        kind: planned.kind,
        id: row.id.clone(),
        version: row.version,
        src_hash,
        spec,
    }))
}

/// Emits temp `wf_tmp/godot_sync.*` writes, registers host cleanup, and queues Godot CLI `Exec` effects.
pub fn emit_cli_effects(
    host: &dyn Host,
    root: &str,
    tasks: Vec<Task>,
    effects: &mut Vec<Effect>,
) -> Result<(), HostError> {
    if tasks.is_empty() {
        return Ok(());
    }
    let manifest_path = paths::join(root, MANIFEST_REL);
    let script_path = paths::join(root, SCRIPT_REL);
    let script_uid_path = paths::join(root, SCRIPT_UID_REL);
    let json = serde_json::to_vec(&Manifest { tasks })
        .map_err(|e| HostError::new(Failure::Internal, format!("failed to serialize CLI manifest: {e}")))?;

    host.cleanup_after_exec(&manifest_path)?;
    host.cleanup_after_exec(&script_path)?;
    host.cleanup_after_exec(&script_uid_path)?;

    effects.push(Effect::WriteFile {
        path: manifest_path,
        bytes: json,
        overwrite: false,
    });
    effects.push(Effect::WriteFile {
        path: script_path,
        bytes: WF_SYNC_GD.as_bytes().to_vec(),
        overwrite: false,
    });

    let project_arg = if root.is_empty() {
        ".".to_owned()
    } else {
        root.to_owned()
    };
    effects.push(Effect::Exec {
        tool: "godot".into(),
        args: vec![
            "--headless".into(),
            "--path".into(),
            project_arg.clone(),
            "--import".into(),
            "--quit".into(),
        ],
        reason: "Import newly exported textures and 3D models into Godot cache".into(),
    });
    effects.push(Effect::Exec {
        tool: "godot".into(),
        args: vec![
            "--headless".into(),
            "--path".into(),
            project_arg,
            "--script".into(),
            paths::resource(root, &paths::join(root, SCRIPT_REL)),
            "--".into(),
            paths::resource(root, &paths::join(root, MANIFEST_REL)),
        ],
        reason: "Generate Godot .tres and .tscn files via Godot CLI".into(),
    });
    Ok(())
}

fn make_target(node_dir: &str, root: &str, stem: &str, suffix: &'static str, main_scene: bool) -> Target {
    let rel_path = paths::join(node_dir, &format!("{stem}{suffix}"));
    let res_path = paths::resource(root, &rel_path);
    Target {
        res_path,
        rel_path,
        suffix,
        main_scene,
        write: false,
    }
}

fn compute_src_hash(kind: &str, id: &str, version: u64, canonical: &Value) -> String {
    let payload = serde_json::to_vec(&(WF_SYNC_GD, kind, id, version, canonical)).unwrap_or_default();
    reconcile::sha256_hex(&payload)
}
