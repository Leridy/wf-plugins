//! Spatial particle helpers for curve sampling, linear gradients, emission, launch, and node naming.
use crate::model::Emitter;
use std::collections::BTreeSet;

/// Node names may not hold these characters.
const UNSAFE: &[char] = &['.', ':', '@', '/', '"', '%'];

pub(crate) fn curve_points(keys: &[f64], largest: f64) -> Vec<[f64; 4]> {
    let points: Vec<_> = even(keys.len())
        .zip(keys)
        .map(|(x, y)| (x, if largest > 0.0 { y / largest } else { 0.0 }))
        .collect();
    let slope = |a: (f64, f64), b: (f64, f64)| (b.1 - a.1) / (b.0 - a.0);
    points
        .iter()
        .enumerate()
        .map(|(i, &p)| {
            let left = if i > 0 { slope(points[i - 1], p) } else { 0.0 };
            let right = points.get(i + 1).map_or(0.0, |&n| slope(p, n));
            [p.0, p.1, left, right]
        })
        .collect()
}

pub(crate) fn gradient_stops(e: &Emitter) -> Vec<(f64, [f64; 4])> {
    let colors: Vec<[f64; 3]> = e.color.iter().map(|c| linear(c)).collect();
    let mut offsets: Vec<f64> = even(colors.len()).chain(even(e.opacity.len())).collect();
    offsets.sort_by(f64::total_cmp);
    offsets.dedup_by(|a, b| (*a - *b).abs() < 1e-9);
    offsets
        .into_iter()
        .map(|t| {
            let [r, g, b] = [0, 1, 2].map(|c| srgb(along(&colors.iter().map(|k| k[c]).collect::<Vec<_>>(), t)));
            (round(t), [r, g, b, along(&e.opacity, t)].map(round))
        })
        .collect()
}

/// `amount` and `explosiveness`: GPUParticles3D emits `amount` particles per
/// lifetime, so a rate becomes rate × lifetime; a burst-only emitter emits its
/// burst at once. An emitter only triggers fill stays sized to its capacity.
#[expect(clippy::cast_sign_loss, reason = "rate and lifetime are positive")]
pub(crate) fn emission(e: &Emitter) -> (u32, f64) {
    if e.rate > 0.0 {
        let steady = (e.rate * e.lifetime[1]).ceil().min(f64::from(e.max_particles)) as u32;
        (steady.max(1), 0.0)
    } else if e.burst > 0 {
        (e.burst.min(e.max_particles), 1.0)
    } else {
        (e.max_particles, 1.0)
    }
}

/// Direction, spread angle (degrees) and speed range of a new particle. A
/// radial burst leaves within its cone of +Y; otherwise the base velocity
/// widens by its per-axis spread.
pub(crate) fn launch(e: &Emitter) -> ([f64; 3], f64, [f64; 2]) {
    let base = length(e.velocity);
    if let Some(radial) = &e.radial {
        return (
            [0.0, 1.0, 0.0],
            radial.cone,
            [radial.speed[0] + base, radial.speed[1] + base],
        );
    }
    let jitter = length(e.velocity_spread);
    if base < 1e-9 {
        return ([0.0, 1.0, 0.0], 180.0, [0.0, jitter]);
    }
    let direction = e.velocity.map(|v| round(v / base));
    let spread = (jitter / base).atan().to_degrees().min(180.0);
    (direction, round(spread), [(base - jitter).max(0.0), base + jitter])
}

/// Each emitter's node name: its name made safe, numbered on repeats.
pub(crate) fn node_names(emitters: &[Emitter]) -> Vec<String> {
    let mut used = BTreeSet::new();
    emitters
        .iter()
        .map(|e| {
            let clean: String = e
                .name
                .chars()
                .filter(|c| !UNSAFE.contains(c) && !c.is_control())
                .collect();
            let clean = clean.trim();
            let base = if clean.is_empty() || clean == "Ground" {
                "Emitter"
            } else {
                clean
            };
            let mut name = base.to_owned();
            let mut suffix = 2;
            while !used.insert(name.clone()) {
                name = format!("{base}{suffix}");
                suffix += 1;
            }
            name
        })
        .collect()
}

/// A curve holds at most 8 keys, so its indices fit `u32` exactly.
fn float(index: usize) -> f64 {
    f64::from(index as u32)
}

fn even(count: usize) -> impl Iterator<Item = f64> {
    let span = float(count.saturating_sub(1).max(1));
    (0..count).map(move |i| float(i) / span)
}

/// A curve's value at `t` (0 birth, 1 death): keys spaced evenly, straight between.
fn along(keys: &[f64], t: f64) -> f64 {
    let span = keys.len() - 1;
    if span == 0 {
        return keys[0];
    }
    let at = t.clamp(0.0, 1.0) * float(span);
    // floor(at), capped at the last segment.
    let index = (1..span).take_while(|&i| float(i) <= at).count();
    keys[index] + (keys[index + 1] - keys[index]) * (at - float(index))
}

/// `#rrggbb` (sRGB) as linear channels.
fn linear(hex: &str) -> [f64; 3] {
    [1, 3, 5].map(|i| {
        let c = f64::from(u8::from_str_radix(&hex[i..i + 2], 16).unwrap_or(0)) / 255.0;
        if c <= 0.04045 {
            c / 12.92
        } else {
            ((c + 0.055) / 1.055).powf(2.4)
        }
    })
}

fn srgb(c: f64) -> f64 {
    if c <= 0.003_130_8 {
        c * 12.92
    } else {
        1.055 * c.powf(1.0 / 2.4) - 0.055
    }
}

/// Six decimals keep the scene stable across platforms and readable.
fn round(value: f64) -> f64 {
    let rounded = (value * 1e6).round() / 1e6;
    if rounded == 0.0 { 0.0 } else { rounded }
}

fn length(v: [f64; 3]) -> f64 {
    (v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).sqrt()
}
