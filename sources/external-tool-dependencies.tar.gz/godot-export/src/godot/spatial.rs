//! 3D orientation helper for `scene3d_map` roles.

/// Column-major 3x3 basis whose -Z axis points along `(fx, fy, fz)`.
pub(crate) fn basis_from_forward(fx: f64, fy: f64, fz: f64) -> [f64; 9] {
    let flen = (fx * fx + fy * fy + fz * fz).sqrt();
    if flen < 1e-6 {
        return [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0];
    }
    let back = [-fx / flen, -fy / flen, -fz / flen];
    let up_hint = if back[1].abs() > 0.99 {
        [0.0, 0.0, 1.0]
    } else {
        [0.0, 1.0, 0.0]
    };
    let rx = up_hint[1] * back[2] - up_hint[2] * back[1];
    let ry = up_hint[2] * back[0] - up_hint[0] * back[2];
    let rz = up_hint[0] * back[1] - up_hint[1] * back[0];
    let rlen = (rx * rx + ry * ry + rz * rz).sqrt().max(1e-6);
    let right = [rx / rlen, ry / rlen, rz / rlen];
    let up = [
        back[1] * right[2] - back[2] * right[1],
        back[2] * right[0] - back[0] * right[2],
        back[0] * right[1] - back[1] * right[0],
    ];
    [
        right[0], up[0], back[0], right[1], up[1], back[1], right[2], up[2], back[2],
    ]
}
