//! Embedded GDScript motion helper for `scrolling_scene` / `scroll_map` sprites.
pub(crate) const MOTION_SCRIPT: &str = r"extends Sprite2D
@export var drift_speed: float = 0.0
@export var bob_amplitude: float = 0.0
@export var bob_period: float = 2.0
@export var sway_degrees: float = 0.0
@export var sway_period: float = 2.0

var _origin: Vector2
var _elapsed: float = 0.0

func _ready() -> void:
	_origin = position

func _process(delta: float) -> void:
	_elapsed += delta
	var bob_y: float = 0.0
	if bob_amplitude != 0.0 and bob_period > 0.0:
		bob_y = sin(_elapsed * TAU / bob_period) * bob_amplitude
	position = Vector2(_origin.x + drift_speed * _elapsed, _origin.y + bob_y)
	if sway_degrees != 0.0 and sway_period > 0.0:
		rotation = deg_to_rad(sway_degrees) * sin(_elapsed * TAU / sway_period)
";
