//! Helpers, naming rules, and embedded GDScript/shader payloads used by Godot CLI sync.
pub mod doc;
mod naming;
pub(crate) mod parallax;
pub(crate) mod particle;
pub(crate) mod particle3d;
pub(crate) mod spatial;
pub(crate) mod theme;
pub(crate) mod tilemap;
pub(crate) mod whole_map;
