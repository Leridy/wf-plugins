//! Theme variation naming and widget style-slot mapping for Godot CLI sync.
use super::naming;
use crate::{
    model::{Kit, Style, WidgetKind},
    types::Element,
};

pub(crate) fn widget_plan(kit: &Kit) -> (Vec<Element>, Vec<(String, &'static str)>) {
    let mut names = naming::reserved();
    let mut elements: Vec<_> = kit
        .elements
        .iter()
        .map(|name| Element {
            name: name.clone(),
            variation: None,
        })
        .collect();
    let mut resolved = Vec::with_capacity(kit.widgets.len());
    for widget in &kit.widgets {
        let base_type = match widget.kind {
            WidgetKind::Press | WidgetKind::Flip => "Button",
            WidgetKind::Bar => "ProgressBar",
            WidgetKind::Slide => "HSlider",
        };
        let name = naming::variation(
            &widget.name,
            &widget.element_kind,
            base_type,
            widget.element + 1,
            &mut names,
        );
        elements[widget.element].variation = Some(name.clone());
        resolved.push((name, base_type));
    }
    (elements, resolved)
}

pub(crate) fn slot(kind: WidgetKind, style: Style) -> (&'static str, &'static str) {
    let slot = match style {
        Style::Thumb => return ("icons", "grabber"),
        Style::ThumbHover => return ("icons", "grabber_highlight"),
        Style::ThumbDisabled => return ("icons", "grabber_disabled"),
        Style::Rest => "normal",
        Style::Hover => "hover",
        Style::Pressed => "pressed",
        Style::Disabled => "disabled",
        Style::HoverPressed => "hover_pressed",
        Style::Track if matches!(kind, WidgetKind::Slide) => "slider",
        Style::Track => "background",
        Style::Fill if matches!(kind, WidgetKind::Slide) => "grabber_area",
        Style::Fill => "fill",
    };
    ("styles", slot)
}
