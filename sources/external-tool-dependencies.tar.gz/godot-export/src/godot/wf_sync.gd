extends SceneTree
## Headless WeaveForge resource/scene generator invoked via Godot CLI.

func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var args := OS.get_cmdline_user_args()
	var manifest_path := "res://wf_tmp/godot_sync.json" if args.is_empty() else args[0]
	var raw := FileAccess.get_file_as_string(manifest_path)
	if raw.is_empty():
		push_error("Missing or empty sync manifest: " + manifest_path)
		quit(1)
		return
	var manifest = JSON.parse_string(raw)
	if not manifest is Dictionary or not manifest.has("tasks"):
		push_error("Invalid sync manifest JSON: " + manifest_path)
		quit(1)
		return
	var ok := true
	for task: Dictionary in manifest["tasks"]:
		if not _process_task(task):
			ok = false
	quit(0 if ok else 1)


func _process_task(task: Dictionary) -> bool:
	var kind := String(task["kind"])
	var id := String(task["id"])
	var version := int(task["version"])
	var src_hash := String(task["src_hash"])
	var s: Dictionary = task["spec"]
	match kind:
		"animation":
			return _build_animation(s, id, version, src_hash)
		"theme":
			return _build_theme(s, id, version, src_hash)
		"tilemap":
			return _build_tilemap(s, id, version, src_hash)
		"particle2d":
			return _build_particle2d(s, id, version, src_hash)
		"particle3d":
			return _build_particle3d(s, id, version, src_hash)
		"whole_map":
			return _build_whole_map(s, id, version, src_hash)
		"parallax":
			return _build_parallax(s, id, version, src_hash)
		"scene3d":
			return _build_scene3d(s, id, version, src_hash)
		"model3d":
			return _build_model3d(s, id, version, src_hash)
		_:
			push_error("Unknown godot-export task kind: " + kind)
			return false


func _ensure_dir(res_path: String) -> bool:
	var dir_abs := ProjectSettings.globalize_path(res_path.get_base_dir())
	var err := DirAccess.make_dir_recursive_absolute(dir_abs)
	if err != OK and err != ERR_ALREADY_EXISTS:
		push_error("Failed to create dir %s: %d" % [dir_abs, err])
		return false
	return true


func _sha256_bytes(data: PackedByteArray) -> String:
	var ctx := HashingContext.new()
	ctx.start(HashingContext.HASH_SHA256)
	ctx.update(data)
	return ctx.finish().hex_encode()


func _save_res(res: Resource, res_path: String, id: String, version: int, src_hash: String) -> bool:
	if not _ensure_dir(res_path):
		return false
	var err := ResourceSaver.save(res, res_path)
	if err != OK:
		push_error("ResourceSaver.save failed for %s: %d" % [res_path, err])
		return false
	var body := FileAccess.get_file_as_bytes(res_path)
	if body.is_empty():
		push_error("Saved resource is empty: " + res_path)
		return false
	var header := "; wf godot-export %s v%d sha256=%s src=%s\n" % [id, version, _sha256_bytes(body), src_hash]
	var out := FileAccess.open(res_path, FileAccess.WRITE)
	if out == null:
		push_error("Failed to open %s for stamping: %d" % [res_path, FileAccess.get_open_error()])
		return false
	out.store_buffer(header.to_utf8_buffer())
	out.store_buffer(body)
	out.close()
	return true


func _save_scene(root_node: Node, res_path: String, id: String, version: int, src_hash: String) -> bool:
	var packed := PackedScene.new()
	var err := packed.pack(root_node)
	root_node.free()
	if err != OK:
		push_error("PackedScene.pack failed for %s: %d" % [res_path, err])
		return false
	return _save_res(packed, res_path, id, version, src_hash)


func _add(parent: Node, child: Node, scene_root: Node) -> Node:
	parent.add_child(child)
	child.owner = scene_root
	return child


func _load_tex(res_path: String, region: Variant) -> Texture2D:
	var base := ResourceLoader.load(res_path) as Texture2D
	if base == null:
		push_error("Failed to load Texture2D: " + res_path)
		return null
	if region == null:
		return base
	var at := AtlasTexture.new()
	at.atlas = base
	at.region = Rect2(float(region[0]), float(region[1]), float(region[2]), float(region[3]))
	return at


func _vec2(v: Array) -> Vector2:
	return Vector2(float(v[0]), float(v[1]))


func _vec3(v: Array) -> Vector3:
	return Vector3(float(v[0]), float(v[1]), float(v[2]))


func _poly(pts: Array) -> PackedVector2Array:
	var out := PackedVector2Array()
	for p: Array in pts:
		out.append(Vector2(float(p[0]), float(p[1])))
	return out


func _t3d(t: Array) -> Transform3D:
	var bx := Vector3(float(t[0]), float(t[3]), float(t[6]))
	var by := Vector3(float(t[1]), float(t[4]), float(t[7]))
	var bz := Vector3(float(t[2]), float(t[5]), float(t[8]))
	return Transform3D(Basis(bx, by, bz), Vector3(float(t[9]), float(t[10]), float(t[11])))


func _build_animation(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var sf_target: Dictionary = s["sprite_frames_target"]
	var scene_target: Dictionary = s["scene_target"]
	var sf_res_path := String(sf_target["res_path"])
	if bool(sf_target["write"]):
		var sf := SpriteFrames.new()
		var has_default := false
		for clip: Dictionary in s["clips"]:
			var cname := StringName(String(clip["name"]))
			if cname == &"default":
				has_default = true
			if not sf.has_animation(cname):
				sf.add_animation(cname)
			else:
				sf.clear(cname)
			sf.set_animation_speed(cname, float(clip["fps"]))
			sf.set_animation_loop(cname, bool(clip["looped"]))
			for frame: Dictionary in clip["frames"]:
				var tex := _load_tex(String(frame["tex_res"]), frame.get("region"))
				if tex == null:
					return false
				sf.add_frame(cname, tex, float(frame["duration"]))
		if not has_default and sf.has_animation(&"default"):
			sf.remove_animation(&"default")
		if not _save_res(sf, sf_res_path, id, version, src_hash):
			return false
	if bool(scene_target["write"]):
		var sf_loaded := ResourceLoader.load(sf_res_path, "", ResourceLoader.CACHE_MODE_IGNORE) as SpriteFrames
		if sf_loaded == null:
			push_error("Failed to reload SpriteFrames: " + sf_res_path)
			return false
		var first: Dictionary = s["clips"][0]
		var sprite := AnimatedSprite2D.new()
		sprite.name = "AnimatedSprite2D"
		sprite.sprite_frames = sf_loaded
		sprite.animation = StringName(String(first["name"]))
		sprite.autoplay = String(first["name"])
		sprite.centered = false
		sprite.offset = -_vec2(first["anchor"])
		return _save_scene(sprite, String(scene_target["res_path"]), id, version, src_hash)
	return true


func _build_theme(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var target: Dictionary = s["theme_target"]
	if not bool(target["write"]):
		return true
	var th := Theme.new()
	for v: Dictionary in s["variations"]:
		var vname := StringName(String(v["name"]))
		th.set_type_variation(vname, StringName(String(v["base_type"])))
		for st: Dictionary in v["states"]:
			var tex := _load_tex(String(st["tex_res"]), st.get("region"))
			if tex == null:
				return false
			var slot := StringName(String(st["slot"]))
			if String(st["category"]) == "icons":
				th.set_icon(slot, vname, tex)
			else:
				var sb := StyleBoxTexture.new()
				sb.texture = tex
				var sl: Array = st["slice"]
				sb.texture_margin_left = float(sl[0])
				sb.texture_margin_right = float(sl[1])
				sb.texture_margin_top = float(sl[2])
				sb.texture_margin_bottom = float(sl[3])
				var cm: Variant = st.get("content")
				if cm != null:
					sb.content_margin_left = float(cm[0])
					sb.content_margin_right = float(cm[1])
					sb.content_margin_top = float(cm[2])
					sb.content_margin_bottom = float(cm[3])
				th.set_stylebox(slot, vname, sb)
		if bool(v["focus_empty"]):
			th.set_stylebox(&"focus", vname, StyleBoxEmpty.new())
	return _save_res(th, String(target["res_path"]), id, version, src_hash)


func _build_tilemap(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var ts_target: Dictionary = s["tileset_target"]
	var scene_target: Dictionary = s["scene_target"]
	var ts_res_path := String(ts_target["res_path"])
	if bool(ts_target["write"]):
		var ts := TileSet.new()
		ts.tile_size = Vector2i(int(s["tile_width"]), int(s["tile_height"]))
		if bool(s["isometric"]):
			ts.tile_shape = TileSet.TILE_SHAPE_ISOMETRIC
			ts.tile_layout = TileSet.TILE_LAYOUT_DIAMOND_DOWN
		for src: Dictionary in s["sources"]:
			var tex := ResourceLoader.load(String(src["tex_res"])) as Texture2D
			if tex == null:
				push_error("Failed to load tile atlas: " + String(src["tex_res"]))
				return false
			var atlas := TileSetAtlasSource.new()
			atlas.texture = tex
			atlas.texture_region_size = ts.tile_size
			for c: Array in src["coords"]:
				atlas.create_tile(Vector2i(int(c[0]), int(c[1])))
			ts.add_source(atlas, int(src["id"]))
		var terrains := []
		for t: Dictionary in s["terrains"]:
			var tiles := {}
			var masks: Dictionary = t["tiles"]
			for k in masks.keys():
				var list := []
				for c: Array in masks[k]:
					list.append(Vector3i(int(c[0]), int(c[1]), int(c[2])))
				tiles[int(k)] = list
			terrains.append({"set": String(t["set"]), "terrain": String(t["terrain"]), "tiles": tiles})
		ts.set_meta("wf_terrains", terrains)
		if not _save_res(ts, ts_res_path, id, version, src_hash):
			return false
	if not bool(scene_target["write"]):
		return true
	var ts_loaded := ResourceLoader.load(ts_res_path, "", ResourceLoader.CACHE_MODE_IGNORE) as TileSet
	if ts_loaded == null:
		push_error("Failed to reload TileSet: " + ts_res_path)
		return false
	var root_node := Node2D.new()
	root_node.name = String(s["root_name"])
	var off := _vec2(s["offset"])
	for lvl: Dictionary in s["levels"]:
		var layer := TileMapLayer.new()
		layer.name = "Ground%d" % int(lvl["level"])
		layer.position = off
		var alpha := float(lvl["opacity"])
		if alpha < 1.0:
			layer.modulate = Color(1, 1, 1, alpha)
		layer.tile_set = ts_loaded
		for cell: Array in lvl["cells"]:
			layer.set_cell(Vector2i(int(cell[0]), int(cell[1])), int(cell[2]), Vector2i(int(cell[3]), int(cell[4])), 0)
		_add(root_node, layer, root_node)
	var scene_node := Node2D.new()
	scene_node.name = "Scene"
	scene_node.y_sort_enabled = true
	_add(root_node, scene_node, root_node)
	for i: int in (s["sprites"] as Array).size():
		var sp: Dictionary = s["sprites"][i]
		var sprite := Sprite2D.new()
		sprite.name = "Sprite%d" % (i + 1)
		sprite.position = _vec2(sp["position"])
		if float(sp["rotation"]) != 0.0:
			sprite.rotation = float(sp["rotation"])
		if sp.get("scale") != null:
			sprite.scale = _vec2(sp["scale"])
		if float(sp["opacity"]) < 1.0:
			sprite.modulate = Color(1, 1, 1, float(sp["opacity"]))
		var sp_tex := ResourceLoader.load(String(sp["tex_res"])) as Texture2D
		if sp_tex == null:
			root_node.free()
			push_error("Failed to load tilemap sprite texture: " + String(sp["tex_res"]))
			return false
		sprite.texture = sp_tex
		sprite.centered = false
		sprite.offset = _vec2(sp["offset"])
		if sp.get("region") != null:
			var r: Array = sp["region"]
			sprite.region_enabled = true
			sprite.region_rect = Rect2(float(r[0]), float(r[1]), float(r[2]), float(r[3]))
		sprite.set_meta("wf_id", String(sp["id"]))
		_add(scene_node, sprite, root_node)
	var col := StaticBody2D.new()
	col.name = "Collision"
	_add(root_node, col, root_node)
	for i: int in (s["obstacles"] as Array).size():
		var obs: Dictionary = s["obstacles"][i]
		var cp := CollisionPolygon2D.new()
		cp.name = "Obstacle%d" % (i + 1)
		cp.polygon = _poly(obs["points"])
		cp.set_meta("wf_kind", String(obs["kind"]))
		_add(col, cp, root_node)
	for i: int in (s["walkable"] as Array).size():
		var cp := CollisionPolygon2D.new()
		cp.name = "Edge%d" % (i + 1)
		cp.build_mode = CollisionPolygon2D.BUILD_SEGMENTS
		cp.polygon = _poly(s["walkable"][i])
		_add(col, cp, root_node)
	if s.get("spawn") != null:
		var m := Marker2D.new()
		m.name = "Spawn"
		m.position = _vec2(s["spawn"])
		_add(root_node, m, root_node)
	return _save_scene(root_node, String(scene_target["res_path"]), id, version, src_hash)


func _build_particle2d(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var target: Dictionary = s["scene_target"]
	if not bool(target["write"]):
		return true
	var scr := GDScript.new()
	scr.source_code = String(s["player_script"])
	var err := scr.reload()
	if err != OK:
		push_error("Failed to reload particle_player.gd: %d" % err)
		return false
	var root_node := Node2D.new()
	root_node.name = "ParticleEffect"
	root_node.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	root_node.set_script(scr)
	root_node.set("duration", float(s["duration"]))
	root_node.set("looping", bool(s["looping"]))
	root_node.set("planar", bool(s["planar"]))
	var emitters := []
	for raw_e: Dictionary in s["emitters"]:
		var e := raw_e.duplicate(true)
		var tex := ResourceLoader.load(String(e["tex_res"])) as Texture2D
		if tex == null:
			root_node.free()
			push_error("Failed to load emitter texture: " + String(e["tex_res"]))
			return false
		e.erase("tex_res")
		e["texture"] = tex
		emitters.append(e)
	root_node.set("emitters", emitters)
	var normal := Node2D.new()
	normal.name = "Normal"
	_add(root_node, normal, root_node)
	var additive := Node2D.new()
	additive.name = "Additive"
	var add_mat := CanvasItemMaterial.new()
	add_mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	additive.material = add_mat
	_add(root_node, additive, root_node)
	return _save_scene(root_node, String(target["res_path"]), id, version, src_hash)


func _build_particle3d(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var target: Dictionary = s["scene_target"]
	if not bool(target["write"]):
		return true
	var root_node := Node3D.new()
	root_node.name = "ParticleEffect"
	for e: Dictionary in s["emitters"]:
		var gp := GPUParticles3D.new()
		gp.name = String(e["node_name"])
		gp.set_meta("wf_id", String(e["id"]))
		gp.set_meta("wf_name", String(e["name"]))
		gp.amount = int(e["amount"])
		gp.lifetime = float(e["lifetime"])
		gp.one_shot = bool(s["one_shot"])
		gp.explosiveness = float(e["explosiveness"])
		gp.fixed_fps = 60
		gp.local_coords = true
		if bool(e["align_velocity"]):
			gp.transform_align = GPUParticles3D.TRANSFORM_ALIGN_Z_BILLBOARD_Y_TO_VELOCITY
		if bool(e["draw_view_depth"]):
			gp.draw_order = GPUParticles3D.DRAW_ORDER_VIEW_DEPTH
		if e.get("sub_target") != null:
			gp.sub_emitter = NodePath("../" + String(e["sub_target"]))
		var pm := ParticleProcessMaterial.new()
		pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
		pm.emission_shape_offset = _vec3(e["position"])
		pm.emission_box_extents = _vec3(e["spread"])
		pm.gravity = _vec3(e["gravity"])
		if e.get("lifetime_randomness") != null:
			pm.lifetime_randomness = float(e["lifetime_randomness"])
		pm.direction = _vec3(e["direction"])
		pm.spread = float(e["launch_spread"])
		pm.initial_velocity_min = float(e["speed_min"])
		pm.initial_velocity_max = float(e["speed_max"])
		if e.get("damping") != null:
			pm.damping_min = float(e["damping"])
			pm.damping_max = float(e["damping"])
		if float(e["angle_max"]) > float(e["angle_min"]):
			pm.angle_min = float(e["angle_min"])
			pm.angle_max = float(e["angle_max"])
		var curve := Curve.new()
		for pt: Array in e["curve_points"]:
			curve.add_point(Vector2(float(pt[0]), float(pt[1])), float(pt[2]), float(pt[3]), Curve.TANGENT_LINEAR, Curve.TANGENT_LINEAR)
		var ct := CurveTexture.new()
		ct.curve = curve
		pm.scale_min = float(e["scale_min"])
		pm.scale_max = float(e["scale_max"])
		pm.scale_curve = ct
		var grad := Gradient.new()
		grad.interpolation_color_space = Gradient.GRADIENT_COLOR_SPACE_LINEAR_SRGB
		var offs := PackedFloat32Array()
		var cols := PackedColorArray()
		for st: Dictionary in e["gradient_stops"]:
			offs.append(float(st["offset"]))
			var rgba: Array = st["color"]
			cols.append(Color(float(rgba[0]), float(rgba[1]), float(rgba[2]), float(rgba[3])))
		grad.offsets = offs
		grad.colors = cols
		var gt := GradientTexture1D.new()
		gt.gradient = grad
		pm.color_ramp = gt
		if e.get("ground") != null:
			var g: Dictionary = e["ground"]
			pm.collision_mode = ParticleProcessMaterial.COLLISION_HIDE_ON_CONTACT if bool(g["kill"]) else ParticleProcessMaterial.COLLISION_RIGID
			pm.collision_bounce = float(g["bounce"])
			pm.collision_friction = float(g["friction"])
		if e.get("trigger") != null:
			var tr: Dictionary = e["trigger"]
			if String(tr["on"]) == "death":
				pm.sub_emitter_mode = ParticleProcessMaterial.SUB_EMITTER_AT_END
				pm.sub_emitter_amount_at_end = int(tr["count"])
			else:
				pm.sub_emitter_mode = ParticleProcessMaterial.SUB_EMITTER_AT_COLLISION
				pm.sub_emitter_amount_at_collision = int(tr["count"])
			pm.sub_emitter_keep_velocity = bool(tr["keep_velocity"])
		gp.process_material = pm
		var sm := StandardMaterial3D.new()
		sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		sm.vertex_color_use_as_albedo = true
		sm.vertex_color_is_srgb = true
		sm.albedo_texture = ResourceLoader.load(String(e["tex_res"])) as Texture2D
		if bool(e["additive"]):
			sm.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		if not bool(e["align_velocity"]):
			sm.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
			sm.billboard_keep_scale = true
		var qm := QuadMesh.new()
		qm.material = sm
		qm.size = Vector2(1, 1)
		gp.draw_pass_1 = qm
		_add(root_node, gp, root_node)
	if bool(s["has_ground"]):
		var col := GPUParticlesCollisionBox3D.new()
		col.name = "Ground"
		col.position = Vector3(0, -0.5, 0)
		col.size = Vector3(100, 1, 100)
		_add(root_node, col, root_node)
	return _save_scene(root_node, String(target["res_path"]), id, version, src_hash)


func _build_whole_map(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var target: Dictionary = s["scene_target"]
	if not bool(target["write"]):
		return true
	var root_node := Node2D.new()
	root_node.name = "WholeMap"
	root_node.set_meta("wf_perspective", String(s["perspective"]))
	root_node.set_meta("wf_tile_width", int(s["tile_width"]))
	root_node.set_meta("wf_tile_height", int(s["tile_height"]))
	root_node.set_meta("wf_bounds", Rect2(int(s["origin_x"]), int(s["origin_y"]), int(s["width"]), int(s["height"])))
	root_node.set_meta("wf_origin", Vector2i(int(s["origin_x"]), int(s["origin_y"])))
	root_node.set_meta("wf_character_radius", int(s["character_radius"]))
	root_node.set_meta("wf_character_speed", int(s["character_speed"]))
	var mask_shader: Shader = null
	if s.get("mask_shader") != null:
		mask_shader = Shader.new()
		mask_shader.code = String(s["mask_shader"])
	var ground := Node2D.new()
	ground.name = "Ground"
	_add(root_node, ground, root_node)
	for tile: Dictionary in s["tiles"]:
		var sp := Sprite2D.new()
		sp.name = "Tile_%d_%d" % [int(tile["grid_x"]), int(tile["grid_y"])]
		sp.position = Vector2(float(tile["x"]), float(tile["y"]))
		sp.texture = ResourceLoader.load(String(tile["base_res"])) as Texture2D
		sp.centered = false
		sp.set_meta("wf_key", String(tile["key"]))
		if tile.get("mask_res") != null and mask_shader != null:
			var sm := ShaderMaterial.new()
			sm.shader = mask_shader
			sm.set_shader_parameter("texel_size", Vector2(1.0 / max(1, int(tile["width"])), 1.0 / max(1, int(tile["height"]))))
			sm.set_shader_parameter("mask_tex", ResourceLoader.load(String(tile["mask_res"])) as Texture2D)
			sp.material = sm
		_add(ground, sp, root_node)
	var below := Node2D.new(); below.name = "Below"; _add(root_node, below, root_node)
	var sorted := Node2D.new(); sorted.name = "Sorted"; sorted.y_sort_enabled = true; _add(root_node, sorted, root_node)
	var above := Node2D.new(); above.name = "Above"; above.z_index = 10; _add(root_node, above, root_node)
	var bands := {"Below": below, "Sorted": sorted, "Above": above}
	for part: Dictionary in s["parts"]:
		var sp := Sprite2D.new()
		sp.name = String(part["node_name"])
		sp.position = _vec2(part["position"])
		sp.texture = ResourceLoader.load(String(part["tex_res"])) as Texture2D
		sp.centered = false
		sp.offset = _vec2(part["offset"])
		sp.set_meta("wf_id", String(part["id"]))
		sp.set_meta("wf_draw_order", int(part["draw_order"]))
		_add(bands[String(part["parent"])], sp, root_node)
	if not (s["nav_layers"] as Array).is_empty():
		var nav := Node2D.new(); nav.name = "Navigation"; _add(root_node, nav, root_node)
		for i: int in (s["nav_layers"] as Array).size():
			var nl: Dictionary = s["nav_layers"][i]
			var np := NavigationPolygon.new()
			var verts := PackedVector2Array()
			var rings: Array = []
			var rects: Array = nl["rects"]
			for r: Array in rects:
				var x0 := float(r[0]); var y0 := float(r[1]); var x1 := float(r[0]) + float(r[2]); var y1 := float(r[1]) + float(r[3])
				var ring := PackedVector2Array([Vector2(x0, y0), Vector2(x1, y0), Vector2(x1, y1), Vector2(x0, y1)])
				verts.append_array(ring)
				rings.append(ring)
			np.vertices = verts
			for idx: int in rings.size():
				var base := idx * 4
				np.add_outline(rings[idx])
				np.add_polygon(PackedInt32Array([base, base + 1, base + 2, base + 3]))
			var reg := NavigationRegion2D.new()
			reg.name = "NavLayer_%d" % (i + 1)
			reg.navigation_polygon = np
			reg.set_meta("wf_id", String(nl["id"]))
			reg.set_meta("wf_name", String(nl["name"]))
			reg.set_meta("wf_role", String(nl["role"]))
			reg.set_meta("wf_z", int(nl["z"]))
			_add(nav, reg, root_node)
	var col := StaticBody2D.new(); col.name = "Collision"; _add(root_node, col, root_node)
	for i: int in (s["blocks"] as Array).size():
		var b: Dictionary = s["blocks"][i]
		var cp := CollisionPolygon2D.new()
		cp.name = "Block%d" % (i + 1)
		cp.polygon = _poly(b["points"])
		cp.set_meta("wf_part", String(b["part_id"]))
		_add(col, cp, root_node)
	if not (s["regions"] as Array).is_empty():
		var regs := Node2D.new(); regs.name = "Regions"; _add(root_node, regs, root_node)
		for i: int in (s["regions"] as Array).size():
			var rg: Dictionary = s["regions"][i]
			var area := Area2D.new(); area.name = "Water%d" % (i + 1)
			area.set_meta("wf_kind", "water"); area.set_meta("wf_id", String(rg["id"]))
			_add(regs, area, root_node)
			var sh := CollisionPolygon2D.new(); sh.name = "Shape"; sh.polygon = _poly(rg["polygon"])
			_add(area, sh, root_node)
	if not (s["connections"] as Array).is_empty():
		var conns := Node2D.new(); conns.name = "Connections"; _add(root_node, conns, root_node)
		for i: int in (s["connections"] as Array).size():
			var c: Dictionary = s["connections"][i]
			var area := Area2D.new(); area.name = "Conn%d" % (i + 1)
			area.set_meta("wf_id", String(c["id"])); area.set_meta("wf_kind", String(c["kind"]))
			area.set_meta("wf_from", String(c["from"])); area.set_meta("wf_to", String(c["to"]))
			area.set_meta("wf_a", _vec2(c["a"])); area.set_meta("wf_b", _vec2(c["b"]))
			_add(conns, area, root_node)
			var sh := CollisionPolygon2D.new(); sh.name = "Shape"; sh.polygon = _poly(c["zone"])
			_add(area, sh, root_node)
	return _save_scene(root_node, String(target["res_path"]), id, version, src_hash)


func _build_parallax(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var target: Dictionary = s["scene_target"]
	if not bool(target["write"]):
		return true
	var motion_scr: GDScript = null
	if s.get("motion_script") != null:
		motion_scr = GDScript.new()
		motion_scr.source_code = String(s["motion_script"])
		if motion_scr.reload() != OK:
			push_error("Failed to reload parallax motion script")
			return false
	var root_node := Node2D.new()
	root_node.name = "ScrollingScene"
	root_node.set_meta("wf_progression", String(s["progression"]))
	root_node.set_meta("wf_view", String(s["view"]))
	root_node.set_meta("wf_speed", float(s["speed"]))
	root_node.set_meta("wf_pixel_ratio", int(s["pixel_ratio"]))
	var wb: Array = s["world_bounds"]
	root_node.set_meta("wf_world", Rect2(float(wb[0]), float(wb[1]), float(wb[2]), float(wb[3])))
	var bd: Dictionary = s["backdrop"]
	var backdrop := Parallax2D.new()
	backdrop.name = "Backdrop"
	backdrop.z_index = -100
	backdrop.scroll_scale = Vector2(float(bd["speed"]), 1.0)
	backdrop.repeat_size = _vec2(bd["repeat_size"])
	backdrop.autoscroll = Vector2(float(bd["drift"]), 0.0)
	backdrop.visible = bool(bd["visible"])
	_add(root_node, backdrop, root_node)
	var bd_sp := Sprite2D.new()
	bd_sp.name = "Texture"
	bd_sp.texture = ResourceLoader.load(String(bd["tex_res"])) as Texture2D
	bd_sp.centered = false
	bd_sp.scale = Vector2(float(s["inv_ratio"]), float(s["inv_ratio"]))
	bd_sp.modulate = Color(1, 1, 1, float(bd["opacity"]))
	_add(backdrop, bd_sp, root_node)
	var behind := Node2D.new(); behind.name = "BehindLayers"; behind.z_index = -20; _add(root_node, behind, root_node)
	var front := Node2D.new(); front.name = "FrontLayers"; front.z_index = 20; _add(root_node, front, root_node)
	var parents := {"BehindLayers": behind, "FrontLayers": front}
	for l: Dictionary in s["layers"]:
		var pl := Parallax2D.new()
		pl.name = String(l["name"])
		pl.scroll_scale = Vector2(float(l["speed"]), 1.0)
		pl.repeat_size = Vector2(float(l["repeat_x"]), 0.0)
		pl.visible = bool(l["visible"])
		pl.modulate = Color(1, 1, 1, float(l["opacity"]))
		pl.set_meta("wf_id", String(l["id"]))
		_add(parents[String(l["parent"])], pl, root_node)
		for i: int in (l["items"] as Array).size():
			var it: Dictionary = l["items"][i]
			var sp := Sprite2D.new()
			sp.name = "Item_%d" % (i + 1)
			sp.position = _vec2(it["position"])
			sp.scale = _vec2(it["scale"])
			sp.modulate = Color(1, 1, 1, float(it["opacity"]))
			sp.texture = ResourceLoader.load(String(it["tex_res"])) as Texture2D
			sp.set_meta("wf_id", String(it["id"]))
			if bool(it["animated"]):
				sp.set_script(motion_scr)
				sp.set("drift_speed", float(it["drift"]))
				sp.set("bob_amplitude", float(it["bob_amplitude"]))
				sp.set("bob_period", float(it["bob_period"]))
				sp.set("sway_degrees", float(it["sway_degrees"]))
				sp.set("sway_period", float(it["sway_period"]))
			_add(pl, sp, root_node)
	if s.get("level") != null:
		_append_parallax_level(root_node, s["level"], float(s["inv_ratio"]))
	return _save_scene(root_node, String(target["res_path"]), id, version, src_hash)


func _append_parallax_level(root_node: Node2D, lv: Dictionary, inv_ratio: float) -> void:
	var level := Node2D.new(); level.name = "Level"
	level.set_meta("wf_speed", float(lv["speed"])); level.set_meta("wf_jump", float(lv["jump"]))
	level.set_meta("wf_gravity", float(lv["gravity"])); level.set_meta("wf_climb", float(lv["climb"]))
	level.set_meta("wf_character_height", int(lv["character_height"]))
	level.set_meta("wf_collision_size", _vec2(lv["collision_size"]))
	_add(root_node, level, root_node)
	var art := Node2D.new(); art.name = "LevelArt"; _add(level, art, root_node)
	for g: Dictionary in lv["art_sprites"]:
		var sp := Sprite2D.new()
		sp.name = String(g["name"]); sp.position = _vec2(g["position"])
		sp.scale = Vector2(inv_ratio, inv_ratio); sp.centered = false
		if g.has("z_index"): sp.z_index = int(g["z_index"])
		sp.texture = ResourceLoader.load(String(g["tex_res"])) as Texture2D
		_add(art, sp, root_node)
	var tc := StaticBody2D.new(); tc.name = "TerrainCollision"; _add(level, tc, root_node)
	for r: Dictionary in lv["rects"]:
		var cs := CollisionShape2D.new(); cs.name = String(r["name"])
		cs.position = _vec2(r["center"]); cs.one_way_collision = bool(r["one_way"])
		var sh := RectangleShape2D.new(); sh.size = _vec2(r["size"]); cs.shape = sh
		_add(tc, cs, root_node)
	for sl: Dictionary in lv["slopes"]:
		var cp := CollisionPolygon2D.new(); cp.name = String(sl["name"]); cp.polygon = _poly(sl["points"])
		_add(tc, cp, root_node)
	if not (lv["climbs"] as Array).is_empty():
		var cl := Node2D.new(); cl.name = "Climbs"; _add(level, cl, root_node)
		for c: Dictionary in lv["climbs"]:
			var a := Area2D.new(); a.name = String(c["name"]); a.position = _vec2(c["center"])
			a.set_meta("wf_id", String(c["id"])); _add(cl, a, root_node)
			var cs := CollisionShape2D.new(); cs.name = "Shape"
			var sh := RectangleShape2D.new(); sh.size = Vector2(32.0, float(c["height"])); cs.shape = sh
			_add(a, cs, root_node)
	if not (lv["hazards"] as Array).is_empty():
		var hz := Node2D.new(); hz.name = "Hazards"; _add(level, hz, root_node)
		for h: Dictionary in lv["hazards"]:
			var a := Area2D.new(); a.name = String(h["name"]); a.position = _vec2(h["center"])
			a.set_meta("wf_kind", String(h["kind"])); _add(hz, a, root_node)
			var cs := CollisionShape2D.new(); cs.name = "Shape"
			var sh := RectangleShape2D.new(); sh.size = _vec2(h["size"]); cs.shape = sh
			_add(a, cs, root_node)
	var mk := Node2D.new(); mk.name = "Markers"; _add(level, mk, root_node)
	for m: Dictionary in lv["markers"]:
		var node := Marker2D.new(); node.name = String(m["name"]); node.position = _vec2(m["position"])
		if m.get("id") != null: node.set_meta("wf_id", String(m["id"]))
		_add(mk, node, root_node)


func _build_scene3d(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var target: Dictionary = s["scene_target"]
	if not bool(target["write"]):
		return true
	var glb := ResourceLoader.load(String(s["glb_res"])) as PackedScene
	if glb == null:
		push_error("Failed to load GLB PackedScene: " + String(s["glb_res"]))
		return false
	var root_node := Node3D.new(); root_node.name = "Scene3D"
	if not (s["blocked_doors"] as Array).is_empty():
		root_node.set_meta("wf_blocked_doors", PackedStringArray(s["blocked_doors"]))
	var env := Environment.new()
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.ambient_light_energy = float(s["ambient_intensity"])
	if s.get("ambient_color") != null:
		var ac: Array = s["ambient_color"]
		env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
		env.ambient_light_color = Color(float(ac[0]), float(ac[1]), float(ac[2]), 1.0)
	if s.get("fog_color") != null:
		var fc: Array = s["fog_color"]
		env.fog_enabled = true
		env.fog_light_color = Color(float(fc[0]), float(fc[1]), float(fc[2]), 1.0)
		env.fog_density = float(s["fog_density"])
	var we := WorldEnvironment.new(); we.name = "WorldEnvironment"; we.environment = env
	_add(root_node, we, root_node)
	var vis := glb.instantiate(); vis.name = "VisualScene"
	_add(root_node, vis, root_node)
	var col := StaticBody3D.new(); col.name = "Collision"; _add(root_node, col, root_node)
	for c: Dictionary in s["colliders"]:
		var cs := CollisionShape3D.new(); cs.name = String(c["name"])
		cs.position = _vec3(c["center"])
		var bx := BoxShape3D.new(); bx.size = _vec3(c["size"]); cs.shape = bx
		if c.get("room") != null: cs.set_meta("wf_room", String(c["room"]))
		_add(col, cs, root_node)
	if not (s["roles"] as Array).is_empty():
		var roles := Node3D.new(); roles.name = "Roles"; _add(root_node, roles, root_node)
		for r: Dictionary in s["roles"]:
			if bool(r["is_trigger"]):
				var area := Area3D.new(); area.name = String(r["name"])
				area.position = _vec3(r["center"])
				area.set_meta("wf_role", String(r["role"]))
				area.set_meta("wf_forward", _vec3(r["forward"]))
				if r.get("id") != null: area.set_meta("wf_id", String(r["id"]))
				if bool(r["blocked"]): area.set_meta("wf_blocked", true)
				_add(roles, area, root_node)
				var bcs := CollisionShape3D.new(); bcs.name = "Bounds"
				var bsh := BoxShape3D.new(); bsh.size = _vec3(r["size"]); bcs.shape = bsh
				_add(area, bcs, root_node)
			else:
				var m := Marker3D.new(); m.name = String(r["name"])
				m.transform = _t3d(r["transform"])
				m.set_meta("wf_role", String(r["role"]))
				if r.get("id") != null: m.set_meta("wf_id", String(r["id"]))
				_add(roles, m, root_node)
	return _save_scene(root_node, String(target["res_path"]), id, version, src_hash)


func _build_model3d(s: Dictionary, id: String, version: int, src_hash: String) -> bool:
	var target: Dictionary = s["scene_target"]
	if not bool(target["write"]):
		return true
	var glb := ResourceLoader.load(String(s["glb_res"])) as PackedScene
	if glb == null:
		push_error("Failed to load GLB PackedScene: " + String(s["glb_res"]))
		return false
	var root_node := Node3D.new(); root_node.name = "Model3D"
	root_node.set_meta("wf_height", float(s["height"])); root_node.set_meta("wf_bottom", float(s["bottom"]))
	root_node.set_meta("wf_bounds_min", _vec3(s["bounds_min"])); root_node.set_meta("wf_bounds_max", _vec3(s["bounds_max"]))
	root_node.set_meta("wf_bones", String(s["bones_json"]))
	var vis := glb.instantiate(); vis.name = "Visual"; _add(root_node, vis, root_node)
	var body := StaticBody3D.new(); body.name = "Body"; _add(root_node, body, root_node)
	var cs := CollisionShape3D.new(); cs.name = "Collider"; cs.position = _vec3(s["collider_center"])
	if String(s["collider_kind"]) == "capsule":
		var cap := CapsuleShape3D.new(); cap.radius = float(s["radius"]); cap.height = float(s["collider_height"])
		cs.shape = cap
	else:
		var bx := BoxShape3D.new(); bx.size = _vec3(s["size"]); cs.shape = bx
	_add(body, cs, root_node)
	if not (s["sockets"] as Array).is_empty():
		var socks := Node3D.new(); socks.name = "Sockets"; _add(root_node, socks, root_node)
		for sk: Dictionary in s["sockets"]:
			var m := Marker3D.new(); m.name = String(sk["name"]); m.position = _vec3(sk["position"])
			m.set_meta("wf_socket", String(sk["raw_name"]))
			if sk.get("bone") != null: m.set_meta("wf_bone", String(sk["bone"]))
			_add(socks, m, root_node)
	if not (s["clips"] as Array).is_empty():
		var clips := Node.new(); clips.name = "Clips"; _add(root_node, clips, root_node)
		for cl: Dictionary in s["clips"]:
			var n := Node.new(); n.name = String(cl["name"])
			n.set_meta("wf_clip", String(cl["raw_name"])); n.set_meta("wf_duration", float(cl["duration"]))
			if cl.get("loops") != null: n.set_meta("wf_loops", bool(cl["loops"]))
			if cl.get("travel") != null: n.set_meta("wf_travel", _vec3(cl["travel"]))
			if cl.get("sole_low") != null: n.set_meta("wf_sole_low", float(cl["sole_low"]))
			if cl.get("sole_high") != null: n.set_meta("wf_sole_high", float(cl["sole_high"]))
			if cl.get("liftoffs") != null: n.set_meta("wf_liftoffs", int(cl["liftoffs"]))
			if not (cl["checks"] as Array).is_empty(): n.set_meta("wf_checks", PackedStringArray(cl["checks"]))
			_add(clips, n, root_node)
	return _save_scene(root_node, String(target["res_path"]), id, version, src_hash)
