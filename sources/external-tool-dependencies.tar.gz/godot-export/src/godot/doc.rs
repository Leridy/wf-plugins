//! Godot node-name sanitization helpers.
use std::collections::BTreeSet;

/// Ensures unique Godot node names within a parent by sanitizing disallowed
/// characters (`. : @ / " %`) and disambiguating duplicates.
pub fn safe_node_name(raw: &str, ordinal: usize, fallback: &str, used: &mut BTreeSet<String>) -> String {
    let mut clean: String = raw
        .chars()
        .filter(|c| !matches!(c, '.' | ':' | '@' | '/' | '"' | '%'))
        .collect();
    if clean.is_empty() {
        clean = format!("{fallback}{ordinal}");
    }
    let base = clean.clone();
    let mut suffix = 2;
    while !used.insert(clean.clone()) {
        clean = format!("{base}_{suffix}");
        suffix += 1;
    }
    clean
}
