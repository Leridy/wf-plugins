//! Tilemap atlas, terrain, and layer preparation helpers for Godot CLI sync.
use crate::model::{Area, Orientation, TileMap};
use std::collections::{BTreeMap, BTreeSet};

/// Pixel values in the sidecar are whole or simple fractions.
const EPSILON: f64 = 1e-6;

/// A cell on a layer and the tile it shows: source, atlas x, atlas y.
pub(crate) type Placed = ([i64; 2], (u16, u16, u16));

pub(crate) fn same(a: f64, b: f64) -> bool {
    (a - b).abs() < EPSILON
}

/// Drops floating-point noise (0.8000000000000002) from a computed value:
/// six decimals are finer than any pixel the scene places.
pub(crate) fn tidy(value: f64) -> f64 {
    format!("{value:.6}").parse().unwrap_or(value)
}

pub(crate) struct PreparedTerrain {
    pub set: String,
    pub terrain: String,
    pub by_mask: BTreeMap<u8, Vec<[u16; 3]>>,
}

pub(crate) struct PreparedTileMap {
    pub atlas: Atlas,
    pub levels: BTreeMap<u32, Vec<Placed>>,
    pub opacity: BTreeMap<u32, f64>,
    pub offset: (f64, f64),
    pub terrains: Vec<PreparedTerrain>,
    pub notes: Vec<String>,
}

pub(crate) struct Atlas {
    pub sources: BTreeMap<String, u16>,
    pub tiles: BTreeMap<u16, BTreeSet<(u16, u16)>>,
}

impl Atlas {
    /// The tile a source rectangle names, when it is one whole aligned tile.
    fn tile(&mut self, map: &TileMap, texture: &str, source: Area) -> Option<(u16, u16, u16)> {
        let (w, h) = (map.tile_width, map.tile_height);
        let aligned = same(source.width, w)
            && same(source.height, h)
            && same((source.x / w).fract(), 0.0)
            && same((source.y / h).fract(), 0.0);
        if !aligned || source.x < 0.0 || source.y < 0.0 {
            return None;
        }
        let next = u16::try_from(self.sources.len()).ok()?;
        let id = *self.sources.entry(texture.to_owned()).or_insert(next);
        let coords = (
            u16::try_from((source.x / w) as i64).ok()?,
            u16::try_from((source.y / h) as i64).ok()?,
        );
        self.tiles.entry(id).or_default().insert(coords);
        Some((id, coords.0, coords.1))
    }
}

pub(crate) fn prepare(map: &TileMap) -> PreparedTileMap {
    let mut notes = Vec::new();
    let mut atlas = Atlas {
        sources: BTreeMap::new(),
        tiles: BTreeMap::new(),
    };
    let mut levels: BTreeMap<u32, Vec<Placed>> = BTreeMap::new();
    let mut opacity: BTreeMap<u32, f64> = BTreeMap::new();
    let mut offset = None;
    let mut skipped = 0;
    for tile in &map.ground {
        let Some(placed) = atlas.tile(map, &tile.texture, tile.source) else {
            skipped += 1;
            continue;
        };
        let local = cell_center(map, tile.cell);
        let shift = (
            tile.target.x + tile.target.width / 2.0 - local.0,
            tile.target.y + tile.target.height / 2.0 - local.1,
        );
        let o = *offset.get_or_insert(shift);
        if (o.0 - shift.0).abs() > 0.01 || (o.1 - shift.1).abs() > 0.01 {
            skipped += 1;
            continue;
        }
        levels.entry(tile.level).or_default().push((tile.cell, placed));
        let level = opacity.entry(tile.level).or_insert(tile.opacity);
        if !same(*level, tile.opacity) {
            notes.push(format!(
                "Terrain level {} mixes opacities; the layer uses {}.",
                tile.level, *level
            ));
        }
    }
    if skipped > 0 {
        notes.push(format!(
            "{skipped} terrain tile(s) are not whole aligned tiles of their atlas or sit off the layer grid; they were left out."
        ));
    }
    let mut terrains = Vec::new();
    for terrain in &map.terrains {
        let mut by_mask: BTreeMap<u8, Vec<[u16; 3]>> = BTreeMap::new();
        for tile in &terrain.tiles {
            if let Some((source, x, y)) = atlas.tile(map, &tile.texture, tile.source) {
                by_mask.entry(tile.mask).or_default().push([source, x, y]);
            }
        }
        terrains.push(PreparedTerrain {
            set: terrain.set.clone(),
            terrain: terrain.id.clone(),
            by_mask,
        });
    }
    notes.dedup();
    PreparedTileMap {
        atlas,
        levels,
        opacity,
        offset: offset.unwrap_or((0.0, 0.0)),
        terrains,
        notes,
    }
}

/// Where Godot puts a cell's centre on a layer of this map's tile set.
fn cell_center(map: &TileMap, [x, y]: [i64; 2]) -> (f64, f64) {
    let (w, h) = (map.tile_width, map.tile_height);
    // Godot keeps cell coordinates in 16 bits; the map's are far inside them.
    let (x, y) = (f64::from(x as i32), f64::from(y as i32));
    match map.orientation {
        Orientation::Isometric => ((x - y) * w / 2.0 + w / 2.0, (x + y) * h / 2.0 + h / 2.0),
        Orientation::Orthogonal => ((x + 0.5) * w, (y + 0.5) * h),
    }
}

/// The root node's name: Godot refuses `.`, `:`, `@`, `/`, `"` and `%` in one.
pub(crate) fn node_name(stem: &str) -> String {
    let name: String = stem
        .chars()
        .map(|c| {
            if matches!(c, '.' | ':' | '@' | '/' | '"' | '%') {
                '_'
            } else {
                c
            }
        })
        .collect();
    if name.is_empty() { "TileMap".into() } else { name }
}
