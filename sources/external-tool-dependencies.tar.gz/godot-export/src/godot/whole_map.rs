//! Embedded tile mask dilation shader for `whole_map` scenes.
pub(crate) const MASK_SHADER: &str = r"shader_type canvas_item;
uniform sampler2D mask_tex : filter_nearest, repeat_disable;
uniform vec2 texel_size = vec2(0.001, 0.001);

void fragment() {
	vec4 base = texture(TEXTURE, UV);
	float m = 0.0;
	for (int dy = -1; dy <= 1; dy++) {
		for (int dx = -1; dx <= 1; dx++) {
			vec2 suv = clamp(UV + vec2(float(dx), float(dy)) * texel_size, vec2(0.0), vec2(1.0));
			m = max(m, texture(mask_tex, suv).a);
		}
	}
	COLOR = vec4(base.rgb, base.a * m);
}
";
