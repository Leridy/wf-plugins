//! Embedded GDScript player (`particle_player.gd`) for 2D `particle_effect` scenes.
pub(crate) const PLAYER: &str = include_str!("particle_player.gd");
