//! Paths at the export boundary never escape the project's read grant.
use plugin_api::Failure;
use plugin_guest::{Host, HostError};

pub fn invalid(message: impl Into<String>) -> HostError {
    HostError::new(Failure::InvalidInput, message)
}

pub fn relative(path: &str) -> Result<(), HostError> {
    if path.is_empty()
        || path.contains(['\\', ':'])
        || path.chars().any(char::is_control)
        || path
            .split('/')
            .any(|s| s.is_empty() || s.starts_with('.') || s.ends_with(['.', ' ']))
    {
        return Err(invalid(format!("unsafe or unreadable export path: {path:?}")));
    }
    Ok(())
}

pub fn join(directory: &str, path: &str) -> String {
    if directory.is_empty() {
        path.into()
    } else {
        format!("{directory}/{path}")
    }
}

pub fn parent(path: &str) -> &str {
    path.rsplit_once('/').map_or("", |(parent, _)| parent)
}

pub fn root(host: &dyn Host, directory: &str) -> Result<String, HostError> {
    let mut dir = directory;
    loop {
        match host.read(&join(dir, "project.godot")) {
            Ok(_) => return Ok(dir.into()),
            Err(e) if e.not_found() => {}
            Err(e) => return Err(e),
        }
        if dir.is_empty() {
            break;
        }
        dir = parent(dir);
    }
    Err(invalid(
        "No project.godot above the export directory; set export_dir inside a Godot project.",
    ))
}

pub fn resource(root: &str, path: &str) -> String {
    format!(
        "res://{}",
        if root.is_empty() {
            path
        } else {
            path.strip_prefix(root).unwrap_or(path).trim_start_matches('/')
        }
    )
}

pub fn glob(path: &str) -> String {
    path.chars()
        .map(|c| match c {
            '*' | '?' | '[' | ']' | '{' | '}' => format!("[{c}]"),
            c => c.to_string(),
        })
        .collect()
}

/// Keep readable Unicode names, remove path syntax, and bound the UTF-8 length.
pub fn filename(name: &str) -> String {
    let mut safe = String::new();
    for c in name.chars() {
        let c = if c.is_alphanumeric() || matches!(c, '-' | '_') {
            c
        } else {
            '_'
        };
        if safe.len() + c.len_utf8() > 120 {
            break;
        }
        safe.push(c);
    }
    if safe.is_empty() {
        safe.push_str("Node");
    }
    // A prefix also avoids Windows device names without changing ordinary names.
    let upper = safe.to_ascii_uppercase();
    if matches!(upper.as_str(), "CON" | "PRN" | "AUX" | "NUL")
        || (upper.len() == 4
            && (upper.starts_with("COM") || upper.starts_with("LPT"))
            && upper.as_bytes()[3].is_ascii_digit())
    {
        safe.insert_str(0, "Node_");
    }
    safe
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing::Fake;
    #[test]
    fn the_nearest_project_and_resource_paths_agree() {
        let mut host = Fake::default();
        host.files.insert("project.godot".into(), Vec::new());
        host.files.insert("game/project.godot".into(), Vec::new());
        assert_eq!(root(&host, "game/assets/wf").unwrap(), "game");
        assert_eq!(resource("game", "game/assets/wf/a.png"), "res://assets/wf/a.png");
        assert!(root(&Fake::default(), "assets").is_err());
    }
    #[test]
    fn untrusted_names_and_paths_stay_local() {
        for path in ["../a", "/a", "a/../b", ".git/a", "a\\b", "a:/b", "a//b", "a./b"] {
            assert!(relative(path).is_err(), "{path}");
        }
        assert_eq!(filename("CON"), "Node_CON");
        assert_eq!(filename("hero/\"jump"), "hero__jump");
        assert!(filename(&"界".repeat(100)).len() <= 120);
    }
}
