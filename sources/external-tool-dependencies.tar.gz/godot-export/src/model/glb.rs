//! Minimal zero-dependency glTF 2.0 binary (`.glb`) chunk-0 JSON reader
//! and transform / AABB helpers for `scene3d_map` and `model_3d`.
use crate::paths::invalid;
use plugin_guest::HostError;
use serde::Deserialize;
use serde_json::Value;

const GLB_MAGIC: u32 = 0x4654_6C67; // "glTF"
const GLB_VERSION: u32 = 2;
const JSON_CHUNK: u32 = 0x4E4F_534A; // "JSON"

#[derive(Clone, Debug, Deserialize)]
pub struct GlbDoc {
    #[serde(default)]
    pub scenes: Vec<GlbScene>,
    #[serde(default)]
    pub scene: Option<usize>,
    #[serde(default)]
    pub nodes: Vec<GlbNode>,
    #[serde(default)]
    pub meshes: Vec<GlbMesh>,
    #[serde(default)]
    pub accessors: Vec<GlbAccessor>,
    #[serde(default)]
    pub extras: Value,
}

#[derive(Clone, Debug, Default, Deserialize)]
pub struct GlbScene {
    #[serde(default)]
    pub nodes: Vec<usize>,
    #[serde(default)]
    pub extras: Value,
}

#[derive(Clone, Debug, Default, Deserialize)]
pub struct GlbNode {
    #[serde(default)]
    pub name: Option<String>,
    #[serde(default)]
    pub children: Vec<usize>,
    #[serde(default)]
    pub mesh: Option<usize>,
    #[serde(default)]
    pub translation: Option<[f64; 3]>,
    #[serde(default)]
    pub rotation: Option<[f64; 4]>,
    #[serde(default)]
    pub scale: Option<[f64; 3]>,
    #[serde(default)]
    pub matrix: Option<[f64; 16]>,
    #[serde(default)]
    pub extras: Value,
}

#[derive(Clone, Debug, Default, Deserialize)]
pub struct GlbMesh {
    #[serde(default)]
    pub primitives: Vec<GlbPrimitive>,
}

#[derive(Clone, Debug, Default, Deserialize)]
pub struct GlbPrimitive {
    #[serde(default)]
    pub attributes: GlbAttributes,
}

#[derive(Clone, Debug, Default, Deserialize)]
#[allow(non_snake_case)]
pub struct GlbAttributes {
    #[serde(default)]
    pub POSITION: Option<usize>,
}

#[derive(Clone, Debug, Default, Deserialize)]
pub struct GlbAccessor {
    #[serde(default)]
    pub min: Option<Vec<f64>>,
    #[serde(default)]
    pub max: Option<Vec<f64>>,
}

pub fn parse_glb(bytes: &[u8]) -> Result<GlbDoc, HostError> {
    if bytes.len() < 20 {
        return Err(invalid("GLB file is truncated (< 20 bytes)"));
    }
    let magic = u32::from_le_bytes(bytes[0..4].try_into().expect("4 bytes"));
    let version = u32::from_le_bytes(bytes[4..8].try_into().expect("4 bytes"));
    let total_len = u32::from_le_bytes(bytes[8..12].try_into().expect("4 bytes")) as usize;
    if magic != GLB_MAGIC || version != GLB_VERSION || total_len > bytes.len() {
        return Err(invalid("invalid glTF 2.0 binary header"));
    }
    let chunk_len = u32::from_le_bytes(bytes[12..16].try_into().expect("4 bytes")) as usize;
    let chunk_type = u32::from_le_bytes(bytes[16..20].try_into().expect("4 bytes"));
    if chunk_type != JSON_CHUNK || 20 + chunk_len > total_len {
        return Err(invalid("missing or truncated glTF JSON chunk 0"));
    }
    serde_json::from_slice(&bytes[20..20 + chunk_len]).map_err(|e| invalid(format!("invalid glTF chunk-0 JSON: {e}")))
}

/// Column-major 4x4 matrix (`glTF` order: col*4 + row).
pub fn node_matrix(node: &GlbNode) -> [f64; 16] {
    if let Some(m) = node.matrix {
        return m;
    }
    let tr = node.translation.unwrap_or([0.0, 0.0, 0.0]);
    let [qx, qy, qz, qw] = node.rotation.unwrap_or([0.0, 0.0, 0.0, 1.0]);
    let [sx, sy, sz] = node.scale.unwrap_or([1.0, 1.0, 1.0]);
    let (x2, y2, z2) = (qx + qx, qy + qy, qz + qz);
    let (xx, xy, xz) = (qx * x2, qx * y2, qx * z2);
    let (yy, yz, zz) = (qy * y2, qy * z2, qz * z2);
    let (wx, wy, wz) = (qw * x2, qw * y2, qw * z2);
    [
        (1.0 - (yy + zz)) * sx,
        (xy + wz) * sx,
        (xz - wy) * sx,
        0.0,
        (xy - wz) * sy,
        (1.0 - (xx + zz)) * sy,
        (yz + wx) * sy,
        0.0,
        (xz + wy) * sz,
        (yz - wx) * sz,
        (1.0 - (xx + yy)) * sz,
        0.0,
        tr[0],
        tr[1],
        tr[2],
        1.0,
    ]
}

pub fn mul_mat4(a: [f64; 16], b: [f64; 16]) -> [f64; 16] {
    let mut out = [0.0; 16];
    for c in 0..4 {
        for r in 0..4 {
            out[c * 4 + r] =
                a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
        }
    }
    out
}

pub fn transform_aabb(m: [f64; 16], min: [f64; 3], max: [f64; 3]) -> ([f64; 3], [f64; 3]) {
    let mut out_min = [f64::INFINITY; 3];
    let mut out_max = [f64::NEG_INFINITY; 3];
    for ix in 0..2 {
        let px = if ix == 0 { min[0] } else { max[0] };
        for iy in 0..2 {
            let py = if iy == 0 { min[1] } else { max[1] };
            for iz in 0..2 {
                let pz = if iz == 0 { min[2] } else { max[2] };
                let x = m[0] * px + m[4] * py + m[8] * pz + m[12];
                let y = m[1] * px + m[5] * py + m[9] * pz + m[13];
                let z = m[2] * px + m[6] * py + m[10] * pz + m[14];
                out_min[0] = out_min[0].min(x);
                out_min[1] = out_min[1].min(y);
                out_min[2] = out_min[2].min(z);
                out_max[0] = out_max[0].max(x);
                out_max[1] = out_max[1].max(y);
                out_max[2] = out_max[2].max(z);
            }
        }
    }
    (out_min, out_max)
}
