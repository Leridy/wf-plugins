use super::*;

fn clip(durations: &str) -> String {
    format!(
        r#"{{"images":{{"a":{{"type":"png","path":"a.png"}},"b":{{"type":"png","path":"b.png"}}}},"clips":[{{"actionId":"walk","direction":"source","files":["a","b"],"durationsMs":{durations},"loop":true,"anchor":{{"x":4,"y":8}}}}]}}"#
    )
}
#[test]
fn fractional_timing_and_unknown_fields_are_preserved() {
    let bytes = clip("[83.33333333333333, 125]");
    let a = Animation::read(bytes.as_bytes()).unwrap();
    assert_eq!(a.clips[0].name, "walk");
    assert!((a.clips[0].frames[0].duration_ms - 1000.0 / 12.0).abs() < 1e-10);
}
#[test]
fn invalid_timing_never_reaches_the_writer() {
    for durations in ["[]", "[1]", "[0,2]", "[-1,2]", "[1e-320,2]"] {
        assert!(Animation::read(clip(durations).as_bytes()).is_err(), "{durations}");
    }
}
#[test]
fn missing_images_and_unsafe_paths_are_rejected() {
    let bytes = clip("[1,2]");
    assert!(Animation::read(bytes.replace("\"a.png\"", "\"../a.png\"").as_bytes()).is_err());
    assert!(Animation::read(bytes.replace("\"files\":[\"a\"", "\"files\":[\"missing\"").as_bytes()).is_err());
}
#[test]
fn empty_animation_and_unknown_image_form_are_rejected() {
    assert!(Animation::read(br#"{"images":{},"clips":[]}"#).is_err());
    assert!(Animation::read(clip("[1,2]").replace("png", "future").as_bytes()).is_err());
}

fn bar(fills: &str) -> Kit {
    let bytes = format!(
        r#"{{"images":{{"low":{{"type":"png","path":"fill-5.png"}},"full":{{"type":"png","path":"fill-100.png"}}}},
        "elements":[{{"name":"Stamina","kind":"progress-bar","size":{{"width":940,"height":129}},
        "widget":{{"type":"bar","fills":{fills}}},"states":[
        {{"name":"low","file":"low","role":"fill","slice":{{"mode":"three","borders":{{"left":46,"right":893,"top":0,"bottom":0}}}}}},
        {{"name":"full","file":"full","role":"fill","slice":{{"mode":"three","borders":{{"left":90,"right":90,"top":0,"bottom":0}}}}}}
        ]}}]}}"#
    );
    Kit::read(bytes.as_bytes()).unwrap()
}

#[test]
fn smallest_first_bar_selects_fullest_with_its_own_borders() {
    let kit = bar(r#"[{"amount":5,"cell":{"name":"low"}},{"amount":100,"cell":{"name":"full"}}]"#);
    let states = &kit.widgets[0].states;
    assert_eq!(states.len(), 1);
    assert_eq!(states[0].style, Style::Fill);
    assert_eq!(states[0].texture.path, "fill-100.png");
    assert_eq!(states[0].slice.values(), [90.0, 90.0, 0.0, 0.0]);
}

#[test]
fn bar_selects_largest_amount_and_breaks_ties_by_last_fill_order() {
    for fills in [
        r#"[{"amount":100,"cell":{"name":"full"}},{"amount":5,"cell":{"name":"low"}}]"#,
        r#"[{"amount":100,"cell":{"name":"low"}},{"amount":100,"cell":{"name":"full"}}]"#,
    ] {
        assert_eq!(bar(fills).widgets[0].states[0].texture.path, "fill-100.png");
    }
    // Fill order, not state order, determines which equal-amount entry wins.
    let kit = bar(r#"[{"amount":100,"cell":{"name":"full"}},{"amount":100,"cell":{"name":"low"}}]"#);
    assert_eq!(kit.widgets[0].states[0].texture.path, "fill-5.png");
    assert_eq!(kit.widgets[0].states[0].slice.values(), [46.0, 893.0, 0.0, 0.0]);
}

fn effect(emitter: &str, sprites: &str) -> String {
    format!(
        r##"{{"schema":"particle-effect/1.0","seed":7,"duration":1,"looping":false,"space":"planar","emitters":[{{"id":"core","name":"Core","enabled":true,"rate":1,"burst":0,"delay":0,"lifetime":[0.5,1],"position":[0,0,0],"spread":[0,0,0],"velocity":[0,0,0],"velocitySpread":[0,0,0],"gravity":[0,0,0],"drag":0,"size":[1,1],"opacity":[1,1],"color":["#FFFFFF","#000000"],"blend":"normal","texture":"soft","maxParticles":10{emitter}}}],"sprites":[{sprites}]}}"##
    )
}
#[test]
fn particle_streams_start_where_the_editor_starts_them() {
    // simulation.ts `random(seed, id)` evaluated in Node for the same inputs.
    assert_eq!(particle::random_state(7, "core"), 2_480_295_964);
    assert_eq!(particle::random_state(7, "ember"), 1_448_717_538);
    assert_eq!(particle::random_state(42, "vortex_arcs"), 1_119_871_702);
    let built_in = ParticleEffect::read(effect("", "").as_bytes()).unwrap();
    assert_eq!(built_in.emitters[0].picture, "particle-texture-soft.png");
    assert_eq!(built_in.emitters[0].orientation.as_str(), "random");
    let sprite =
        ParticleEffect::read(effect(r#","sprite":"puff""#, r#"{"id":"puff","name":"Puff"}"#).as_bytes()).unwrap();
    assert_eq!(sprite.emitters[0].picture, "particle-sprite-puff.png");
    assert_eq!(sprite.emitters[0].orientation.as_str(), "upright");
}
#[test]
fn invalid_particle_documents_never_reach_the_writer() {
    let cases = [
        effect("", "").replace("particle-effect/1.0", "particle-effect/2.0"),
        effect(r#","sprite":"puff""#, ""),
        effect(r#","sprite":"../x""#, r#"{"id":"../x","name":"X"}"#),
        effect("", "").replace("#000000", "red"),
        effect("", "").replace("[0.5,1]", "[1,0.5]"),
        effect("", "").replace("\"duration\":1", "\"duration\":0"),
        effect("", "").replace("\"maxParticles\":10", "\"maxParticles\":10001"),
        effect("", "").replace("\"drag\":0", "\"drag\":-1"),
        effect("", "").replace("\"size\":[1,1]", "\"size\":[1]"),
        effect("", "").replace("\"opacity\":[1,1]", "\"opacity\":[1,1,1,1,1,1,1,1,1]"),
        effect(r#","radial":{"speed":[3,1],"radius":[0,0],"cone":90}"#, ""),
        effect(
            r#","triggers":[{"on":"death","emitter":"core","count":1,"inherit":0}]"#,
            "",
        ),
        effect(
            r#","triggers":[{"on":"land","emitter":"missing","count":1,"inherit":0}]"#,
            "",
        ),
    ];
    for case in cases {
        assert!(ParticleEffect::read(case.as_bytes()).is_err(), "{case}");
    }
}
#[test]
fn curve_keys_and_motion_reach_the_writer_and_a_disabled_target_is_dropped() {
    let emitter = |id: &str, enabled: bool, extra: &str| {
        format!(
            r##"{{"id":"{id}","name":"{id}","enabled":{enabled},"rate":0,"burst":1,"delay":0,"lifetime":[1,1],"position":[0,0,0],"spread":[0,0,0],"velocity":[0,0,0],"velocitySpread":[0,0,0],"gravity":[0,0,0],"drag":0,"opacity":[1,1],"color":["#FFFFFF","#FFFFFF"],"blend":"normal","texture":"soft","maxParticles":10{extra}}}"##
        )
    };
    let core = emitter(
        "core",
        true,
        r#","size":[1,2,0.5],"stretch":0.04,"ground":{"bounce":0.4,"friction":0.3,"kill":false},"triggers":[{"on":"land","emitter":"puff","count":2,"inherit":0.5},{"on":"death","emitter":"off","count":1,"inherit":0}]"#,
    );
    let document = format!(
        r#"{{"schema":"particle-effect/1.0","seed":7,"duration":1,"looping":false,"space":"planar","emitters":[{core},{},{}]}}"#,
        emitter("puff", true, r#","size":[1,1]"#),
        emitter("off", false, r#","size":[1,1]"#),
    );
    let read = ParticleEffect::read(document.as_bytes()).unwrap();
    let core = &read.emitters[0];
    assert_eq!(core.size, [1.0, 2.0, 0.5]);
    assert_eq!(core.stretch, 0.04);
    let ground = core.ground.as_ref().unwrap();
    assert_eq!(ground.bounce, 0.4);
    assert!(!ground.kill);
    assert_eq!(
        core.triggers.len(),
        1,
        "the trigger naming the disabled emitter is dropped"
    );
    assert_eq!(core.triggers[0].emitter, "puff");
    assert_eq!(read.emitters.len(), 2);
}
