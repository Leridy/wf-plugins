//! A tile map as `wf export` resolves it (`tilemap.json`): terrain tiles on
//! dual-grid display cells, sprites in drawing order, collision polygons and
//! the terrain tables, all in map pixels. Texture files are relative to the
//! sidecar. Unknown fields are ignored: the file is the CLI's output.
use super::{Point, parse};
use crate::paths::{self, invalid};
use plugin_guest::HostError;
use serde::Deserialize;
use std::collections::BTreeMap;

#[derive(Clone, Copy, Debug, Deserialize, PartialEq)]
pub struct Area {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Orientation {
    Orthogonal,
    Isometric,
}

#[derive(Debug, Deserialize)]
pub struct TextureFile {
    pub file: String,
    pub width: f64,
    pub height: f64,
}

#[derive(Debug, Deserialize)]
pub struct GroundTile {
    pub level: u32,
    pub cell: [i64; 2],
    pub texture: String,
    pub source: Area,
    pub target: Area,
    pub opacity: f64,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Sprite {
    pub id: String,
    pub texture: String,
    pub position: Point,
    pub rect: Area,
    #[serde(default)]
    pub source: Option<Area>,
    pub rotation: f64,
    pub flip_x: bool,
    pub opacity: f64,
}

#[derive(Debug, Deserialize)]
pub struct Obstacle {
    pub kind: String,
    pub points: Vec<Point>,
}

#[derive(Debug, Deserialize)]
pub struct TerrainTile {
    pub mask: u8,
    pub texture: String,
    pub source: Area,
}

#[derive(Debug, Deserialize)]
pub struct Terrain {
    pub set: String,
    /// The terrain's id within its set.
    #[serde(rename = "terrain")]
    pub id: String,
    pub tiles: Vec<TerrainTile>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TileMap {
    pub orientation: Orientation,
    pub tile_width: f64,
    pub tile_height: f64,
    pub textures: BTreeMap<String, TextureFile>,
    pub ground: Vec<GroundTile>,
    pub sprites: Vec<Sprite>,
    pub walkable: Vec<Vec<Point>>,
    pub obstacles: Vec<Obstacle>,
    pub spawn: Option<Point>,
    pub terrains: Vec<Terrain>,
}

impl TileMap {
    pub fn read(bytes: &[u8]) -> Result<Self, HostError> {
        let map: Self = parse(bytes)?;
        let positive = |v: f64| v.is_finite() && v > 0.0;
        if !positive(map.tile_width) || !positive(map.tile_height) {
            return Err(invalid("tilemap.json: tile size must be positive"));
        }
        for texture in map.textures.values() {
            paths::relative(&texture.file)?;
            if !positive(texture.width) || !positive(texture.height) {
                return Err(invalid(format!("tilemap.json: {} has no size", texture.file)));
            }
        }
        let known = |key: &str| {
            map.textures
                .contains_key(key)
                .then_some(())
                .ok_or_else(|| invalid(format!("tilemap.json: texture {key:?} is absent from textures")))
        };
        let finite = |area: Area| [area.x, area.y, area.width, area.height].iter().all(|v| v.is_finite());
        for tile in &map.ground {
            known(&tile.texture)?;
            if !finite(tile.source) || !finite(tile.target) || tile.level > 64 {
                return Err(invalid("tilemap.json: invalid ground tile"));
            }
        }
        for sprite in &map.sprites {
            known(&sprite.texture)?;
            if !finite(sprite.rect)
                || sprite.rect.width <= 0.0
                || sprite.rect.height <= 0.0
                || sprite
                    .source
                    .is_some_and(|s| !finite(s) || s.width <= 0.0 || s.height <= 0.0)
                || ![sprite.position.x, sprite.position.y, sprite.rotation, sprite.opacity]
                    .iter()
                    .all(|v| v.is_finite())
            {
                return Err(invalid(format!("tilemap.json: invalid sprite {:?}", sprite.id)));
            }
        }
        for terrain in &map.terrains {
            for tile in &terrain.tiles {
                known(&tile.texture)?;
            }
        }
        let polygons = map.walkable.iter().chain(map.obstacles.iter().map(|o| &o.points));
        for polygon in polygons {
            if polygon.iter().any(|p| !p.x.is_finite() || !p.y.is_finite()) {
                return Err(invalid("tilemap.json: invalid polygon point"));
            }
        }
        Ok(map)
    }
}
