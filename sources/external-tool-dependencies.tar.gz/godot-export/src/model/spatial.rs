//! `scene3d_map` (`engine-scene.glb`) and `model_3d` (`model.json` + `main.glb`) models.
use super::glb::{GlbDoc, mul_mat4, node_matrix, parse_glb, transform_aabb};
use crate::paths::invalid;
use plugin_guest::HostError;
use serde::Deserialize;
use serde_json::Value;
use std::collections::BTreeMap;

#[derive(Clone, Debug, Deserialize)]
#[serde(tag = "shape", rename_all = "camelCase")]
pub enum Collider3d {
    Capsule { radius: f64, height: f64, center: [f64; 3] },
    Box { size: [f64; 3], center: [f64; 3] },
}

#[derive(Clone, Debug, Deserialize)]
pub struct ModelBounds {
    pub min: [f64; 3],
    pub max: [f64; 3],
}

#[derive(Clone, Debug, Deserialize)]
pub struct ModelSocket {
    pub name: String,
    pub position: [f64; 3],
    #[serde(default)]
    pub bone: Option<String>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ModelClip {
    pub name: String,
    pub duration: f64,
    #[serde(default)]
    pub loops: Option<bool>,
    #[serde(default)]
    pub travel: Option<[f64; 3]>,
    #[serde(default)]
    pub sole_low: Option<f64>,
    #[serde(default)]
    pub sole_high: Option<f64>,
    #[serde(default)]
    pub liftoffs: Option<u32>,
    #[serde(default)]
    pub checks: Vec<String>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Model3d {
    pub schema: String,
    pub bounds: ModelBounds,
    pub height: f64,
    pub bottom: f64,
    pub collider: Collider3d,
    #[serde(default)]
    pub bones: BTreeMap<String, String>,
    #[serde(default)]
    pub sockets: Vec<ModelSocket>,
    #[serde(default)]
    pub clips: Vec<ModelClip>,
    #[serde(skip)]
    pub glb_file: String,
}

impl Model3d {
    pub fn read(model_bytes: &[u8], glb_bytes: &[u8], glb_file: String) -> Result<Self, HostError> {
        let model: Self = super::parse(model_bytes)?;
        if model.schema != "weaveforge-model/1" {
            return Err(invalid(format!("unsupported model_3d schema {:?}", model.schema)));
        }
        let _glb = parse_glb(glb_bytes)?;
        Ok(Self { glb_file, ..model })
    }
}

#[derive(Clone, Debug, Deserialize)]
pub struct SceneRole {
    pub role: String,
    #[serde(default)]
    pub id: Option<String>,
    #[serde(default)]
    pub node: Option<String>,
    pub position: [f64; 3],
    #[serde(default = "default_forward")]
    pub forward: [f64; 3],
    #[serde(default)]
    pub min: Option<[f64; 3]>,
    #[serde(default)]
    pub max: Option<[f64; 3]>,
}

fn default_forward() -> [f64; 3] {
    [0.0, 0.0, -1.0]
}

#[derive(Clone, Debug)]
pub struct SolidColliderBox {
    pub name: String,
    pub center: [f64; 3],
    pub size: [f64; 3],
    pub room: Option<String>,
}

#[derive(Clone, Debug, Default)]
pub struct SceneEnvironment {
    pub ambient_color: Option<[f64; 3]>,
    pub ambient_intensity: f64,
    pub fog_color: Option<[f64; 3]>,
    pub fog_density: f64,
    pub fog_near: Option<f64>,
    pub fog_far: Option<f64>,
}

#[derive(Clone, Debug)]
pub struct Scene3dMap {
    pub glb_file: String,
    pub environment: SceneEnvironment,
    pub roles: Vec<SceneRole>,
    pub blocked_doors: Vec<String>,
    pub colliders: Vec<SolidColliderBox>,
    pub notes: Vec<String>,
}

impl Scene3dMap {
    pub fn read(glb_bytes: &[u8], glb_file: String) -> Result<Self, HostError> {
        let doc = parse_glb(glb_bytes)?;
        let wf = find_weaveforge_root(&doc);
        let environment = wf
            .and_then(|v| v.get("environment"))
            .map(parse_environment)
            .unwrap_or_default();

        let roles: Vec<SceneRole> = wf
            .and_then(|v| v.get("roles"))
            .and_then(|v| serde_json::from_value(v.clone()).ok())
            .unwrap_or_default();

        let mut blocked_doors = Vec::new();
        if let Some(blocked) = wf.and_then(|v| v.get("blockedDoors")).and_then(Value::as_array) {
            for entry in blocked {
                if let Some(door_name) = entry
                    .get("door")
                    .and_then(Value::as_str)
                    .or_else(|| entry.get("id").and_then(Value::as_str))
                {
                    blocked_doors.push(door_name.to_owned());
                }
            }
        }

        let mut notes = Vec::new();
        if !blocked_doors.is_empty() {
            notes.push(format!(
                "Blocked doors in engine-scene.glb: {}",
                blocked_doors.join(", ")
            ));
        }

        let colliders = extract_solid_colliders(&doc);
        Ok(Self {
            glb_file,
            environment,
            roles,
            blocked_doors,
            colliders,
            notes,
        })
    }
}

fn find_weaveforge_root(doc: &GlbDoc) -> Option<&Value> {
    if let Some(wf) = doc.extras.get("weaveforge") {
        return Some(wf);
    }
    let scene_idx = doc.scene.unwrap_or(0);
    if let Some(scene) = doc.scenes.get(scene_idx) {
        if let Some(wf) = scene.extras.get("weaveforge") {
            return Some(wf);
        }
        for &root_idx in &scene.nodes {
            if let Some(wf) = doc.nodes.get(root_idx).and_then(|n| n.extras.get("weaveforge"))
                && wf.get("schema").is_some()
            {
                return Some(wf);
            }
        }
    }
    doc.nodes
        .iter()
        .find_map(|n| n.extras.get("weaveforge").filter(|w| w.get("schema").is_some()))
}

fn extract_solid_colliders(doc: &GlbDoc) -> Vec<SolidColliderBox> {
    let mut out = Vec::new();
    let roots: Vec<usize> = doc
        .scenes
        .get(doc.scene.unwrap_or(0))
        .map(|s| s.nodes.clone())
        .unwrap_or_else(|| (0..doc.nodes.len()).take(1).collect());
    let identity = [
        1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0,
    ];
    for root in roots {
        traverse_node(doc, root, identity, None, None, &mut out);
    }
    out
}

fn traverse_node(
    doc: &GlbDoc,
    idx: usize,
    parent_mat: [f64; 16],
    inherited_collision: Option<&str>,
    inherited_room: Option<&str>,
    out: &mut Vec<SolidColliderBox>,
) {
    let Some(node) = doc.nodes.get(idx) else {
        return;
    };
    let wf = node.extras.get("weaveforge");
    let collision = wf
        .and_then(|w| w.get("collision"))
        .and_then(Value::as_str)
        .or(inherited_collision);
    let room = wf
        .and_then(|w| w.get("room"))
        .and_then(Value::as_str)
        .or(inherited_room);
    let world = mul_mat4(parent_mat, node_matrix(node));

    if collision == Some("solid")
        && let Some(mesh_idx) = node.mesh
        && let Some(mesh) = doc.meshes.get(mesh_idx)
    {
        for (p_idx, prim) in mesh.primitives.iter().enumerate() {
            let Some(acc_idx) = prim.attributes.POSITION else {
                continue;
            };
            let Some(acc) = doc.accessors.get(acc_idx) else {
                continue;
            };
            let (Some(min), Some(max)) = (acc.min.as_deref(), acc.max.as_deref()) else {
                continue;
            };
            if min.len() < 3 || max.len() < 3 {
                continue;
            }
            let (wmin, wmax) = transform_aabb(world, [min[0], min[1], min[2]], [max[0], max[1], max[2]]);
            let size = [
                (wmax[0] - wmin[0]).max(0.01),
                (wmax[1] - wmin[1]).max(0.01),
                (wmax[2] - wmin[2]).max(0.01),
            ];
            let center = [
                (wmin[0] + wmax[0]) * 0.5,
                (wmin[1] + wmax[1]) * 0.5,
                (wmin[2] + wmax[2]) * 0.5,
            ];
            let base = node.name.as_deref().unwrap_or("Solid");
            let name = if p_idx == 0 {
                base.to_owned()
            } else {
                format!("{base}_{p_idx}")
            };
            out.push(SolidColliderBox {
                name,
                center,
                size,
                room: room.map(str::to_owned),
            });
        }
    }

    for &child in &node.children {
        traverse_node(doc, child, world, collision, room, out);
    }
}

fn parse_environment(env: &Value) -> SceneEnvironment {
    let mut out = SceneEnvironment {
        ambient_color: None,
        ambient_intensity: 0.5,
        fog_color: None,
        fog_density: 0.0,
        fog_near: None,
        fog_far: None,
    };
    if let Some(arr) = env.get("ambient").and_then(Value::as_array)
        && let Some(first) = arr.first()
    {
        out.ambient_color = parse_rgb(first.get("color"));
        if let Some(i) = first.get("intensity").and_then(Value::as_f64) {
            out.ambient_intensity = i;
        }
    } else if let Some(obj) = env.get("ambient").and_then(Value::as_object) {
        out.ambient_color = parse_rgb(obj.get("color"));
        if let Some(i) = obj.get("intensity").and_then(Value::as_f64) {
            out.ambient_intensity = i;
        }
    }
    if let Some(fog) = env.get("fog").filter(|v| !v.is_null()) {
        out.fog_color = parse_rgb(fog.get("color"));
        out.fog_density = fog.get("density").and_then(Value::as_f64).unwrap_or(0.01);
        out.fog_near = fog.get("near").and_then(Value::as_f64);
        out.fog_far = fog.get("far").and_then(Value::as_f64);
    }
    out
}

fn parse_rgb(v: Option<&Value>) -> Option<[f64; 3]> {
    let v = v?;
    if let Some(arr) = v.as_array()
        && arr.len() >= 3
    {
        return Some([arr[0].as_f64()?, arr[1].as_f64()?, arr[2].as_f64()?]);
    }
    if let Some(s) = v.as_str()
        && let Some(hex) = s.strip_prefix('#')
        && hex.len() == 6
    {
        let r = u8::from_str_radix(&hex[0..2], 16).ok()? as f64 / 255.0;
        let g = u8::from_str_radix(&hex[2..4], 16).ok()? as f64 / 255.0;
        let b = u8::from_str_radix(&hex[4..6], 16).ok()? as f64 / 255.0;
        return Some([r, g, b]);
    }
    if let Some(n) = v.as_u64() {
        let r = ((n >> 16) & 0xff) as f64 / 255.0;
        let g = ((n >> 8) & 0xff) as f64 / 255.0;
        let b = (n & 0xff) as f64 / 255.0;
        return Some([r, g, b]);
    }
    None
}
