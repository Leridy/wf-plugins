//! A result row uses the same node status as the structured sync report.
use crate::types::{Node, Output, Status};
use plugin_protocols::ui::{Cell, Status as UiStatus, Tone};

impl Output {
    pub(crate) fn push_node(&mut self, node: Node, form: Option<&str>) {
        let (tone, text) = match (form, node.status) {
            (None, _) => (Tone::Warn, "Run wf export"),
            (_, Status::Written) => (Tone::Ok, "Written"),
            (_, Status::Updated) => (Tone::Ok, "Updated"),
            (_, Status::Unchanged) => (Tone::Neutral, "Unchanged"),
            (_, Status::Skipped) => (Tone::Warn, "Skipped"),
            (_, Status::Kept) => (Tone::Warn, "Edits kept"),
        };
        self.table.rows.push(vec![
            Cell::Node(format!("wf://{}", node.id)),
            Cell::Status(UiStatus {
                tone,
                text: text.into(),
            }),
            Cell::Number(f64::from(
                u32::try_from(node.files.len()).expect("resource count fits u32"),
            )),
            Cell::Path(node.main_scene.clone().unwrap_or_default()),
        ]);
        self.nodes.push(node);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::File;

    #[test]
    fn multiple_scenes_use_the_explicit_entry_point_in_any_file_order() {
        // Current writers emit at most one scene. Exercise the result contract
        // with a supporting scene ahead of the one a user should instance.
        let child = "assets/wf/meadow/Tree.tscn";
        let main = "assets/wf/meadow/Meadow.tscn";
        for paths in [[child, main], [main, child]] {
            for status in [Status::Written, Status::Unchanged, Status::Kept] {
                let mut output = Output::default();
                output.push_node(
                    Node {
                        id: "11111111-1111-4111-8111-111111111111".into(),
                        number: 75,
                        path: "Maps/Meadow".into(),
                        node_type: "tilemap".into(),
                        status,
                        files: paths
                            .map(|path| File {
                                path: path.into(),
                                resource: format!("res://{path}"),
                                status,
                            })
                            .into(),
                        main_scene: Some(main.into()),
                        elements: Vec::new(),
                        reasons: Vec::new(),
                    },
                    Some("source"),
                );
                // The host receives this serialized output, including typed cells.
                let wire = serde_json::to_vec(&output).unwrap();
                let output: Output = serde_json::from_slice(&wire).unwrap();
                assert_eq!(output.nodes[0].main_scene.as_deref(), Some(main));
                assert_eq!(output.table.rows[0][2], Cell::Number(2.0));
                assert_eq!(output.table.rows[0][3], Cell::Path(main.into()));
            }
        }
    }
}
