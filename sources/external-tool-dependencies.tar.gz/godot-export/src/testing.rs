//! The unit tests' in-memory host, with typed mirror answers.
use globset::Glob;
use plugin_api::{
    Effect, Failure,
    platform::{LocksOutput, NodeInput, NodeOutput},
};
use plugin_guest::{Host, HostError, Platform};
use std::{
    cell::RefCell,
    collections::{BTreeMap, BTreeSet},
};

#[derive(Default)]
pub struct Fake {
    pub files: BTreeMap<String, Vec<u8>>,
    pub locks: Option<LocksOutput>,
    pub nodes: Vec<NodeOutput>,
    pub tools: BTreeSet<String>,
    pub cleanup: RefCell<Vec<String>>,
}
impl Fake {
    #[allow(dead_code)]
    pub fn apply(&mut self, effects: Vec<Effect>) {
        for effect in effects {
            match effect {
                Effect::WriteFile { path, bytes, .. } => {
                    self.files.insert(path, bytes);
                }
                Effect::DeleteFile { path } => {
                    self.files.remove(&path);
                }
                Effect::Exec { .. } => {}
                _ => unreachable!("only writes, deletes and exec"),
            }
        }
        for path in self.cleanup.borrow_mut().drain(..) {
            self.files.remove(&path);
        }
    }
}
impl Host for Fake {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        self.files.keys().filter(|p| matcher.is_match(p)).cloned().collect()
    }
    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.files
            .get(path)
            .cloned()
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }
    fn warn(&self, _: &str) {}
    fn tool_available(&self, tool: &str) -> bool {
        self.tools.contains(tool)
    }
    fn cleanup_after_exec(&self, path: &str) -> Result<(), HostError> {
        self.cleanup.borrow_mut().push(path.to_owned());
        Ok(())
    }
}
impl Platform for Fake {
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, HostError> {
        match method {
            "wf.mirror.locks" => Ok(serde_json::to_vec(self.locks.as_ref().unwrap()).unwrap()),
            "wf.mirror.node" => {
                let query: NodeInput = serde_json::from_slice(input).unwrap();
                let node = self
                    .nodes
                    .iter()
                    .find(|n| {
                        query.address == format!("wf://{}", n.node.id)
                            || query.address == format!("#{}", n.node.number)
                            || query.address == n.node.path
                    })
                    .ok_or_else(|| HostError::new(Failure::NotFound, "node"))?;
                Ok(serde_json::to_vec(node).unwrap())
            }
            _ => unreachable!("only mirror reads"),
        }
    }
}
