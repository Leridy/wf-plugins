//! Ownership is proven by a complete header and an unchanged body hash.
use crate::{paths, types::Status};
use plugin_guest::{Host, HostError};
use sha2::{Digest, Sha256};

const PREFIX: &str = "; wf godot-export ";

/// Computes lowercase SHA-256 hex digest for canonical byte inputs.
pub fn sha256_hex(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

#[cfg(test)]
pub fn stamped(id: &str, version: u64, body: &str) -> Vec<u8> {
    format!("{PREFIX}{id} v{version} sha256={}\n{body}", sha256_hex(body.as_bytes())).into_bytes()
}

/// Parsed WeaveForge ownership header from a generated Godot file.
#[derive(Debug, Eq, PartialEq)]
pub struct Stamp<'a> {
    pub id: &'a str,
    pub version: u64,
    pub src: Option<&'a str>,
}

/// Parses and validates a generated file's ownership header and body SHA-256.
pub fn parse_stamp(bytes: &[u8]) -> Option<Stamp<'_>> {
    let text = str::from_utf8(bytes).ok()?;
    let (header, body) = text.split_once('\n')?;
    let header = header.strip_prefix(PREFIX)?;
    let mut words = header.split(' ');
    let id = words.next()?;
    if id.is_empty() || !id.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-') {
        return None;
    }
    let version = words.next()?.strip_prefix('v')?.parse::<u64>().ok()?;
    let hash = words.next()?.strip_prefix("sha256=")?;
    let src = match words.next() {
        None => None,
        Some(word) => {
            let src = word.strip_prefix("src=")?;
            if src.is_empty() || !src.bytes().all(|c| c.is_ascii_hexdigit()) || words.next().is_some() {
                return None;
            }
            Some(src)
        }
    };
    if hash != format!("{:x}", Sha256::digest(body.as_bytes())) {
        return None;
    }
    Some(Stamp { id, version, src })
}

/// The owner of an unedited generated file. Version and digest must be complete.
pub fn owner(bytes: &[u8]) -> Option<&str> {
    parse_stamp(bytes).map(|stamp| stamp.id)
}

/// Reconciles one CLI-generated target file on disk without emitting `WriteFile`.
pub fn cli_file(host: &dyn Host, path: &str, version: u64, src_hash: &str, force: bool) -> Result<Status, HostError> {
    paths::relative(path)?;
    let existing = match host.read(path) {
        Ok(bytes) => Some(bytes),
        Err(e) if e.not_found() => None,
        Err(e) => return Err(e),
    };
    Ok(match existing.as_deref() {
        None => Status::Written,
        Some(old) => match parse_stamp(old) {
            None if !force => Status::Kept,
            Some(stamp) if stamp.version == version && stamp.src == Some(src_hash) => Status::Unchanged,
            _ => Status::Updated,
        },
    })
}

#[cfg(test)]
mod tests;
