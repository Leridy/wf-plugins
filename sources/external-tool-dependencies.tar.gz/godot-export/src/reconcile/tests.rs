use super::*;
use crate::testing::Fake;

#[test]
fn only_a_complete_matching_header_proves_ownership() {
    let original = stamped("node-1", 7, "[resource]\n");
    assert_eq!(owner(&original), Some("node-1"));
    let mut edited = original.clone();
    edited.push(b' ');
    assert!(owner(&edited).is_none());
    for bytes in [
        b"[resource]\n".as_slice(),
        b"; wf godot-export node-1 v7 sha256=abc\n",
        b"\xff",
    ] {
        assert!(owner(bytes).is_none());
    }
    let invalid_version = String::from_utf8(original).unwrap().replace("v7 ", "vX ");
    assert!(owner(invalid_version.as_bytes()).is_none());
}

#[test]
fn headerless_and_non_utf8_files_are_kept() {
    let mut host = Fake::default();
    for bytes in [b"[resource]".to_vec(), vec![255]] {
        host.files.insert("hero.tres".into(), bytes);
        assert_eq!(
            cli_file(&host, "hero.tres", 1, "abcd1234", false).unwrap(),
            Status::Kept
        );
    }
}

#[test]
fn cli_stamps_preserve_user_edits_and_detect_unchanged_sources() {
    let body = "[gd_scene format=3]\n";
    let digest = format!("{:x}", Sha256::digest(body.as_bytes()));
    let stamped_cli = format!("; wf godot-export node-1 v2 sha256={digest} src=abcd1234\n{body}");
    let mut host = Fake::default();
    assert_eq!(
        cli_file(&host, "Hero.tscn", 2, "abcd1234", false).unwrap(),
        Status::Written
    );
    host.files.insert("Hero.tscn".into(), stamped_cli.into_bytes());
    assert_eq!(owner(&host.files["Hero.tscn"]), Some("node-1"));
    assert_eq!(
        cli_file(&host, "Hero.tscn", 2, "abcd1234", false).unwrap(),
        Status::Unchanged
    );
    assert_eq!(
        cli_file(&host, "Hero.tscn", 2, "ffff9999", false).unwrap(),
        Status::Updated
    );
    host.files.get_mut("Hero.tscn").unwrap().push(b'\n');
    assert_eq!(
        cli_file(&host, "Hero.tscn", 2, "abcd1234", false).unwrap(),
        Status::Kept
    );
    assert_eq!(
        cli_file(&host, "Hero.tscn", 2, "abcd1234", true).unwrap(),
        Status::Updated
    );
}
