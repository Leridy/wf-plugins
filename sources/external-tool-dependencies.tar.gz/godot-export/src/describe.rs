//! Schemas come from the same types used at the component boundary.
use crate::{
    headless,
    types::{Input, Output},
};
use plugin_api::{Capability, Description, Example, Risk};
use schemars::{JsonSchema, schema_for};
use serde_json::Value;

pub const OP: &str = "sync";

pub fn description() -> Description {
    Description {
        capabilities: vec![
            Capability {
                op: OP.into(),
                summary: "Turn exported animations, UI kits, maps, particles and 3D assets into Godot resources".into(),
                when: "After wf export, create SpriteFrames and an autoplaying AnimatedSprite2D scene, a Theme, \
                   a TileSet / WholeMap / Parallax2D map scene, a particle effect scene, or 3D GLB wrapper scenes \
                   with colliders, roles and sockets. The export directory must be inside a Godot project. Re-run \
                   after exporting new versions; edited files are kept unless force is set."
                    .into(),
                risk: Risk::HighRisk,
                input: schema::<Input>(),
                output: Some(schema::<Output>()),
                examples: vec![
                    Example {
                        args: "sync".into(),
                        note: "sync every node in the export lock".into(),
                    },
                    Example {
                        args: "sync --nodes '#75' --nodes '#81'".into(),
                        note: "sync only these exported nodes".into(),
                    },
                ],
                implements: None,
            },
            Capability {
                op: "headless-import".into(),
                summary: "Import Godot project resources without opening a window".into(),
                when: "After export or sync, or before headless-run. Uses the confirmed Godot installation. \
                   Godot writes its import cache and may run project editor scripts; execution requires approval."
                    .into(),
                risk: Risk::HighRisk,
                input: schema::<headless::ImportInput>(),
                output: Some(schema::<headless::Output>()),
                examples: vec![Example {
                    args: "headless-import".into(),
                    note: "import the current Godot project".into(),
                }],
                implements: None,
            },
            Capability {
                op: "headless-run".into(),
                summary: "Run a Godot scene without a window for a bounded number of iterations".into(),
                when: "After headless-import, smoke-test the main scene or a selected .tscn/.scn scene. \
                   Runs project code and requires approval. Frames are engine iterations, not seconds; \
                   a successful exit alone does not certify that every script or resource is error-free."
                    .into(),
                risk: Risk::HighRisk,
                input: schema::<headless::RunInput>(),
                output: Some(schema::<headless::Output>()),
                examples: vec![Example {
                    args: "headless-run --frames 60".into(),
                    note: "run the configured main scene for 60 iterations".into(),
                }],
                implements: None,
            },
        ],
    }
}

fn schema<T: JsonSchema>() -> Value {
    serde_json::to_value(schema_for!(T)).expect("a schema serializes")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strict_capabilities_declare_external_execution_as_high_risk() {
        let d = description();
        assert_eq!(d.capabilities.len(), 3);
        for c in &d.capabilities {
            assert_eq!(c.risk, Risk::HighRisk);
            assert_eq!(c.input["additionalProperties"], false);
        }
        let c = &d.capabilities[0];
        assert_eq!(c.risk, Risk::HighRisk);
        assert_eq!(c.input["additionalProperties"], false);
        assert_eq!(c.input["properties"]["nodes"]["type"], "array");
        assert!(c.output.as_ref().unwrap()["properties"].get("table").is_some());
        assert!(c.implements.is_none());
    }
}
