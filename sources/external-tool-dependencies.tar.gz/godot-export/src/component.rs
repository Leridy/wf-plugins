//! The frozen WIT boundary; all work is performed through the testable Host.
use crate::{
    Input,
    describe::{self, OP},
    headless, sync,
};
use plugin_api::Effect as Planned;
use plugin_api::Failure;
use plugin_guest::{
    HostError, Wit,
    bindings::{
        Error, Guest, Outcome, export,
        wf::plugin::types::{Effect, ExecRequest, FileWrite, Verdict},
    },
};

struct Plugin;
impl Guest for Plugin {
    fn describe() -> Vec<u8> {
        plugin_guest::describe(&describe::description())
    }

    fn call(op: String, input: Vec<u8>) -> Result<Outcome, Error> {
        let decode_error = |e: serde_json::Error| HostError::new(Failure::InvalidInput, e.to_string());
        let (output, planned) = match op.as_str() {
            OP => {
                let input: Input = serde_json::from_slice(&input).map_err(decode_error)?;
                let plan = sync(&Wit, &input)?;
                (serde_json::to_vec(&plan.output), plan.effects)
            }
            "headless-import" => {
                let input = serde_json::from_slice(&input).map_err(decode_error)?;
                let plan = headless::import(&Wit, &input)?;
                (serde_json::to_vec(&plan.output), plan.effects)
            }
            "headless-run" => {
                let input = serde_json::from_slice(&input).map_err(decode_error)?;
                let plan = headless::run(&Wit, &input)?;
                (serde_json::to_vec(&plan.output), plan.effects)
            }
            _ => return Err(HostError::new(Failure::NotFound, "unknown godot-export operation").into()),
        };
        let output = output.map_err(|e| HostError::new(Failure::Internal, e.to_string()))?;
        let effects = planned
            .into_iter()
            .map(|effect| match effect {
                Planned::WriteFile { path, bytes, overwrite } => {
                    Ok(Effect::WriteFile(FileWrite { path, bytes, overwrite }))
                }
                Planned::DeleteFile { path } => Ok(Effect::DeleteFile(path)),
                Planned::Exec { tool, args, reason } => Ok(Effect::Exec(ExecRequest { tool, args, reason })),
                _ => Err(HostError::new(Failure::Internal, "unexpected effect")),
            })
            .collect::<Result<Vec<_>, _>>()?;
        Ok(Outcome {
            output,
            effects,
            verdict: Verdict::Ok,
            hints: Vec::new(),
        })
    }
}
export!(Plugin);
