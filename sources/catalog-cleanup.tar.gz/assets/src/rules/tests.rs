use super::*;
use crate::message::label;
use crate::testing::{export, locked, node, uuid};
use plugin_api::platform::Head;
use std::collections::BTreeSet;
use std::time::Instant;

/// A scanned file: project-relative path and its text.
struct Source {
    path: String,
    text: String,
}

fn source(path: &str, text: &str) -> Source {
    Source {
        path: path.to_owned(),
        text: text.to_owned(),
    }
}

/// Every diagnostic for `sources`, ordered by file and position.
fn check(export: &Export, sources: &[Source]) -> Vec<Diagnostic> {
    let mut checker = Checker::new(export);
    for source in sources {
        checker.scan(&source.path, &source.text);
    }
    checker.finish()
}

fn button(export: &Export) -> String {
    export.file_path(&export.locked[0].files[0])
}

fn rules(diagnostics: &[Diagnostic]) -> Vec<&str> {
    diagnostics.iter().map(|d| d.rule.as_str()).collect()
}

fn slice<'a>(text: &'a str, diagnostic: &Diagnostic) -> &'a str {
    let span = diagnostic.span.expect("a span");
    &text[span.start as usize..span.end as usize]
}

#[test]
fn a_current_asset_with_its_file_present_is_fine() {
    let mut export = export([Head::Current; 3]);
    export.on_disk = Some(export.locked.iter().map(|l| export.file_path(&l.files[0])).collect());
    let text = format!("load(\"{}\") # {}", button(&export), uuid(2));
    assert!(check(&export, &[source("a.gd", &text)]).is_empty());
}

#[test]
fn a_removed_asset_is_reported_at_every_reference() {
    let export = export([Head::Removed, Head::Current, Head::Current]);
    let file = button(&export);
    let first = format!("x = \"res://{file}\"\n");
    let second = format!("y = \"{}:primary\"\nz = \"{file}\"\n", uuid(1));
    let found = check(&export, &[source("a.gd", &first), source("sub/b.gd", &second)]);
    assert_eq!(rules(&found), ["removed-asset"; 3]);
    assert!(found.iter().all(|d| d.severity == Severity::Error && d.fix.is_none()));
    assert_eq!(found[0].file, "a.gd");
    assert_eq!(slice(&first, &found[0]), file);
    assert_eq!(found[1].file, "sub/b.gd");
    assert_eq!(slice(&second, &found[1]), uuid(1));
    assert_eq!(slice(&second, &found[2]), file);
    for text in found.iter().map(|d| &d.message) {
        assert!(text.contains("`ui/button` (#1)"), "{text}");
        assert!(text.contains("version 3"), "{text}");
    }
}

#[test]
fn withdrawn_and_deleted_nodes_are_removed_even_when_head_still_lists_them() {
    for (state, words) in [(NodeState::Withdrawn, "withdrawn"), (NodeState::Deleted, "deleted")] {
        let mut export = export([Head::Current; 3]);
        export.nodes[1] = node(2, "ui/panel", state);
        let text = uuid(2);
        let found = check(&export, &[source("a.gd", &text)]);
        assert_eq!(rules(&found), ["removed-asset"], "{state:?}");
        assert!(found[0].message.contains(words), "{}", found[0].message);
    }
}

#[test]
fn a_stale_asset_is_a_warning_naming_both_versions_and_the_new_path() {
    let mut export = export([Head::Moved, Head::Current, Head::Current]);
    export.nodes[0] = node(1, "ui/button-v2", NodeState::Current);
    let text = format!("preload(\"{}\")", button(&export));
    let found = check(&export, &[source("a.gd", &text)]);
    assert_eq!(rules(&found), ["stale-asset"]);
    assert_eq!(found[0].severity, Severity::Warning);
    let message = &found[0].message;
    assert!(
        message.contains("version 3") && message.contains("version 5"),
        "{message}"
    );
    assert!(
        message.contains("`ui/button-v2`") && message.contains("export"),
        "{message}"
    );
    assert!(message.contains("`assets/wf`"), "{message}");
}

#[test]
fn removed_wins_over_moved_and_one_reference_gets_one_diagnostic() {
    let mut export = export([Head::Moved, Head::Current, Head::Current]);
    export.nodes[0] = node(1, "ui/button", NodeState::Withdrawn);
    let text = format!("{} {}", button(&export), uuid(1));
    let found = check(&export, &[source("a.gd", &text)]);
    assert_eq!(rules(&found), ["removed-asset", "removed-asset"]);
}

#[test]
fn an_unreferenced_problem_node_is_reported_once_on_the_lock() {
    let mut export = export([Head::Removed, Head::Moved, Head::Current]);
    let lock = format!(
        "{{\n  \"nodes\": [\n    {{ \"id\": \"{}\" }},\n    {{ \"id\": \"{}\" }}\n  ]\n}}",
        uuid(1),
        uuid(2)
    );
    export.lock_text = Some(lock.clone());
    let found = check(&export, &[source("a.gd", "nothing here")]);
    assert_eq!(rules(&found), ["removed-asset", "stale-asset"]);
    assert!(found.iter().all(|d| d.file == "assets/wf/wf.lock.json"));
    assert_eq!(slice(&lock, &found[0]), uuid(1));
    assert_eq!(slice(&lock, &found[1]), uuid(2));
    assert!(found[0].message.contains("No scanned source"), "{}", found[0].message);
    // A referenced node is reported at the reference only.
    let text = uuid(1);
    let found = check(&export, &[source("a.gd", &text)]);
    assert_eq!(found.iter().filter(|d| d.file == "a.gd").count(), 1);
    assert_eq!(found.iter().filter(|d| d.file != "a.gd").count(), 1);
}

#[test]
fn without_a_readable_lock_the_lock_diagnostic_has_no_span() {
    let export = export([Head::Removed, Head::Current, Head::Current]);
    let found = check(&export, &[]);
    assert_eq!(rules(&found), ["removed-asset"]);
    assert_eq!(found[0].span, None);
    assert_eq!(found[0].file, "assets/wf/wf.lock.json");
}

#[test]
fn a_source_path_the_lock_does_not_list_is_a_missing_asset_file() {
    let export = export([Head::Current; 3]);
    let text = "a = \"res://assets/wf/other/thing.png\"";
    let found = check(&export, &[source("a.gd", text)]);
    assert_eq!(rules(&found), ["missing-asset-file"]);
    assert_eq!(found[0].severity, Severity::Error);
    assert_eq!(slice(text, &found[0]), "assets/wf/other/thing.png");
    assert!(found[0].message.contains("not listed"), "{}", found[0].message);
    // A listed file with another case is suggested.
    let wrong_case = button(&export).replace("button", "Button");
    let found = check(&export, &[source("a.gd", &wrong_case)]);
    assert_eq!(rules(&found), ["missing-asset-file"]);
    assert!(found[0].message.contains(&button(&export)), "{}", found[0].message);
}

#[test]
fn a_locked_file_missing_on_disk_is_reported_on_the_lock_at_its_entry() {
    let mut export = export([Head::Current; 3]);
    let lock = format!(
        "{{\"nodes\":[{{\"id\":\"{}\",\"files\":[\"{}\"]}}],\"keys\":{{\"k\":\"{}\"}}}}",
        uuid(1),
        export.locked[0].files[0],
        export.locked[0].files[0],
    );
    export.lock_text = Some(lock.clone());
    export.on_disk = Some(
        [1, 2, 3]
            .iter()
            .skip(1)
            .map(|n| export.file_path(&export.locked[n - 1].files[0]))
            .collect(),
    );
    let found = check(&export, &[]);
    assert_eq!(rules(&found), ["missing-asset-file"]);
    assert_eq!(found[0].file, "assets/wf/wf.lock.json");
    assert_eq!(slice(&lock, &found[0]), export.locked[0].files[0]);
    assert!(found[0].message.contains("`ui/button` (#1)") && found[0].message.contains("missing on disk"));
    // Not checked: nothing is reported.
    export.on_disk = None;
    assert!(check(&export, &[]).is_empty());
}

#[test]
fn a_mirror_node_the_lock_does_not_know_is_unexported() {
    let mut export = export([Head::Current; 3]);
    export.nodes.push(node(4, "props/crate", NodeState::Current));
    export.nodes.push(node(5, "props/old", NodeState::Deleted));
    export.nodes.push(node(6, "props/gone", NodeState::Withdrawn));
    let mut folder = node(7, "props", NodeState::Current);
    folder.node_type = "directory".into();
    export.nodes.push(folder);
    let text = [4, 5, 6, 7, 99].map(uuid).join("\n");
    let found = check(&export, &[source("a.gd", &text)]);
    assert_eq!(rules(&found), ["unexported-asset"; 3]);
    assert!(found.iter().all(|d| d.severity == Severity::Error));
    assert_eq!(slice(&text, &found[0]), uuid(4));
    assert!(
        found[0].message.contains("`props/crate` (#4)")
            && found[0].message.contains(&format!("wf export wf://{}", uuid(4)))
    );
    assert!(found[1].message.contains("deleted"), "{}", found[1].message);
    assert!(found[2].message.contains("withdrawn"), "{}", found[2].message);
}

#[test]
fn a_path_through_an_unexported_node_is_that_node_not_a_missing_file() {
    let mut export = export([Head::Current; 3]);
    export.nodes.push(node(4, "props/crate", NodeState::Current));
    let text = format!("assets/wf/{}/crate.png", uuid(4));
    let found = check(&export, &[source("a.gd", &text)]);
    assert_eq!(rules(&found), ["unexported-asset"]);
    // Through a node the mirror does not know, it is a missing file.
    let text = format!("assets/wf/{}/crate.png", uuid(9));
    assert_eq!(rules(&check(&export, &[source("a.gd", &text)])), ["missing-asset-file"]);
}

#[test]
fn a_typo_inside_a_locked_nodes_directory_is_one_missing_file_and_the_node_counts_as_referenced() {
    let export = export([Head::Removed, Head::Moved, Head::Current]);
    let text = format!("assets/wf/{}/typo.png\nassets/wf/{}/typo.png", uuid(1), uuid(2));
    let found = check(&export, &[source("a.gd", &text)]);
    assert_eq!(rules(&found), ["missing-asset-file", "missing-asset-file"]);
    assert!(found.iter().all(|d| d.file == "a.gd"));
}

#[test]
fn node_paths_with_line_breaks_stay_on_one_line() {
    let mut export = export([Head::Removed, Head::Moved, Head::Current]);
    export.locked[0].path = "evil\nname `x`\r\u{2028}end\u{1b}[31m".to_owned();
    export.locked[1].path = "p".repeat(300);
    export.nodes[1].path = "moved\nsomewhere".to_owned();
    let found = check(&export, &[]);
    assert_eq!(found.len(), 2);
    for diagnostic in &found {
        let message = &diagnostic.message;
        assert!(
            !message.chars().any(|c| c.is_control() || c == '\u{2028}'),
            "{message:?}"
        );
        assert!(message.len() < 600);
    }
    assert!(
        found[0].message.starts_with("`evil name 'x'  end [31m` (#1)"),
        "{}",
        found[0].message
    );
    assert_eq!(label("a\nb", 2), "`a b` (#2)");
}

#[test]
fn an_empty_lock_text_and_an_empty_disk_report_without_spans() {
    let mut export = export([Head::Removed; 3]);
    export.lock_text = Some(String::new());
    export.on_disk = Some(BTreeSet::new());
    export.locked.push(locked(9, "x", &["a/b.png"], Head::Current));
    let found = check(&export, &[source("a.gd", "")]);
    // Four lock-level missing files, three removed nodes.
    assert_eq!(found.len(), 3 + 4);
    assert!(found.iter().all(|d| d.span.is_none()));
}

#[test]
fn judging_a_file_of_millions_of_mentions_takes_linear_time() {
    let export = export([Head::Removed, Head::Current, Head::Current]);
    // Unlisted paths, each through an unexported UUID, and locked UUIDs inside unlisted paths.
    let unlisted = format!("assets/wf/{}/gone.png {}\n", uuid(9), uuid(1));
    let text = unlisted.repeat((4 << 20) / unlisted.len());
    let started = Instant::now();
    let found = check(&export, &[source("a.gd", &text)]);
    assert!(!found.is_empty());
    assert!(started.elapsed().as_secs() < 10, "took {:?}", started.elapsed());
}
