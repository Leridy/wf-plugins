//! What `describe()` returns: one capability, `lint`, that implements `wf.lint/1`.
use plugin_api::{Capability, Description, Example, Risk};
use plugin_protocols::lint::{LintInput, LintOutput, PROTOCOL};
use schemars::{JsonSchema, schema_for};
use serde_json::Value;

pub const OP: &str = "lint";

pub fn description() -> Description {
    Description {
        capabilities: vec![Capability {
            op: OP.to_owned(),
            summary: "Check that game source still refers to valid exported WeaveForge assets".to_owned(),
            when:
                "Use it to find references to exported nodes that were removed, withdrawn or updated on the platform, \
                   exported files that are missing, and node IDs or export paths the export lock does not know. \
                   It reads text only, so it works for any engine; the `lint` command runs it with the other linters."
                    .to_owned(),
            risk: Risk::Read,
            input: schema::<LintInput>(),
            output: Some(schema::<LintOutput>()),
            examples: vec![
                Example {
                    args: "lint".to_owned(),
                    note: "check the whole project".to_owned(),
                },
                Example {
                    args: "lint --paths scripts --paths scenes/main.tscn".to_owned(),
                    note: "check only these files and directories".to_owned(),
                },
            ],
            implements: Some(PROTOCOL.to_owned()),
        }],
    }
}

fn schema<T: JsonSchema>() -> Value {
    serde_json::to_value(schema_for!(T)).expect("a schema serializes")
}

#[cfg(test)]
mod tests {
    use super::*;
    use plugin_api::is_name;

    #[test]
    fn declares_one_read_only_lint_capability() {
        let description = description();
        let [capability] = description.capabilities.as_slice() else {
            panic!("exactly one capability")
        };
        assert!(is_name(&capability.op));
        assert_eq!(capability.implements.as_deref(), Some("wf.lint/1"));
        assert_eq!(capability.risk, Risk::Read);
        assert!(!capability.examples.is_empty());
        assert_eq!(capability.input["properties"]["paths"]["type"], "array");
        assert!(capability.output.is_some());
        assert!(is_name("assets"));
    }
}
