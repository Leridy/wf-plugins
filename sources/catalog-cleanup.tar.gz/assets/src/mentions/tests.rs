use super::*;
use crate::testing::{export, locked, uuid};
use plugin_api::platform::Head;
use std::time::Instant;

fn index() -> Index {
    Index::new(&export([Head::Current; 3]))
}

fn file(n: u32) -> String {
    format!(
        "assets/wf/{}/{}.png",
        uuid(n),
        ["button", "panel", "icon"][n as usize - 1]
    )
}

fn mentions(text: &str) -> Vec<Mention<'_>> {
    index().scan(text).into_iter().map(|(_, m)| m).collect()
}

fn nodes<'a>(index: &Index, text: &'a str) -> Vec<Mention<'a>> {
    index.scan(text).into_iter().map(|(_, m)| m).collect()
}

/// The mentions of paths, without the UUIDs inside unlisted ones.
fn paths(text: &str) -> Vec<Mention<'_>> {
    mentions(text)
        .into_iter()
        .filter(|m| !matches!(m, Mention::Uuid(_)))
        .collect()
}

#[test]
fn an_exported_file_is_one_mention_covering_the_uuid_inside_it() {
    let text = format!("load(\"res://{}\")", file(1));
    let found = index().scan(&text);
    assert_eq!(found.len(), 1);
    assert_eq!(found[0].1, Mention::Node(0));
    assert_eq!(&text[found[0].0.clone()], file(1));
}

#[test]
fn a_directory_of_one_node_names_the_node() {
    assert_eq!(mentions(&format!("assets/wf/{}/", uuid(2))), [Mention::Node(1)]);
    assert_eq!(
        mentions(&format!("dir = \"assets/wf/{}\"", uuid(3))),
        [Mention::Node(2)]
    );
}

#[test]
fn a_path_the_lock_does_not_list_is_unlisted_and_its_uuid_still_counts() {
    let text = format!("assets/wf/{}/nope.png", uuid(1));
    let found = index().scan(&text);
    assert_eq!(found.len(), 2);
    assert_eq!(found[0], (0..text.len(), Mention::Unlisted(&text)));
    assert!(matches!(found[1].1, Mention::Uuid(id) if id == uuid(1)));
    assert!(matches!(
        mentions("see assets/wf/other/thing.png")[..],
        [Mention::Unlisted("assets/wf/other/thing.png")]
    ));
}

#[test]
fn an_extension_continues_a_path_but_a_full_stop_ends_it() {
    let import = format!("{}.import", file(1));
    assert_eq!(paths(&import), [Mention::Unlisted(&import)]);
    let sentence = format!("It uses {}. Then more.", file(1));
    assert_eq!(mentions(&sentence), [Mention::Node(0)]);
    let prefix = format!("{}x", file(1));
    assert_eq!(paths(&prefix), [Mention::Unlisted(&prefix)]);
}

#[test]
fn the_lock_file_and_a_bare_export_directory_are_not_mentions() {
    assert!(mentions("assets/wf/wf.lock.json").is_empty());
    assert!(mentions("assets/wf/").is_empty());
    assert!(mentions("assets/wf/*.png").is_empty());
    assert!(mentions("assets/wf-extra/a.png").is_empty());
}

#[test]
fn the_directory_must_not_continue_a_longer_name() {
    for before in ["my-", "my_", "my", "my.", "100%"] {
        let text = format!("{before}{}", file(1));
        assert!(paths(&text).is_empty(), "{text}");
    }
    for before in ["res://", "./", "../", "\"", "'", "("] {
        assert_eq!(
            mentions(&format!("{before}{}", file(1))),
            [Mention::Node(0)],
            "{before}"
        );
    }
}

#[test]
fn a_name_layout_directory_names_a_node_only_when_it_holds_one() {
    let mut export = export([Head::Current; 3]);
    export.locked = vec![
        locked(
            1,
            "characters/hero",
            &["characters/hero/idle.png", "characters/hero/walk 01.png"],
            Head::Current,
        ),
        locked(2, "characters/imp", &["characters/imp/idle.png"], Head::Current),
    ];
    let index = Index::new(&export);
    assert_eq!(nodes(&index, "assets/wf/characters/hero/idle.png"), [Mention::Node(0)]);
    assert_eq!(
        nodes(&index, "assets/wf/characters/hero/walk 01.png"),
        [Mention::Node(0)]
    );
    assert_eq!(nodes(&index, "assets/wf/characters/hero"), [Mention::Node(0)]);
    assert!(nodes(&index, "assets/wf/characters/").is_empty());
    assert_eq!(nodes(&index, "assets/wf/characters/hero/jump.png").len(), 1);
    assert!(matches!(
        nodes(&index, "assets/wf/characters/hero/jump.png")[0],
        Mention::Unlisted(_)
    ));
}

#[test]
fn only_standalone_lowercase_canonical_uuids_match() {
    let id = uuid(0x00ab_cdef);
    let ids = |text: &str| -> usize { mentions(text).iter().filter(|m| matches!(m, Mention::Uuid(_))).count() };
    assert_eq!(ids(&format!("{id}:primary")), 1);
    assert_eq!(ids(&format!("key = \"{id}\"; {id}.png")), 2);
    assert_eq!(ids(&id.to_uppercase()), 0);
    // Mixed case is not the form the mirror writes.
    assert_eq!(ids(&format!("{}{}", &id[..20], id[20..].to_uppercase())), 0);
    // Inside a longer run of hex digits.
    assert_eq!(ids(&format!("a{id}")), 0);
    assert_eq!(ids(&format!("{id}0")), 0);
    assert_eq!(ids(&format!("DEADBEEF{id}")), 0);
    assert_eq!(ids(&format!("{id}F")), 0);
    // A dash or a letter that is not a hex digit ends the run.
    assert_eq!(ids(&format!("node-{id}-x")), 1);
    assert_eq!(ids(&format!("item_{id}g")), 1);
    assert_eq!(ids(&format!("{id}\n{id}")), 2);
}

#[test]
fn spans_are_byte_offsets_after_multibyte_text() {
    let text = format!("é 日本 {}", uuid(1));
    let found = index().scan(&text);
    assert_eq!(found.len(), 1);
    assert_eq!(found[0].0.start, "é 日本 ".len());
    assert_eq!(&text[found[0].0.clone()], uuid(1));
}

#[test]
fn a_file_of_millions_of_mentions_is_scanned_in_linear_time() {
    // Paths with a UUID outside them, and UUIDs inside unlisted paths: each
    // UUID was once compared with every path before it.
    let lines = [
        format!("{} {}\n", file(1), uuid(2)),
        format!("assets/wf/{}/gone.png {}\n", uuid(9), uuid(3)),
    ];
    for line in lines {
        let text = line.repeat((4 << 20) / line.len());
        let started = Instant::now();
        let found = index().scan(&text);
        assert!(found.len() > 50_000);
        assert!(started.elapsed().as_secs() < 10, "took {:?}", started.elapsed());
    }
}
