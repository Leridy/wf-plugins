//! Builders shared by the unit tests.
use crate::model::Export;
use plugin_api::platform::{Head, LockedRow, NodeRow, NodeState};

/// A canonical lowercase UUID for test node `n`.
pub fn uuid(n: u32) -> String {
    format!("{n:08x}-0000-4000-8000-{n:012x}")
}

pub fn locked(n: u32, path: &str, files: &[&str], head: Head) -> LockedRow {
    LockedRow {
        id: uuid(n),
        number: u64::from(n),
        path: path.to_owned(),
        version: 3,
        form: "source".to_owned(),
        files: files.iter().map(|f| (*f).to_owned()).collect(),
        head,
        head_version: match head {
            Head::Removed => None,
            Head::Current => Some(3),
            Head::Moved => Some(5),
        },
    }
}

pub fn node(n: u32, path: &str, state: NodeState) -> NodeRow {
    NodeRow {
        id: uuid(n),
        number: u64::from(n),
        path: path.to_owned(),
        node_type: "image".to_owned(),
        version: Some(3),
        state,
    }
}

/// Nodes 1 to 3 exported in `assets/wf` with the `id` layout, one image each.
pub fn export(heads: [Head; 3]) -> Export {
    let paths = ["ui/button", "ui/panel", "ui/icon"];
    let locked: Vec<LockedRow> = (1..=3u32)
        .map(|n| {
            let file = format!("{}/{}.png", uuid(n), paths[n as usize - 1].rsplit('/').next().unwrap());
            locked(n, paths[n as usize - 1], &[file.as_str()], heads[n as usize - 1])
        })
        .collect();
    Export {
        directory: "assets/wf".to_owned(),
        lock: "assets/wf/wf.lock.json".to_owned(),
        lock_text: None,
        nodes: (1..=3u32)
            .map(|n| node(n, paths[n as usize - 1], NodeState::Current))
            .collect(),
        locked,
        on_disk: None,
    }
}
