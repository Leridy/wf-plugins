//! The facts the rules judge, gathered once so the rules stay pure.
use plugin_api::platform::{LockedRow, NodeRow};
use std::collections::BTreeSet;

/// The export directory as the lock and the mirror describe it.
#[derive(Clone, Debug)]
pub struct Export {
    /// Project-relative, `/`-separated, no trailing slash.
    pub directory: String,
    /// The export lock, project-relative, as the host names it.
    pub lock: String,
    /// The lock's text, when the plugin may read it; spans point into it.
    pub lock_text: Option<String>,
    pub locked: Vec<LockedRow>,
    /// The mirror's nodes at HEAD and the ones the fetched history deleted.
    pub nodes: Vec<NodeRow>,
    /// Project-relative exported files known to exist, or `None` when the
    /// plugin did not check the disk. A file it could not check is in the set.
    pub on_disk: Option<BTreeSet<String>>,
}

impl Export {
    /// The lock's path inside the export directory: its file name.
    pub fn lock_name(&self) -> &str {
        self.lock
            .strip_prefix(&self.directory)
            .and_then(|rest| rest.strip_prefix('/'))
            .unwrap_or(&self.lock)
    }

    /// An exported file's project-relative path.
    pub fn file_path(&self, file: &str) -> String {
        format!("{}/{file}", self.directory)
    }
}
