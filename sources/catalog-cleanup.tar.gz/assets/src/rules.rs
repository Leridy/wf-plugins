//! The four rules, as pure functions over the lock, the mirror's nodes and the
//! text of the scanned files. Rule names carry no plugin prefix; the host adds it.
use crate::{
    mentions::{Index, Mention},
    message::{self, Gone, Moved, Place},
    model::Export,
};
use plugin_api::platform::{Head, LockedRow, NodeRow, NodeState};
use plugin_protocols::lint::{Diagnostic, Severity, Span};
use std::{collections::HashMap, ops::Range};

pub const REMOVED_ASSET: &str = "removed-asset";
pub const STALE_ASSET: &str = "stale-asset";
pub const MISSING_ASSET_FILE: &str = "missing-asset-file";
pub const UNEXPORTED_ASSET: &str = "unexported-asset";

/// How an exported node stands against the platform.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Health {
    Fine,
    Gone(Gone),
    Stale,
}

/// Most diagnostics one run reports; a hostile file could mention millions.
pub const MAX_DIAGNOSTICS: usize = 5_000;

/// Judges source files one at a time, keeping only what they mention, so the
/// run never holds more than one file's text.
pub struct Checker<'a> {
    judge: Judge<'a>,
    index: Index,
    referenced: Vec<bool>,
    diagnostics: Vec<Diagnostic>,
    /// Some mentions were left unreported past [`MAX_DIAGNOSTICS`].
    cut: bool,
}

impl<'a> Checker<'a> {
    pub fn new(export: &'a Export) -> Self {
        Self {
            judge: Judge::new(export),
            index: Index::new(export),
            referenced: vec![false; export.locked.len()],
            diagnostics: Vec::new(),
            cut: false,
        }
    }

    /// Whether the diagnostics are as many as a run reports.
    pub fn full(&self) -> bool {
        self.diagnostics.len() >= MAX_DIAGNOSTICS
    }

    /// Whether mentions went unreported because the diagnostics were full.
    pub fn cut(&self) -> bool {
        self.cut
    }

    /// Judges what the source file at `path` mentions.
    pub fn scan(&mut self, path: &str, text: &str) {
        let found = self.index.scan(text);
        // Unlisted paths do not overlap, so a position is inside at most one.
        let unlisted: Vec<&Range<usize>> = found
            .iter()
            .filter(|(_, mention)| matches!(mention, Mention::Unlisted(_)))
            .map(|(range, _)| range)
            .collect();
        let in_unlisted = |range: &Range<usize>| {
            let before = unlisted.partition_point(|outer| outer.start <= range.start);
            before > 0 && range.end <= unlisted[before - 1].end
        };
        for (at, (range, mention)) in found.iter().enumerate() {
            if self.full() {
                self.cut = true;
                return;
            }
            match *mention {
                Mention::Node(node) => {
                    self.referenced[node] = true;
                    self.diagnostics.extend(self.judge.reference(node, path, range));
                }
                Mention::Uuid(id) => {
                    if let Some(node) = self.judge.locked(id) {
                        self.referenced[node] = true;
                        // The path it is part of is reported instead.
                        if !in_unlisted(range) {
                            self.diagnostics.extend(self.judge.reference(node, path, range));
                        }
                    } else {
                        self.diagnostics.extend(self.judge.unexported(id, path, range));
                    }
                }
                Mention::Unlisted(unlisted_path) => {
                    // A path through an unexported node's UUID is reported as that node.
                    let through_node = found[at + 1..]
                        .iter()
                        .take_while(|(inner, _)| inner.start < range.end)
                        .any(|(inner, mention)| {
                            inner.end <= range.end
                                && matches!(mention, Mention::Uuid(id) if self.judge.unexported_node(id).is_some())
                        });
                    if !through_node {
                        self.diagnostics.push(self.judge.unlisted(unlisted_path, path, range));
                    }
                }
            }
        }
    }

    /// Every diagnostic, the lock's included, ordered by file and position.
    pub fn finish(mut self) -> Vec<Diagnostic> {
        self.diagnostics.extend(self.judge.lock_findings(&self.referenced));
        self.diagnostics.sort_by(|a, b| {
            (&a.file, a.span.map(|s| s.start), &a.rule).cmp(&(&b.file, b.span.map(|s| s.start), &b.rule))
        });
        self.diagnostics
    }
}

struct Judge<'a> {
    export: &'a Export,
    health: Vec<Health>,
    locked_by_id: HashMap<&'a str, usize>,
    nodes_by_id: HashMap<&'a str, &'a NodeRow>,
}

impl<'a> Judge<'a> {
    fn new(export: &'a Export) -> Self {
        let nodes_by_id: HashMap<&str, &NodeRow> = export.nodes.iter().map(|n| (n.id.as_str(), n)).collect();
        Self {
            export,
            health: export
                .locked
                .iter()
                .map(|locked| health(locked, nodes_by_id.get(locked.id.as_str()).copied()))
                .collect(),
            locked_by_id: export
                .locked
                .iter()
                .enumerate()
                .map(|(i, l)| (l.id.as_str(), i))
                .collect(),
            nodes_by_id,
        }
    }

    fn locked(&self, id: &str) -> Option<usize> {
        self.locked_by_id.get(id).copied()
    }

    /// A node the mirror knows, that is an item and not in the lock.
    fn unexported_node(&self, id: &str) -> Option<&'a NodeRow> {
        self.nodes_by_id
            .get(id)
            .copied()
            .filter(|node| node.node_type != "directory" && !self.locked_by_id.contains_key(id))
    }

    /// The diagnostic for a reference to a locked node, when it is not fine.
    fn reference(&self, node: usize, file: &str, range: &Range<usize>) -> Option<Diagnostic> {
        self.problem(node, Place::Reference)
            .map(|(rule, severity, text)| diagnostic(rule, severity, text, file, Some(span(range))))
    }

    fn problem(&self, node: usize, place: Place) -> Option<(&'static str, Severity, String)> {
        let locked = &self.export.locked[node];
        let label = message::label(&locked.path, locked.number);
        match self.health[node] {
            Health::Fine => None,
            Health::Gone(gone) => Some((
                REMOVED_ASSET,
                Severity::Error,
                message::removed(&label, locked.version, gone, place),
            )),
            Health::Stale => {
                let head = self.nodes_by_id.get(locked.id.as_str());
                let moved = Moved {
                    version: locked.version,
                    head_version: locked.head_version,
                    path: &locked.path,
                    head_path: head.map(|n| n.path.as_str()),
                };
                Some((
                    STALE_ASSET,
                    Severity::Warning,
                    message::stale(&label, &self.export.directory, &moved),
                ))
            }
        }
    }

    fn unexported(&self, id: &str, file: &str, range: &Range<usize>) -> Option<Diagnostic> {
        let node = self.unexported_node(id)?;
        let gone = match node.state {
            NodeState::Current | NodeState::Draft => None,
            NodeState::Withdrawn => Some(Gone::Withdrawn),
            NodeState::Deleted => Some(Gone::Deleted),
        };
        Some(diagnostic(
            UNEXPORTED_ASSET,
            Severity::Error,
            message::unexported(node, gone),
            file,
            Some(span(range)),
        ))
    }

    fn unlisted(&self, path: &str, file: &str, range: &Range<usize>) -> Diagnostic {
        let similar = self.export.locked.iter().flat_map(|l| &l.files).find_map(|file| {
            let full = self.export.file_path(file);
            full.eq_ignore_ascii_case(path).then_some(full)
        });
        diagnostic(
            MISSING_ASSET_FILE,
            Severity::Error,
            message::missing_in_lock(path, &self.export.lock, similar.as_deref()),
            file,
            Some(span(range)),
        )
    }

    /// Problems of the lock itself: nodes nothing scanned refers to, and
    /// locked files missing on disk.
    fn lock_findings(&self, referenced: &[bool]) -> Vec<Diagnostic> {
        let lock = &self.export.lock;
        let mut found = Vec::new();
        for (node, locked) in self.export.locked.iter().enumerate() {
            let at = self.export.lock_text.as_deref().and_then(|text| text.find(&locked.id));
            if !referenced[node]
                && let Some((rule, severity, text)) = self.problem(node, Place::Lock)
            {
                let range = at.map(|start| start..start + locked.id.len());
                found.push(diagnostic(rule, severity, text, lock, range.as_ref().map(span)));
            }
            let Some(on_disk) = &self.export.on_disk else {
                continue;
            };
            let label = message::label(&locked.path, locked.number);
            for file in &locked.files {
                let path = self.export.file_path(file);
                if on_disk.contains(&path) {
                    continue;
                }
                let range = self
                    .export
                    .lock_text
                    .as_deref()
                    .and_then(|text| string_in(text, at?, file));
                found.push(diagnostic(
                    MISSING_ASSET_FILE,
                    Severity::Error,
                    message::missing_on_disk(file, &path, &label),
                    lock,
                    range.as_ref().map(span),
                ));
            }
        }
        found
    }
}

fn health(locked: &LockedRow, node: Option<&NodeRow>) -> Health {
    match (node.map(|n| n.state), locked.head) {
        (Some(NodeState::Deleted), _) => Health::Gone(Gone::Deleted),
        (Some(NodeState::Withdrawn), _) => Health::Gone(Gone::Withdrawn),
        (_, Head::Removed) => Health::Gone(Gone::Missing),
        (_, Head::Moved) => Health::Stale,
        (_, Head::Current) => Health::Fine,
    }
}

/// The JSON string `value` (its content, without the quotes) first written in
/// `text` at or after `from`.
fn string_in(text: &str, from: usize, value: &str) -> Option<Range<usize>> {
    let literal = serde_json::to_string(value).ok()?;
    let start = from + text[from..].find(&literal)? + 1;
    Some(start..start + literal.len() - 2)
}

fn diagnostic(rule: &str, severity: Severity, message: String, file: &str, span: Option<Span>) -> Diagnostic {
    Diagnostic {
        rule: rule.to_owned(),
        severity,
        message,
        file: file.to_owned(),
        span,
        fix: None,
    }
}

fn span(range: &Range<usize>) -> Span {
    Span {
        start: range.start as u32,
        end: range.end as u32,
    }
}

#[cfg(test)]
mod tests;
