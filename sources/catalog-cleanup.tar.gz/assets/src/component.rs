//! The two exports, over the WIT imports.
use crate::{
    describe::{self, OP},
    gather,
};
use plugin_guest::{
    Wit,
    bindings::{Error, Guest, Outcome, export},
};

struct Plugin;

impl Guest for Plugin {
    fn describe() -> Vec<u8> {
        plugin_guest::describe(&describe::description())
    }

    fn call(op: String, input: Vec<u8>) -> Result<Outcome, Error> {
        plugin_guest::lint(OP, &op, &input, |input| gather::lint(&Wit, input))
    }
}

export!(Plugin);
