//! The official `assets` plugin: checks that game source still refers to valid
//! WeaveForge assets, the platform nodes `wf export` copied into the project.
//! It implements `wf.lint/1` for any engine because it reads text only: the
//! export lock and the mirror through `host.call`, source files as plain text.
//! Checks that need an engine's file format belong to that engine's plugin.
#![cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "the component glue that calls into these is wasm-only")
)]

mod describe;
mod gather;
mod mentions;
mod message;
mod model;
mod rules;
#[cfg(test)]
mod testing;

pub use gather::lint;

#[cfg(target_arch = "wasm32")]
mod component;
