use super::*;
use crate::{
    rules,
    testing::{export, node, uuid},
};
use globset::Glob;
use plugin_api::{
    Failure, LIST_LIMIT,
    platform::{Head, LockedRow, NodeRow, NodeState},
};
use plugin_protocols::lint::Severity;
use std::{cell::RefCell, collections::BTreeMap};

/// A project in memory with canned platform answers.
struct Fake {
    files: BTreeMap<String, Vec<u8>>,
    locks: Result<LocksOutput, HostError>,
    nodes: Vec<NodeRow>,
    reads: RefCell<Vec<String>>,
    warnings: RefCell<Vec<String>>,
    /// Paths `list` leaves out although they can be read, like VCS-ignored files.
    unlisted: Vec<String>,
    /// Paths a listing holds at most, when not the host's.
    limit: Option<usize>,
    lists: RefCell<Vec<String>>,
}

impl Fake {
    fn exported(heads: [Head; 3]) -> Self {
        let export = export(heads);
        let mut fake = Self {
            files: BTreeMap::new(),
            locks: Ok(LocksOutput {
                directory: export.directory.clone(),
                lock: export.lock.clone(),
                nodes: export.locked.clone(),
            }),
            nodes: export.nodes.clone(),
            reads: RefCell::default(),
            warnings: RefCell::default(),
            unlisted: Vec::new(),
            limit: None,
            lists: RefCell::default(),
        };
        for locked in &export.locked {
            fake.put(&export.file_path(&locked.files[0]), "png");
        }
        fake.put("assets/wf/wf.lock.json", "{}");
        fake
    }

    fn put(&mut self, path: &str, text: &str) {
        self.files.insert(path.to_owned(), text.as_bytes().to_vec());
    }

    fn locked(&self) -> &[LockedRow] {
        &self.locks.as_ref().unwrap().nodes
    }

    fn file(&self, n: usize) -> String {
        format!("assets/wf/{}", self.locked()[n].files[0])
    }
}

impl Platform for Fake {
    fn call(&self, method: &str, _input: &[u8]) -> Result<Vec<u8>, HostError> {
        match method {
            "wf.mirror.locks" => self.locks.clone().map(|l| serde_json::to_vec(&l).unwrap()),
            "wf.mirror.nodes" => Ok(serde_json::to_vec(&NodesOutput {
                nodes: self.nodes.clone(),
            })
            .unwrap()),
            other => Err(HostError::new(Failure::NotFound, format!("unknown {other}"))),
        }
    }
}

impl Host for Fake {
    fn list(&self, glob: &str) -> Vec<String> {
        self.lists.borrow_mut().push(glob.to_owned());
        let matcher = Glob::new(glob).expect("a valid glob").compile_matcher();
        self.files
            .keys()
            .filter(|path| !self.unlisted.contains(path) && matcher.is_match(path))
            .take(self.list_limit())
            .cloned()
            .collect()
    }

    fn list_limit(&self) -> usize {
        self.limit.unwrap_or(LIST_LIMIT)
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.reads.borrow_mut().push(path.to_owned());
        self.files
            .get(path)
            .cloned()
            .ok_or_else(|| HostError::new(Failure::NotFound, format!("`{path}` is not readable")))
    }

    fn warn(&self, message: &str) {
        self.warnings.borrow_mut().push(message.to_owned());
    }
}

fn input(paths: &[&str]) -> LintInput {
    LintInput {
        paths: paths.iter().map(|p| (*p).to_owned()).collect(),
    }
}

fn rules(output: &LintOutput) -> Vec<(&str, &str)> {
    output
        .diagnostics
        .iter()
        .map(|d| (d.file.as_str(), d.rule.as_str()))
        .collect()
}

#[test]
fn no_mirror_or_no_lock_is_an_empty_result_not_an_error() {
    let mut fake = Fake::exported([Head::Current; 3]);
    fake.put("scripts/a.gd", &uuid(1));
    fake.locks = Err(HostError::new(Failure::NotFound, "No wf mirror"));
    assert_eq!(lint(&fake, &input(&[])).unwrap(), LintOutput::default());
    assert!(fake.reads.borrow().is_empty());
}

#[test]
fn a_missing_grant_checks_nothing_and_says_so_while_other_host_errors_are_reported() {
    let mut fake = Fake::exported([Head::Current; 3]);
    fake.locks = Err(HostError::new(Failure::Unsupported, "not granted the platform"));
    assert_eq!(lint(&fake, &input(&[])).unwrap(), LintOutput::default());
    assert!(fake.warnings.borrow()[0].contains("not granted the platform"));
    fake.locks = Err(HostError::new(Failure::Internal, "the mirror is damaged"));
    assert_eq!(lint(&fake, &input(&[])).unwrap_err().message, "the mirror is damaged");
}

#[test]
fn scans_text_files_outside_the_export_and_lists_them_as_checked() {
    let mut fake = Fake::exported([Head::Removed, Head::Current, Head::Current]);
    let reference = format!("load(\"{}\")", fake.file(0));
    fake.put("scripts/player.gd", &reference);
    fake.put("scripts/clean.gd", "print(1)");
    fake.put("big.txt", &"x".repeat(MAX_FILE_BYTES + 1));
    fake.files.insert("latin.txt".into(), vec![0xE9, 0xFF]);
    fake.put("textures/hero.png", &uuid(1));
    let output = lint(&fake, &input(&[])).unwrap();
    // The lock counts as checked: its listed files were looked for on disk.
    assert_eq!(
        output.checked,
        ["assets/wf/wf.lock.json", "scripts/clean.gd", "scripts/player.gd"]
    );
    assert_eq!(rules(&output), [("scripts/player.gd", "removed-asset")]);
    // Nothing under the export directory is scanned, and binary files are not even read.
    let reads = fake.reads.borrow();
    assert!(!reads.iter().any(|p| p == "textures/hero.png"));
    assert_eq!(
        reads.iter().filter(|p| p.starts_with("assets/wf/")).collect::<Vec<_>>(),
        ["assets/wf/wf.lock.json"]
    );
}

#[test]
fn paths_limit_what_is_scanned_and_reported() {
    let mut fake = Fake::exported([Head::Removed, Head::Current, Head::Current]);
    let reference = uuid(1);
    fake.put("scripts/a.gd", &reference);
    fake.put("scripts/deep/b.gd", &reference);
    fake.put("scripts2/c.gd", &reference);
    fake.put("main.tscn", &reference);
    let output = lint(&fake, &input(&["scripts/", "./main.tscn"])).unwrap();
    assert_eq!(output.checked, ["main.tscn", "scripts/a.gd", "scripts/deep/b.gd"]);
    assert_eq!(output.diagnostics.len(), 3);
    // A node without a scanned reference is reported on the lock only when the lock is in scope.
    let mut fake = Fake::exported([Head::Removed, Head::Current, Head::Current]);
    fake.put("scripts/a.gd", "nothing");
    let output = lint(&fake, &input(&["scripts"])).unwrap();
    assert!(output.diagnostics.is_empty());
    let output = lint(&fake, &input(&["assets/wf"])).unwrap();
    assert_eq!(rules(&output), [("assets/wf/wf.lock.json", "removed-asset")]);
    assert_eq!(output.checked, ["assets/wf/wf.lock.json"]);
}

#[test]
fn missing_files_are_found_by_listing_and_by_probing_ignored_directories() {
    let mut fake = Fake::exported([Head::Current; 3]);
    let gone = fake.file(1);
    fake.files.remove(&gone);
    let output = lint(&fake, &input(&[])).unwrap();
    assert_eq!(rules(&output), [("assets/wf/wf.lock.json", "missing-asset-file")]);
    assert!(output.diagnostics[0].message.contains("`ui/panel` (#2)"));
    // A directory the listing leaves out is probed with reads.
    fake.unlisted = fake
        .files
        .keys()
        .filter(|p| p.starts_with("assets/wf/"))
        .cloned()
        .collect();
    let output = lint(&fake, &input(&[])).unwrap();
    assert_eq!(rules(&output), [("assets/wf/wf.lock.json", "missing-asset-file")]);
}

#[test]
fn only_so_many_unlisted_files_are_probed_and_the_rest_count_as_present() {
    let mut fake = Fake::exported([Head::Current; 3]);
    let files: Vec<String> = (0..MAX_PROBES + 5).map(|n| format!("m{n}.png")).collect();
    for file in &files {
        fake.put(&format!("assets/wf/{file}"), "x");
    }
    let mut locks = fake.locks.clone().unwrap();
    locks.nodes[0].files = files;
    fake.locks = Ok(locks);
    fake.unlisted = fake.files.keys().cloned().collect();
    let output = lint(&fake, &input(&[])).unwrap();
    // The run says it could not tell for the rest.
    assert_eq!(rules(&output), [("assets/wf/wf.lock.json", "incomplete-check")]);
    assert!(output.diagnostics[0].message.contains("taken to exist"));
    assert_eq!(output.diagnostics[0].severity, Severity::Warning);
    assert_eq!(fake.warnings.borrow().len(), 1);
    // Two probes less were made for the missing ones, never more than the cap.
    let probes = fake
        .reads
        .borrow()
        .iter()
        .filter(|p| p.starts_with("assets/wf/m"))
        .count();
    assert!(probes <= MAX_PROBES + 1, "{probes}");
}

#[test]
fn the_lock_is_read_and_reported_where_the_host_says_it_is() {
    let mut fake = Fake::exported([Head::Removed, Head::Current, Head::Current]);
    let text = fake.files.remove("assets/wf/wf.lock.json").unwrap();
    fake.files.insert("assets/wf/game.lock.json".into(), text);
    fake.locks.as_mut().unwrap().lock = "assets/wf/game.lock.json".into();
    // Naming the lock in source is no mention of an exported file.
    fake.put("scripts/a.gd", "assets/wf/game.lock.json");
    let output = lint(&fake, &input(&[])).unwrap();
    assert_eq!(rules(&output), [("assets/wf/game.lock.json", "removed-asset")]);
    assert!(fake.reads.borrow().iter().any(|p| p == "assets/wf/game.lock.json"));
}

#[test]
fn a_hidden_export_directory_is_not_checked_for_existence() {
    let mut fake = Fake::exported([Head::Current; 3]);
    let LocksOutput { nodes, .. } = fake.locks.clone().unwrap();
    fake.locks = Ok(LocksOutput {
        directory: ".assets/wf".into(),
        lock: ".assets/wf/wf.lock.json".into(),
        nodes,
    });
    let output = lint(&fake, &input(&[])).unwrap();
    // The lock lies out of reach, so the note sits on a file that was scanned.
    assert_eq!(rules(&output), [("assets/wf/wf.lock.json", "incomplete-check")]);
    assert!(output.diagnostics[0].message.contains("not checked for existence"));
    assert_eq!(fake.warnings.borrow().len(), 1);
}

#[test]
fn an_export_directory_cut_short_is_asked_about_file_by_file() {
    let mut fake = Fake::exported([Head::Current; 3]);
    let gone = fake.file(1);
    fake.files.remove(&gone);
    // The directory holds 3 files and the lock; a listing of 3 is cut short.
    fake.limit = Some(3);
    let output = lint(&fake, &input(&["assets/wf"])).unwrap();
    let found = rules(&output);
    assert!(
        found.contains(&("assets/wf/wf.lock.json", "missing-asset-file")),
        "{found:?}"
    );
    assert_eq!(
        found.iter().filter(|(_, rule)| *rule == "missing-asset-file").count(),
        1
    );
    assert!(
        found.contains(&("assets/wf/wf.lock.json", "incomplete-check")),
        "{found:?}"
    );
    let lists = fake.lists.borrow();
    assert!(
        lists.contains(&gone),
        "a file the listing lacks is asked for by name: {lists:?}"
    );
    assert!(fake.reads.borrow().contains(&gone), "and read when no listing shows it");
    assert!(
        output
            .diagnostics
            .iter()
            .any(|d| d.message.contains("`assets/wf/**` matched 3 files"))
    );
}

#[test]
fn a_project_with_more_files_than_a_listing_holds_is_scanned_by_source_extension() {
    let mut fake = Fake::exported([Head::Removed, Head::Current, Head::Current]);
    // Binary files fill the first listing; the sources are listed by extension.
    for n in 0..12 {
        fake.put(&format!("art/{n:02}.png"), "x");
    }
    fake.put("scripts/player.gd", &uuid(1));
    fake.put("notes.weird", &uuid(1));
    fake.limit = Some(10);
    let output = lint(&fake, &input(&[])).unwrap();
    assert!(fake.lists.borrow().iter().any(|g| g.starts_with("**/*.{gd,")));
    let found = rules(&output);
    assert!(found.contains(&("scripts/player.gd", "removed-asset")), "{found:?}");
    assert!(
        found.contains(&("assets/wf/wf.lock.json", "incomplete-check")),
        "{found:?}"
    );
    assert!(
        output
            .diagnostics
            .iter()
            .any(|d| d.message.contains("`**` matched 10 files"))
    );
}

#[test]
fn a_clean_run_that_listed_everything_reports_no_partial_check() {
    let mut fake = Fake::exported([Head::Current; 3]);
    fake.put("scripts/a.gd", "print(1)");
    fake.limit = Some(100);
    let output = lint(&fake, &input(&[])).unwrap();
    assert_eq!(output.diagnostics, []);
    assert!(fake.warnings.borrow().is_empty());
}

#[test]
fn diagnostics_stop_at_a_limit_and_the_run_says_so() {
    let mut fake = Fake::exported([Head::Removed, Head::Current, Head::Current]);
    let mention = format!("{}\n", uuid(1));
    fake.put("a.gd", &mention.repeat(rules::MAX_DIAGNOSTICS + 100));
    fake.put("b.gd", &mention);
    let output = lint(&fake, &input(&[])).unwrap();
    let removed = output.diagnostics.iter().filter(|d| d.rule == "removed-asset").count();
    assert_eq!(removed, rules::MAX_DIAGNOSTICS);
    assert!(output.diagnostics.iter().any(|d| d.rule == "incomplete-check"));
    assert!(
        !output.checked.contains(&"b.gd".to_owned()),
        "scanning stops when the diagnostics are full"
    );
}

#[test]
fn unexported_nodes_come_from_the_deleted_mirror_listing() {
    let mut fake = Fake::exported([Head::Current; 3]);
    fake.nodes.push(node(8, "props/old", NodeState::Deleted));
    fake.put("a.gd", &format!("id = \"{}\"", uuid(8)));
    let output = lint(&fake, &input(&[])).unwrap();
    assert_eq!(rules(&output), [("a.gd", "unexported-asset")]);
}

#[test]
fn glob_characters_in_paths_are_escaped() {
    assert_eq!(escape_glob("assets/[wf]*/x?{a}"), "assets/[[]wf[]][*]/x[?][{]a[}]");
    let scope = Scope::new(&["a b/".into(), "./c".into(), ".".into(), String::new()]);
    assert_eq!(scope.globs(), ["a b", "a b/**", "c", "c/**"]);
    assert!(scope.contains("a b/x") && scope.contains("c") && !scope.contains("a bc") && !scope.contains("cc/x"));
    assert!(Scope::new(&[]).contains("anything"));
}
