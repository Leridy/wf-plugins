//! The text of each diagnostic: one or two sentences that name the node by
//! path and number and say what to do. Node paths are user data, so they are
//! flattened to one line before they reach a message.
use plugin_api::platform::NodeRow;
use plugin_guest::quoted;

const LABEL_CHARS: usize = 100;
/// The CLI name and its node address scheme, as commands in messages spell them.
const CLI: &str = "wf";
const ADDRESS_SCHEME: &str = "wf://";

/// Why an exported node is gone.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Gone {
    /// HEAD no longer has it; the fetched history does not say why.
    Missing,
    Withdrawn,
    Deleted,
}

/// Where a diagnostic about a node sits.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Place {
    /// At a reference in source.
    Reference,
    /// On the export lock, because no scanned file refers to the node.
    Lock,
}

/// `path` (#number) on one line, safe inside backticks.
pub fn label(path: &str, number: u64) -> String {
    format!("{} (#{number})", quoted(path, LABEL_CHARS))
}

pub fn removed(label: &str, version: u64, gone: Gone, place: Place) -> String {
    let state = match gone {
        Gone::Missing => "is no longer on the platform",
        Gone::Withdrawn => "was withdrawn, so its files are no longer available",
        Gone::Deleted => "was deleted on the platform",
    };
    let action = match place {
        Place::Reference => "Replace it with another asset or remove this reference.",
        Place::Lock => "No scanned source refers to it: replace it or drop its export.",
    };
    format!("{label} was exported at version {version} but {state}. {action}")
}

/// What changed at HEAD since the export, for `stale`.
pub struct Moved<'a> {
    pub version: u64,
    pub head_version: Option<u64>,
    pub path: &'a str,
    pub head_path: Option<&'a str>,
}

pub fn stale(label: &str, directory: &str, moved: &Moved) -> String {
    let mut changes = Vec::new();
    if let Some(version) = moved.head_version.filter(|v| *v != moved.version) {
        changes.push(format!("version {version}"));
    }
    if let Some(path) = moved.head_path.filter(|p| *p != moved.path) {
        changes.push(format!("the path {}", label_path(path)));
    }
    let head = if changes.is_empty() {
        "other changes".to_owned()
    } else {
        changes.join(" and ")
    };
    let directory = label_path(directory);
    format!(
        "{label} was exported at version {}, but HEAD has {head}. Run `{CLI} export` again to update {directory}.",
        moved.version
    )
}

pub fn missing_in_lock(path: &str, lock_file: &str, similar: Option<&str>) -> String {
    let lock = label_path(lock_file);
    let hint = similar.map_or_else(
        || "Export the node that owns it, or fix the path.".to_owned(),
        |similar| format!("Did you mean {}?", label_path(similar)),
    );
    format!("{} is not listed in the export lock {lock}. {hint}", label_path(path))
}

pub fn missing_on_disk(file: &str, path: &str, label: &str) -> String {
    format!(
        "The export lock lists {} of {label}, but {} is missing on disk. Run `{CLI} export` again to restore it.",
        label_path(file),
        label_path(path)
    )
}

pub fn unexported(node: &NodeRow, gone: Option<Gone>) -> String {
    let label = label(&node.path, node.number);
    match gone {
        None => format!(
            "This names {label}, which is not in the export lock, so the game has none of its files. Export it with `{CLI} export {ADDRESS_SCHEME}{}`.",
            node.id
        ),
        Some(Gone::Deleted) => format!(
            "This names {label}, which was deleted and never exported, so the game has none of its files. Replace it or remove this reference."
        ),
        Some(_) => format!(
            "This names {label}, which is withdrawn and not in the export lock, so the game has none of its files. Replace it or remove this reference."
        ),
    }
}

/// A project path in backticks, on one line, whole.
fn label_path(path: &str) -> String {
    quoted(path, usize::MAX)
}
