//! Reads the export lock, the mirror and the source files through the host,
//! then hands the facts to the rules.
use crate::{
    model::Export,
    rules::{self, Checker},
};
use plugin_api::{
    Failure,
    platform::{LocksInput, LocksOutput, Method, NodesInput, NodesOutput},
};
use plugin_guest::{Host, HostError, Platform};
use plugin_protocols::lint::{Diagnostic, LintInput, LintOutput, Severity};
use serde::{Serialize, de::DeserializeOwned};
use std::{
    collections::BTreeSet,
    time::{Duration, Instant},
};

/// Larger files are generated or binary data, not hand-written references.
const MAX_FILE_BYTES: usize = 4 * 1024 * 1024;
/// Exported files absent from every listing that are read to tell a VCS-ignored file from a missing one.
const MAX_PROBES: usize = 64;
/// Exported files a cut listing lacks that are asked for by name.
const MAX_NAME_PROBES: usize = 2_000;
/// Name lookups stop after this long, whatever a slow host makes of them; the plugin has 30 seconds.
const LOOKUP_TIME: Duration = Duration::from_secs(10);
/// The rule of the warning that a check was partial.
pub const INCOMPLETE_CHECK: &str = "incomplete-check";
/// Reading a file only to find it is not text costs the most for these; skipping
/// them is only a shortcut, the UTF-8 check still decides for every other file.
const BINARY_EXTENSIONS: &[&str] = &[
    "png", "jpg", "jpeg", "gif", "webp", "bmp", "tga", "psd", "ico", "exr", "hdr", "wav", "ogg", "mp3", "flac", "mp4",
    "webm", "mov", "glb", "fbx", "ttf", "otf", "woff", "woff2", "zip", "gz", "7z", "pck", "wasm", "dll", "so", "dylib",
    "exe", "a", "o", "pdf", "bin",
];
/// The extensions of source and data files, listed instead of every file when
/// the project has more files than one listing holds.
const SOURCE_EXTENSIONS: &[&str] = &[
    "gd", "gdshader", "shader", "tscn", "tres", "cfg", "cs", "c", "cc", "cpp", "h", "hpp", "m", "mm", "rs", "go", "py",
    "js", "jsx", "ts", "tsx", "lua", "java", "kt", "swift", "json", "toml", "yaml", "yml", "xml", "ini", "md", "txt",
    "html", "css", "glsl", "hlsl", "csv", "uproject", "uplugin",
];
/// Extensions per listing, so that no one holds more than the host returns.
const EXTENSIONS_PER_LISTING: usize = 8;

pub fn lint(host: &dyn Platform, input: &LintInput) -> Result<LintOutput, HostError> {
    let Some(mut export) = load(host)? else {
        return Ok(LintOutput::default());
    };
    let scope = Scope::new(&input.paths);
    let lock = export.lock.clone();
    let mut partial = Partial::new(host);
    if scope.contains(&lock) {
        export.on_disk = on_disk(host, &export, &mut partial);
    }
    let mut scanner = Checker::new(&export);
    let mut checked = scan_sources(host, &export, &scope, &mut scanner, &mut partial);
    if scanner.cut() {
        partial.note(&format!(
            "The run stopped after {} diagnostics; fix those and run it again to see the rest.",
            rules::MAX_DIAGNOSTICS
        ));
    }
    let mut diagnostics = scanner.finish();
    diagnostics.retain(|d| scope.contains(&d.file));
    // The lock was examined too when its listed files were checked on disk.
    if export.on_disk.is_some() {
        checked.push(lock.clone());
    }
    checked.sort();
    // Reported on the lock when it is in scope and readable, else on a file that was checked.
    let anchor = (scope.contains(&lock) && !hidden(&lock))
        .then_some(lock)
        .or_else(|| checked.first().cloned());
    diagnostics.extend(partial.diagnostic(anchor));
    Ok(LintOutput { checked, diagnostics })
}

/// Why the check may be incomplete, each reason once.
struct Partial<'h> {
    host: &'h dyn Host,
    reasons: BTreeSet<String>,
}

impl<'h> Partial<'h> {
    fn new(host: &'h dyn Host) -> Self {
        Self {
            host,
            reasons: BTreeSet::new(),
        }
    }

    fn note(&mut self, reason: &str) {
        if self.reasons.insert(reason.to_owned()) {
            self.host.warn(reason);
        }
    }

    /// The files `glob` lists, noting a listing that is cut short.
    fn list(&mut self, glob: &str) -> Vec<String> {
        let found = self.host.list(glob);
        let limit = self.host.list_limit();
        if found.len() >= limit {
            self.note(&format!(
                "`{glob}` matched {limit} files, the most the host lists, so some files were not seen."
            ));
        }
        found
    }

    /// The warning that the check was partial, on `file`.
    fn diagnostic(&self, file: Option<String>) -> Option<Diagnostic> {
        if self.reasons.is_empty() {
            return None;
        }
        let reasons: Vec<&str> = self.reasons.iter().map(String::as_str).collect();
        Some(Diagnostic {
            rule: INCOMPLETE_CHECK.to_owned(),
            severity: Severity::Warning,
            message: format!(
                "This project was only partly checked, so a clean result does not mean it is clean: {} Check one directory at a time by passing it as a path.",
                reasons.join(" ")
            ),
            file: file?,
            span: None,
            fix: None,
        })
    }
}

/// The lock and the mirror, or `None` when the project has no mirror or no
/// export lock yet: there is nothing to check, which is no error.
fn load(host: &dyn Platform) -> Result<Option<Export>, HostError> {
    let Some(locks) = answer::<_, LocksOutput>(host, Method::MirrorLocks, &LocksInput::default())? else {
        return Ok(None);
    };
    let nodes_input = NodesInput {
        deleted: true,
        ..NodesInput::default()
    };
    let Some(nodes) = answer::<_, NodesOutput>(host, Method::MirrorNodes, &nodes_input)? else {
        return Ok(None);
    };
    let directory = locks.directory.trim_end_matches('/').to_owned();
    if directory.is_empty() {
        host.warn("The export directory is the project root; nothing was checked.");
        return Ok(None);
    }
    let lock_text = host
        .read(&locks.lock)
        .ok()
        .and_then(|bytes| String::from_utf8(bytes).ok());
    Ok(Some(Export {
        directory,
        lock: locks.lock,
        lock_text,
        locked: locks.nodes,
        nodes: nodes.nodes,
        on_disk: None,
    }))
}

/// A platform method's answer, or `None` when it cannot be read and there is
/// nothing to check: no mirror, no export lock, or (only while `plugin test`
/// runs the examples) no grant. The host stops a real run that lacks the
/// grant before it reaches the plugin, so the warning is for the author.
fn answer<I: Serialize, O: DeserializeOwned>(
    host: &dyn Platform,
    method: Method,
    input: &I,
) -> Result<Option<O>, HostError> {
    let input = serde_json::to_vec(input).map_err(|e| internal(&e))?;
    match host.call(method.name(), &input) {
        Ok(output) => serde_json::from_slice(&output).map(Some).map_err(|e| internal(&e)),
        Err(error) if error.not_found() => Ok(None),
        Err(error) if error.kind == Failure::Unsupported => {
            host.warn(&format!("Nothing was checked: {}", error.message));
            Ok(None)
        }
        Err(error) => Err(error),
    }
}

fn internal(error: &serde_json::Error) -> HostError {
    HostError::new(
        Failure::Internal,
        format!("a platform answer did not match its schema: {error}"),
    )
}

/// Whether a path in the project is out of reach of `**`: a segment starts with `.`.
fn hidden(path: &str) -> bool {
    path.split('/').any(|segment| segment.starts_with('.'))
}

/// The locked files that exist, or `None` when the plugin cannot see the
/// export directory at all. The export directory is listed once; when that
/// listing is cut short, or the VCS ignores the directory, the files it lacks
/// are asked for by name, and read as a last resort.
fn on_disk(host: &dyn Host, export: &Export, partial: &mut Partial) -> Option<BTreeSet<String>> {
    // `**` never reaches a segment starting with `.`.
    if hidden(&export.directory) {
        partial.note(&format!(
            "`{}` is out of reach of this plugin's read permission, so exported files are not checked for existence.",
            export.directory
        ));
        return None;
    }
    let listed = partial.list(&format!("{}/**", escape_glob(&export.directory)));
    let complete = listed.len() < host.list_limit();
    let mut present: BTreeSet<String> = listed.into_iter().collect();
    let started = Instant::now();
    let (mut asked, mut read, mut unchecked) = (0, 0, 0);
    let wanted: BTreeSet<String> = export
        .locked
        .iter()
        .flat_map(|locked| locked.files.iter().map(|file| export.file_path(file)))
        .collect();
    let lacking: Vec<String> = wanted.into_iter().filter(|path| !present.contains(path)).collect();
    for path in lacking {
        if !complete && asked < MAX_NAME_PROBES && started.elapsed() < LOOKUP_TIME {
            asked += 1;
            if host.list(&escape_glob(&path)).contains(&path) {
                present.insert(path);
                continue;
            }
        }
        if read >= MAX_PROBES {
            unchecked += 1;
            present.insert(path);
            continue;
        }
        read += 1;
        // A VCS-ignored export directory is not listed; those files can still be read.
        if !matches!(host.read(&path), Err(error) if error.not_found()) {
            present.insert(path);
        }
    }
    if unchecked > 0 {
        partial.note(&format!(
            "{unchecked} exported files are not listed (a VCS-ignored export directory?) and were taken to exist; only {MAX_PROBES} were checked."
        ));
    }
    Some(present)
}

/// Judges the text files to scan, one at a time: under the requested paths,
/// outside the export directory, UTF-8 and not over 4 MiB. Returns the paths examined.
fn scan_sources(
    host: &dyn Host,
    export: &Export,
    scope: &Scope,
    scanner: &mut Checker,
    partial: &mut Partial,
) -> Vec<String> {
    let outside = format!("{}/", export.directory);
    let mut checked = Vec::new();
    let listed = list_sources(partial, scope);
    for path in listed
        .into_iter()
        .filter(|path| !path.starts_with(&outside) && !binary(path))
    {
        if scanner.full() {
            break;
        }
        let Some(text) = host
            .read(&path)
            .ok()
            .filter(|bytes| bytes.len() <= MAX_FILE_BYTES)
            .and_then(|bytes| String::from_utf8(bytes).ok())
        else {
            continue;
        };
        scanner.scan(&path, &text);
        checked.push(path);
    }
    checked
}

/// The files in the requested paths. When one listing is cut short, the files
/// with source extensions are listed as well, a few extensions at a time.
fn list_sources(partial: &mut Partial, scope: &Scope) -> BTreeSet<String> {
    let limit = partial.host.list_limit();
    let mut listed = BTreeSet::new();
    for glob in scope.globs() {
        let found = partial.list(&glob);
        let cut = found.len() >= limit;
        listed.extend(found);
        if cut && glob.ends_with("**") {
            for extensions in SOURCE_EXTENSIONS.chunks(EXTENSIONS_PER_LISTING) {
                listed.extend(partial.list(&format!("{glob}/*.{{{}}}", extensions.join(","))));
            }
        }
    }
    listed
}

fn binary(path: &str) -> bool {
    path.rsplit_once('.')
        .is_some_and(|(_, extension)| BINARY_EXTENSIONS.contains(&extension.to_ascii_lowercase().as_str()))
}

/// The requested files and directories; empty means the whole project.
struct Scope {
    paths: Vec<String>,
}

impl Scope {
    fn new(paths: &[String]) -> Self {
        Self {
            paths: paths
                .iter()
                .map(|p| p.trim_start_matches("./").trim_end_matches('/').to_owned())
                .filter(|p| !p.is_empty() && p != ".")
                .collect(),
        }
    }

    fn contains(&self, file: &str) -> bool {
        self.paths.is_empty()
            || self
                .paths
                .iter()
                .any(|p| file == p || file.strip_prefix(p.as_str()).is_some_and(|rest| rest.starts_with('/')))
    }

    /// Listings that cover the scope: each path as a file and as a directory.
    fn globs(&self) -> Vec<String> {
        if self.paths.is_empty() {
            return vec!["**".to_owned()];
        }
        self.paths
            .iter()
            .flat_map(|p| {
                let p = escape_glob(p);
                [p.clone(), format!("{p}/**")]
            })
            .collect()
    }
}

/// `path` as a glob that matches only itself.
fn escape_glob(path: &str) -> String {
    path.chars()
        .map(|c| match c {
            '*' | '?' | '[' | ']' | '{' | '}' => format!("[{c}]"),
            c => c.to_string(),
        })
        .collect()
}

#[cfg(test)]
mod tests;
