//! Where source text names an exported asset: by an exported file path, by
//! the export directory followed by something else, or by a node UUID (every
//! resource key starts with one). Plain text matching, no language parsing.
use crate::model::Export;
use std::{collections::HashMap, iter, ops::Range};

/// What a piece of text names.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Mention<'a> {
    /// An exported file, or a directory that holds only one locked node's files.
    Node(usize),
    /// A path under the export directory that names no exported file.
    Unlisted(&'a str),
    /// A node UUID.
    Uuid(&'a str),
}

/// A mention and where it starts and ends (byte offsets).
pub type Found<'a> = (Range<usize>, Mention<'a>);

/// The locked files, grouped by their first path segment so a lookup only
/// compares the few paths that can match.
pub struct Index {
    prefix: String,
    /// The export lock's path after `prefix`: never a mention.
    lock: String,
    groups: HashMap<String, Vec<(String, usize)>>,
}

impl Index {
    pub fn new(export: &Export) -> Self {
        let mut groups: HashMap<String, Vec<(String, usize)>> = HashMap::new();
        for (node, locked) in export.locked.iter().enumerate() {
            for file in &locked.files {
                let first = file.split('/').next().unwrap_or(file);
                groups.entry(first.to_owned()).or_default().push((file.clone(), node));
            }
        }
        Self {
            prefix: format!("{}/", export.directory),
            lock: export.lock_name().to_owned(),
            groups,
        }
    }

    /// Every mention in `text`, by position. A UUID inside a mentioned
    /// exported path is part of that mention, not another.
    pub fn scan<'a>(&self, text: &'a str) -> Vec<Found<'a>> {
        let mut found = self.paths(text);
        let covered: Vec<Range<usize>> = found
            .iter()
            .filter(|(_, mention)| !matches!(mention, Mention::Unlisted(_)))
            .map(|(span, _)| span.clone())
            .collect();
        // Mentioned paths do not overlap and come in order, so a position is in at most one.
        let inside = |at: usize| {
            let before = covered.partition_point(|c| c.start <= at);
            before > 0 && at < covered[before - 1].end
        };
        found.extend(uuids(text).filter(|(span, _)| !inside(span.start)));
        found.sort_by_key(|(span, _)| span.start);
        found
    }

    fn paths<'a>(&self, text: &'a str) -> Vec<Found<'a>> {
        let mut found: Vec<Found<'a>> = Vec::new();
        let mut resume = 0;
        for (start, _) in text.match_indices(&self.prefix) {
            if start < resume || !left_boundary(text[..start].chars().next_back()) {
                continue;
            }
            let rest = &text[start + self.prefix.len()..];
            let Some((length, named)) = self.path(rest) else {
                continue;
            };
            let end = start + self.prefix.len() + length;
            resume = end;
            match named {
                Named::Node(node) => found.push((start..end, Mention::Node(node))),
                Named::Unlisted => found.push((start..end, Mention::Unlisted(&text[start..end]))),
                Named::Nothing => {}
            }
        }
        found
    }

    /// The path at the start of `rest` (the text after the export directory):
    /// its length and what it names. An empty path is not a mention.
    fn path(&self, rest: &str) -> Option<(usize, Named)> {
        let first = rest.split(|c: char| !path_char(c) || c == '/').next().unwrap_or("");
        if let Some((file, node)) = self.longest_file(first, rest) {
            return Some((file.len(), Named::Node(node)));
        }
        let token = rest[..path_length(rest)].trim_end_matches('.');
        if token.is_empty() {
            return None;
        }
        let named = if token == self.lock {
            Named::Nothing
        } else {
            match self.owners_of_directory(first, token).as_slice() {
                [] => Named::Unlisted,
                [node] => Named::Node(*node),
                _ => Named::Nothing,
            }
        };
        Some((token.len(), named))
    }

    /// The longest locked file that `rest` starts with, ending where the path ends.
    fn longest_file(&self, first: &str, rest: &str) -> Option<(&str, usize)> {
        self.groups
            .get(first)?
            .iter()
            .filter(|(file, _)| rest.starts_with(file.as_str()) && right_boundary(&rest[file.len()..]))
            .max_by_key(|(file, _)| file.len())
            .map(|(file, node)| (file.as_str(), *node))
    }

    /// The nodes with a locked file under `token` taken as a directory.
    fn owners_of_directory(&self, first: &str, token: &str) -> Vec<usize> {
        let directory = format!("{}/", token.trim_end_matches('/'));
        let mut owners: Vec<usize> = self
            .groups
            .get(first)
            .into_iter()
            .flatten()
            .filter(|(file, _)| file.starts_with(&directory))
            .map(|(_, node)| *node)
            .collect();
        owners.sort_unstable();
        owners.dedup();
        owners
    }
}

/// What a path under the export directory names.
enum Named {
    Node(usize),
    Unlisted,
    /// The lock file, or a directory that several nodes share.
    Nothing,
}

/// Characters of an exported path. Spaces and quotes end it, which is where
/// source text ends a path; a locked file name with a space is matched whole.
fn path_char(c: char) -> bool {
    c.is_alphanumeric() || matches!(c, '_' | '-' | '.' | '/' | '%')
}

fn path_length(rest: &str) -> usize {
    rest.char_indices()
        .find(|&(_, c)| !path_char(c))
        .map_or(rest.len(), |(at, _)| at)
}

/// A path is not part of a longer name when it follows one.
fn left_boundary(before: Option<char>) -> bool {
    before.is_none_or(|c| !(c.is_alphanumeric() || matches!(c, '_' | '-' | '.' | '%')))
}

/// A path ends where no further name character follows; a `.` that starts an
/// extension (`hero.png.import`) continues it, one that ends a sentence does not.
fn right_boundary(after: &str) -> bool {
    let mut chars = after.chars();
    match chars.next() {
        None => true,
        Some('.') => !chars
            .next()
            .is_some_and(|c| c.is_alphanumeric() || c == '_' || c == '-'),
        Some(c) => !(c.is_alphanumeric() || matches!(c, '_' | '-' | '%' | '/')),
    }
}

const UUID_LENGTH: usize = 36;

/// Canonical lowercase UUIDs that are not part of a longer run of hex digits.
fn uuids(text: &str) -> impl Iterator<Item = Found<'_>> {
    let bytes = text.as_bytes();
    let mut at = 0;
    iter::from_fn(move || {
        while at + UUID_LENGTH <= bytes.len() {
            let start = at;
            at += 1;
            if is_uuid(&bytes[start..start + UUID_LENGTH]) && standalone(bytes, start, start + UUID_LENGTH) {
                at = start + UUID_LENGTH;
                return Some((start..at, Mention::Uuid(&text[start..at])));
            }
        }
        None
    })
}

fn is_uuid(candidate: &[u8]) -> bool {
    candidate.iter().enumerate().all(|(at, byte)| match at {
        8 | 13 | 18 | 23 => *byte == b'-',
        _ => byte.is_ascii_digit() || (b'a'..=b'f').contains(byte),
    })
}

/// No hex digit touches the UUID: it is not part of a longer run of them.
fn standalone(bytes: &[u8], start: usize, end: usize) -> bool {
    let hex = |at: Option<usize>| at.and_then(|at| bytes.get(at)).is_some_and(u8::is_ascii_hexdigit);
    !hex(start.checked_sub(1)) && !hex(Some(end))
}

#[cfg(test)]
mod tests;
