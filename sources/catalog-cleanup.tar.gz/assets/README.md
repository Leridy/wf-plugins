# assets

The official `wf` plugin that checks that game source still refers to valid
WeaveForge assets: the platform nodes `wf export` copied into the game project.
It implements the `wf.lint/1` protocol, so `wf lint` runs it with every other
linter, and `wf assets lint` runs it alone.

## What it checks

It reads three things: the export lock and the nodes of the local mirror
(`wf.mirror.locks`, `wf.mirror.nodes` through `host.call`), and the project's
files as plain text. It looks for the UUIDs of nodes and for paths under the
export directory by exact text match, as `wf diff --since --impact` does, and
never returns an effect.

**It parses no language or engine format.** The same text search works for GDScript,
C#, C++, scene files and JSON alike, and a new engine needs no change here.
Checks that need an engine's syntax or file format (a `res://` path inside a
`.tscn`, a Unity `.meta` GUID) belong to that engine's plugin, as rules of its
own such as `godot/missing-resource`.

| Rule | Level | When |
| --- | --- | --- |
| `removed-asset` | error | An exported node is gone from the platform: HEAD no longer has it, or it is withdrawn or deleted. |
| `stale-asset` | warning | An exported node has a newer version or another path at HEAD. Run the export again. |
| `incomplete-check` | warning | A listing hit the host's limit, files were taken to exist unchecked, or the diagnostics were cut: the project was only partly checked. |
| `missing-asset-file` | error | Source names a path under the export directory that the lock does not list, or the lock lists a file that is missing on disk. |
| `unexported-asset` | error | Source holds the UUID of a node the mirror knows (at HEAD or deleted) that is not in the export lock, so the game has none of its files. |

The host prefixes each rule with the plugin name (`assets/stale-asset`) and
applies the levels in `wf-plugins.toml`:

```toml
[lint.rules]
"assets/stale-asset" = "error"
"assets/unexported-asset" = "off"
```

### Where a diagnostic points

- `removed-asset` and `stale-asset` sit on every reference in the scanned
  files: an exported file path, or the node UUID (every resource key starts
  with one), as a byte span. A node nothing refers to is reported once on the
  export lock (`<export dir>/wf.lock.json`), at the node's `id`.
- `missing-asset-file` sits on the path in source, or on the lock entry of the
  file that is missing on disk.
- `unexported-asset` sits on the UUID. A path through an unexported node's
  directory (`assets/wf/<uuid>/x.png`) is reported this way, once, instead of as
  `missing-asset-file`. A typo in the path of a locked node is reported only as
  the missing file, not again as that node's own problem.
- A reference to a lock-listed file that exists, whose node is current, is fine.

### What it scans

`LintInput.paths` limits the files, as the lint command passes them; with none it
scans the whole project. It skips the export directory itself, files over 4 MiB,
files that are not UTF-8 and a few well-known binary extensions it does not
bother to open. With no mirror or no export lock it returns an empty result and
no diagnostics.

Matching is deliberately plain:

- A UUID matches only in its canonical lowercase form, and not inside a longer
  run of hex digits (`a<uuid>` and `<uuid>0` are other identifiers).
- A path matches from the export directory as written in `wf.toml`
  (`assets/wf/...`), whatever precedes it (`res://`, `./`); it ends at the first
  character that cannot be in an exported path. `hero.png.import` is another
  file than `hero.png`, and `hero.png.` at the end of a sentence is `hero.png`.
- A directory path counts as a reference to a node when only that node has
  files below it.

Limits: it needs the paths as the export wrote them; if the game project's engine
root is below the export directory's parent (`res://` drops a leading folder),
only the UUID matches. The host lists at most 10,000 files per request. Sources
are read one at a time, so memory does not grow with the project; the export
directory's files are looked up by name when its listing is cut short; and when
the listing of all files is, the files with source extensions are listed too.
The run then reports an `incomplete-check` warning on the lock saying what it
could not see, and `paths` check the rest.

## Permissions

```toml
[permissions]
read = ["**"]      # source files; dot directories stay unreadable
platform = "read"  # the export lock and the mirror's nodes
```

The export lock (`wf.lock.json`; the plugin takes its path from
`wf.mirror.locks`, never assumes the name) is readable under `**` (it is not one of the
files the host keeps from every plugin), unless the export directory has a dot
segment. Then spans on the lock are left out, and the existence of the exported
files is not checked.

## Build, test and pack

It depends on [`plugin-kit`](https://gitlab.xqhuyu.cn/996-ugc/wf-plugins/plugin-kit)
by path, so clone that repository beside this one first:

```sh
git clone ssh://git@gitlab.xqhuyu.cn:10022/996-ugc/wf-plugins/plugin-kit.git ../plugin-kit
```

Then, from this directory:

```sh
cargo test                                       # the rules, on the host target
cargo build --release --target wasm32-wasip2     # the component
wf plugin test .                                 # description and examples
wf plugin link .                                 # shows the permissions; --yes grants them
wf assets lint --help
wf plugin pack                                   # assets-0.1.5.wfplugin, for release
```

`wf plugin test` runs the examples without the permissions until the plugin is
linked and trusted, and then reports them as partial: the plugin reads nothing
and says so in its log. Link it, then test again, to run them for real.

The plugin binds the API in `plugin-kit/plugin-api/wit` through `plugin-kit/plugin-guest`,
which also holds the host glue and message quoting it shares with the other
official plugins, so it always follows the latest API. The built component is
not committed: the official plugin is packed, signed and published at release,
from the tag's source; bump `version` whenever its bytes change.
