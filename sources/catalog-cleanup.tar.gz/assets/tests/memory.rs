//! The plugin runs in a WebAssembly store with a 256 MiB memory limit. This
//! measures what a project of many large text files makes it allocate on the
//! host target, where allocations are no smaller than there, and that hostile
//! files of the largest size it reads (4 MiB) are scanned in good time.
#![allow(clippy::print_stderr, reason = "the peaks are the test's result")]

use globset::Glob;
use plugin_api::{
    Failure,
    platform::{Head, LockedRow, LocksOutput, NodeRow, NodeState, NodesOutput},
};
use plugin_guest::{Host, HostError, Platform, counting::Counting};
use plugin_protocols::lint::LintInput;
use std::time::{Duration, Instant};
use wf_assets::lint;

#[global_allocator]
static ALLOCATOR: Counting = Counting;

const FILE: usize = 4 << 20;
/// Half the store's 256 MiB, which also holds the component and the host's
/// copies; a native pointer is twice a wasm32 one.
const BUDGET: usize = 128 << 20;

fn uuid(n: u32) -> String {
    format!("{n:08x}-0000-4000-8000-{n:012x}")
}

/// A project of `count` source files of `text` each, generated when read, and
/// an export of three current nodes.
struct Project {
    count: usize,
    text: String,
}

impl Project {
    fn export_files() -> Vec<String> {
        (1..=3).map(|n| format!("assets/wf/{}/a.png", uuid(n))).collect()
    }

    fn source(n: usize) -> String {
        format!("src/{n:04}.txt")
    }
}

impl Platform for Project {
    fn call(&self, method: &str, _input: &[u8]) -> Result<Vec<u8>, HostError> {
        let nodes: Vec<NodeRow> = (1..=3)
            .map(|n| NodeRow {
                id: uuid(n),
                number: u64::from(n),
                path: format!("ui/n{n}"),
                node_type: "image".to_owned(),
                version: Some(3),
                state: NodeState::Current,
            })
            .collect();
        let answer = match method {
            "wf.mirror.nodes" => serde_json::to_vec(&NodesOutput { nodes }),
            "wf.mirror.locks" => serde_json::to_vec(&LocksOutput {
                directory: "assets/wf".to_owned(),
                lock: "assets/wf/wf.lock.json".to_owned(),
                nodes: (1..=3)
                    .map(|n| LockedRow {
                        id: uuid(n),
                        number: u64::from(n),
                        path: format!("ui/n{n}"),
                        version: 3,
                        form: "source".to_owned(),
                        files: vec![format!("{}/a.png", uuid(n))],
                        head: Head::Current,
                        head_version: Some(3),
                    })
                    .collect(),
            }),
            other => return Err(HostError::new(Failure::NotFound, other)),
        };
        Ok(answer.unwrap())
    }
}

impl Host for Project {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        let mut all: Vec<String> = (0..self.count).map(Self::source).collect();
        all.extend(Self::export_files());
        all.push("assets/wf/wf.lock.json".to_owned());
        all.into_iter().filter(|path| matcher.is_match(path)).collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        if path.starts_with("src/") {
            Ok(self.text.clone().into_bytes())
        } else if path.starts_with("assets/wf/") {
            Ok(b"{}".to_vec())
        } else {
            Err(HostError::new(Failure::NotFound, path))
        }
    }

    fn warn(&self, _message: &str) {}
}

/// Lints `project`; returns the peak allocation above the start, the time
/// taken and the number of files checked.
fn measure(project: &Project) -> (usize, Duration, usize) {
    let started = Instant::now();
    let (output, peak) = Counting::peak(|| lint(project, &LintInput::default()).unwrap());
    (peak, started.elapsed(), output.checked.len())
}

fn filled(unit: &str) -> String {
    unit.repeat(FILE / unit.len())
}

/// One test, so the cases run one after another and the peaks are not mixed.
#[test]
fn many_large_files_and_hostile_mentions_stay_far_under_the_memory_limit() {
    let paths = format!("{} {}\n", Project::export_files()[0], uuid(2));
    let cases = [
        // 40 files of 4 MiB: 160 MiB of text, which must never be held at once.
        ("plain text", 40, filled("var x = 1; # nothing to find here\n"), true),
        ("mentions", 4, filled(&paths), true),
        ("uuids", 4, filled(&format!("{}\n", uuid(3))), true),
        // Every mention is a diagnostic: the run stops when they are as many as it reports.
        (
            "unlisted paths",
            4,
            filled("assets/wf/9/a.png assets/wf/aaaaaaaa-0000-4000-8000-000000000000 \n"),
            false,
        ),
    ];
    for (name, count, text, all) in cases {
        let project = Project { count, text };
        let (peak, elapsed, checked) = measure(&project);
        eprintln!("{name}: {count} files, peak {} KiB, {elapsed:?}", peak >> 10);
        if all {
            assert_eq!(checked, count + 1, "{name}: every source and the lock were checked");
        } else {
            assert!(
                checked < count,
                "{name}: the run stopped when its diagnostics were full"
            );
        }
        assert!(peak < BUDGET, "{name} allocated {} MiB", peak >> 20);
        assert!(elapsed < Duration::from_secs(60), "{name} took {elapsed:?}");
    }
}
