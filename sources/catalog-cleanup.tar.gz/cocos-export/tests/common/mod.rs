//! The integration tests' in-memory host, with typed mirror answers and case loader.
#![allow(dead_code, reason = "shared integration test host helpers")]
use globset::Glob;
use plugin_api::{
    Effect, Failure,
    platform::{LocksOutput, NodeInput, NodeOutput},
};
use plugin_guest::{Host, HostError, Platform};
use std::{collections::BTreeMap, fs, path::Path};

#[derive(Default)]
pub struct Fake {
    pub files: BTreeMap<String, Vec<u8>>,
    pub locks: Option<LocksOutput>,
    pub nodes: Vec<NodeOutput>,
}

impl Fake {
    pub fn apply(&mut self, effects: Vec<Effect>) {
        for effect in effects {
            match effect {
                Effect::WriteFile { path, bytes, .. } => {
                    self.files.insert(path, bytes);
                }
                Effect::DeleteFile { path } => {
                    self.files.remove(&path);
                }
                _ => unreachable!("only writes and deletes"),
            }
        }
    }

    pub fn case(name: &str) -> Self {
        let path = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/cases").join(name);
        Self {
            files: files(&path.join("project")),
            locks: Some(serde_json::from_slice(&fs::read(path.join("locks.json")).unwrap()).unwrap()),
            nodes: serde_json::from_slice(&fs::read(path.join("nodes.json")).unwrap()).unwrap(),
        }
    }
}

impl Host for Fake {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        self.files.keys().filter(|p| matcher.is_match(p)).cloned().collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.files
            .get(path)
            .cloned()
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }

    fn warn(&self, _: &str) {}
}

impl Platform for Fake {
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, HostError> {
        match method {
            "wf.mirror.locks" => self
                .locks
                .as_ref()
                .map(|locks| serde_json::to_vec(locks).unwrap())
                .ok_or_else(|| HostError::new(Failure::NotFound, "no export lock")),
            "wf.mirror.node" => {
                let query: NodeInput = serde_json::from_slice(input).unwrap();
                let node = self
                    .nodes
                    .iter()
                    .find(|n| {
                        query.address == format!("wf://{}", n.node.id)
                            || query.address == format!("#{}", n.node.number)
                            || query.address == n.node.path
                    })
                    .ok_or_else(|| HostError::new(Failure::NotFound, "node"))?;
                Ok(serde_json::to_vec(node).unwrap())
            }
            _ => unreachable!("only mirror reads"),
        }
    }
}

pub fn files(root: &Path) -> BTreeMap<String, Vec<u8>> {
    fn walk(root: &Path, dir: &Path, output: &mut BTreeMap<String, Vec<u8>>) {
        for item in fs::read_dir(dir).unwrap() {
            let path = item.unwrap().path();
            if path.is_dir() {
                walk(root, &path, output);
            } else {
                output.insert(
                    path.strip_prefix(root).unwrap().to_str().unwrap().replace('\\', "/"),
                    fs::read(path).unwrap(),
                );
            }
        }
    }
    let mut output = BTreeMap::new();
    walk(root, root, &mut output);
    output
}
