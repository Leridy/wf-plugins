//! Reads the mirror and sidecars, generates Cocos Creator 3.x assets and prefabs, and plans guarded writes.
use crate::{
    cocos::{Document, ExportTarget, Exported, animation, parallax, particle, prop, spatial, tilemap, ui, whole_map},
    model::{Animation, Kit, Model3d, ParallaxMap, ParticleEffect, PropSet, Scene3dMap, TileMap, WholeMap, png},
    paths::{self, invalid},
    reconcile::{self, MANIFEST_NAME, Manifest, ManifestEntry},
    types::{File, Input, Node, Output, Plan, Status},
};
use plugin_api::{
    Failure,
    platform::{LockedRow, LocksInput, LocksOutput, Method, NodeInput, NodeOutput},
};
use plugin_guest::{Host, HostError, Platform};
use serde::{Serialize, de::DeserializeOwned};
use std::{
    collections::{BTreeMap, BTreeSet},
    iter::once,
};

const MAX_SIDECAR: usize = 4 << 20;
const MAX_GLB: usize = 32 << 20;
const MAX_OUTPUT: usize = 16 << 20;
const SCHEMA_VERSION: u32 = 1;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum SharedKind {
    Particle,
    WholeMap,
    Parallax,
    Spatial,
}

type SharedRuntimes = BTreeSet<SharedKind>;

pub fn sync(host: &dyn Platform, input: &Input) -> Result<Plan, HostError> {
    let mut plan = Plan {
        output: Output::default(),
        effects: Vec::new(),
    };
    let locks: LocksOutput = match answer(
        host,
        Method::MirrorLocks,
        &LocksInput {
            directory: input.directory.clone(),
        },
    ) {
        Ok(locks) => locks,
        Err(error) if error.kind == Failure::NotFound && !input.nodes.is_empty() => {
            selection(host, input, &[], &mut plan.output)?;
            return Ok(plan);
        }
        Err(error) => return Err(error),
    };
    let directory = locks.directory.trim_end_matches('/');
    if directory != "." && !directory.is_empty() {
        paths::relative(directory)?;
    }
    let directory = if directory == "." { "" } else { directory };
    let root = paths::root(host, directory)?;
    let selected = selection(host, input, &locks.nodes, &mut plan.output)?;

    let manifest_path = paths::join(directory, MANIFEST_NAME);
    let prev_manifest = Manifest::load(host, &manifest_path);
    let mut next_manifest = Manifest::default();
    let mut wanted = BTreeSet::new();
    let mut size = 0;
    let mut runtimes = SharedRuntimes::default();
    let mut synced_owners = BTreeSet::new();

    for row in locks.nodes.iter().filter(|r| selected.contains(&r.id)) {
        synced_owners.insert(row.id.clone());
        sync_node(
            host,
            &locks,
            directory,
            &root,
            input.force,
            row,
            &prev_manifest,
            &mut next_manifest,
            &mut wanted,
            &mut size,
            &mut runtimes,
            &mut plan,
        )?;
    }

    sync_shared_runtimes(
        host,
        &locks,
        directory,
        &root,
        input.force,
        &runtimes,
        &prev_manifest,
        &mut next_manifest,
        &mut wanted,
        &mut size,
        &mut plan,
    )?;

    leftovers(
        host,
        directory,
        &locks,
        input.nodes.is_empty(),
        &synced_owners,
        &wanted,
        input.force,
        &prev_manifest,
        &mut next_manifest,
        &mut plan,
    )?;

    if next_manifest != prev_manifest {
        let mbytes = next_manifest.to_bytes();
        let (_, _) = reconcile::plan_write(host, &manifest_path, mbytes, true, None, &mut plan.effects)?;
    }
    Ok(plan)
}

#[allow(clippy::too_many_arguments)]
fn sync_node(
    host: &dyn Platform,
    locks: &LocksOutput,
    directory: &str,
    root: &str,
    force: bool,
    row: &LockedRow,
    prev_manifest: &Manifest,
    next_manifest: &mut Manifest,
    wanted: &mut BTreeSet<String>,
    size: &mut usize,
    runtimes: &mut SharedRuntimes,
    plan: &mut Plan,
) -> Result<(), HostError> {
    let node: NodeOutput = answer(
        host,
        Method::MirrorNode,
        &NodeInput {
            address: format!("wf://{}", row.id),
        },
    )?;
    let node_type = node.node.node_type.as_str();
    let mut result = Node {
        id: row.id.clone(),
        number: row.number,
        path: row.path.clone(),
        node_type: node.node.node_type.clone(),
        status: Status::Skipped,
        files: Vec::new(),
        main_prefab: None,
        elements: Vec::new(),
        reasons: Vec::new(),
    };
    let Some(sidecar_name) = sidecar_file(node_type) else {
        result
            .reasons
            .push(format!("{}: unsupported node type {node_type}; skipped.", row.path));
        plan.output.push_node(result, Some(&row.form));
        return Ok(());
    };
    let Ok(prefix) = sidecar_prefix(row, sidecar_name) else {
        result.reasons.push(format!(
            "{}: missing expected {sidecar_name} export file; skipped.",
            row.path
        ));
        plan.output.push_node(result, Some(&row.form));
        return Ok(());
    };

    let node_dir = paths::join(directory, prefix);
    let stem = paths::stem_from_dir(prefix);
    let sidecar_path = paths::join(&node_dir, sidecar_name);
    let bytes = read_sidecar(host, &sidecar_path, sidecar_name == "engine-scene.glb")?;
    let display_name = node
        .node
        .path
        .rsplit('/')
        .next()
        .filter(|s| !s.is_empty())
        .unwrap_or(&stem);

    let target = ExportTarget {
        node_prefix: &row.id,
        node_dir: &node_dir,
        directory,
        root,
    };
    let exported = generate_node_docs(
        host,
        row,
        target,
        prefix,
        &stem,
        display_name,
        node_type,
        sidecar_name,
        &bytes,
        runtimes,
    )?;
    result.elements = exported.elements;
    result.reasons.extend(exported.notes);

    result.main_prefab = exported
        .documents
        .iter()
        .find(|d| d.rel_path.ends_with(".prefab"))
        .map(|d| d.resource.clone());

    apply_node_documents(
        host,
        locks,
        directory,
        force,
        row,
        exported.documents,
        prev_manifest,
        next_manifest,
        wanted,
        size,
        plan,
        &mut result,
    )?;

    result.status = node_status(&result.files);
    plan.output.push_node(result, Some(&row.form));
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn apply_node_documents(
    host: &dyn Platform,
    locks: &LocksOutput,
    directory: &str,
    force: bool,
    row: &LockedRow,
    documents: Vec<Document>,
    prev_manifest: &Manifest,
    next_manifest: &mut Manifest,
    wanted: &mut BTreeSet<String>,
    size: &mut usize,
    plan: &mut Plan,
    result: &mut Node,
) -> Result<(), HostError> {
    for document in documents {
        let path = paths::join(directory, &document.rel_path);
        if !wanted.insert(path.clone()) {
            return Err(invalid(format!("generated paths collide: {path}")));
        }
        ensure_not_locked(locks, directory, &path)?;
        let bytes = reconcile::prepare_bytes(&row.id, SCHEMA_VERSION, &document.body, document.stamp);
        *size += bytes.len();
        if *size > MAX_OUTPUT {
            return Err(invalid("generated output exceeds 16 MiB; sync fewer nodes"));
        }
        let recorded = prev_manifest.files.get(&path).map(|e| e.sha256.as_str());
        let (st, sha) = reconcile::plan_write(host, &path, bytes, force, recorded, &mut plan.effects)?;
        if st == Status::Kept {
            plan.output
                .warnings
                .push(format!("{path}: local edits detected; use --force to replace it."));
        }
        next_manifest.files.insert(
            path.clone(),
            ManifestEntry {
                owner: row.id.clone(),
                version: SCHEMA_VERSION,
                sha256: sha,
            },
        );
        result.files.push(File {
            path,
            resource: document.resource,
            status: st,
        });
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn generate_node_docs(
    host: &dyn Platform,
    row: &LockedRow,
    target: ExportTarget<'_>,
    prefix: &str,
    stem: &str,
    raw_name: &str,
    kind: &str,
    sidecar: &str,
    bytes: &[u8],
    runtimes: &mut SharedRuntimes,
) -> Result<Exported, HostError> {
    let locked: BTreeSet<String> = row.files.iter().cloned().collect();
    if matches!(sidecar, "main.json" | "engine-scene.glb" | "model.json") {
        return generate_world_or_fx_docs(
            host, row, target, prefix, stem, raw_name, kind, sidecar, bytes, &locked, runtimes,
        );
    }
    if sidecar == "animation.json" {
        let anim = Animation::read(bytes)?;
        let dims = load_textures(
            host,
            row,
            target.directory,
            prefix,
            anim.clips
                .iter()
                .flat_map(|c| &c.frames)
                .map(|f| f.texture.path.as_str()),
            true,
        )?;
        Ok(animation::generate(&anim, target, stem, raw_name, &dims))
    } else if sidecar == "tilemap.json" {
        let map = TileMap::read(bytes)?;
        load_textures(
            host,
            row,
            target.directory,
            prefix,
            map.textures.values().map(|t| t.file.as_str()),
            false,
        )?;
        Ok(tilemap::generate(&map, target, stem, raw_name))
    } else if sidecar == "props.json" {
        let prop_set = PropSet::read(bytes)?;
        let dims = load_textures(
            host,
            row,
            target.directory,
            prefix,
            prop_set.objects.iter().flat_map(|o| {
                o.states.iter().map(|s| s.texture.path.as_str()).chain(
                    o.animations
                        .iter()
                        .flat_map(|a| a.textures.iter().map(|t| t.path.as_str())),
                )
            }),
            true,
        )?;
        Ok(prop::generate(&prop_set, target, &dims))
    } else {
        let kit = Kit::read(bytes)?;
        let dims = load_textures(
            host,
            row,
            target.directory,
            prefix,
            kit.extra_textures.iter().map(|t| t.path.as_str()),
            true,
        )?;
        Ok(ui::generate(&kit, target, &dims))
    }
}

#[allow(clippy::too_many_arguments)]
fn generate_world_or_fx_docs(
    host: &dyn Platform,
    row: &LockedRow,
    target: ExportTarget<'_>,
    prefix: &str,
    stem: &str,
    raw_name: &str,
    kind: &str,
    sidecar: &str,
    bytes: &[u8],
    locked: &BTreeSet<String>,
    runtimes: &mut SharedRuntimes,
) -> Result<Exported, HostError> {
    if sidecar == "main.json" && kind == "whole_map" {
        let map = WholeMap::read(bytes, locked, prefix)?;
        let dims = load_textures(host, row, target.directory, prefix, map.texture_paths(), true)?;
        runtimes.insert(SharedKind::WholeMap);
        Ok(whole_map::generate(&map, target, stem, raw_name, &dims))
    } else if sidecar == "main.json" && matches!(kind, "scrolling_scene" | "scroll_map") {
        let map = ParallaxMap::read(bytes, locked, prefix)?;
        let dims = load_textures(host, row, target.directory, prefix, map.texture_paths(), true)?;
        runtimes.insert(SharedKind::Parallax);
        Ok(parallax::generate(&map, target, stem, raw_name, &dims))
    } else if sidecar == "main.json" {
        let effect = ParticleEffect::read(bytes)?;
        let dims = load_textures(
            host,
            row,
            target.directory,
            prefix,
            effect.emitters.iter().map(|e| e.picture.as_str()),
            true,
        )?;
        runtimes.insert(SharedKind::Particle);
        Ok(particle::generate(&effect, target, stem, raw_name, &dims))
    } else if sidecar == "engine-scene.glb" {
        let scene = Scene3dMap::read(bytes, "engine-scene.glb".to_owned())?;
        runtimes.insert(SharedKind::Spatial);
        Ok(spatial::scene3d(&scene, target, stem, raw_name))
    } else {
        let glb_name = "main.glb";
        load_textures(host, row, target.directory, prefix, once(glb_name), false)?;
        let glb_bytes = host.read(&paths::join(target.node_dir, glb_name))?;
        let model = Model3d::read(bytes, &glb_bytes, glb_name.to_owned())?;
        runtimes.insert(SharedKind::Spatial);
        Ok(spatial::model3d(&model, target, stem, raw_name))
    }
}

#[allow(clippy::too_many_arguments)]
fn sync_shared_runtimes(
    host: &dyn Platform,
    locks: &LocksOutput,
    directory: &str,
    root: &str,
    force: bool,
    runtimes: &SharedRuntimes,
    prev_manifest: &Manifest,
    next_manifest: &mut Manifest,
    wanted: &mut BTreeSet<String>,
    size: &mut usize,
    plan: &mut Plan,
) -> Result<(), HostError> {
    type SharedBuilder = fn(&str, &str) -> Vec<Document>;
    let groups: [(SharedKind, &str, SharedBuilder); 4] = [
        (
            SharedKind::Particle,
            particle::SHARED_OWNER_ID,
            particle::shared_runtime_documents,
        ),
        (
            SharedKind::WholeMap,
            whole_map::SHARED_OWNER_ID,
            whole_map::shared_runtime_documents,
        ),
        (
            SharedKind::Parallax,
            parallax::SHARED_OWNER_ID,
            parallax::shared_runtime_documents,
        ),
        (
            SharedKind::Spatial,
            spatial::SHARED_OWNER_ID,
            spatial::shared_runtime_documents,
        ),
    ];

    for (kind, owner_id, build_docs) in groups {
        if !runtimes.contains(&kind) {
            continue;
        }
        for document in build_docs(directory, root) {
            let path = paths::join(directory, &document.rel_path);
            if !wanted.insert(path.clone()) {
                return Err(invalid(format!("generated paths collide: {path}")));
            }
            ensure_not_locked(locks, directory, &path)?;
            let bytes = reconcile::prepare_bytes(owner_id, SCHEMA_VERSION, &document.body, document.stamp);
            *size += bytes.len();
            if *size > MAX_OUTPUT {
                return Err(invalid("generated output exceeds 16 MiB; sync fewer nodes"));
            }
            let recorded = prev_manifest.files.get(&path).map(|e| e.sha256.as_str());
            let (st, sha) = reconcile::plan_write(host, &path, bytes, force, recorded, &mut plan.effects)?;
            if st == Status::Kept {
                plan.output.warnings.push(format!(
                    "{path}: shared runtime has local edits; use --force to replace it."
                ));
            }
            next_manifest.files.insert(
                path,
                ManifestEntry {
                    owner: owner_id.to_owned(),
                    version: SCHEMA_VERSION,
                    sha256: sha,
                },
            );
        }
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn leftovers(
    host: &dyn Platform,
    directory: &str,
    locks: &LocksOutput,
    full_sync: bool,
    synced_owners: &BTreeSet<String>,
    wanted: &BTreeSet<String>,
    force: bool,
    prev_manifest: &Manifest,
    next_manifest: &mut Manifest,
    plan: &mut Plan,
) -> Result<(), HostError> {
    let locked_files: BTreeSet<String> = locks
        .nodes
        .iter()
        .flat_map(|n| n.files.iter().map(|f| paths::join(directory, f)))
        .collect();
    let active_ids: BTreeSet<&str> = locks.nodes.iter().map(|n| n.id.as_str()).collect();

    for (path, entry) in &prev_manifest.files {
        if wanted.contains(path) || locked_files.contains(path) {
            continue;
        }
        let is_shared = entry.owner.starts_with("shared-");
        let removable = if full_sync {
            !is_shared || !active_ids.is_empty()
        } else {
            synced_owners.contains(&entry.owner)
        };
        if !removable {
            next_manifest.files.insert(path.clone(), entry.clone());
            continue;
        }
        if reconcile::plan_delete(host, path, force, Some(&entry.sha256), &mut plan.effects)? {
            plan.output.deleted.push(path.clone());
        } else {
            plan.output.warnings.push(format!(
                "{path}: leftover has local edits; kept (pass force to remove)."
            ));
            next_manifest.files.insert(path.clone(), entry.clone());
        }
    }
    Ok(())
}

fn sidecar_file(node_type: &str) -> Option<&'static str> {
    match node_type {
        "frame_animation" | "character_effect" => Some("animation.json"),
        "particle_effect" | "whole_map" | "scrolling_scene" | "scroll_map" => Some("main.json"),
        "scene3d_map" => Some("engine-scene.glb"),
        "model_3d" => Some("model.json"),
        "tilemap" => Some("tilemap.json"),
        "prop" => Some("props.json"),
        "ui" => Some("ui.json"),
        _ => None,
    }
}

fn sidecar_prefix<'a>(row: &'a LockedRow, file: &str) -> Result<&'a str, HostError> {
    let found = row.files.iter().find_map(|p| {
        if p == file {
            Some("")
        } else {
            p.strip_suffix(&format!("/{file}"))
        }
    });
    found.ok_or_else(|| invalid(format!("missing sidecar {file}")))
}

fn read_sidecar(host: &dyn Host, path: &str, allow_glb: bool) -> Result<Vec<u8>, HostError> {
    let bytes = host.read(path)?;
    let max = if allow_glb { MAX_GLB } else { MAX_SIDECAR };
    if bytes.len() > max {
        return Err(invalid(format!("{path} exceeds size limit")));
    }
    Ok(bytes)
}

fn load_textures<'a>(
    host: &dyn Platform,
    row: &LockedRow,
    directory: &str,
    prefix: &str,
    paths_iter: impl Iterator<Item = &'a str>,
    read_png_dims: bool,
) -> Result<BTreeMap<String, (u32, u32)>, HostError> {
    let locked: BTreeSet<&str> = row.files.iter().map(String::as_str).collect();
    let mut dims = BTreeMap::new();
    for rel in paths_iter {
        if dims.contains_key(rel) {
            continue;
        }
        paths::relative(rel)?;
        let full_locked = paths::join(prefix, rel);
        if !locked.contains(full_locked.as_str()) {
            return Err(invalid(format!("locked file {full_locked:?} is missing")));
        }
        let disk_path = paths::join(directory, &full_locked);
        let bytes = host.read(&disk_path)?;
        if read_png_dims {
            dims.insert(rel.to_owned(), png::dimensions(&bytes)?);
        } else {
            dims.insert(rel.to_owned(), (1, 1));
        }
    }
    Ok(dims)
}

fn selection(
    host: &dyn Platform,
    input: &Input,
    nodes: &[LockedRow],
    output: &mut Output,
) -> Result<BTreeSet<String>, HostError> {
    if input.nodes.is_empty() {
        return Ok(nodes.iter().map(|n| n.id.clone()).collect());
    }
    let mut selected = BTreeSet::new();
    for addr in &input.nodes {
        let info: NodeOutput = answer(host, Method::MirrorNode, &NodeInput { address: addr.clone() })?;
        if let Some(row) = nodes.iter().find(|r| r.id == info.node.id) {
            selected.insert(row.id.clone());
        } else {
            output.push_node(
                Node {
                    id: info.node.id.clone(),
                    number: info.node.number,
                    path: info.node.path.clone(),
                    node_type: info.node.node_type.clone(),
                    status: Status::Skipped,
                    files: Vec::new(),
                    main_prefab: None,
                    elements: Vec::new(),
                    reasons: vec![format!("{} has no ready export; run wf export first.", info.node.path)],
                },
                None,
            );
        }
    }
    Ok(selected)
}

fn ensure_not_locked(locks: &LocksOutput, directory: &str, path: &str) -> Result<(), HostError> {
    let conflict = locks
        .nodes
        .iter()
        .flat_map(|n| &n.files)
        .any(|f| paths::join(directory, f) == path);
    if conflict {
        return Err(invalid(format!("refusing to overwrite locked export file {path}")));
    }
    Ok(())
}

fn node_status(files: &[File]) -> Status {
    if files.iter().any(|f| f.status == Status::Kept) {
        Status::Kept
    } else if files.iter().all(|f| f.status == Status::Unchanged) {
        Status::Unchanged
    } else if files.iter().any(|f| f.status == Status::Updated) {
        Status::Updated
    } else {
        Status::Written
    }
}

fn answer<I: Serialize, O: DeserializeOwned>(host: &dyn Platform, method: Method, input: &I) -> Result<O, HostError> {
    let payload = serde_json::to_vec(input).map_err(|e| invalid(e.to_string()))?;
    let bytes = host.call(method.name(), &payload)?;
    serde_json::from_slice(&bytes).map_err(|e| invalid(e.to_string()))
}
