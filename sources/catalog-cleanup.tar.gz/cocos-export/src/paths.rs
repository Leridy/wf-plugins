//! Relative path validation and Cocos Creator 3.x project root resolution.
use plugin_api::Failure;
use plugin_guest::{Host, HostError};

pub fn invalid(message: impl Into<String>) -> HostError {
    HostError::new(Failure::InvalidInput, message)
}

pub fn relative(path: &str) -> Result<(), HostError> {
    if path.is_empty() || path.starts_with('/') || path.contains('\\') {
        return Err(invalid(format!("unsafe relative path {path:?}")));
    }
    for segment in path.split('/') {
        if segment.is_empty()
            || segment == "."
            || segment == ".."
            || matches!(segment, ".git" | "library" | "temp" | "local" | "build")
        {
            return Err(invalid(format!("unsafe relative path {path:?}")));
        }
    }
    Ok(())
}

pub fn join(base: &str, child: &str) -> String {
    let base = base.trim_matches('/');
    let child = child.trim_start_matches('/');
    if base.is_empty() {
        child.to_owned()
    } else if child.is_empty() {
        base.to_owned()
    } else {
        format!("{base}/{child}")
    }
}

pub fn stem_from_dir(dir: &str) -> String {
    dir.rsplit('/').find(|s| !s.is_empty()).unwrap_or("asset").to_owned()
}

pub fn root(host: &dyn Host, directory: &str) -> Result<String, HostError> {
    let mut candidate = directory.trim_end_matches('/').to_owned();
    loop {
        if is_cocos_root(host, &candidate) {
            return Ok(candidate);
        }
        if candidate.is_empty() {
            break;
        }
        candidate = candidate
            .rsplit_once('/')
            .map_or_else(String::new, |(parent, _)| parent.to_owned());
    }
    Err(invalid(
        "directory is not inside a Cocos Creator 3.x project (expected assets/ plus settings/, package.json, or project.json)",
    ))
}

fn is_cocos_root(host: &dyn Host, root: &str) -> bool {
    let has_assets = !host.list(&join(root, "assets/**")).is_empty();
    if !has_assets {
        return false;
    }
    !host.list(&join(root, "settings/**")).is_empty()
        || !host.list(&join(root, "package.json")).is_empty()
        || !host.list(&join(root, "project.json")).is_empty()
        || !host.list(&join(root, "tsconfig.json")).is_empty()
}

pub fn asset_path(root: &str, project_path: &str) -> String {
    let root = root.trim_matches('/');
    if root.is_empty() {
        project_path.to_owned()
    } else if let Some(rest) = project_path.strip_prefix(&format!("{root}/")) {
        rest.to_owned()
    } else {
        project_path.to_owned()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeSet;

    struct FakeHost(BTreeSet<String>);
    impl Host for FakeHost {
        fn list(&self, pattern: &str) -> Vec<String> {
            self.0
                .iter()
                .filter(|p| {
                    if let Some(prefix) = pattern.strip_suffix("/**") {
                        p.starts_with(&format!("{prefix}/"))
                    } else {
                        *p == pattern
                    }
                })
                .cloned()
                .collect()
        }
        fn read(&self, _: &str) -> Result<Vec<u8>, HostError> {
            Err(invalid("unused"))
        }
        fn warn(&self, _: &str) {}
    }

    #[test]
    fn root_requires_assets_and_cocos_marker() {
        let valid = FakeHost(
            ["client/package.json", "client/assets/wf/wf.lock.json"]
                .into_iter()
                .map(str::to_owned)
                .collect(),
        );
        assert_eq!(root(&valid, "client/assets/wf").unwrap(), "client");

        let only_assets = FakeHost(["assets/foo.png".to_owned()].into_iter().collect());
        assert!(root(&only_assets, "assets").is_err());
    }
}
