//! Capability description for `cocos-export`.
use crate::types::{Input, Output};
use plugin_api::{Capability, Description, Example, Risk};
use schemars::schema_for;

pub const OP: &str = "sync";

pub fn description() -> Description {
    Description {
        capabilities: vec![Capability {
            op: OP.into(),
            summary: "Convert exported WeaveForge assets into Cocos Creator 3.x .meta, Prefabs, AnimationClips, and runtimes".into(),
            when: "The project is a Cocos Creator 3.x workspace and ready wf exports should become native Cocos assets, prefabs, clips, or maps.".into(),
            risk: Risk::Write,
            input: serde_json::to_value(schema_for!(Input)).expect("input schema"),
            output: Some(serde_json::to_value(schema_for!(Output)).expect("output schema")),
            examples: vec![
                Example {
                    args: "sync".into(),
                    note: "Convert every exported node in the workspace mirror into Cocos assets and prefabs.".into(),
                },
                Example {
                    args: "sync --nodes #12 --force".into(),
                    note: "Re-export node #12 and overwrite locally modified generated files.".into(),
                },
            ],
            implements: None,
        }],
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn one_write_capability_with_strict_typed_input() {
        let desc = description();
        assert_eq!(desc.capabilities.len(), 1);
        let cap = &desc.capabilities[0];
        assert_eq!(cap.op, "sync");
        assert_eq!(cap.risk, Risk::Write);
        assert!(cap.output.is_some());
        assert_eq!(cap.input["additionalProperties"], serde_json::Value::Bool(false));
    }
}
