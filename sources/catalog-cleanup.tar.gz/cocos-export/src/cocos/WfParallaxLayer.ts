import { _decorator, Component, Node, Vec3 } from "cc";

const { ccclass, property } = _decorator;

@ccclass("WfParallaxLayer")
export class WfParallaxLayer extends Component {
  @property
  parallaxSpeed = 1;

  @property
  driftSpeed = 0;

  @property
  bobAmplitude = 0;

  @property
  bobPeriod = 2;

  @property
  swayDegrees = 0;

  @property
  swayPeriod = 2;

  @property
  repeatSpan = 0;

  @property({ type: Node })
  cameraTarget: Node | null = null;

  private originPos = new Vec3();
  private originCamX = 0;
  private elapsed = 0;

  onLoad(): void {
    this.originPos.set(this.node.position);
    if (this.cameraTarget) {
      this.originCamX = this.cameraTarget.worldPosition.x;
    }
  }

  update(dt: number): void {
    this.elapsed += dt;
    const camDx = this.cameraTarget ? this.cameraTarget.worldPosition.x - this.originCamX : 0;
    let x = this.originPos.x + camDx * (1 - this.parallaxSpeed) + this.driftSpeed * this.elapsed;
    if (this.repeatSpan > 0) {
      const offset = ((x - this.originPos.x) % this.repeatSpan + this.repeatSpan) % this.repeatSpan;
      x = this.originPos.x + offset;
    }
    const bob =
      this.bobAmplitude !== 0 && this.bobPeriod > 0
        ? Math.sin((this.elapsed / this.bobPeriod) * Math.PI * 2) * this.bobAmplitude
        : 0;
    this.node.setPosition(x, this.originPos.y + bob, this.originPos.z);

    if (this.swayDegrees !== 0 && this.swayPeriod > 0) {
      const deg = Math.sin((this.elapsed / this.swayPeriod) * Math.PI * 2) * this.swayDegrees;
      this.node.setRotationFromEuler(0, 0, deg);
    }
  }
}
