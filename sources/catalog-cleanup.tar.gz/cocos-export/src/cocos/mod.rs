//! Cocos Creator 3.x asset metadata, typed schema/prefab serialization, and converter modules.
pub mod animation;
pub mod parallax;
pub mod particle;
pub mod prefab;
pub mod prop;
pub mod schema;
pub mod spatial;
pub mod texture;
pub mod tilemap;
pub mod ui;
pub mod uuid;
pub mod whole_map;

use crate::{paths, reconcile::StampKind, types::Element};
use schema::{AssetMeta, EmptyObj, GltfSubMetas, SubMeta, serialize_pretty};

pub use prefab::{BuiltinComponent, PrefabBuilder, ScriptBody};
pub use schema::NodeRef;

#[derive(Clone, Debug)]
pub struct Document {
    pub rel_path: String,
    pub resource: String,
    pub body: String,
    pub stamp: StampKind,
}

#[derive(Clone, Copy)]
pub struct ExportTarget<'a> {
    pub node_prefix: &'a str,
    pub node_dir: &'a str,
    pub directory: &'a str,
    pub root: &'a str,
}

#[derive(Default)]
pub struct Exported {
    pub documents: Vec<Document>,
    pub elements: Vec<Element>,
    pub notes: Vec<String>,
}

pub fn doc(directory: &str, root: &str, rel_path: String, body: String, stamp: StampKind) -> Document {
    let project_rel = paths::join(directory, &rel_path);
    let resource = paths::asset_path(root, &project_rel);
    Document {
        rel_path,
        resource,
        body,
        stamp,
    }
}

pub fn join_rel(prefix: &str, path: &str) -> String {
    if prefix.is_empty() {
        path.to_owned()
    } else if path.is_empty() {
        prefix.to_owned()
    } else {
        format!("{prefix}/{path}")
    }
}

pub fn rel_prefix<'a>(node_dir: &'a str, directory: &'a str) -> &'a str {
    if directory.is_empty() {
        node_dir
    } else if node_dir == directory {
        ""
    } else {
        node_dir.strip_prefix(&format!("{directory}/")).unwrap_or(node_dir)
    }
}

pub fn simple_meta(uuid_str: &str, importer: &str, ver: &str) -> String {
    serialize_pretty(&AssetMeta {
        ver,
        importer,
        imported: true,
        uuid: uuid_str,
        files: vec![".json"],
        sub_metas: EmptyObj {},
        user_data: EmptyObj {},
    })
}

pub fn prefab_meta(uuid_str: &str) -> String {
    simple_meta(uuid_str, "prefab", "1.3.12")
}

pub fn script_meta(uuid_str: &str) -> String {
    simple_meta(uuid_str, "typescript", "4.0.10")
}

pub fn effect_meta(uuid_str: &str) -> String {
    simple_meta(uuid_str, "effect", "1.0.18")
}

pub fn material_meta(uuid_str: &str) -> String {
    simple_meta(uuid_str, "material", "1.0.21")
}

pub fn anim_meta(uuid_str: &str) -> String {
    simple_meta(uuid_str, "animation-clip", "1.0.16")
}

pub fn tmx_meta(uuid_str: &str) -> String {
    simple_meta(uuid_str, "tiled-map", "1.0.9")
}

pub fn gltf_meta(uuid_str: &str, sub_prefab_uuid: &str) -> String {
    serialize_pretty(&AssetMeta {
        ver: "1.2.15",
        importer: "gltf-scene",
        imported: true,
        uuid: uuid_str,
        files: vec![".json"],
        sub_metas: GltfSubMetas {
            prefab: SubMeta {
                importer: "gltf-prefab",
                uuid: sub_prefab_uuid.to_owned(),
                display_name: "Scene",
                id: "prefab",
                name: "Scene.prefab",
                user_data: EmptyObj {},
            },
        },
        user_data: EmptyObj {},
    })
}
