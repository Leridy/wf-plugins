//! `whole_map` -> shared `WfWholeMapNav.ts`, `WfYSortContainer.ts`, `wf-whole-map-tile.effect`,
//! per-masked-tile `.mtl`, `.png.meta`, and `<stem>.prefab`.
use super::prefab::{BuiltinComponent, PolygonCollider2DBody, PrefabBuilder, ScriptBody, WfWholeMapNavFields};
use super::schema::{CcVec4, EmptyObj, MaterialAsset, NodeRef, UuidRef, WholeMapMaterialProps, serialize_pretty};
use super::texture::{FilterMode, ResolvedSprites, SliceSpec, SpriteKey, TextureRegistry};
use super::tilemap::poly_to_cc_vec2;
use super::uuid::{compress_uuid, uuid};
use super::{
    Document, ExportTarget, Exported, StampKind, doc, effect_meta, join_rel, material_meta, prefab_meta, rel_prefix,
    script_meta,
};
use crate::model::whole_map::{CellRect, ConnectionKind, SortMode, WholeMap};
use serde::Serialize;
use std::collections::BTreeMap;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct WholeMapNavConfig<'a> {
    perspective: &'a str,
    tile_width: i64,
    tile_height: i64,
    character_radius: i64,
    character_speed: i64,
    walkable_rects: Vec<NavRectDto>,
    connections: Vec<NavConnDto<'a>>,
}

#[derive(Serialize)]
struct NavRectDto {
    x: i64,
    y: i64,
    width: i64,
    height: i64,
}

#[derive(Serialize)]
struct NavConnDto<'a> {
    id: &'a str,
    kind: &'static str,
    from: &'a str,
    to: &'a str,
    a: NavPointDto,
    b: NavPointDto,
}

#[derive(Serialize)]
struct NavPointDto {
    x: f64,
    y: f64,
}

pub const SHARED_OWNER_ID: &str = "shared-whole-map-runtime";
const NAV_SCRIPT_PATH: &str = "Scripts/WfWholeMapNav.ts";
const NAV_SCRIPT_META_PATH: &str = "Scripts/WfWholeMapNav.ts.meta";
const YSORT_SCRIPT_PATH: &str = "Scripts/WfYSortContainer.ts";
const YSORT_SCRIPT_META_PATH: &str = "Scripts/WfYSortContainer.ts.meta";
const EFFECT_PATH: &str = "Shaders/wf-whole-map-tile.effect";
const EFFECT_META_PATH: &str = "Shaders/wf-whole-map-tile.effect.meta";

const NAV_TS_SOURCE: &str = include_str!("WfWholeMapNav.ts");
const YSORT_TS_SOURCE: &str = include_str!("WfYSortContainer.ts");
const EFFECT_SOURCE: &str = include_str!("wf-whole-map-tile.effect");

pub fn shared_runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let nav_uuid = uuid("shared:WfWholeMapNav.ts");
    let ysort_uuid = uuid("shared:WfYSortContainer.ts");
    let eff_uuid = uuid("shared:wf-whole-map-tile.effect");
    vec![
        doc(
            directory,
            root,
            NAV_SCRIPT_PATH.into(),
            NAV_TS_SOURCE.into(),
            StampKind::SlashLine,
        ),
        doc(
            directory,
            root,
            NAV_SCRIPT_META_PATH.into(),
            script_meta(&nav_uuid),
            StampKind::None,
        ),
        doc(
            directory,
            root,
            YSORT_SCRIPT_PATH.into(),
            YSORT_TS_SOURCE.into(),
            StampKind::SlashLine,
        ),
        doc(
            directory,
            root,
            YSORT_SCRIPT_META_PATH.into(),
            script_meta(&ysort_uuid),
            StampKind::None,
        ),
        doc(
            directory,
            root,
            EFFECT_PATH.into(),
            EFFECT_SOURCE.into(),
            StampKind::SlashLine,
        ),
        doc(
            directory,
            root,
            EFFECT_META_PATH.into(),
            effect_meta(&eff_uuid),
            StampKind::None,
        ),
    ]
}

pub fn generate(
    map: &WholeMap,
    target: ExportTarget<'_>,
    stem: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
) -> Exported {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let mut tile_keys = Vec::with_capacity(map.tiles.len());
    let mut mask_keys = Vec::with_capacity(map.tiles.len());
    for tile in &map.tiles {
        tile_keys.push(registry.register(
            &tile.base_file,
            &format!("tile_{}_{}", tile.grid_x, tile.grid_y),
            SliceSpec {
                rect: None,
                pivot: [0.0, 1.0],
                border: [0.0; 4],
                ppu: 100.0,
                filter: FilterMode::Bilinear,
            },
        ));
        mask_keys.push(tile.mask_file.as_deref().map(|mask| {
            registry.register(
                mask,
                &format!("mask_{}_{}", tile.grid_x, tile.grid_y),
                SliceSpec {
                    rect: None,
                    pivot: [0.0, 1.0],
                    border: [0.0; 4],
                    ppu: 100.0,
                    filter: FilterMode::Point,
                },
            )
        }));
    }

    let mut part_keys = Vec::with_capacity(map.parts.len());
    for part in &map.parts {
        let (pw, ph) = dims.get(&part.texture_file).copied().unwrap_or((1, 1));
        let px = ((part.foot.x - part.x) / f64::from(pw.max(1))).clamp(0.0, 1.0);
        let py = (1.0 - (part.foot.y - part.y) / f64::from(ph.max(1))).clamp(0.0, 1.0);
        part_keys.push(registry.register(
            &part.texture_file,
            &part.id,
            SliceSpec {
                rect: None,
                pivot: [px, py],
                border: [0.0; 4],
                ppu: 100.0,
                filter: FilterMode::Bilinear,
            },
        ));
    }

    let (resolved, mut documents) = registry.build(target);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let tile_materials = build_tile_materials(map, target, stem, dir_rel_prefix, &resolved, &mask_keys, &mut documents);

    let prefab_body = build_prefab(
        map,
        target.node_prefix,
        display_name,
        dims,
        &resolved,
        &tile_keys,
        &part_keys,
        &tile_materials,
    );
    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let p_uuid = uuid(&format!("{}:wm:prefab:{stem}", target.node_prefix));
    documents.push(doc(
        target.directory,
        target.root,
        prefab_rel.clone(),
        prefab_body,
        StampKind::None,
    ));
    documents.push(doc(
        target.directory,
        target.root,
        format!("{prefab_rel}.meta"),
        prefab_meta(&p_uuid),
        StampKind::None,
    ));

    Exported {
        documents,
        elements: Vec::new(),
        notes: Vec::new(),
    }
}

fn build_tile_materials(
    map: &WholeMap,
    target: ExportTarget<'_>,
    stem: &str,
    dir_rel_prefix: &str,
    resolved: &ResolvedSprites,
    mask_keys: &[Option<SpriteKey>],
    documents: &mut Vec<Document>,
) -> Vec<Option<String>> {
    let eff_uuid = uuid("shared:wf-whole-map-tile.effect");
    let mut tile_materials = Vec::with_capacity(map.tiles.len());
    for (idx, tile) in map.tiles.iter().enumerate() {
        let Some(mkey) = &mask_keys[idx] else {
            tile_materials.push(None);
            continue;
        };
        let mask_tex_uuid = resolved.texture_uuid(&mkey.tex_path);
        let tw = f64::from(i32::try_from(tile.width.max(1)).unwrap_or(i32::MAX));
        let th = f64::from(i32::try_from(tile.height.max(1)).unwrap_or(i32::MAX));
        let mat_json = serialize_pretty(&MaterialAsset {
            kind: "cc.Material",
            name: format!("{stem}_Tile_{}_{}", tile.grid_x, tile.grid_y),
            effect_asset: UuidRef::new(&eff_uuid),
            tech_idx: 0,
            defines: vec![EmptyObj {}],
            states: vec![EmptyObj {}],
            props: vec![WholeMapMaterialProps {
                mask_texture: UuidRef::new(mask_tex_uuid),
                texel_size: CcVec4::new(1.0 / tw, 1.0 / th, tw, th),
            }],
        });
        let mat_rel = join_rel(
            dir_rel_prefix,
            &format!("{stem}_Tile_{}_{}.mtl", tile.grid_x, tile.grid_y),
        );
        let mat_uuid = uuid(&format!("{}:wm:mtl:{}", target.node_prefix, tile.key));
        documents.push(doc(
            target.directory,
            target.root,
            mat_rel.clone(),
            mat_json,
            StampKind::None,
        ));
        documents.push(doc(
            target.directory,
            target.root,
            format!("{mat_rel}.meta"),
            material_meta(&mat_uuid),
            StampKind::None,
        ));
        tile_materials.push(Some(mat_uuid));
    }
    tile_materials
}

#[allow(clippy::too_many_arguments)]
fn build_prefab(
    map: &WholeMap,
    node_prefix: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
    resolved: &ResolvedSprites,
    tile_keys: &[SpriteKey],
    part_keys: &[SpriteKey],
    tile_materials: &[Option<String>],
) -> String {
    let (mut pb, root) = PrefabBuilder::new(&format!("{node_prefix}:wm"), display_name);
    pb.add_ui_transform(root, 1.0, 1.0, [0.5, 0.5]);
    attach_nav_component(&mut pb, root, map);
    attach_tiles(&mut pb, root, map, dims, resolved, tile_keys, tile_materials);
    attach_parts(&mut pb, root, map, dims, resolved, part_keys);
    attach_collisions_and_regions(&mut pb, root, map);
    pb.build()
}

fn attach_nav_component(pb: &mut PrefabBuilder, root: NodeRef, map: &WholeMap) {
    let mut rects: Vec<&CellRect> = map.nav_layers.iter().flat_map(|l| l.walkable_rects.iter()).collect();
    for p in &map.parts {
        rects.extend(p.walkable_rects.iter());
    }
    let nav_json = serde_json::to_string(&WholeMapNavConfig {
        perspective: &map.perspective,
        tile_width: map.tile_width,
        tile_height: map.tile_height,
        character_radius: map.character.radius,
        character_speed: map.character.speed,
        walkable_rects: rects
            .iter()
            .map(|r| NavRectDto {
                x: r.x,
                y: r.y,
                width: r.width,
                height: r.height,
            })
            .collect(),
        connections: map
            .connections
            .iter()
            .map(|c| NavConnDto {
                id: &c.id,
                kind: match c.kind {
                    ConnectionKind::Stairs => "stairs",
                    ConnectionKind::Ramp => "ramp",
                },
                from: &c.from,
                to: &c.to,
                a: NavPointDto { x: c.a.x, y: c.a.y },
                b: NavPointDto { x: c.b.x, y: c.b.y },
            })
            .collect(),
    })
    .expect("nav json");
    let nav_type = compress_uuid(&uuid("shared:WfWholeMapNav.ts"));
    pb.add_script(
        root,
        nav_type,
        ScriptBody::WholeMapNav(WfWholeMapNavFields { nav_json }),
    );
}

fn attach_tiles(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    map: &WholeMap,
    dims: &BTreeMap<String, (u32, u32)>,
    resolved: &ResolvedSprites,
    tile_keys: &[SpriteKey],
    tile_materials: &[Option<String>],
) {
    let ground = pb.add_node(root, "Ground", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    for (i, tile) in map.tiles.iter().enumerate() {
        let _ = dims.get(&tile.base_file);
        let tw = f64::from(i32::try_from(tile.width.max(1)).unwrap_or(1));
        let th = f64::from(i32::try_from(tile.height.max(1)).unwrap_or(1));
        let tx = f64::from(i32::try_from(tile.x).unwrap_or(0));
        let ty = f64::from(i32::try_from(tile.y).unwrap_or(0));
        let node = pb.add_node(
            ground,
            &format!("Tile_{}_{}", tile.grid_x, tile.grid_y),
            [tx, -ty, 0.0],
            [1.0, 1.0, 1.0],
            true,
        );
        pb.add_ui_transform(node, tw, th, [0.0, 1.0]);
        let sf = resolved.sprite_frame_uuid(&tile_keys[i]);
        pb.add_sprite(
            node,
            Some(&sf),
            0,
            0,
            [255, 255, 255, 255],
            tile_materials[i].as_deref(),
        );
    }
}

fn attach_parts(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    map: &WholeMap,
    dims: &BTreeMap<String, (u32, u32)>,
    resolved: &ResolvedSprites,
    part_keys: &[SpriteKey],
) {
    let below = pb.add_node(root, "Below", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    let sorted = pb.add_node(root, "Sorted", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    let ysort_type = compress_uuid(&uuid("shared:WfYSortContainer.ts"));
    pb.add_script(sorted, ysort_type, ScriptBody::YSort(EmptyObj {}));
    let above = pb.add_node(root, "Above", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);

    for (i, part) in map.parts.iter().enumerate() {
        let parent = match part.sort_mode {
            SortMode::Below => below,
            SortMode::Sorted => sorted,
            SortMode::Above => above,
        };
        let (pw, ph) = dims.get(&part.texture_file).copied().unwrap_or((1, 1));
        let px = ((part.foot.x - part.x) / f64::from(pw.max(1))).clamp(0.0, 1.0);
        let py = (1.0 - (part.foot.y - part.y) / f64::from(ph.max(1))).clamp(0.0, 1.0);
        let node = pb.add_node(
            parent,
            &part.name,
            [part.foot.x, -part.foot.y, 0.0],
            [1.0, 1.0, 1.0],
            true,
        );
        pb.add_ui_transform(node, f64::from(pw.max(1)), f64::from(ph.max(1)), [px, py]);
        let sf = resolved.sprite_frame_uuid(&part_keys[i]);
        pb.add_sprite(node, Some(&sf), 0, 0, [255, 255, 255, 255], None);
    }
}

fn attach_collisions_and_regions(pb: &mut PrefabBuilder, root: NodeRef, map: &WholeMap) {
    let col = pb.add_node(root, "Collision", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    for (pi, part) in map.parts.iter().filter(|p| p.blocking).enumerate() {
        for poly in part.footprints.iter().filter(|p| p.len() >= 3) {
            pb.add_component(
                col,
                BuiltinComponent::PolygonCollider2D(PolygonCollider2DBody {
                    tag: Some(pi),
                    sensor: false,
                    points: poly_to_cc_vec2(poly),
                }),
            );
        }
    }

    let regions = pb.add_node(root, "Regions", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    for (ri, region) in map.regions.iter().enumerate() {
        if region.polygon.len() < 3 {
            continue;
        }
        let rnode = pb.add_node(
            regions,
            &format!("Water_{}", region.id),
            [0.0, 0.0, 0.0],
            [1.0, 1.0, 1.0],
            true,
        );
        pb.add_component(
            rnode,
            BuiltinComponent::PolygonCollider2D(PolygonCollider2DBody {
                tag: Some(ri),
                sensor: true,
                points: poly_to_cc_vec2(&region.polygon),
            }),
        );
    }
}
