//! `particle_effect` -> shared `WfParticleSim.ts` + `WfParticlePlayer.ts`, `.png.meta`, and `<stem>.prefab`.
use super::prefab::{PrefabBuilder, ScriptBody, WfParticlePlayerFields};
use super::schema::UuidRef;
use super::texture::{FilterMode, SliceSpec, TextureRegistry};
use super::uuid::{compress_uuid, uuid};
use super::{Document, ExportTarget, Exported, StampKind, doc, join_rel, prefab_meta, rel_prefix, script_meta};
use crate::model::{Blend, ParticleEffect, Space, particle::Emitter};
use serde::Serialize;
use std::collections::BTreeMap;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ParticleEffectConfig<'a> {
    seed: u32,
    duration: f64,
    looping: bool,
    space: &'static str,
    emitters: Vec<EmitterConfig<'a>>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct EmitterConfig<'a> {
    id: &'a str,
    random_state: u32,
    enabled: bool,
    rate: f64,
    burst: u32,
    delay: f64,
    lifetime: [f64; 2],
    position: [f64; 3],
    spread: [f64; 3],
    velocity: [f64; 3],
    velocity_spread: [f64; 3],
    gravity: [f64; 3],
    drag: f64,
    size: &'a [f64],
    opacity: &'a [f64],
    color: &'a [String],
    blend: &'static str,
    orientation: &'a str,
    sprite: bool,
    sprite_index: usize,
    tilt: f64,
    flip: bool,
    size_jitter: f64,
    stretch: f64,
    max_particles: u32,
    triggers: Vec<TriggerConfig<'a>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    radial: Option<RadialConfig>,
    #[serde(skip_serializing_if = "Option::is_none")]
    ground: Option<GroundConfig>,
}

#[derive(Serialize)]
struct TriggerConfig<'a> {
    on: &'a str,
    emitter: &'a str,
    count: u32,
    inherit: f64,
}

#[derive(Serialize)]
struct RadialConfig {
    speed: [f64; 2],
    radius: [f64; 2],
    cone: f64,
}

#[derive(Serialize)]
struct GroundConfig {
    bounce: f64,
    friction: f64,
    kill: bool,
}

pub const SHARED_OWNER_ID: &str = "shared-particle-runtime";
const SIM_SCRIPT_PATH: &str = "Scripts/WfParticleSim.ts";
const SIM_SCRIPT_META_PATH: &str = "Scripts/WfParticleSim.ts.meta";
const PLAYER_SCRIPT_PATH: &str = "Scripts/WfParticlePlayer.ts";
const PLAYER_SCRIPT_META_PATH: &str = "Scripts/WfParticlePlayer.ts.meta";
const SIM_TS_SOURCE: &str = include_str!("WfParticleSim.ts");
const PLAYER_TS_SOURCE: &str = include_str!("WfParticlePlayer.ts");

pub fn shared_runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let sim_uuid = uuid("shared:WfParticleSim.ts");
    let player_uuid = uuid("shared:WfParticlePlayer.ts");
    vec![
        doc(
            directory,
            root,
            SIM_SCRIPT_PATH.into(),
            SIM_TS_SOURCE.into(),
            StampKind::SlashLine,
        ),
        doc(
            directory,
            root,
            SIM_SCRIPT_META_PATH.into(),
            script_meta(&sim_uuid),
            StampKind::None,
        ),
        doc(
            directory,
            root,
            PLAYER_SCRIPT_PATH.into(),
            PLAYER_TS_SOURCE.into(),
            StampKind::SlashLine,
        ),
        doc(
            directory,
            root,
            PLAYER_SCRIPT_META_PATH.into(),
            script_meta(&player_uuid),
            StampKind::None,
        ),
    ]
}

pub fn generate(
    effect: &ParticleEffect,
    target: ExportTarget<'_>,
    stem: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
) -> Exported {
    let mut notes = effect.notes.clone();
    if effect.space == Space::Spatial {
        notes.push(format!(
            "{display_name}: spatial 3D depth uses Z offsets on child nodes; attach 3D billboards if rotating the camera."
        ));
    }

    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let mut pic_keys = BTreeMap::new();
    let mut sprite_frames = Vec::new();
    for (ei, emitter) in effect.emitters.iter().enumerate() {
        if !pic_keys.contains_key(&emitter.picture) {
            let key = registry.register(
                &emitter.picture,
                &format!("particle_{ei}"),
                SliceSpec {
                    rect: None,
                    pivot: [0.5, 0.5],
                    border: [0.0; 4],
                    ppu: 100.0,
                    filter: FilterMode::Bilinear,
                },
            );
            pic_keys.insert(emitter.picture.clone(), sprite_frames.len());
            sprite_frames.push(key);
        }
    }

    let (resolved, mut documents) = registry.build(target);
    let sf_refs: Vec<UuidRef> = sprite_frames
        .iter()
        .map(|k| UuidRef::new(resolved.sprite_frame_uuid(k)))
        .collect();

    let emitters_cfg: Vec<EmitterConfig<'_>> = effect
        .emitters
        .iter()
        .map(|e| emitter_to_config(e, pic_keys[&e.picture]))
        .collect();

    let config_json = serde_json::to_string(&ParticleEffectConfig {
        seed: 0,
        duration: effect.duration,
        looping: effect.looping,
        space: match effect.space {
            Space::Planar => "planar",
            Space::Spatial => "spatial",
        },
        emitters: emitters_cfg,
    })
    .expect("particle config json");

    let player_type = compress_uuid(&uuid("shared:WfParticlePlayer.ts"));
    let (mut pb, root) = PrefabBuilder::new(&format!("{}:fx", target.node_prefix), display_name);
    pb.add_ui_transform(root, 128.0, 128.0, [0.5, 0.5]);
    pb.add_script(
        root,
        player_type,
        ScriptBody::Particle(WfParticlePlayerFields {
            config_json,
            sprite_frames: sf_refs,
            pixels_per_unit: 100,
        }),
    );

    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let p_uuid = uuid(&format!("{}:fx:prefab:{stem}", target.node_prefix));
    documents.push(doc(
        target.directory,
        target.root,
        prefab_rel.clone(),
        pb.build(),
        StampKind::None,
    ));
    documents.push(doc(
        target.directory,
        target.root,
        format!("{prefab_rel}.meta"),
        prefab_meta(&p_uuid),
        StampKind::None,
    ));

    Exported {
        documents,
        elements: Vec::new(),
        notes,
    }
}

fn emitter_to_config(e: &Emitter, sprite_index: usize) -> EmitterConfig<'_> {
    EmitterConfig {
        id: &e.id,
        random_state: e.random_state,
        enabled: true,
        rate: e.rate,
        burst: e.burst,
        delay: e.delay,
        lifetime: e.lifetime,
        position: e.position,
        spread: e.spread,
        velocity: e.velocity,
        velocity_spread: e.velocity_spread,
        gravity: e.gravity,
        drag: e.drag,
        size: &e.size,
        opacity: &e.opacity,
        color: &e.color,
        blend: match e.blend {
            Blend::Normal => "normal",
            Blend::Additive => "additive",
        },
        orientation: e.orientation.as_str(),
        sprite: e.sprite,
        sprite_index,
        tilt: e.tilt,
        flip: e.flip,
        size_jitter: e.size_jitter,
        stretch: e.stretch,
        max_particles: e.max_particles,
        triggers: e
            .triggers
            .iter()
            .map(|t| TriggerConfig {
                on: t.on.as_str(),
                emitter: &t.emitter,
                count: t.count,
                inherit: t.inherit,
            })
            .collect(),
        radial: e.radial.as_ref().map(|rad| RadialConfig {
            speed: rad.speed,
            radius: rad.radius,
            cone: rad.cone,
        }),
        ground: e.ground.as_ref().map(|gr| GroundConfig {
            bounce: gr.bounce,
            friction: gr.friction,
            kill: gr.kill,
        }),
    }
}
