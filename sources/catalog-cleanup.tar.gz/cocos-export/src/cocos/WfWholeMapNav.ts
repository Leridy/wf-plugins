import { _decorator, Component } from "cc";

const { ccclass, property } = _decorator;

export interface WfNavRect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface WfNavConnection {
  id: string;
  kind: "stairs" | "ramp";
  from: string;
  to: string;
  a: { x: number; y: number };
  b: { x: number; y: number };
}

export interface WfWholeMapNavData {
  perspective: string;
  tileWidth: number;
  tileHeight: number;
  characterRadius: number;
  characterSpeed: number;
  walkableRects: WfNavRect[];
  connections: WfNavConnection[];
}

@ccclass("WfWholeMapNav")
export class WfWholeMapNav extends Component {
  @property
  navJson = "{}";

  private parsed: WfWholeMapNavData | null = null;

  getData(): WfWholeMapNavData {
    if (!this.parsed) {
      this.parsed = JSON.parse(this.navJson) as WfWholeMapNavData;
    }
    return this.parsed;
  }

  /** Test a map-space coordinate (Y-down image pixel coordinates) against walkable cells. */
  isWalkable(px: number, py: number): boolean {
    for (const r of this.getData().walkableRects ?? []) {
      if (px >= r.x && px < r.x + r.width && py >= r.y && py < r.y + r.height) {
        return true;
      }
    }
    return false;
  }
}
