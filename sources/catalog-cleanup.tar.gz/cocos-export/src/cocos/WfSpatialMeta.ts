import { _decorator, Component } from "cc";

const { ccclass, property } = _decorator;

@ccclass("WfSpatialMeta")
export class WfSpatialMeta extends Component {
  @property
  kind = "";

  @property
  glbPath = "";

  @property
  height = 0;

  @property
  bottom = 0;

  @property
  metaJson = "{}";
}
