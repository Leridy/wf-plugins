import { _decorator, Component } from "cc";

const { ccclass } = _decorator;

/** Keeps child sprites sorted back-to-front by Cocos Y-up position (lower Y renders on top). */
@ccclass("WfYSortContainer")
export class WfYSortContainer extends Component {
  lateUpdate(): void {
    const children = this.node.children;
    if (children.length < 2) return;
    const sorted = [...children].sort((a, b) => b.position.y - a.position.y);
    for (let i = 0; i < sorted.length; i++) {
      if (sorted[i].getSiblingIndex() !== i) {
        sorted[i].setSiblingIndex(i);
      }
    }
  }
}
