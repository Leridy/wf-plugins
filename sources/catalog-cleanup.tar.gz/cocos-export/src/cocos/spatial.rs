//! `model_3d` and `scene3d_map` -> `.glb.meta`, shared `WfSpatialMeta.ts`, and
//! native Cocos 3D Prefabs with `cc.BoxCollider`, `cc.CapsuleCollider`, `SOCKET_*` nodes, and `Roles`.
use super::prefab::{BoxColliderBody, CapsuleColliderBody, WfSpatialMetaFields};
use super::schema::CcVec3;
use super::uuid::{compress_uuid, uuid};
use super::{
    BuiltinComponent, Document, ExportTarget, Exported, NodeRef, PrefabBuilder, ScriptBody, StampKind, doc, gltf_meta,
    join_rel, prefab_meta, rel_prefix, script_meta,
};
use crate::model::spatial::{Collider3d, Model3d, Scene3dMap};
use crate::paths::{asset_path, join};
use serde::Serialize;
use std::collections::{BTreeMap, BTreeSet};

pub const SHARED_OWNER_ID: &str = "shared-spatial-runtime";
const META_SCRIPT_PATH: &str = "Scripts/WfSpatialMeta.ts";
const META_SCRIPT_META_PATH: &str = "Scripts/WfSpatialMeta.ts.meta";
const META_TS_SOURCE: &str = include_str!("WfSpatialMeta.ts");

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ModelMetaJson<'a> {
    glb_prefab: &'a str,
    bones: &'a BTreeMap<String, String>,
    clips: Vec<ModelClipMetaJson<'a>>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ModelClipMetaJson<'a> {
    name: &'a str,
    duration: f64,
    loops: bool,
    travel: [f64; 3],
    sole_low: f64,
    sole_high: f64,
    liftoffs: u32,
    checks: &'a [String],
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct SceneMetaJson<'a> {
    glb_prefab: &'a str,
    blocked_doors: &'a [String],
    environment: SceneEnvMetaJson,
    roles: Vec<SceneRoleMetaJson<'a>>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct SceneEnvMetaJson {
    ambient_color: Option<[f64; 3]>,
    ambient_intensity: f64,
    fog_color: Option<[f64; 3]>,
    fog_density: f64,
    fog_near: Option<f64>,
    fog_far: Option<f64>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct SceneRoleMetaJson<'a> {
    role: &'a str,
    id: Option<&'a str>,
    node: Option<&'a str>,
    position: [f64; 3],
    forward: [f64; 3],
    blocked: bool,
}

pub fn shared_runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let cs_uuid = uuid("shared:WfSpatialMeta.ts");
    vec![
        doc(
            directory,
            root,
            META_SCRIPT_PATH.into(),
            META_TS_SOURCE.into(),
            StampKind::SlashLine,
        ),
        doc(
            directory,
            root,
            META_SCRIPT_META_PATH.into(),
            script_meta(&cs_uuid),
            StampKind::None,
        ),
    ]
}

pub fn model3d(model: &Model3d, target: ExportTarget<'_>, stem: &str, display_name: &str) -> Exported {
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let glb_rel = join_rel(dir_rel_prefix, &model.glb_file);
    let glb_asset = asset_path(target.root, &join(target.directory, &glb_rel));
    let glb_uuid = uuid(&format!("{}:glb:{}", target.node_prefix, model.glb_file));
    let sub_prefab_uuid = format!("{glb_uuid}@prefab");

    let (mut pb, root) = PrefabBuilder::new(&format!("{}:m3d", target.node_prefix), display_name);
    match model.collider {
        Collider3d::Capsule { radius, height, center } => {
            pb.add_component(
                root,
                BuiltinComponent::CapsuleCollider(CapsuleColliderBody {
                    center: CcVec3::exact(center[0], center[1], center[2]),
                    radius,
                    cylinder_height: (height - radius * 2.0).max(0.0),
                    is_trigger: false,
                }),
            );
        }
        Collider3d::Box { size, center } => {
            add_box_collider(&mut pb, root, center, size, false);
        }
    }

    let meta_type = compress_uuid(&uuid("shared:WfSpatialMeta.ts"));
    let meta = ModelMetaJson {
        glb_prefab: &sub_prefab_uuid,
        bones: &model.bones,
        clips: model
            .clips
            .iter()
            .map(|c| ModelClipMetaJson {
                name: &c.name,
                duration: c.duration,
                loops: c.loops.unwrap_or(false),
                travel: c.travel.unwrap_or([0.0; 3]),
                sole_low: c.sole_low.unwrap_or(0.0),
                sole_high: c.sole_high.unwrap_or(0.0),
                liftoffs: c.liftoffs.unwrap_or(0),
                checks: &c.checks,
            })
            .collect(),
    };
    let meta_json = serde_json::to_string(&meta).expect("valid model3d meta json");
    pb.add_script(
        root,
        meta_type,
        ScriptBody::SpatialMeta(WfSpatialMetaFields {
            kind: "model_3d",
            glb_path: glb_asset,
            height: model.height,
            bottom: model.bottom,
            meta_json,
        }),
    );

    for s in &model.sockets {
        pb.add_node(root, &s.name, s.position, [1.0, 1.0, 1.0], true);
    }

    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let p_uuid = uuid(&format!("{}:m3d:prefab:{stem}", target.node_prefix));
    let documents = vec![
        doc(
            target.directory,
            target.root,
            format!("{glb_rel}.meta"),
            gltf_meta(&glb_uuid, &sub_prefab_uuid),
            StampKind::None,
        ),
        doc(
            target.directory,
            target.root,
            prefab_rel.clone(),
            pb.build(),
            StampKind::None,
        ),
        doc(
            target.directory,
            target.root,
            format!("{prefab_rel}.meta"),
            prefab_meta(&p_uuid),
            StampKind::None,
        ),
    ];

    Exported {
        documents,
        elements: Vec::new(),
        notes: Vec::new(),
    }
}

pub fn scene3d(scene: &Scene3dMap, target: ExportTarget<'_>, stem: &str, display_name: &str) -> Exported {
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let glb_rel = join_rel(dir_rel_prefix, &scene.glb_file);
    let glb_asset = asset_path(target.root, &join(target.directory, &glb_rel));
    let glb_uuid = uuid(&format!("{}:glb:{}", target.node_prefix, scene.glb_file));
    let sub_prefab_uuid = format!("{glb_uuid}@prefab");

    let (mut pb, root) = PrefabBuilder::new(&format!("{}:s3d", target.node_prefix), display_name);
    let meta_json = build_scene_meta_json(scene, &sub_prefab_uuid);

    let meta_type = compress_uuid(&uuid("shared:WfSpatialMeta.ts"));
    pb.add_script(
        root,
        meta_type,
        ScriptBody::SpatialMeta(WfSpatialMetaFields {
            kind: "scene3d_map",
            glb_path: glb_asset,
            height: 0.0,
            bottom: 0.0,
            meta_json,
        }),
    );

    append_scene_colliders_and_roles(&mut pb, root, scene);

    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let p_uuid = uuid(&format!("{}:s3d:prefab:{stem}", target.node_prefix));
    let documents = vec![
        doc(
            target.directory,
            target.root,
            format!("{glb_rel}.meta"),
            gltf_meta(&glb_uuid, &sub_prefab_uuid),
            StampKind::None,
        ),
        doc(
            target.directory,
            target.root,
            prefab_rel.clone(),
            pb.build(),
            StampKind::None,
        ),
        doc(
            target.directory,
            target.root,
            format!("{prefab_rel}.meta"),
            prefab_meta(&p_uuid),
            StampKind::None,
        ),
    ];

    Exported {
        documents,
        elements: Vec::new(),
        notes: scene.notes.clone(),
    }
}

fn build_scene_meta_json(scene: &Scene3dMap, sub_prefab_uuid: &str) -> String {
    let blocked_set: BTreeSet<&str> = scene.blocked_doors.iter().map(String::as_str).collect();
    let roles = scene
        .roles
        .iter()
        .map(|role| {
            let blocked = role.role == "door"
                && (role.id.as_deref().is_some_and(|i| blocked_set.contains(i))
                    || role.node.as_deref().is_some_and(|n| blocked_set.contains(n)));
            SceneRoleMetaJson {
                role: &role.role,
                id: role.id.as_deref(),
                node: role.node.as_deref(),
                position: role.position,
                forward: role.forward,
                blocked,
            }
        })
        .collect();
    let meta = SceneMetaJson {
        glb_prefab: sub_prefab_uuid,
        blocked_doors: &scene.blocked_doors,
        environment: SceneEnvMetaJson {
            ambient_color: scene.environment.ambient_color,
            ambient_intensity: scene.environment.ambient_intensity,
            fog_color: scene.environment.fog_color,
            fog_density: scene.environment.fog_density,
            fog_near: scene.environment.fog_near,
            fog_far: scene.environment.fog_far,
        },
        roles,
    };
    serde_json::to_string(&meta).expect("valid scene3d meta json")
}

fn add_box_collider(pb: &mut PrefabBuilder, node: NodeRef, center: [f64; 3], size: [f64; 3], is_trigger: bool) {
    pb.add_component(
        node,
        BuiltinComponent::BoxCollider(BoxColliderBody {
            center: CcVec3::exact(center[0], center[1], center[2]),
            size: CcVec3::exact(size[0], size[1], size[2]),
            is_trigger,
        }),
    );
}

fn append_scene_colliders_and_roles(pb: &mut PrefabBuilder, root: NodeRef, scene: &Scene3dMap) {
    let col_node = pb.add_node(root, "Collision", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    for bx in &scene.colliders {
        let g = pb.add_node(col_node, &bx.name, bx.center, [1.0, 1.0, 1.0], true);
        add_box_collider(pb, g, [0.0, 0.0, 0.0], bx.size, false);
    }

    let roles_node = pb.add_node(root, "Roles", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    for role in &scene.roles {
        let label = role.id.as_deref().or(role.node.as_deref()).unwrap_or(&role.role);
        if let (Some(min), Some(max)) = (role.min, role.max) {
            let center = [
                f64::midpoint(min[0], max[0]),
                f64::midpoint(min[1], max[1]),
                f64::midpoint(min[2], max[2]),
            ];
            let size = [
                (max[0] - min[0]).abs().max(0.1),
                (max[1] - min[1]).abs().max(0.1),
                (max[2] - min[2]).abs().max(0.1),
            ];
            let g = pb.add_node(roles_node, label, center, [1.0, 1.0, 1.0], true);
            add_box_collider(pb, g, [0.0, 0.0, 0.0], size, true);
        } else {
            pb.add_node(roles_node, label, role.position, [1.0, 1.0, 1.0], true);
        }
    }
}
