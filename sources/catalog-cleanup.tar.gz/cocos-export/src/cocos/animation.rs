//! `frame_animation` and `character_effect` -> `.png.meta`, `.anim` (`cc.AnimationClip`), and `<stem>.prefab` (`cc.Sprite` + `cc.Animation`).
use super::prefab::{AnimationBody, BuiltinComponent, PrefabBuilder};
use super::schema::{UuidRef, build_sprite_anim_clip, r4};
use super::texture::{FilterMode, ResolvedSprites, SliceSpec, SpriteKey, TextureRegistry};
use super::uuid::uuid;
use super::{Document, ExportTarget, Exported, StampKind, anim_meta, doc, join_rel, prefab_meta, rel_prefix};
use crate::model::{Animation, Clip, Point};
use std::collections::{BTreeMap, BTreeSet};

pub fn generate(
    anim: &Animation,
    target: ExportTarget<'_>,
    stem: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
) -> Exported {
    let mut notes = Vec::new();
    let anchors: BTreeSet<(i64, i64)> = anim
        .clips
        .iter()
        .map(|c| (c.anchor.x.round() as i64, c.anchor.y.round() as i64))
        .collect();
    if anchors.len() > 1 {
        notes.push(format!(
            "{display_name}: multiple clip anchors found; using first clip anchor for Cocos SpriteFrame pivot."
        ));
    }

    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let mut clip_keys: Vec<Vec<SpriteKey>> = Vec::with_capacity(anim.clips.len());
    let first_anchor = anim.clips[0].anchor;
    let (mut first_w, mut first_h) = (64.0, 64.0);

    for (ci, clip) in anim.clips.iter().enumerate() {
        let mut keys = Vec::with_capacity(clip.frames.len());
        for (fi, frame) in clip.frames.iter().enumerate() {
            let (tw, th) = dims.get(&frame.texture.path).copied().unwrap_or((1, 1));
            let (fw, fh) = frame
                .texture
                .region
                .map_or((f64::from(tw.max(1)), f64::from(th.max(1))), |r| {
                    (r.w.max(1.0), r.h.max(1.0))
                });
            if ci == 0 && fi == 0 {
                first_w = fw;
                first_h = fh;
            }
            let pivot = cocos_pivot(clip.anchor, fw, fh);
            let name = format!("{}_{}", clip.name, fi);
            keys.push(registry.register(
                &frame.texture.path,
                &name,
                SliceSpec {
                    rect: frame.texture.region,
                    pivot,
                    border: [0.0; 4],
                    ppu: 100.0,
                    filter: FilterMode::Bilinear,
                },
            ));
        }
        clip_keys.push(keys);
    }

    let (resolved, mut documents) = registry.build(target);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let clip_uuids = append_clip_assets(
        anim,
        target,
        stem,
        dir_rel_prefix,
        &clip_keys,
        &resolved,
        &mut documents,
    );

    let default_pivot = cocos_pivot(first_anchor, first_w, first_h);
    let first_sf = clip_keys
        .first()
        .and_then(|v| v.first())
        .map(|k| resolved.sprite_frame_uuid(k));

    let (mut pb, root) = PrefabBuilder::new(&format!("{}:anim", target.node_prefix), display_name);
    pb.add_ui_transform(root, first_w, first_h, default_pivot);
    pb.add_sprite(root, first_sf.as_deref(), 2, 0, [255, 255, 255, 255], None);
    let clip_refs: Vec<UuidRef> = clip_uuids.iter().map(UuidRef::new).collect();
    let default_ref = clip_uuids.first().map(UuidRef::new);
    pb.add_component(
        root,
        BuiltinComponent::Animation(AnimationBody {
            clips: clip_refs,
            default_clip: default_ref,
            play_on_load: true,
        }),
    );

    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let p_uuid = uuid(&format!("{}:prefab:{stem}", target.node_prefix));
    documents.push(doc(
        target.directory,
        target.root,
        prefab_rel.clone(),
        pb.build(),
        StampKind::None,
    ));
    documents.push(doc(
        target.directory,
        target.root,
        format!("{prefab_rel}.meta"),
        prefab_meta(&p_uuid),
        StampKind::None,
    ));

    Exported {
        documents,
        elements: Vec::new(),
        notes,
    }
}

fn append_clip_assets(
    anim: &Animation,
    target: ExportTarget<'_>,
    stem: &str,
    dir_rel_prefix: &str,
    clip_keys: &[Vec<SpriteKey>],
    resolved: &ResolvedSprites,
    documents: &mut Vec<Document>,
) -> Vec<String> {
    let mut clip_uuids = Vec::with_capacity(anim.clips.len());
    let mut used_stems = BTreeSet::new();
    for (ci, clip) in anim.clips.iter().enumerate() {
        let clip_stem = unique_clip_stem(&clip.name, ci, &mut used_stems);
        let clip_rel = join_rel(dir_rel_prefix, &format!("{stem}_{clip_stem}.anim"));
        let clip_uuid = uuid(&format!("{}:anim:{clip_stem}", target.node_prefix));
        let body = build_anim_clip(&clip_stem, clip, &clip_keys[ci], resolved);
        documents.push(doc(
            target.directory,
            target.root,
            clip_rel.clone(),
            body,
            StampKind::None,
        ));
        documents.push(doc(
            target.directory,
            target.root,
            format!("{clip_rel}.meta"),
            anim_meta(&clip_uuid),
            StampKind::None,
        ));
        clip_uuids.push(clip_uuid);
    }
    clip_uuids
}

pub fn build_anim_clip(name: &str, clip: &Clip, keys: &[SpriteKey], resolved: &ResolvedSprites) -> String {
    let sample = 60.0;
    let mut times = Vec::with_capacity(clip.frames.len());
    let mut values = Vec::with_capacity(clip.frames.len());
    let mut cursor = 0.0_f64;
    for (idx, frame) in clip.frames.iter().enumerate() {
        times.push(r4(cursor));
        values.push(UuidRef::new(resolved.sprite_frame_uuid(&keys[idx])));
        cursor += (frame.duration_ms / 1000.0).max(1.0 / sample);
    }
    let duration = cursor.max(1.0 / sample);
    let wrap_mode = if clip.looped { 2 } else { 1 };
    build_sprite_anim_clip(name, sample, wrap_mode, duration, times, values)
}

pub fn cocos_pivot(anchor: Point, w: f64, h: f64) -> [f64; 2] {
    [
        (anchor.x / w.max(1.0)).clamp(0.0, 1.0),
        (1.0 - anchor.y / h.max(1.0)).clamp(0.0, 1.0),
    ]
}

fn unique_clip_stem(name: &str, idx: usize, used: &mut BTreeSet<String>) -> String {
    let mut s: String = name
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || matches!(c, '_' | '-') {
                c
            } else {
                '_'
            }
        })
        .collect();
    if s.is_empty() {
        s = format!("clip_{idx}");
    }
    if used.insert(s.clone()) {
        return s;
    }
    let candidate = format!("{s}_{idx}");
    used.insert(candidate.clone());
    candidate
}
