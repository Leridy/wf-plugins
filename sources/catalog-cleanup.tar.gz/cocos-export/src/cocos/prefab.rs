//! Strongly-typed Cocos Creator 3.x `.prefab` scene-graph builder and pass-2 integrity verifier.
use super::schema::{
    CcColor, CcQuat, CcSize, CcVec2, CcVec3, ComponentRef, EmptyObj, NodeRef, ObjectId, UuidRef, serialize_pretty,
};
use super::uuid;
use serde::Serialize;

const DEFAULT_UI_LAYER: u32 = 33_554_432;

/// Serializes any slot in a Cocos `.prefab` flat object graph (`cc.*` builtin or compressed-UUID script).
#[derive(Serialize)]
#[serde(untagged)]
pub enum PrefabSlot {
    Engine(EngineObject),
    Script(ScriptComponent),
}

#[derive(Serialize)]
#[serde(tag = "__type__")]
pub enum EngineObject {
    #[serde(rename = "cc.Prefab")]
    Prefab(PrefabAsset),
    #[serde(rename = "cc.Node")]
    Node(CcNode),
    #[serde(rename = "cc.PrefabInfo")]
    PrefabInfo(PrefabInfo),
    #[serde(rename = "cc.CompPrefabInfo")]
    CompPrefabInfo(CompPrefabInfo),
    #[serde(rename = "cc.UITransform")]
    UiTransform(ComponentEnvelope<UiTransformBody>),
    #[serde(rename = "cc.Sprite")]
    Sprite(ComponentEnvelope<SpriteBody>),
    #[serde(rename = "cc.Animation")]
    Animation(ComponentEnvelope<AnimationBody>),
    #[serde(rename = "cc.Button")]
    Button(ComponentEnvelope<ButtonBody>),
    #[serde(rename = "cc.Toggle")]
    Toggle(ComponentEnvelope<ToggleBody>),
    #[serde(rename = "cc.ProgressBar")]
    ProgressBar(ComponentEnvelope<ProgressBarBody>),
    #[serde(rename = "cc.Slider")]
    Slider(ComponentEnvelope<SliderBody>),
    #[serde(rename = "cc.TiledMap")]
    TiledMap(ComponentEnvelope<TiledMapBody>),
    #[serde(rename = "cc.PolygonCollider2D")]
    PolygonCollider2D(ComponentEnvelope<PolygonCollider2DBody>),
    #[serde(rename = "cc.BoxCollider2D")]
    BoxCollider2D(ComponentEnvelope<BoxCollider2DBody>),
    #[serde(rename = "cc.CapsuleCollider")]
    CapsuleCollider(ComponentEnvelope<CapsuleColliderBody>),
    #[serde(rename = "cc.BoxCollider")]
    BoxCollider(ComponentEnvelope<BoxColliderBody>),
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PrefabAsset {
    #[serde(rename = "_name")]
    pub name: String,
    #[serde(rename = "_objFlags")]
    pub obj_flags: u32,
    #[serde(rename = "_native")]
    pub native: &'static str,
    pub data: NodeRef,
    pub optimization_policy: u32,
    pub persistent: bool,
}

#[derive(Serialize)]
pub struct CcNode {
    #[serde(rename = "_name")]
    pub name: String,
    #[serde(rename = "_objFlags")]
    pub obj_flags: u32,
    #[serde(rename = "_parent")]
    pub parent: Option<NodeRef>,
    #[serde(rename = "_children")]
    pub children: Vec<NodeRef>,
    #[serde(rename = "_active")]
    pub active: bool,
    #[serde(rename = "_components")]
    pub components: Vec<ComponentRef>,
    #[serde(rename = "_prefab")]
    pub prefab: ObjectId,
    #[serde(rename = "_lpos")]
    pub lpos: CcVec3,
    #[serde(rename = "_lrot")]
    pub lrot: CcQuat,
    #[serde(rename = "_lscale")]
    pub lscale: CcVec3,
    #[serde(rename = "_layer")]
    pub layer: u32,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct PrefabInfo {
    pub root: NodeRef,
    pub asset: ObjectId,
    pub file_id: String,
    pub target_overrides: Option<()>,
    pub nested_prefab_instance_roots: Option<()>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CompPrefabInfo {
    pub file_id: String,
}

#[derive(Serialize)]
pub struct ComponentEnvelope<B> {
    #[serde(rename = "_name")]
    pub name: &'static str,
    #[serde(rename = "_objFlags")]
    pub obj_flags: u32,
    #[serde(rename = "__prefab")]
    pub prefab: ObjectId,
    pub node: NodeRef,
    #[serde(rename = "_enabled")]
    pub enabled: bool,
    #[serde(flatten)]
    pub body: B,
}

pub use super::schema::{
    AnimationBody, BoxCollider2DBody, BoxColliderBody, ButtonBody, CapsuleColliderBody, PolygonCollider2DBody,
    ProgressBarBody, SliderBody, SpriteBody, TiledMapBody, ToggleBody, UiTransformBody,
};

#[derive(Serialize)]
pub struct ScriptComponent {
    #[serde(rename = "__type__")]
    pub kind: String,
    #[serde(rename = "_name")]
    pub name: &'static str,
    #[serde(rename = "_objFlags")]
    pub obj_flags: u32,
    #[serde(rename = "__prefab")]
    pub prefab: ObjectId,
    pub node: NodeRef,
    #[serde(rename = "_enabled")]
    pub enabled: bool,
    #[serde(flatten)]
    pub body: ScriptBody,
}

#[derive(Serialize)]
#[serde(untagged)]
pub enum ScriptBody {
    Particle(WfParticlePlayerFields),
    WholeMapNav(WfWholeMapNavFields),
    YSort(EmptyObj),
    ParallaxLayer(WfParallaxLayerFields),
    SpatialMeta(WfSpatialMetaFields),
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WfParticlePlayerFields {
    pub config_json: String,
    pub sprite_frames: Vec<UuidRef>,
    pub pixels_per_unit: u32,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WfWholeMapNavFields {
    pub nav_json: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WfParallaxLayerFields {
    pub parallax_speed: f64,
    pub drift_speed: f64,
    pub bob_amplitude: f64,
    pub bob_period: f64,
    pub sway_degrees: f64,
    pub sway_period: f64,
    pub repeat_span: f64,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WfSpatialMetaFields {
    pub kind: &'static str,
    pub glb_path: String,
    pub height: f64,
    pub bottom: f64,
    pub meta_json: String,
}

/// Typed component variants passed into [`PrefabBuilder::add_component`].
pub enum BuiltinComponent {
    UiTransform(UiTransformBody),
    Sprite(SpriteBody),
    Animation(AnimationBody),
    Button(ButtonBody),
    Toggle(ToggleBody),
    ProgressBar(ProgressBarBody),
    Slider(SliderBody),
    TiledMap(TiledMapBody),
    PolygonCollider2D(PolygonCollider2DBody),
    BoxCollider2D(BoxCollider2DBody),
    CapsuleCollider(CapsuleColliderBody),
    BoxCollider(BoxColliderBody),
}

/// Cocos Creator 3.x `.prefab` object-graph builder with typed node/component handles
/// and pass-2 reference verification.
pub struct PrefabBuilder {
    seed: String,
    objects: Vec<PrefabSlot>,
}

impl PrefabBuilder {
    pub fn new(seed: &str, root_name: &str) -> (Self, NodeRef) {
        let mut builder = Self {
            seed: seed.to_owned(),
            objects: vec![PrefabSlot::Engine(EngineObject::Prefab(PrefabAsset {
                name: root_name.to_owned(),
                obj_flags: 0,
                native: "",
                data: NodeRef::new(1),
                optimization_policy: 0,
                persistent: false,
            }))],
        };
        let root = builder.push_node_raw(None, root_name, [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
        (builder, root)
    }

    pub fn add_node(
        &mut self,
        parent: NodeRef,
        name: &str,
        position: [f64; 3],
        scale: [f64; 3],
        active: bool,
    ) -> NodeRef {
        let child = self.push_node_raw(Some(parent), name, position, scale, active);
        if let Some(PrefabSlot::Engine(EngineObject::Node(p_node))) = self.objects.get_mut(parent.id) {
            p_node.children.push(child);
        }
        child
    }

    fn push_node_raw(
        &mut self,
        parent: Option<NodeRef>,
        name: &str,
        position: [f64; 3],
        scale: [f64; 3],
        active: bool,
    ) -> NodeRef {
        let node_id = self.objects.len();
        let prefab_info_id = ObjectId::new(node_id + 1);
        let file_id = uuid::file_id(&format!("{}:n:{node_id}:{name}", self.seed));
        let node_ref = NodeRef::new(node_id);
        self.objects.push(PrefabSlot::Engine(EngineObject::Node(CcNode {
            name: name.to_owned(),
            obj_flags: 0,
            parent,
            children: Vec::new(),
            active,
            components: Vec::new(),
            prefab: prefab_info_id,
            lpos: CcVec3::new(position[0], position[1], position[2]),
            lrot: CcQuat::identity(),
            lscale: CcVec3::new(scale[0], scale[1], scale[2]),
            layer: DEFAULT_UI_LAYER,
        })));
        self.objects
            .push(PrefabSlot::Engine(EngineObject::PrefabInfo(PrefabInfo {
                root: NodeRef::new(1),
                asset: ObjectId::new(0),
                file_id,
                target_overrides: None,
                nested_prefab_instance_roots: None,
            })));
        node_ref
    }

    pub fn set_rotation_z_deg(&mut self, node: NodeRef, deg: f64) {
        if let Some(PrefabSlot::Engine(EngineObject::Node(n))) = self.objects.get_mut(node.id) {
            n.lrot = CcQuat::from_deg_z(deg);
        }
    }

    pub fn add_ui_transform(&mut self, node: NodeRef, width: f64, height: f64, anchor: [f64; 2]) -> ComponentRef {
        self.add_component(
            node,
            BuiltinComponent::UiTransform(UiTransformBody {
                content_size: CcSize::new(width, height),
                anchor_point: CcVec2::raw(anchor[0], anchor[1]),
            }),
        )
    }

    pub fn add_sprite(
        &mut self,
        node: NodeRef,
        sprite_frame_uuid: Option<&str>,
        size_mode: i32,
        sprite_type: i32,
        color: [u8; 4],
        custom_material_uuid: Option<&str>,
    ) -> ComponentRef {
        self.add_component(
            node,
            BuiltinComponent::Sprite(SpriteBody {
                size_mode,
                sprite_type,
                sprite_frame: sprite_frame_uuid.map(UuidRef::new),
                color: CcColor::rgba(color[0], color[1], color[2], color[3]),
                custom_material: custom_material_uuid.map(UuidRef::new),
            }),
        )
    }

    pub fn add_component(&mut self, node: NodeRef, comp: BuiltinComponent) -> ComponentRef {
        let comp_id = self.objects.len();
        let comp_info_id = ObjectId::new(comp_id + 1);
        let type_tag = comp.type_tag();
        let file_id = uuid::file_id(&format!("{}:c:{comp_id}:{type_tag}", self.seed));
        self.objects
            .push(PrefabSlot::Engine(comp.into_object(node, comp_info_id)));
        self.push_comp_info_and_link(node, comp_id, file_id)
    }

    pub fn add_script(&mut self, node: NodeRef, script_type: String, body: ScriptBody) -> ComponentRef {
        let comp_id = self.objects.len();
        let comp_info_id = ObjectId::new(comp_id + 1);
        let file_id = uuid::file_id(&format!("{}:c:{comp_id}:{script_type}", self.seed));
        self.objects.push(PrefabSlot::Script(ScriptComponent {
            kind: script_type,
            name: "",
            obj_flags: 0,
            prefab: comp_info_id,
            node,
            enabled: true,
            body,
        }));
        self.push_comp_info_and_link(node, comp_id, file_id)
    }

    fn push_comp_info_and_link(&mut self, node: NodeRef, comp_id: usize, file_id: String) -> ComponentRef {
        self.objects
            .push(PrefabSlot::Engine(EngineObject::CompPrefabInfo(CompPrefabInfo {
                file_id,
            })));
        let comp_ref = ComponentRef::new(comp_id);
        if let Some(PrefabSlot::Engine(EngineObject::Node(n))) = self.objects.get_mut(node.id) {
            n.components.push(comp_ref);
        }
        comp_ref
    }

    /// Pass-2 structural verifier validating bounds, target types, parent/child symmetry,
    /// component backpointers, and compressed script `__type__` tokens.
    pub fn verify(&self) -> Result<(), String> {
        let Some(PrefabSlot::Engine(EngineObject::Prefab(asset))) = self.objects.first() else {
            return Err("objects[0] must be cc.Prefab".into());
        };
        if asset.data.id != 1 || !matches!(self.objects.get(1), Some(PrefabSlot::Engine(EngineObject::Node(_)))) {
            return Err("cc.Prefab.data must reference root cc.Node at index 1".into());
        }
        for (idx, slot) in self.objects.iter().enumerate() {
            match slot {
                PrefabSlot::Engine(EngineObject::Node(node)) => self.verify_node(idx, node)?,
                PrefabSlot::Engine(EngineObject::PrefabInfo(info)) => {
                    self.expect_node(info.root, "PrefabInfo.root")?;
                    if !matches!(
                        self.objects.get(info.asset.id),
                        Some(PrefabSlot::Engine(EngineObject::Prefab(_)))
                    ) {
                        return Err(format!("PrefabInfo[{idx}].asset must target cc.Prefab"));
                    }
                }
                PrefabSlot::Engine(obj) => self.verify_engine_component(idx, obj)?,
                PrefabSlot::Script(sc) => {
                    if sc.kind.len() != 23 {
                        return Err(format!("Script[{idx}] invalid compressed UUID `{}`", sc.kind));
                    }
                    self.verify_component_links(idx, sc.node, sc.prefab)?;
                }
            }
        }
        Ok(())
    }

    fn verify_node(&self, idx: usize, node: &CcNode) -> Result<(), String> {
        if !matches!(
            self.objects.get(node.prefab.id),
            Some(PrefabSlot::Engine(EngineObject::PrefabInfo(_)))
        ) {
            return Err(format!(
                "Node[{idx}]._prefab {} must point to cc.PrefabInfo",
                node.prefab.id
            ));
        }
        if let Some(parent) = node.parent {
            let p_node = self.expect_node(parent, "Node._parent")?;
            if !p_node.children.iter().any(|c| c.id == idx) {
                return Err(format!("Node[{idx}] missing from parent {} _children", parent.id));
            }
        }
        for child in &node.children {
            let c_node = self.expect_node(*child, "Node._children")?;
            if c_node.parent.map(|p| p.id) != Some(idx) {
                return Err(format!("Child {} _parent does not match Node[{idx}]", child.id));
            }
        }
        for comp in &node.components {
            self.expect_component_owned_by(*comp, idx)?;
        }
        Ok(())
    }

    fn verify_engine_component(&self, idx: usize, obj: &EngineObject) -> Result<(), String> {
        if let Some((node, prefab)) = obj.component_meta() {
            self.verify_component_links(idx, node, prefab)?;
        }
        match obj {
            EngineObject::Button(c) => self.expect_node(c.body.target, "Button._target").map(|_| ()),
            EngineObject::Toggle(c) => self.expect_component_exists(c.body.check_mark, "Toggle._checkMark"),
            EngineObject::ProgressBar(c) => self.expect_component_exists(c.body.bar_sprite, "ProgressBar._barSprite"),
            EngineObject::Slider(c) => self.expect_node(c.body.handle, "Slider._handle").map(|_| ()),
            _ => Ok(()),
        }
    }

    fn verify_component_links(&self, idx: usize, node_ref: NodeRef, prefab_ref: ObjectId) -> Result<(), String> {
        let owner = self.expect_node(node_ref, "Component.node")?;
        if !owner.components.iter().any(|c| c.id == idx) {
            return Err(format!(
                "Component[{idx}] missing from owner Node[{}]._components",
                node_ref.id
            ));
        }
        if !matches!(
            self.objects.get(prefab_ref.id),
            Some(PrefabSlot::Engine(EngineObject::CompPrefabInfo(_)))
        ) {
            return Err(format!(
                "Component[{idx}].__prefab {} must point to cc.CompPrefabInfo",
                prefab_ref.id
            ));
        }
        Ok(())
    }

    fn expect_node(&self, r: NodeRef, label: &str) -> Result<&CcNode, String> {
        match self.objects.get(r.id) {
            Some(PrefabSlot::Engine(EngineObject::Node(n))) => Ok(n),
            _ => Err(format!("{label} ({}) does not point to cc.Node", r.id)),
        }
    }

    fn expect_component_exists(&self, r: ComponentRef, label: &str) -> Result<(), String> {
        if component_owner(self.objects.get(r.id)).is_some() {
            Ok(())
        } else {
            Err(format!("{label} ({}) does not point to a component", r.id))
        }
    }

    fn expect_component_owned_by(&self, r: ComponentRef, expected_owner: usize) -> Result<(), String> {
        match component_owner(self.objects.get(r.id)) {
            Some(owner) if owner.id == expected_owner => Ok(()),
            Some(owner) => Err(format!(
                "Node[{expected_owner}] lists Component[{}] whose owner is Node[{}]",
                r.id, owner.id
            )),
            None => Err(format!(
                "Node[{expected_owner}] _components entry {} is not a component",
                r.id
            )),
        }
    }

    pub fn build(self) -> String {
        self.verify().expect("valid Cocos Creator prefab graph");
        serialize_pretty(&self.objects)
    }
}

fn env<B>(node: NodeRef, prefab: ObjectId, body: B) -> ComponentEnvelope<B> {
    ComponentEnvelope {
        name: "",
        obj_flags: 0,
        prefab,
        node,
        enabled: true,
        body,
    }
}

impl BuiltinComponent {
    const fn type_tag(&self) -> &'static str {
        match self {
            Self::UiTransform(_) => "cc.UITransform",
            Self::Sprite(_) => "cc.Sprite",
            Self::Animation(_) => "cc.Animation",
            Self::Button(_) => "cc.Button",
            Self::Toggle(_) => "cc.Toggle",
            Self::ProgressBar(_) => "cc.ProgressBar",
            Self::Slider(_) => "cc.Slider",
            Self::TiledMap(_) => "cc.TiledMap",
            Self::PolygonCollider2D(_) => "cc.PolygonCollider2D",
            Self::BoxCollider2D(_) => "cc.BoxCollider2D",
            Self::CapsuleCollider(_) => "cc.CapsuleCollider",
            Self::BoxCollider(_) => "cc.BoxCollider",
        }
    }

    fn into_object(self, node: NodeRef, prefab: ObjectId) -> EngineObject {
        match self {
            Self::UiTransform(b) => EngineObject::UiTransform(env(node, prefab, b)),
            Self::Sprite(b) => EngineObject::Sprite(env(node, prefab, b)),
            Self::Animation(b) => EngineObject::Animation(env(node, prefab, b)),
            Self::Button(b) => EngineObject::Button(env(node, prefab, b)),
            Self::Toggle(b) => EngineObject::Toggle(env(node, prefab, b)),
            Self::ProgressBar(b) => EngineObject::ProgressBar(env(node, prefab, b)),
            Self::Slider(b) => EngineObject::Slider(env(node, prefab, b)),
            Self::TiledMap(b) => EngineObject::TiledMap(env(node, prefab, b)),
            Self::PolygonCollider2D(b) => EngineObject::PolygonCollider2D(env(node, prefab, b)),
            Self::BoxCollider2D(b) => EngineObject::BoxCollider2D(env(node, prefab, b)),
            Self::CapsuleCollider(b) => EngineObject::CapsuleCollider(env(node, prefab, b)),
            Self::BoxCollider(b) => EngineObject::BoxCollider(env(node, prefab, b)),
        }
    }
}

impl EngineObject {
    const fn component_meta(&self) -> Option<(NodeRef, ObjectId)> {
        match self {
            Self::Prefab(_) | Self::Node(_) | Self::PrefabInfo(_) | Self::CompPrefabInfo(_) => None,
            Self::UiTransform(c) => Some((c.node, c.prefab)),
            Self::Sprite(c) => Some((c.node, c.prefab)),
            Self::Animation(c) => Some((c.node, c.prefab)),
            Self::Button(c) => Some((c.node, c.prefab)),
            Self::Toggle(c) => Some((c.node, c.prefab)),
            Self::ProgressBar(c) => Some((c.node, c.prefab)),
            Self::Slider(c) => Some((c.node, c.prefab)),
            Self::TiledMap(c) => Some((c.node, c.prefab)),
            Self::PolygonCollider2D(c) => Some((c.node, c.prefab)),
            Self::BoxCollider2D(c) => Some((c.node, c.prefab)),
            Self::CapsuleCollider(c) => Some((c.node, c.prefab)),
            Self::BoxCollider(c) => Some((c.node, c.prefab)),
        }
    }
}

fn component_owner(slot: Option<&PrefabSlot>) -> Option<NodeRef> {
    match slot? {
        PrefabSlot::Script(s) => Some(s.node),
        PrefabSlot::Engine(obj) => obj.component_meta().map(|(n, _)| n),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn verify_rejects_broken_references_and_accepts_valid_tree() {
        let (mut pb, root) = PrefabBuilder::new("seed", "Hero");
        let child = pb.add_node(root, "Visual", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
        let sp = pb.add_sprite(child, None, 0, 0, [255, 255, 255, 255], None);
        pb.add_component(
            root,
            BuiltinComponent::Toggle(ToggleBody {
                is_checked: false,
                check_mark: sp,
            }),
        );
        assert!(pb.verify().is_ok());

        // Inject a dangling Toggle._checkMark pointing to an out-of-range component slot.
        let (mut bad, b_root) = PrefabBuilder::new("bad", "Bad");
        bad.add_component(
            b_root,
            BuiltinComponent::Toggle(ToggleBody {
                is_checked: false,
                check_mark: ComponentRef::new(999),
            }),
        );
        let err = bad.verify().unwrap_err();
        assert!(err.contains("_checkMark"), "{err}");

        // Reject invalid custom script compressed UUIDs.
        let (mut bad_script, s_root) = PrefabBuilder::new("s", "BadScript");
        bad_script.add_script(s_root, "not-23-chars".into(), ScriptBody::YSort(EmptyObj {}));
        assert!(bad_script.verify().unwrap_err().contains("compressed UUID"));
    }
}
