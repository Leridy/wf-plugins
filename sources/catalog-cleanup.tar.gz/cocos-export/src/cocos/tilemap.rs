//! `tilemap` -> `.png.meta`, `.tmx` + `.tmx.meta` (`cc.TiledMap`), Y-sorted object sprites,
//! `cc.PolygonCollider2D` obstacle bodies, and `Spawn` marker node.
use super::prefab::{BuiltinComponent, PolygonCollider2DBody, PrefabBuilder, TiledMapBody};
use super::schema::{CcVec2, NodeRef, UuidRef};
use super::texture::{FilterMode, ResolvedSprites, SliceSpec, SpriteKey, TextureRegistry};
use super::uuid::uuid;
use super::{ExportTarget, Exported, StampKind, doc, join_rel, prefab_meta, rel_prefix, tmx_meta};
use crate::model::{Orientation, Point, Rect, TileMap};
use std::collections::BTreeMap;
use std::fmt::Write;

pub fn generate(map: &TileMap, target: ExportTarget<'_>, stem: &str, display_name: &str) -> Exported {
    let dims: BTreeMap<String, (u32, u32)> = map
        .textures
        .values()
        .map(|t| {
            (
                t.file.clone(),
                (t.width.max(1.0).round() as u32, t.height.max(1.0).round() as u32),
            )
        })
        .collect();
    let (obj_keys, resolved, mut documents) = register_and_build_textures(map, &dims, target);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);

    let tmx_rel = join_rel(dir_rel_prefix, &format!("{stem}.tmx"));
    let tmx_uuid = uuid(&format!("{}:tmx:{stem}", target.node_prefix));
    documents.push(doc(
        target.directory,
        target.root,
        tmx_rel.clone(),
        build_tmx(map, &dims),
        StampKind::None,
    ));
    documents.push(doc(
        target.directory,
        target.root,
        format!("{tmx_rel}.meta"),
        tmx_meta(&tmx_uuid),
        StampKind::None,
    ));

    let (mut pb, root) = PrefabBuilder::new(&format!("{}:tilemap", target.node_prefix), display_name);
    pb.add_component(
        root,
        BuiltinComponent::TiledMap(TiledMapBody {
            tmx_file: UuidRef::new(tmx_uuid),
        }),
    );
    append_objects_and_collisions(&mut pb, root, map, &obj_keys, &resolved);
    if let Some(spawn) = map.spawn {
        pb.add_node(root, "Spawn", [spawn.x, -spawn.y, 0.0], [1.0, 1.0, 1.0], true);
    }

    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let p_uuid = uuid(&format!("{}:tm:prefab:{stem}", target.node_prefix));
    documents.push(doc(
        target.directory,
        target.root,
        prefab_rel.clone(),
        pb.build(),
        StampKind::None,
    ));
    documents.push(doc(
        target.directory,
        target.root,
        format!("{prefab_rel}.meta"),
        prefab_meta(&p_uuid),
        StampKind::None,
    ));

    let notes = if map.walkable.is_empty() && map.terrains.is_empty() {
        Vec::new()
    } else {
        vec![format!(
            "{display_name}: exported .tmx layers and obstacle PolygonCollider2Ds; read tilemap.json for walkable zones/terrains."
        )]
    };

    Exported {
        documents,
        elements: Vec::new(),
        notes,
    }
}

fn register_and_build_textures(
    map: &TileMap,
    dims: &BTreeMap<String, (u32, u32)>,
    target: ExportTarget<'_>,
) -> (Vec<(usize, SpriteKey)>, ResolvedSprites, Vec<super::Document>) {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let mut obj_keys = Vec::with_capacity(map.sprites.len());
    for (idx, sp) in map.sprites.iter().enumerate() {
        let Some(tex) = map.textures.get(&sp.texture) else {
            continue;
        };
        let key = registry.register(
            &tex.file,
            &format!("obj_{idx}_{}", sp.id),
            SliceSpec {
                rect: sp.source.map(|a| Rect {
                    x: a.x,
                    y: a.y,
                    w: a.width,
                    h: a.height,
                }),
                pivot: [0.5, 0.5],
                border: [0.0; 4],
                ppu: 100.0,
                filter: FilterMode::Point,
            },
        );
        obj_keys.push((idx, key));
    }
    for (k, tex) in &map.textures {
        let _ = registry.register(
            &tex.file,
            k,
            SliceSpec {
                rect: None,
                pivot: [0.5, 0.5],
                border: [0.0; 4],
                ppu: 100.0,
                filter: FilterMode::Point,
            },
        );
    }
    let (resolved, documents) = registry.build(target);
    (obj_keys, resolved, documents)
}

fn append_objects_and_collisions(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    map: &TileMap,
    obj_keys: &[(usize, SpriteKey)],
    resolved: &ResolvedSprites,
) {
    let objects_node = pb.add_node(root, "Objects", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    let mut sorted_objs: Vec<_> = obj_keys.iter().collect();
    sorted_objs.sort_by(|(a, _), (b, _)| map.sprites[*a].position.y.total_cmp(&map.sprites[*b].position.y));
    for (idx, key) in sorted_objs {
        let sp = &map.sprites[*idx];
        let sf = resolved.sprite_frame_uuid(key);
        let sx = if sp.flip_x { -1.0 } else { 1.0 };
        let node = pb.add_node(
            objects_node,
            &format!("Object_{}", sp.id),
            [sp.position.x, -sp.position.y, 0.0],
            [sx, 1.0, 1.0],
            true,
        );
        if sp.rotation.abs() > f64::EPSILON {
            pb.set_rotation_z_deg(node, -sp.rotation);
        }
        pb.add_ui_transform(node, sp.rect.width.max(1.0), sp.rect.height.max(1.0), [0.5, 0.5]);
        let alpha = (sp.opacity.clamp(0.0, 1.0) * 255.0).round() as u8;
        pb.add_sprite(node, Some(&sf), 0, 0, [255, 255, 255, alpha], None);
    }

    if !map.obstacles.is_empty() {
        let col_root = pb.add_node(root, "Collision", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
        for (oi, obs) in map.obstacles.iter().enumerate() {
            if obs.points.len() < 3 {
                continue;
            }
            let pts = poly_to_cc_vec2(&obs.points);
            let obs_node = pb.add_node(
                col_root,
                &format!("Obstacle_{}_{}", obs.kind, oi + 1),
                [0.0, 0.0, 0.0],
                [1.0, 1.0, 1.0],
                true,
            );
            pb.add_component(
                obs_node,
                BuiltinComponent::PolygonCollider2D(PolygonCollider2DBody {
                    tag: Some(oi),
                    sensor: false,
                    points: pts,
                }),
            );
        }
    }
}

pub fn poly_to_cc_vec2(pts: &[Point]) -> Vec<CcVec2> {
    pts.iter().map(|p| CcVec2::new(p.x, -p.y)).collect()
}

fn build_tmx(map: &TileMap, dims: &BTreeMap<String, (u32, u32)>) -> String {
    let orient = match map.orientation {
        Orientation::Orthogonal => "orthogonal",
        Orientation::Isometric => "isometric",
    };
    let min_x = map.ground.iter().map(|g| g.cell[0]).min().unwrap_or(0);
    let max_x = map.ground.iter().map(|g| g.cell[0]).max().unwrap_or(0);
    let min_y = map.ground.iter().map(|g| g.cell[1]).min().unwrap_or(0);
    let max_y = map.ground.iter().map(|g| g.cell[1]).max().unwrap_or(0);
    let cols = (max_x - min_x + 1).max(1);
    let rows = (max_y - min_y + 1).max(1);
    let tw = map.tile_width.round().max(1.0) as u32;
    let th = map.tile_height.round().max(1.0) as u32;

    let mut out = format!(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\
         <map version=\"1.10\" tiledversion=\"1.10.2\" orientation=\"{orient}\" renderorder=\"right-down\" \
         width=\"{cols}\" height=\"{rows}\" tilewidth=\"{tw}\" tileheight=\"{th}\" infinite=\"0\">\n"
    );

    // Build per-texture uniform gid mapping so standard TMX readers + Cocos TiledMap can resolve every tile.
    let mut next_gid = 1u32;
    let mut tex_first_gid = BTreeMap::new();
    for (name, tex) in &map.textures {
        let (pw, ph) = dims.get(&tex.file).copied().unwrap_or((tw, th));
        let tcols = (pw / tw).max(1);
        let trows = (ph / th).max(1);
        let count = tcols * trows;
        writeln!(
            out,
            " <tileset firstgid=\"{next_gid}\" name=\"{name}\" tilewidth=\"{tw}\" tileheight=\"{th}\" \
             tilecount=\"{count}\" columns=\"{tcols}\">\n  \
             <image source=\"{}\" width=\"{pw}\" height=\"{ph}\"/>\n </tileset>",
            tex.file
        )
        .expect("write");
        tex_first_gid.insert(name.as_str(), (next_gid, tcols));
        next_gid += count;
    }

    let mut levels: BTreeMap<u32, Vec<_>> = BTreeMap::new();
    for tile in &map.ground {
        levels.entry(tile.level).or_default().push(tile);
    }
    for (li, (level, tiles)) in levels.into_iter().enumerate() {
        let mut grid = vec![0u32; usize::try_from(cols * rows).unwrap_or(1)];
        let opacity = tiles.first().map_or(1.0, |t| t.opacity);
        for t in tiles {
            let Some(&(first_gid, tcols)) = tex_first_gid.get(t.texture.as_str()) else {
                continue;
            };
            let cx = usize::try_from(t.cell[0] - min_x).unwrap_or(0);
            let cy = usize::try_from(t.cell[1] - min_y).unwrap_or(0);
            let col = (t.source.x / f64::from(tw)).floor().max(0.0) as u32;
            let row = (t.source.y / f64::from(th)).floor().max(0.0) as u32;
            let tile_gid = first_gid + row * tcols + col;
            if let Some(slot) = grid.get_mut(cy * usize::try_from(cols).unwrap_or(1) + cx) {
                *slot = tile_gid;
            }
        }
        writeln!(
            out,
            " <layer id=\"{}\" name=\"level_{level}\" width=\"{cols}\" height=\"{rows}\" opacity=\"{opacity}\">\n  \
             <data encoding=\"csv\">",
            li + 1
        )
        .expect("write");
        for r in 0..usize::try_from(rows).unwrap_or(1) {
            let start = r * usize::try_from(cols).unwrap_or(1);
            let end = start + usize::try_from(cols).unwrap_or(1);
            let row_csv: Vec<String> = grid[start..end].iter().map(u32::to_string).collect();
            let trailing = if r + 1 < usize::try_from(rows).unwrap_or(1) {
                ","
            } else {
                ""
            };
            writeln!(out, "{}{trailing}", row_csv.join(",")).expect("write");
        }
        out.push_str("  </data>\n </layer>\n");
    }
    out.push_str("</map>\n");
    out
}
