//! Typed Cocos Creator 3.x serialization primitives, math values, `.meta`, `.anim`, and `.mtl` ASTs.
use serde::Serialize;
use std::collections::BTreeMap;

/// Rounds to 3 decimal places matching Cocos Inspector precision.
pub fn r3(v: f64) -> f64 {
    (v * 1000.0).round() / 1000.0
}

/// Rounds to 4 decimal places for normalized pivots, UVs, and quaternions.
pub fn r4(v: f64) -> f64 {
    (v * 10_000.0).round() / 10_000.0
}

/// Pretty-prints any Cocos serializable document with trailing newline and zero comments.
pub fn serialize_pretty<T: Serialize>(value: &T) -> String {
    let mut s = serde_json::to_string_pretty(value).expect("valid cocos json");
    s.push('\n');
    s
}

/// Internal graph reference pointing to a `cc.Node` entry by array index.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub struct NodeRef {
    #[serde(rename = "__id__")]
    pub id: usize,
}

impl NodeRef {
    pub const fn new(id: usize) -> Self {
        Self { id }
    }
}

/// Internal graph reference pointing to a component entry by array index.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub struct ComponentRef {
    #[serde(rename = "__id__")]
    pub id: usize,
}

impl ComponentRef {
    pub const fn new(id: usize) -> Self {
        Self { id }
    }
}

/// Internal graph reference pointing to a non-node helper object (`cc.Prefab`, `PrefabInfo`, track, curve).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub struct ObjectId {
    #[serde(rename = "__id__")]
    pub id: usize,
}

impl ObjectId {
    pub const fn new(id: usize) -> Self {
        Self { id }
    }
}

/// External asset or sub-asset reference serialized as `{ "__uuid__": "..." }`.
#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct UuidRef {
    #[serde(rename = "__uuid__")]
    pub uuid: String,
}

impl UuidRef {
    pub fn new(uuid: impl Into<String>) -> Self {
        Self { uuid: uuid.into() }
    }
}

/// Empty JSON object `{}` used for default states, defines, and marker components.
#[derive(Clone, Copy, Debug, Default, Serialize)]
pub struct EmptyObj {}

#[derive(Clone, Copy, Debug, Serialize)]
pub struct CcVec2 {
    #[serde(rename = "__type__")]
    kind: &'static str,
    pub x: f64,
    pub y: f64,
}

impl CcVec2 {
    pub fn new(x: f64, y: f64) -> Self {
        Self {
            kind: "cc.Vec2",
            x: r3(x),
            y: r3(y),
        }
    }

    pub fn raw(x: f64, y: f64) -> Self {
        Self {
            kind: "cc.Vec2",
            x: r4(x),
            y: r4(y),
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize)]
pub struct CcVec3 {
    #[serde(rename = "__type__")]
    kind: &'static str,
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

impl CcVec3 {
    pub fn new(x: f64, y: f64, z: f64) -> Self {
        Self {
            kind: "cc.Vec3",
            x: r3(x),
            y: r3(y),
            z: r3(z),
        }
    }

    pub fn exact(x: f64, y: f64, z: f64) -> Self {
        Self {
            kind: "cc.Vec3",
            x,
            y,
            z,
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize)]
pub struct CcVec4 {
    #[serde(rename = "__type__")]
    kind: &'static str,
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub w: f64,
}

impl CcVec4 {
    pub const fn new(x: f64, y: f64, z: f64, w: f64) -> Self {
        Self {
            kind: "cc.Vec4",
            x,
            y,
            z,
            w,
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize)]
pub struct CcQuat {
    #[serde(rename = "__type__")]
    kind: &'static str,
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub w: f64,
}

impl CcQuat {
    pub const fn identity() -> Self {
        Self {
            kind: "cc.Quat",
            x: 0.0,
            y: 0.0,
            z: 0.0,
            w: 1.0,
        }
    }

    pub fn from_deg_z(deg: f64) -> Self {
        let half = (deg * 0.5).to_radians();
        Self {
            kind: "cc.Quat",
            x: 0.0,
            y: 0.0,
            z: r4(half.sin()),
            w: r4(half.cos()),
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize)]
pub struct CcSize {
    #[serde(rename = "__type__")]
    kind: &'static str,
    pub width: f64,
    pub height: f64,
}

impl CcSize {
    pub fn new(width: f64, height: f64) -> Self {
        Self {
            kind: "cc.Size",
            width: r3(width),
            height: r3(height),
        }
    }
}

#[derive(Clone, Copy, Debug, Serialize)]
pub struct CcColor {
    #[serde(rename = "__type__")]
    kind: &'static str,
    pub r: u8,
    pub g: u8,
    pub b: u8,
    pub a: u8,
}

impl CcColor {
    pub const fn rgba(r: u8, g: u8, b: u8, a: u8) -> Self {
        Self {
            kind: "cc.Color",
            r,
            g,
            b,
            a,
        }
    }
}

/// Root `.meta` structure shared across Cocos Creator 3.x importers.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AssetMeta<'a, U, S> {
    pub ver: &'a str,
    pub importer: &'a str,
    pub imported: bool,
    pub uuid: &'a str,
    pub files: Vec<&'static str>,
    pub sub_metas: S,
    pub user_data: U,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SubMeta<'a, U> {
    pub importer: &'a str,
    pub uuid: String,
    pub display_name: &'a str,
    pub id: &'a str,
    pub name: &'a str,
    pub user_data: U,
}

#[derive(Serialize)]
pub struct GltfSubMetas<'a> {
    pub prefab: SubMeta<'a, EmptyObj>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ImageMetaUserData {
    #[serde(rename = "type")]
    pub kind: &'static str,
    pub fix_alpha_transparency_artifacts: bool,
    pub has_alpha: bool,
    pub filter_mode: &'static str,
    pub redirect: String,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SpriteFrameUserData {
    pub trim_type: &'static str,
    pub trim_threshold: i32,
    pub rotated: bool,
    pub offset_x: i32,
    pub offset_y: i32,
    pub trim_x: i64,
    pub trim_y: i64,
    pub width: u32,
    pub height: u32,
    pub raw_width: u32,
    pub raw_height: u32,
    pub border_top: u32,
    pub border_bottom: u32,
    pub border_left: u32,
    pub border_right: u32,
    pub pivot_x: f64,
    pub pivot_y: f64,
    pub is_trimmed: bool,
    pub pixels_to_unit: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub filter_mode: Option<&'static str>,
}

pub type SpriteFrameSubMetas<'a> = BTreeMap<String, SubMeta<'a, SpriteFrameUserData>>;

/// Cocos Creator 3.x `.mtl` material JSON document.
#[derive(Serialize)]
pub struct MaterialAsset<P> {
    #[serde(rename = "__type__")]
    pub kind: &'static str,
    #[serde(rename = "_name")]
    pub name: String,
    #[serde(rename = "_effectAsset")]
    pub effect_asset: UuidRef,
    #[serde(rename = "_techIdx")]
    pub tech_idx: u32,
    #[serde(rename = "_defines")]
    pub defines: Vec<EmptyObj>,
    #[serde(rename = "_states")]
    pub states: Vec<EmptyObj>,
    #[serde(rename = "_props")]
    pub props: Vec<P>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WholeMapMaterialProps {
    pub mask_texture: UuidRef,
    pub texel_size: CcVec4,
}

/// Cocos Creator 3.x `.anim` typed graph (`0: AnimationClip` .. `6: ObjectCurve`).
#[derive(Serialize)]
#[serde(untagged)]
pub enum AnimGraphEntry {
    Clip {
        #[serde(rename = "__type__")]
        kind: &'static str,
        #[serde(rename = "_name")]
        name: String,
        #[serde(rename = "_objFlags")]
        obj_flags: u32,
        #[serde(rename = "_native")]
        native: &'static str,
        sample: f64,
        speed: f64,
        #[serde(rename = "wrapMode")]
        wrap_mode: u32,
        #[serde(rename = "_duration")]
        duration: f64,
        #[serde(rename = "_tracks")]
        tracks: Vec<ObjectId>,
    },
    ObjectTrack {
        #[serde(rename = "__type__")]
        kind: &'static str,
        #[serde(rename = "_binding")]
        binding: ObjectId,
        #[serde(rename = "_channel")]
        channel: ObjectId,
    },
    TrackBinding {
        #[serde(rename = "__type__")]
        kind: &'static str,
        path: ObjectId,
    },
    TrackPath {
        #[serde(rename = "__type__")]
        kind: &'static str,
        #[serde(rename = "_paths")]
        paths: Vec<TrackPathStep>,
    },
    Channel {
        #[serde(rename = "__type__")]
        kind: &'static str,
        #[serde(rename = "_curve")]
        curve: ObjectId,
    },
    ComponentPath {
        #[serde(rename = "__type__")]
        kind: &'static str,
        component: &'static str,
    },
    ObjectCurve {
        #[serde(rename = "__type__")]
        kind: &'static str,
        #[serde(rename = "_times")]
        times: Vec<f64>,
        #[serde(rename = "_values")]
        values: Vec<UuidRef>,
    },
}

#[derive(Serialize)]
#[serde(untagged)]
pub enum TrackPathStep {
    Ref(ObjectId),
    Property(&'static str),
}

/// Builds and validates a 7-entry `cc.AnimationClip` sprite-frame animation graph.
pub fn build_sprite_anim_clip(
    name: &str,
    sample: f64,
    wrap_mode: u32,
    duration: f64,
    times: Vec<f64>,
    frames: Vec<UuidRef>,
) -> String {
    let entries = vec![
        AnimGraphEntry::Clip {
            kind: "cc.AnimationClip",
            name: name.to_owned(),
            obj_flags: 0,
            native: "",
            sample,
            speed: 1.0,
            wrap_mode,
            duration: r4(duration),
            tracks: vec![ObjectId::new(1)],
        },
        AnimGraphEntry::ObjectTrack {
            kind: "cc.animation.ObjectTrack",
            binding: ObjectId::new(2),
            channel: ObjectId::new(4),
        },
        AnimGraphEntry::TrackBinding {
            kind: "cc.animation.TrackBinding",
            path: ObjectId::new(3),
        },
        AnimGraphEntry::TrackPath {
            kind: "cc.animation.TrackPath",
            paths: vec![
                TrackPathStep::Ref(ObjectId::new(5)),
                TrackPathStep::Property("spriteFrame"),
            ],
        },
        AnimGraphEntry::Channel {
            kind: "cc.animation.Channel",
            curve: ObjectId::new(6),
        },
        AnimGraphEntry::ComponentPath {
            kind: "cc.animation.ComponentPath",
            component: "cc.Sprite",
        },
        AnimGraphEntry::ObjectCurve {
            kind: "cc.ObjectCurve",
            times,
            values: frames,
        },
    ];
    serialize_pretty(&entries)
}

#[derive(Serialize)]
pub struct UiTransformBody {
    #[serde(rename = "_contentSize")]
    pub content_size: CcSize,
    #[serde(rename = "_anchorPoint")]
    pub anchor_point: CcVec2,
}

#[derive(Serialize)]
pub struct SpriteBody {
    #[serde(rename = "_sizeMode")]
    pub size_mode: i32,
    #[serde(rename = "_type")]
    pub sprite_type: i32,
    #[serde(rename = "_spriteFrame")]
    pub sprite_frame: Option<UuidRef>,
    #[serde(rename = "_color")]
    pub color: CcColor,
    #[serde(rename = "_customMaterial")]
    pub custom_material: Option<UuidRef>,
}

#[derive(Serialize)]
pub struct AnimationBody {
    #[serde(rename = "_clips")]
    pub clips: Vec<UuidRef>,
    #[serde(rename = "_defaultClip")]
    pub default_clip: Option<UuidRef>,
    #[serde(rename = "playOnLoad")]
    pub play_on_load: bool,
}

#[derive(Serialize)]
pub struct ButtonBody {
    #[serde(rename = "_transition")]
    pub transition: i32,
    #[serde(rename = "_target")]
    pub target: NodeRef,
    #[serde(rename = "_normalSprite")]
    pub normal_sprite: Option<UuidRef>,
    #[serde(rename = "_hoverSprite")]
    pub hover_sprite: Option<UuidRef>,
    #[serde(rename = "_pressedSprite")]
    pub pressed_sprite: Option<UuidRef>,
    #[serde(rename = "_disabledSprite")]
    pub disabled_sprite: Option<UuidRef>,
}

#[derive(Serialize)]
pub struct ToggleBody {
    #[serde(rename = "_isChecked")]
    pub is_checked: bool,
    #[serde(rename = "_checkMark")]
    pub check_mark: ComponentRef,
}

#[derive(Serialize)]
pub struct ProgressBarBody {
    #[serde(rename = "_barSprite")]
    pub bar_sprite: ComponentRef,
    #[serde(rename = "_totalLength")]
    pub total_length: f64,
    #[serde(rename = "_progress")]
    pub progress: f64,
    #[serde(rename = "_mode")]
    pub mode: i32,
}

#[derive(Serialize)]
pub struct SliderBody {
    #[serde(rename = "_handle")]
    pub handle: NodeRef,
    #[serde(rename = "_direction")]
    pub direction: i32,
    #[serde(rename = "_progress")]
    pub progress: f64,
}

#[derive(Serialize)]
pub struct TiledMapBody {
    #[serde(rename = "_tmxFile")]
    pub tmx_file: UuidRef,
}

#[derive(Serialize)]
pub struct PolygonCollider2DBody {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tag: Option<usize>,
    pub sensor: bool,
    #[serde(rename = "_points")]
    pub points: Vec<CcVec2>,
}

#[derive(Serialize)]
pub struct BoxCollider2DBody {
    pub sensor: bool,
    #[serde(rename = "_offset")]
    pub offset: CcVec2,
    #[serde(rename = "_size")]
    pub size: CcSize,
}

#[derive(Serialize)]
pub struct CapsuleColliderBody {
    #[serde(rename = "_center")]
    pub center: CcVec3,
    #[serde(rename = "_radius")]
    pub radius: f64,
    #[serde(rename = "_cylinderHeight")]
    pub cylinder_height: f64,
    #[serde(rename = "_isTrigger")]
    pub is_trigger: bool,
}

#[derive(Serialize)]
pub struct BoxColliderBody {
    #[serde(rename = "_center")]
    pub center: CcVec3,
    #[serde(rename = "_size")]
    pub size: CcVec3,
    #[serde(rename = "_isTrigger")]
    pub is_trigger: bool,
}
