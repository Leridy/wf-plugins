// Pure TypeScript fixed-step particle simulation matching WeaveForge packages/editors/src/particle/simulation.ts.

export const PARTICLE_STEP = 1 / 60;
const REST = 0.2;

export type Vec3 = [number, number, number];
export type ParticleEvent = "land" | "death";
export type ParticleOrientation = "random" | "upright" | "velocity";

export interface ParticleRadial {
  radius: [number, number];
  speed: [number, number];
  cone: number;
}

export interface ParticleGround {
  bounce: number;
  friction: number;
  kill: boolean;
}

export interface ParticleTrigger {
  on: ParticleEvent;
  emitter: string;
  count: number;
  inherit: number;
}

export interface ParticleEmitterConfig {
  id: string;
  randomState?: number;
  enabled: boolean;
  rate: number;
  burst: number;
  delay: number;
  lifetime: [number, number];
  position: Vec3;
  spread: Vec3;
  velocity: Vec3;
  velocitySpread: Vec3;
  gravity: Vec3;
  drag: number;
  size: number[];
  opacity: number[];
  color: string[];
  blend: "normal" | "additive";
  orientation?: ParticleOrientation;
  sprite?: string;
  spriteIndex?: number;
  tilt?: number;
  flip?: boolean;
  sizeJitter?: number;
  stretch?: number;
  radial?: ParticleRadial;
  ground?: ParticleGround;
  triggers?: ParticleTrigger[];
  maxParticles: number;
}

export interface ParticleConfig {
  seed: number;
  duration: number;
  looping: boolean;
  space: "planar" | "spatial";
  emitters: ParticleEmitterConfig[];
}

export interface SimParticle {
  emitter: ParticleEmitterConfig;
  position: Vec3;
  velocity: Vec3;
  age: number;
  lifetime: number;
  rotation: number;
  flip: boolean;
  scale: number;
  landed: boolean;
}

interface EmitterStream {
  emitter: ParticleEmitterConfig;
  random: () => number;
  credit: number;
}

interface EventRecord {
  emitter: ParticleEmitterConfig;
  on: ParticleEvent;
  position: Vec3;
  velocity: Vec3;
}

export function particleOrientation(emitter: ParticleEmitterConfig): ParticleOrientation {
  return emitter.orientation ?? (emitter.sprite ? "upright" : "random");
}

function createRng(seed: number, id: string, randomState?: number): () => number {
  let state = randomState !== undefined ? randomState >>> 0 : seed >>> 0;
  if (randomState === undefined) {
    for (const char of id) {
      state = Math.imul(state ^ char.charCodeAt(0), 16777619);
    }
  }
  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let value = Math.imul(state ^ (state >>> 15), 1 | state);
    value ^= value + Math.imul(value ^ (value >>> 7), 61 | value);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

export function along(keys: readonly number[], progress: number): number {
  const span = keys.length - 1;
  if (span <= 0) return keys[0] ?? 0;
  const at = Math.min(1, Math.max(0, progress)) * span;
  const index = Math.min(Math.floor(at), span - 1);
  return keys[index] + (keys[index + 1] - keys[index]) * (at - index);
}

export function srgbToLinear(c: number): number {
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

export function linearToSrgb(c: number): number {
  const clamped = Math.min(1, Math.max(0, c));
  return clamped <= 0.0031308 ? clamped * 12.92 : 1.055 * Math.pow(clamped, 1 / 2.4) - 0.055;
}

export function parseHexLinear(hex: string): [number, number, number] {
  const clean = hex.startsWith("#") ? hex.slice(1) : hex;
  if (clean.length !== 6) return [1, 1, 1];
  const r = parseInt(clean.slice(0, 2), 16) / 255;
  const g = parseInt(clean.slice(2, 4), 16) / 255;
  const b = parseInt(clean.slice(4, 6), 16) / 255;
  return [srgbToLinear(r), srgbToLinear(g), srgbToLinear(b)];
}

export function sampleLinearColorSrgb255(
  linearKeys: readonly [number, number, number][],
  progress: number,
): [number, number, number] {
  if (linearKeys.length === 0) return [255, 255, 255];
  const rs = linearKeys.map((k) => k[0]);
  const gs = linearKeys.map((k) => k[1]);
  const bs = linearKeys.map((k) => k[2]);
  return [
    Math.round(linearToSrgb(along(rs, progress)) * 255),
    Math.round(linearToSrgb(along(gs, progress)) * 255),
    Math.round(linearToSrgb(along(bs, progress)) * 255),
  ];
}

export class WfParticleSimulation {
  particles: SimParticle[] = [];
  private tick = 0;
  private remainder = 0;
  private streams: EmitterStream[];
  readonly config: ParticleConfig;

  constructor(config: ParticleConfig) {
    this.config = config;
    this.streams = config.emitters.map((emitter) => ({
      emitter,
      random: createRng(config.seed, emitter.id, emitter.randomState),
      credit: 0,
    }));
  }

  get time(): number {
    return this.tick * PARTICLE_STEP;
  }

  advance(seconds: number): void {
    if (!Number.isFinite(seconds) || seconds <= 0) return;
    this.remainder += seconds;
    while (this.remainder + 1e-10 >= PARTICLE_STEP) {
      this.step();
      this.remainder = Math.max(0, this.remainder - PARTICLE_STEP);
    }
  }

  private step(): void {
    const dt = PARTICLE_STEP;
    const planar = this.config.space === "planar";
    const events: EventRecord[] = [];
    this.particles = this.particles.filter((p) => {
      const e = p.emitter;
      const emitEvent = (on: ParticleEvent) => {
        if ((e.triggers ?? []).some((t) => t.on === on)) {
          events.push({
            emitter: e,
            on,
            position: [...p.position],
            velocity: [...p.velocity],
          });
        }
      };
      p.age += dt;
      if (p.age >= p.lifetime) {
        emitEvent("death");
        return false;
      }
      const above = p.position[1] >= 0;
      const damping = Math.exp(-e.drag * dt);
      for (let axis = 0; axis < 3; axis++) {
        p.velocity[axis] = (p.velocity[axis] + e.gravity[axis] * dt) * damping;
        p.position[axis] += p.velocity[axis] * dt;
      }
      if (planar) p.position[2] = 0;
      const ground = e.ground;
      if (ground && above && p.position[1] < 0) {
        p.position[1] = 0;
        if (!p.landed) {
          p.landed = true;
          emitEvent("land");
        }
        if (ground.kill) {
          emitEvent("death");
          return false;
        }
        const up = -p.velocity[1] * ground.bounce;
        p.velocity[1] = up < REST ? 0 : up;
        p.velocity[0] *= 1 - ground.friction;
        p.velocity[2] *= 1 - ground.friction;
      }
      return true;
    });

    const start = this.time;
    const end = ++this.tick * dt;
    const { duration, looping } = this.config;
    const aliveCount = (e: ParticleEmitterConfig) =>
      this.particles.reduce((n, p) => n + (p.emitter === e ? 1 : 0), 0);

    for (const stream of this.streams) {
      const e = stream.emitter;
      if (!e.enabled) continue;
      let count = 0;
      const first = Math.floor(start / duration);
      const last = Math.floor((end - 1e-10) / duration);
      for (let cycle = first; cycle <= last && (looping || cycle === 0); cycle++) {
        const birth = cycle * duration + e.delay;
        if (birth >= start - 1e-10 && birth < end - 1e-10) count += e.burst;
        stream.credit +=
          Math.max(0, Math.min(end, (cycle + 1) * duration) - Math.max(start, birth)) * e.rate;
      }
      const continuous = Math.floor(stream.credit + 1e-10);
      stream.credit -= continuous;
      count += continuous;
      count = Math.min(count, e.maxParticles - aliveCount(e));
      for (let i = 0; i < count; i++) {
        this.particles.push(born(e, stream.random, planar, [0, 0, 0], [0, 0, 0]));
      }
    }

    for (const ev of events) {
      for (const trigger of ev.emitter.triggers ?? []) {
        if (trigger.on !== ev.on) continue;
        const stream = this.streams.find((s) => s.emitter.id === trigger.emitter);
        if (!stream?.emitter.enabled) continue;
        const target = stream.emitter;
        const count = Math.min(trigger.count, target.maxParticles - aliveCount(target));
        const carried: Vec3 = [
          ev.velocity[0] * trigger.inherit,
          ev.velocity[1] * trigger.inherit,
          ev.velocity[2] * trigger.inherit,
        ];
        for (let i = 0; i < count; i++) {
          this.particles.push(born(target, stream.random, planar, ev.position, carried));
        }
      }
    }
  }
}

function born(
  e: ParticleEmitterConfig,
  rand: () => number,
  planar: boolean,
  at: Vec3,
  carried: Vec3,
): SimParticle {
  const position: Vec3 = [0, 0, 0];
  const velocity: Vec3 = [0, 0, 0];
  for (let axis = 0; axis < 3; axis++) {
    position[axis] = at[axis] + e.position[axis] + (rand() * 2 - 1) * e.spread[axis];
    velocity[axis] = carried[axis] + e.velocity[axis] + (rand() * 2 - 1) * e.velocitySpread[axis];
  }
  if (planar) {
    position[2] = 0;
    velocity[2] = 0;
  }
  const lifetime = e.lifetime[0] + rand() * (e.lifetime[1] - e.lifetime[0]);
  const tilt = ((e.tilt ?? 0) * Math.PI) / 180;
  let rotation = 0;
  if (particleOrientation(e) === "random") rotation = rand() * Math.PI * 2;
  else if (tilt > 0) rotation = (rand() * 2 - 1) * tilt;
  const flip = e.flip === true && rand() < 0.5;
  const jitter = e.sizeJitter ?? 0;
  const scale = jitter > 0 ? 1 + (rand() * 2 - 1) * jitter : 1;
  const radial = e.radial;
  if (radial) {
    const cone = (radial.cone * Math.PI) / 180;
    let direction: Vec3;
    if (planar) {
      const angle = (rand() * 2 - 1) * cone;
      direction = [Math.sin(angle), Math.cos(angle), 0];
    } else {
      const height = 1 - rand() * (1 - Math.cos(cone));
      const azimuth = rand() * Math.PI * 2;
      const across = Math.sqrt(Math.max(0, 1 - height * height));
      direction = [across * Math.cos(azimuth), height, across * Math.sin(azimuth)];
    }
    const radius = radial.radius[0] + rand() * (radial.radius[1] - radial.radius[0]);
    const speed = radial.speed[0] + rand() * (radial.speed[1] - radial.speed[0]);
    for (let axis = 0; axis < 3; axis++) {
      position[axis] += direction[axis] * radius;
      velocity[axis] += direction[axis] * speed;
    }
  }
  return {
    emitter: e,
    position,
    velocity,
    age: 0,
    lifetime,
    rotation,
    flip,
    scale,
    landed: false,
  };
}
