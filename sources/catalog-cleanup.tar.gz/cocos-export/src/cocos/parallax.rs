//! `scrolling_scene` / `scroll_map` -> `.png.meta`, shared `WfParallaxLayer.ts`,
//! and `<stem>.prefab` with backdrop, behind/front layers, and level colliders/markers.
use super::prefab::{BoxCollider2DBody, PolygonCollider2DBody, WfParallaxLayerFields};
use super::schema::{CcSize, CcVec2};
use super::texture::{FilterMode, ResolvedSprites, SliceSpec, SpriteKey, TextureRegistry};
use super::tilemap::poly_to_cc_vec2;
use super::uuid::{compress_uuid, uuid};
use super::{
    BuiltinComponent, Document, ExportTarget, Exported, NodeRef, PrefabBuilder, ScriptBody, StampKind, doc, join_rel,
    prefab_meta, rel_prefix, script_meta,
};
use crate::model::{
    Point,
    parallax::{LayerPlacement, Level, Marker, ParallaxMap, Slot, Whitebox},
};
use std::collections::BTreeMap;

pub const SHARED_OWNER_ID: &str = "shared-parallax-runtime";
const LAYER_SCRIPT_PATH: &str = "Scripts/WfParallaxLayer.ts";
const LAYER_SCRIPT_META_PATH: &str = "Scripts/WfParallaxLayer.ts.meta";
const LAYER_TS_SOURCE: &str = include_str!("WfParallaxLayer.ts");

pub fn shared_runtime_documents(directory: &str, root: &str) -> Vec<Document> {
    let cs_uuid = uuid("shared:WfParallaxLayer.ts");
    vec![
        doc(
            directory,
            root,
            LAYER_SCRIPT_PATH.into(),
            LAYER_TS_SOURCE.into(),
            StampKind::SlashLine,
        ),
        doc(
            directory,
            root,
            LAYER_SCRIPT_META_PATH.into(),
            script_meta(&cs_uuid),
            StampKind::None,
        ),
    ]
}

pub fn generate(
    map: &ParallaxMap,
    target: ExportTarget<'_>,
    stem: &str,
    display_name: &str,
    dims: &BTreeMap<String, (u32, u32)>,
) -> Exported {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let ratio = f64::from(map.pixel_ratio.max(1));
    let bd_key = registry.register(
        &map.backdrop.file,
        "backdrop",
        SliceSpec {
            rect: None,
            pivot: [0.0, 1.0],
            border: [0.0; 4],
            ppu: 100.0 * ratio,
            filter: FilterMode::Bilinear,
        },
    );
    let mut sprite_keys = BTreeMap::new();
    for s in &map.sprites {
        sprite_keys.insert(
            s.id.as_str(),
            registry.register(
                &s.file,
                &s.id,
                SliceSpec {
                    rect: None,
                    pivot: [0.5, 0.5],
                    border: [0.0; 4],
                    ppu: 100.0 * ratio,
                    filter: FilterMode::Bilinear,
                },
            ),
        );
    }
    let mut art_keys = BTreeMap::new();
    for (orig, resolved_name) in &map.art_files {
        art_keys.insert(
            orig.as_str(),
            registry.register(
                resolved_name,
                orig,
                SliceSpec {
                    rect: None,
                    pivot: [0.0, 1.0],
                    border: [0.0; 4],
                    ppu: 100.0 * ratio,
                    filter: FilterMode::Bilinear,
                },
            ),
        );
    }

    let (resolved, mut documents) = registry.build(target);
    let (mut pb, root) = PrefabBuilder::new(&format!("{}:px", target.node_prefix), display_name);
    pb.add_ui_transform(root, 1.0, 1.0, [0.5, 0.5]);

    append_backdrop(&mut pb, root, map, dims, &resolved, &bd_key);
    append_scenery_layers(&mut pb, root, map, dims, &resolved, &sprite_keys);
    if let Some(level) = &map.level {
        append_level(&mut pb, root, level, dims, &resolved, &art_keys, ratio);
    }

    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let p_uuid = uuid(&format!("{}:px:prefab:{stem}", target.node_prefix));
    documents.push(doc(
        target.directory,
        target.root,
        prefab_rel.clone(),
        pb.build(),
        StampKind::None,
    ));
    documents.push(doc(
        target.directory,
        target.root,
        format!("{prefab_rel}.meta"),
        prefab_meta(&p_uuid),
        StampKind::None,
    ));

    Exported {
        documents,
        elements: Vec::new(),
        notes: Vec::new(),
    }
}

fn layer_script(
    parallax_speed: f64,
    drift_speed: f64,
    bob_amplitude: f64,
    bob_period: f64,
    sway_degrees: f64,
    sway_period: f64,
    repeat_span: f64,
) -> ScriptBody {
    ScriptBody::ParallaxLayer(WfParallaxLayerFields {
        parallax_speed,
        drift_speed,
        bob_amplitude,
        bob_period,
        sway_degrees,
        sway_period,
        repeat_span,
    })
}

fn append_backdrop(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    map: &ParallaxMap,
    dims: &BTreeMap<String, (u32, u32)>,
    resolved: &ResolvedSprites,
    bd_key: &SpriteKey,
) {
    let ratio = f64::from(map.pixel_ratio.max(1));
    let (bw, bh) = dims.get(&map.backdrop.file).copied().unwrap_or((1, 1));
    let bd = pb.add_node(root, "Backdrop", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], map.backdrop.visible);
    pb.add_ui_transform(bd, f64::from(bw) / ratio, f64::from(bh) / ratio, [0.0, 1.0]);
    let sf = resolved.sprite_frame_uuid(bd_key);
    let alpha = (map.backdrop.opacity.clamp(0.0, 1.0) * 255.0).round() as u8;
    pb.add_sprite(bd, Some(&sf), 0, 0, [255, 255, 255, alpha], None);
    let script_type = compress_uuid(&uuid("shared:WfParallaxLayer.ts"));
    pb.add_script(
        bd,
        script_type,
        layer_script(
            map.backdrop.speed,
            map.backdrop.drift,
            0.0,
            2.0,
            0.0,
            2.0,
            f64::from(map.backdrop.width),
        ),
    );
}

fn append_scenery_layers(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    map: &ParallaxMap,
    dims: &BTreeMap<String, (u32, u32)>,
    resolved: &ResolvedSprites,
    sprite_keys: &BTreeMap<&str, SpriteKey>,
) {
    let ratio = f64::from(map.pixel_ratio.max(1));
    let behind = pb.add_node(root, "BehindLayers", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    let front = pb.add_node(root, "FrontLayers", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    let script_type = compress_uuid(&uuid("shared:WfParallaxLayer.ts"));

    for layer in &map.layers {
        let parent = match layer.placement {
            LayerPlacement::Behind => behind,
            LayerPlacement::Front => front,
        };
        for (ii, item) in layer.items.iter().enumerate() {
            let skey = &sprite_keys[item.sprite_id.as_str()];
            let (sw, sh) = dims.get(&skey.tex_path).copied().unwrap_or((1, 1));
            let sx = if item.flip_x { -item.scale } else { item.scale };
            let node = pb.add_node(
                parent,
                &format!("{}_{}", layer.name, ii + 1),
                [item.x, -item.y, 0.0],
                [sx, item.scale, 1.0],
                layer.visible,
            );
            pb.add_ui_transform(node, f64::from(sw) / ratio, f64::from(sh) / ratio, [0.5, 0.5]);
            let sf = resolved.sprite_frame_uuid(skey);
            let alpha = ((layer.opacity * item.opacity).clamp(0.0, 1.0) * 255.0).round() as u8;
            pb.add_sprite(node, Some(&sf), 0, 0, [255, 255, 255, alpha], None);
            pb.add_script(
                node,
                script_type.clone(),
                layer_script(
                    layer.speed,
                    item.motion.drift,
                    item.motion.bob.amplitude,
                    item.motion.bob.period,
                    item.motion.sway.degrees,
                    item.motion.sway.period,
                    f64::from(item.repeat_span.unwrap_or(0)),
                ),
            );
        }
    }
}

fn append_level(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    level: &Level,
    dims: &BTreeMap<String, (u32, u32)>,
    resolved: &ResolvedSprites,
    art_keys: &BTreeMap<&str, SpriteKey>,
    ratio: f64,
) {
    let level_node = pb.add_node(root, "Level", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    let art_node = pb.add_node(level_node, "LevelArt", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    let is_front = |kind: &str| {
        level
            .whitebox
            .slot_kinds
            .iter()
            .any(|sk| sk.id == kind && sk.depth == "front")
    };
    let emit_slot = |pb: &mut PrefabBuilder, i: usize, slot: &Slot| {
        let Some(art) = level.kit.objects.iter().find(|o| o.kind == slot.kind) else {
            return;
        };
        let Some(key) = art_keys.get(art.file.as_str()) else {
            return;
        };
        let (aw, ah) = dims.get(&key.tex_path).copied().unwrap_or((1, 1));
        let snode = pb.add_node(
            art_node,
            &format!("Slot_{}", i + 1),
            [f64::from(slot.x) - art.anchor, -(f64::from(slot.y) - art.base), 0.0],
            [1.0, 1.0, 1.0],
            true,
        );
        pb.add_ui_transform(snode, f64::from(aw) / ratio, f64::from(ah) / ratio, [0.0, 1.0]);
        pb.add_sprite(
            snode,
            Some(&resolved.sprite_frame_uuid(key)),
            0,
            0,
            [255, 255, 255, 255],
            None,
        );
    };
    for (i, slot) in level.whitebox.slots.iter().enumerate() {
        if !is_front(&slot.kind) {
            emit_slot(pb, i, slot);
        }
    }
    for (i, group) in level.kit.groups.iter().enumerate() {
        let Some(key) = art_keys.get(group.file.as_str()) else {
            continue;
        };
        let (aw, ah) = dims.get(&key.tex_path).copied().unwrap_or((1, 1));
        let gnode = pb.add_node(
            art_node,
            &format!("Terrain_{}", i + 1),
            [f64::from(group.image.x), -f64::from(group.image.y), 0.0],
            [1.0, 1.0, 1.0],
            true,
        );
        pb.add_ui_transform(gnode, f64::from(aw) / ratio, f64::from(ah) / ratio, [0.0, 1.0]);
        pb.add_sprite(
            gnode,
            Some(&resolved.sprite_frame_uuid(key)),
            0,
            0,
            [255, 255, 255, 255],
            None,
        );
    }
    for (i, slot) in level.whitebox.slots.iter().enumerate() {
        if is_front(&slot.kind) {
            emit_slot(pb, i, slot);
        }
    }

    append_level_collisions(pb, level_node, &level.whitebox);
    append_level_interactables(pb, level_node, &level.whitebox);
}

fn append_level_collisions(pb: &mut PrefabBuilder, level_node: NodeRef, wb: &Whitebox) {
    let col_node = pb.add_node(level_node, "TerrainCollision", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    if wb.collisions.is_empty() {
        for solid in &wb.solids {
            add_box_2d(
                pb,
                col_node,
                f64::from(solid.x) + f64::from(solid.width) * 0.5,
                -(f64::from(solid.y) + f64::from(solid.height) * 0.5),
                f64::from(solid.width.max(1)),
                f64::from(solid.height.max(1)),
                false,
            );
        }
        for row in &wb.rows {
            let rw = row.resolved_width().max(1);
            add_box_2d(
                pb,
                col_node,
                f64::from(row.x) + f64::from(rw) * 0.5,
                -(f64::from(row.y) + f64::from(row.height) * 0.5),
                f64::from(rw),
                f64::from(row.height.max(1)),
                false,
            );
        }
        for slope in &wb.slopes {
            let left = f64::from(slope.x);
            let right = f64::from(slope.x + slope.width);
            let top = f64::from(slope.y);
            let bottom = f64::from(slope.y + slope.height);
            let (left_y, right_y) = if slope.direction == "up" {
                (bottom, top)
            } else {
                (top, bottom)
            };
            let poly = [
                Point { x: left, y: bottom },
                Point { x: left, y: left_y },
                Point { x: right, y: right_y },
                Point { x: right, y: bottom },
            ];
            pb.add_component(
                col_node,
                BuiltinComponent::PolygonCollider2D(PolygonCollider2DBody {
                    tag: None,
                    sensor: false,
                    points: poly_to_cc_vec2(&poly),
                }),
            );
        }
        return;
    }

    for col in &wb.collisions {
        if col.bodies.is_empty() {
            add_box_2d(
                pb,
                col_node,
                col.bounds.x + col.bounds.width * 0.5,
                -(col.bounds.y + col.bounds.height * 0.5),
                col.bounds.width.max(1.0),
                col.bounds.height.max(1.0),
                false,
            );
            continue;
        }
        for body in &col.bodies {
            add_box_2d(
                pb,
                col_node,
                col.bounds.x + body.x + body.width * 0.5,
                -(col.bounds.y + body.y + body.height * 0.5),
                body.width.max(1.0),
                body.height.max(1.0),
                false,
            );
        }
    }
}

fn add_box_2d(pb: &mut PrefabBuilder, node: NodeRef, cx: f64, cy: f64, w: f64, h: f64, sensor: bool) {
    pb.add_component(
        node,
        BuiltinComponent::BoxCollider2D(BoxCollider2DBody {
            sensor,
            offset: CcVec2::new(cx, cy),
            size: CcSize::new(w, h),
        }),
    );
}

fn append_level_interactables(pb: &mut PrefabBuilder, level_node: NodeRef, wb: &Whitebox) {
    for (i, haz) in wb.hazards.iter().enumerate() {
        let hnode = pb.add_node(
            level_node,
            &format!("Hazard_{}_{}", haz.kind, i + 1),
            [
                f64::from(haz.x) + f64::from(haz.width) * 0.5,
                -(f64::from(haz.y) + f64::from(haz.height) * 0.5),
                0.0,
            ],
            [1.0, 1.0, 1.0],
            true,
        );
        add_box_2d(
            pb,
            hnode,
            0.0,
            0.0,
            f64::from(haz.width.max(1)),
            f64::from(haz.height.max(1)),
            true,
        );
    }
    for climb in &wb.climbs {
        let h_px = f64::from((climb.bottom - climb.top).abs().max(1));
        let cy_px = f64::from(climb.top.min(climb.bottom)) + h_px * 0.5;
        let cnode = pb.add_node(
            level_node,
            &format!("Climb_{}", climb.id),
            [f64::from(climb.x), -cy_px, 0.0],
            [1.0, 1.0, 1.0],
            true,
        );
        add_box_2d(pb, cnode, 0.0, 0.0, 32.0, h_px, true);
    }
    let markers = pb.add_node(level_node, "Markers", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    add_marker(pb, markers, "Spawn", &wb.markers.spawn);
    add_marker(pb, markers, "Exit", &wb.markers.exit);
    for cp in &wb.markers.checkpoints {
        add_marker(pb, markers, &format!("Checkpoint_{}", cp.id), cp);
    }
    for col in &wb.markers.collectibles {
        add_marker(pb, markers, &format!("Collectible_{}", col.id), col);
    }
}

fn add_marker(pb: &mut PrefabBuilder, parent: NodeRef, name: &str, m: &Marker) {
    pb.add_node(
        parent,
        name,
        [f64::from(m.x), -f64::from(m.y), 0.0],
        [1.0, 1.0, 1.0],
        true,
    );
}
