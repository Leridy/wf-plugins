import { _decorator, Color, Component, gfx, Node, Sprite, SpriteFrame, UITransform, Vec3 } from "cc";
import {
  along,
  parseHexLinear,
  particleOrientation,
  sampleLinearColorSrgb255,
  WfParticleSimulation,
  type ParticleConfig,
} from "./WfParticleSim";

const { ccclass, property } = _decorator;

interface PooledQuad {
  node: Node;
  ui: UITransform;
  sprite: Sprite;
}

@ccclass("WfParticlePlayer")
export class WfParticlePlayer extends Component {
  @property
  configJson = "{}";

  @property([SpriteFrame])
  spriteFrames: SpriteFrame[] = [];

  @property
  pixelsPerUnit = 100;

  private sim: WfParticleSimulation | null = null;
  private linearPalettes = new Map<string, [number, number, number][]>();
  private pool: PooledQuad[] = [];

  onLoad(): void {
    const parsed = JSON.parse(this.configJson) as ParticleConfig;
    if (!parsed || !Array.isArray(parsed.emitters)) return;
    for (const emitter of parsed.emitters) {
      this.linearPalettes.set(
        emitter.id,
        (emitter.color ?? ["#ffffff"]).map(parseHexLinear),
      );
    }
    this.sim = new WfParticleSimulation(parsed);
  }

  update(dt: number): void {
    if (!this.sim) return;
    this.sim.advance(dt);
    const active = this.sim.particles;
    this.ensurePoolSize(active.length);

    for (let i = 0; i < this.pool.length; i++) {
      const quad = this.pool[i];
      if (i >= active.length) {
        quad.node.active = false;
        continue;
      }
      const p = active[i];
      const e = p.emitter;
      const progress = p.lifetime > 0 ? p.age / p.lifetime : 1;
      const sizePx = Math.max(1, along(e.size, progress) * p.scale * this.pixelsPerUnit);
      const stretch = e.stretch ?? 0;
      const speed = Math.hypot(p.velocity[0], p.velocity[1]);
      const lengthPx = sizePx + (stretch > 0 ? speed * stretch * this.pixelsPerUnit : 0);
      const orient = particleOrientation(e);
      let angleRad = orient === "random" && stretch > 0 ? 0 : p.rotation;
      if ((orient === "velocity" || stretch > 0) && speed > 1e-6) {
        angleRad += Math.atan2(p.velocity[1], p.velocity[0]) - Math.PI * 0.5;
      }

      quad.node.active = true;
      quad.node.setPosition(
        new Vec3(
          p.position[0] * this.pixelsPerUnit,
          p.position[1] * this.pixelsPerUnit,
          p.position[2] * this.pixelsPerUnit,
        ),
      );
      quad.node.setRotationFromEuler(0, 0, (angleRad * 180) / Math.PI);
      quad.node.setScale(p.flip ? -1 : 1, 1, 1);
      quad.ui.setContentSize(sizePx, lengthPx);

      const frameIndex = e.spriteIndex ?? 0;
      if (frameIndex >= 0 && frameIndex < this.spriteFrames.length) {
        quad.sprite.spriteFrame = this.spriteFrames[frameIndex];
      }
      quad.sprite.dstBlendFactor =
        e.blend === "additive" ? gfx.BlendFactor.ONE : gfx.BlendFactor.ONE_MINUS_SRC_ALPHA;
      const [r, g, b] = sampleLinearColorSrgb255(
        this.linearPalettes.get(e.id) ?? [[1, 1, 1]],
        progress,
      );
      const a = Math.round(Math.min(1, Math.max(0, along(e.opacity, progress))) * 255);
      quad.sprite.color = new Color(r, g, b, a);
    }
  }

  private ensurePoolSize(target: number): void {
    while (this.pool.length < target) {
      const node = new Node(`P_${this.pool.length}`);
      node.parent = this.node;
      const ui = node.addComponent(UITransform);
      const sprite = node.addComponent(Sprite);
      sprite.sizeMode = Sprite.SizeMode.CUSTOM;
      sprite.srcBlendFactor = gfx.BlendFactor.SRC_ALPHA;
      this.pool.push({ node, ui, sprite });
    }
  }
}
