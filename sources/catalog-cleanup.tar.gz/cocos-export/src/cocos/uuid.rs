//! Deterministic UUIDv4-style generation and Cocos Creator 3.x Base64 script UUID compression.
use sha2::{Digest, Sha256};

const BASE64_KEYS: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
#[cfg(test)]
const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";

pub fn uuid(seed: &str) -> String {
    let mut bytes = [0u8; 16];
    let hash = Sha256::digest(format!("wf:cocos:{seed}").as_bytes());
    bytes.copy_from_slice(&hash[..16]);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        bytes[0],
        bytes[1],
        bytes[2],
        bytes[3],
        bytes[4],
        bytes[5],
        bytes[6],
        bytes[7],
        bytes[8],
        bytes[9],
        bytes[10],
        bytes[11],
        bytes[12],
        bytes[13],
        bytes[14],
        bytes[15]
    )
}

pub fn file_id(seed: &str) -> String {
    compress_uuid(&uuid(seed))
}

/// Cocos Creator 3.x `Editor.Utils.UuidUtils.compressUuid(uuid, false)` (23-char script `__type__`).
pub fn compress_uuid(hyphenated: &str) -> String {
    let hex: Vec<u8> = hyphenated
        .bytes()
        .filter(u8::is_ascii_hexdigit)
        .map(|b| b.to_ascii_lowercase())
        .collect();
    if hex.len() != 32 {
        return hyphenated.to_owned();
    }
    let mut out = Vec::with_capacity(23);
    out.extend_from_slice(&hex[..5]);
    let mut i = 5;
    while i < 32 {
        let a = hex_val(hex[i]);
        let b = hex_val(hex[i + 1]);
        let c = hex_val(hex[i + 2]);
        out.push(BASE64_KEYS[((a << 2) | (b >> 2)) as usize]);
        out.push(BASE64_KEYS[(((b & 0x3) << 4) | c) as usize]);
        i += 3;
    }
    String::from_utf8(out).expect("ascii base64")
}

/// Decode either 23-char (`min=false`) or 22-char (`min=true`) Cocos compressed UUIDs.
#[cfg(test)]
pub fn decompress_uuid(compressed: &str) -> Option<String> {
    let bytes = compressed.as_bytes();
    let (prefix_len, rest) = match bytes.len() {
        23 => (5usize, &bytes[5..]),
        22 => (2usize, &bytes[2..]),
        _ => return None,
    };
    if !bytes[..prefix_len].iter().all(u8::is_ascii_hexdigit) || !rest.len().is_multiple_of(2) {
        return None;
    }
    let mut hex = Vec::with_capacity(32);
    for &b in &bytes[..prefix_len] {
        hex.push(b.to_ascii_lowercase());
    }
    for pair in rest.chunks_exact(2) {
        let lhs = b64_val(pair[0])?;
        let rhs = b64_val(pair[1])?;
        hex.push(HEX_CHARS[(lhs >> 2) as usize]);
        hex.push(HEX_CHARS[(((lhs & 0x3) << 2) | (rhs >> 4)) as usize]);
        hex.push(HEX_CHARS[(rhs & 0xf) as usize]);
    }
    if hex.len() != 32 {
        return None;
    }
    let s = String::from_utf8(hex).ok()?;
    Some(format!(
        "{}-{}-{}-{}-{}",
        &s[0..8],
        &s[8..12],
        &s[12..16],
        &s[16..20],
        &s[20..32]
    ))
}

fn hex_val(b: u8) -> u8 {
    match b {
        b'0'..=b'9' => b - b'0',
        b'a'..=b'f' => b - b'a' + 10,
        b'A'..=b'F' => b - b'A' + 10,
        _ => 0,
    }
}

#[cfg(test)]
fn b64_val(b: u8) -> Option<u8> {
    BASE64_KEYS
        .iter()
        .position(|&k| k == b)
        .and_then(|pos| u8::try_from(pos).ok())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn compress_and_decompress_matches_cocos_creator_standard() {
        let u = "f897c2f3-3a4b-45c1-9abc-def012345678";
        let c = compress_uuid(u);
        assert_eq!(c.len(), 23);
        assert!(c.starts_with("f897c"));
        assert_eq!(decompress_uuid(&c).as_deref(), Some(u));

        // 22-char `min=true` form (`2` literal hex + `10` pairs) decodes too.
        let min22 = "f8pfC8zqS1Fwavze8BI0V4";
        // Let's also verify a known 22-char roundtrip using the algorithm directly:
        let raw = "fc991dd7-0033-4b80-9d41-6e8f2c123456";
        let hex: Vec<u8> = raw.bytes().filter(u8::is_ascii_hexdigit).collect();
        let mut c22 = Vec::new();
        c22.extend_from_slice(&hex[..2]);
        for chunk in hex[2..].chunks_exact(3) {
            let (a, b, c) = (hex_val(chunk[0]), hex_val(chunk[1]), hex_val(chunk[2]));
            c22.push(BASE64_KEYS[((a << 2) | (b >> 2)) as usize]);
            c22.push(BASE64_KEYS[(((b & 0x3) << 4) | c) as usize]);
        }
        let s22 = String::from_utf8(c22).unwrap();
        assert_eq!(s22.len(), 22);
        assert_eq!(decompress_uuid(&s22).as_deref(), Some(raw));
        let _ = min22;
    }
}
