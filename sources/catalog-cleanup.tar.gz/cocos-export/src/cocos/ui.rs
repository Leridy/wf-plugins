//! `ui` kits -> `.png.meta` (9-slice borders) and per-widget Cocos Prefabs (`cc.Button`, `cc.Toggle`, `cc.ProgressBar`, `cc.Slider`).
use super::prefab::{BuiltinComponent, ButtonBody, PrefabBuilder, ProgressBarBody, SliderBody, ToggleBody};
use super::schema::{NodeRef, UuidRef};
use super::texture::{FilterMode, ResolvedSprites, SliceSpec, SpriteKey, TextureRegistry};
use super::uuid::uuid;
use super::{ExportTarget, Exported, StampKind, doc, join_rel, prefab_meta, rel_prefix};
use crate::model::{Kit, Style, WidgetKind, ui::Widget};
use crate::paths;
use crate::types::Element;
use std::collections::{BTreeMap, BTreeSet};

pub fn generate(kit: &Kit, target: ExportTarget<'_>, dims: &BTreeMap<String, (u32, u32)>) -> Exported {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let mut widget_keys: Vec<Vec<(Style, SpriteKey)>> = Vec::with_capacity(kit.widgets.len());

    for widget in &kit.widgets {
        let mut pairs = Vec::with_capacity(widget.states.len());
        for state in &widget.states {
            let key = registry.register(
                &state.texture.path,
                &format!("{}_{:?}", widget.name, state.style),
                SliceSpec {
                    rect: state.texture.region,
                    pivot: [0.5, 0.5],
                    border: state.slice.values(),
                    ppu: 100.0,
                    filter: FilterMode::Bilinear,
                },
            );
            pairs.push((state.style, key));
        }
        widget_keys.push(pairs);
    }

    for (idx, tex) in kit.extra_textures.iter().enumerate() {
        let _ = registry.register(
            &tex.path,
            &format!("extra_{idx}"),
            SliceSpec {
                rect: tex.region,
                pivot: [0.5, 0.5],
                border: [0.0; 4],
                ppu: 100.0,
                filter: FilterMode::Bilinear,
            },
        );
    }

    let (resolved, mut documents) = registry.build(target);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let mut used_stems = BTreeSet::new();
    let mut widget_prefabs: BTreeMap<usize, String> = BTreeMap::new();

    for (wi, widget) in kit.widgets.iter().enumerate() {
        let file_stem = unique_file_stem(&widget.name, wi, &mut used_stems);
        let prefab_body = build_widget_prefab(widget, &widget_keys[wi], &resolved, target.node_prefix);
        let prefab_rel = join_rel(dir_rel_prefix, &format!("{file_stem}.prefab"));
        let full_rel = paths::join(target.directory, &prefab_rel);
        let resource = paths::asset_path(target.root, &full_rel);
        let p_uuid = uuid(&format!("{}:ui:prefab:{file_stem}", target.node_prefix));

        documents.push(doc(
            target.directory,
            target.root,
            prefab_rel.clone(),
            prefab_body,
            StampKind::None,
        ));
        documents.push(doc(
            target.directory,
            target.root,
            format!("{prefab_rel}.meta"),
            prefab_meta(&p_uuid),
            StampKind::None,
        ));
        widget_prefabs.insert(widget.element, resource);
    }

    let elements = kit
        .elements
        .iter()
        .enumerate()
        .map(|(i, name)| Element {
            name: name.clone(),
            prefab: widget_prefabs.get(&i).cloned(),
        })
        .collect();

    Exported {
        documents,
        elements,
        notes: kit.notes.clone(),
    }
}

fn find_sf(pairs: &[(Style, SpriteKey)], resolved: &ResolvedSprites, styles: &[Style]) -> Option<String> {
    for want in styles {
        if let Some((_, key)) = pairs.iter().find(|(s, _)| *s == *want) {
            return Some(resolved.sprite_frame_uuid(key));
        }
    }
    pairs.first().map(|(_, k)| resolved.sprite_frame_uuid(k))
}

fn build_widget_prefab(
    widget: &Widget,
    pairs: &[(Style, SpriteKey)],
    resolved: &ResolvedSprites,
    node_prefix: &str,
) -> String {
    let sliced = widget.states.iter().any(|s| s.slice.values().iter().any(|v| *v > 0.0));
    let sprite_type = i32::from(sliced);
    let (w, h) = (widget.size.0.max(1.0), widget.size.1.max(1.0));
    let (mut pb, root) = PrefabBuilder::new(&format!("{node_prefix}:ui:{}", widget.name), &widget.name);
    pb.add_ui_transform(root, w, h, [0.5, 0.5]);

    match widget.kind {
        WidgetKind::Press => build_press(&mut pb, root, pairs, resolved, sprite_type),
        WidgetKind::Flip => build_flip(&mut pb, root, w, h, pairs, resolved, sprite_type),
        WidgetKind::Bar => build_bar(&mut pb, root, w, h, pairs, resolved, sprite_type),
        WidgetKind::Slide => build_slide(&mut pb, root, w, h, pairs, resolved, sprite_type),
    }
    pb.build()
}

fn build_press(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    pairs: &[(Style, SpriteKey)],
    resolved: &ResolvedSprites,
    sprite_type: i32,
) {
    let normal = find_sf(pairs, resolved, &[Style::Rest]);
    let hover = find_sf(pairs, resolved, &[Style::Hover, Style::Rest]);
    let pressed = find_sf(pairs, resolved, &[Style::Pressed, Style::Rest]);
    let disabled = find_sf(pairs, resolved, &[Style::Disabled, Style::Rest]);
    pb.add_sprite(root, normal.as_deref(), 0, sprite_type, [255, 255, 255, 255], None);
    pb.add_component(
        root,
        BuiltinComponent::Button(ButtonBody {
            transition: 2,
            target: root,
            normal_sprite: normal.map(UuidRef::new),
            hover_sprite: hover.map(UuidRef::new),
            pressed_sprite: pressed.map(UuidRef::new),
            disabled_sprite: disabled.map(UuidRef::new),
        }),
    );
}

fn build_flip(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    w: f64,
    h: f64,
    pairs: &[(Style, SpriteKey)],
    resolved: &ResolvedSprites,
    sprite_type: i32,
) {
    let off = find_sf(pairs, resolved, &[Style::Rest]);
    let on = find_sf(pairs, resolved, &[Style::Pressed, Style::HoverPressed, Style::Rest]);
    pb.add_sprite(root, off.as_deref(), 0, sprite_type, [255, 255, 255, 255], None);
    let check_node = pb.add_node(root, "Checkmark", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    pb.add_ui_transform(check_node, w, h, [0.5, 0.5]);
    let check_sp = pb.add_sprite(check_node, on.as_deref(), 0, sprite_type, [255, 255, 255, 255], None);
    pb.add_component(
        root,
        BuiltinComponent::Toggle(ToggleBody {
            is_checked: false,
            check_mark: check_sp,
        }),
    );
}

fn build_bar(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    w: f64,
    h: f64,
    pairs: &[(Style, SpriteKey)],
    resolved: &ResolvedSprites,
    sprite_type: i32,
) {
    let track = find_sf(pairs, resolved, &[Style::Track, Style::Rest]);
    let fill = find_sf(pairs, resolved, &[Style::Fill, Style::Rest]);
    pb.add_sprite(root, track.as_deref(), 0, sprite_type, [255, 255, 255, 255], None);
    let bar_node = pb.add_node(root, "Bar", [-w * 0.5, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    pb.add_ui_transform(bar_node, w, h, [0.0, 0.5]);
    let bar_sp = pb.add_sprite(bar_node, fill.as_deref(), 0, sprite_type, [255, 255, 255, 255], None);
    pb.add_component(
        root,
        BuiltinComponent::ProgressBar(ProgressBarBody {
            bar_sprite: bar_sp,
            total_length: w,
            progress: 1.0,
            mode: 0,
        }),
    );
}

fn build_slide(
    pb: &mut PrefabBuilder,
    root: NodeRef,
    w: f64,
    h: f64,
    pairs: &[(Style, SpriteKey)],
    resolved: &ResolvedSprites,
    sprite_type: i32,
) {
    let track = find_sf(pairs, resolved, &[Style::Track, Style::Rest]);
    let fill = find_sf(pairs, resolved, &[Style::Fill]);
    let thumb = find_sf(pairs, resolved, &[Style::Thumb, Style::Rest]);
    pb.add_sprite(root, track.as_deref(), 0, sprite_type, [255, 255, 255, 255], None);
    if fill.is_some() {
        let fill_node = pb.add_node(root, "Fill", [-w * 0.5, 0.0, 0.0], [1.0, 1.0, 1.0], true);
        pb.add_ui_transform(fill_node, w, h, [0.0, 0.5]);
        pb.add_sprite(fill_node, fill.as_deref(), 0, sprite_type, [255, 255, 255, 255], None);
    }
    let handle_node = pb.add_node(root, "Handle", [0.0, 0.0, 0.0], [1.0, 1.0, 1.0], true);
    let thumb_h = h.max(16.0);
    pb.add_ui_transform(handle_node, thumb_h, thumb_h, [0.5, 0.5]);
    pb.add_sprite(handle_node, thumb.as_deref(), 0, 0, [255, 255, 255, 255], None);
    pb.add_component(
        root,
        BuiltinComponent::Slider(SliderBody {
            handle: handle_node,
            direction: 0,
            progress: 0.5,
        }),
    );
}

fn unique_file_stem(name: &str, ordinal: usize, used: &mut BTreeSet<String>) -> String {
    let mut clean: String = name
        .trim()
        .chars()
        .map(|c| {
            if matches!(c, '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|') {
                '_'
            } else {
                c
            }
        })
        .collect();
    if clean.is_empty() {
        clean = format!("Widget_{ordinal}");
    }
    if used.insert(clean.clone()) {
        return clean;
    }
    let candidate = format!("{clean}_{ordinal}");
    used.insert(candidate.clone());
    candidate
}
