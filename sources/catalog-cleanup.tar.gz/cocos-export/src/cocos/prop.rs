//! `prop` -> `.png.meta`, per-object Prefabs (`cc.Sprite` + `cc.PolygonCollider2D` + optional `cc.Animation`).
use super::animation::{build_anim_clip, cocos_pivot};
use super::prefab::{AnimationBody, BuiltinComponent, PolygonCollider2DBody, PrefabBuilder};
use super::schema::UuidRef;
use super::texture::{FilterMode, ResolvedSprites, SliceSpec, SpriteKey, TextureRegistry};
use super::tilemap::poly_to_cc_vec2;
use super::uuid::uuid;
use super::{Document, ExportTarget, Exported, StampKind, anim_meta, doc, join_rel, prefab_meta, rel_prefix};
use crate::model::{Clip, Frame, Point, PropSet, prop::PropObject};
use crate::paths;
use crate::types::Element;
use std::collections::{BTreeMap, BTreeSet};

pub fn generate(props: &PropSet, target: ExportTarget<'_>, dims: &BTreeMap<String, (u32, u32)>) -> Exported {
    let mut registry = TextureRegistry::new(target.node_prefix, dims);
    let mut obj_state_keys: Vec<Vec<SpriteKey>> = Vec::with_capacity(props.objects.len());
    let mut obj_anim_keys: Vec<Vec<Vec<SpriteKey>>> = Vec::with_capacity(props.objects.len());

    for obj in &props.objects {
        let pivot = cocos_pivot(obj.anchor, obj.canvas_width, obj.canvas_height);
        let ppu = f64::from(obj.pixels_per_tile);
        let s_keys = obj
            .states
            .iter()
            .map(|st| {
                registry.register(
                    &st.texture.path,
                    &format!("{}_{}", obj.name, st.id),
                    SliceSpec {
                        rect: st.texture.region,
                        pivot,
                        border: [0.0; 4],
                        ppu,
                        filter: FilterMode::Bilinear,
                    },
                )
            })
            .collect();
        obj_state_keys.push(s_keys);

        let a_keys = obj
            .animations
            .iter()
            .map(|anim| {
                anim.textures
                    .iter()
                    .enumerate()
                    .map(|(fi, tex)| {
                        registry.register(
                            &tex.path,
                            &format!("{}_{}_{}", obj.name, anim.id, fi),
                            SliceSpec {
                                rect: tex.region,
                                pivot,
                                border: [0.0; 4],
                                ppu,
                                filter: FilterMode::Bilinear,
                            },
                        )
                    })
                    .collect()
            })
            .collect();
        obj_anim_keys.push(a_keys);
    }

    let (resolved, mut documents) = registry.build(target);
    let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
    let mut used_names = BTreeSet::new();
    let mut elements = Vec::with_capacity(props.objects.len());

    for (oi, obj) in props.objects.iter().enumerate() {
        let element = emit_prop_object(
            obj,
            oi,
            target,
            dir_rel_prefix,
            &obj_state_keys[oi],
            &obj_anim_keys[oi],
            &resolved,
            &mut used_names,
            &mut documents,
        );
        elements.push(element);
    }

    Exported {
        documents,
        elements,
        notes: props.notes.clone(),
    }
}

#[allow(clippy::too_many_arguments)]
fn emit_prop_object(
    obj: &PropObject,
    oi: usize,
    target: ExportTarget<'_>,
    dir_rel_prefix: &str,
    state_keys: &[SpriteKey],
    anim_keys: &[Vec<SpriteKey>],
    resolved: &ResolvedSprites,
    used_names: &mut BTreeSet<String>,
    documents: &mut Vec<Document>,
) -> Element {
    let stem = unique_prop_stem(&obj.name, oi, used_names);
    let pivot = cocos_pivot(obj.anchor, obj.canvas_width, obj.canvas_height);
    let (mut pb, root) = PrefabBuilder::new(&format!("{}:prop:{stem}", target.node_prefix), &obj.name);
    pb.add_ui_transform(root, obj.canvas_width, obj.canvas_height, pivot);

    let default_sf = resolved.sprite_frame_uuid(&state_keys[0]);
    pb.add_sprite(root, Some(&default_sf), 2, 0, [255, 255, 255, 255], None);

    for (pi, poly) in obj.states[0].collision.iter().enumerate() {
        if poly.len() < 3 {
            continue;
        }
        let local_pts: Vec<Point> = poly
            .iter()
            .map(|p| Point {
                x: p.x - obj.anchor.x,
                y: p.y - obj.anchor.y,
            })
            .collect();
        pb.add_component(
            root,
            BuiltinComponent::PolygonCollider2D(PolygonCollider2DBody {
                tag: Some(pi),
                sensor: false,
                points: poly_to_cc_vec2(&local_pts),
            }),
        );
    }

    if !obj.animations.is_empty() {
        let mut clip_uuids = Vec::with_capacity(obj.animations.len());
        for (ai, trans) in obj.animations.iter().enumerate() {
            let frames = trans
                .textures
                .iter()
                .enumerate()
                .map(|(fi, t)| Frame {
                    texture: t.clone(),
                    duration_ms: trans.durations_ms.get(fi).copied().unwrap_or(100.0),
                })
                .collect();
            let clip = Clip {
                name: trans.id.clone(),
                frames,
                looped: trans.looped,
                anchor: obj.anchor,
            };
            let anim_rel = join_rel(dir_rel_prefix, &format!("{stem}_{}.anim", trans.id));
            let anim_uuid = uuid(&format!("{}:prop:anim:{stem}:{}", target.node_prefix, trans.id));
            documents.push(doc(
                target.directory,
                target.root,
                anim_rel.clone(),
                build_anim_clip(&trans.id, &clip, &anim_keys[ai], resolved),
                StampKind::None,
            ));
            documents.push(doc(
                target.directory,
                target.root,
                format!("{anim_rel}.meta"),
                anim_meta(&anim_uuid),
                StampKind::None,
            ));
            clip_uuids.push(anim_uuid);
        }
        let clip_refs: Vec<UuidRef> = clip_uuids.iter().map(UuidRef::new).collect();
        let default_clip = clip_uuids.first().map(UuidRef::new);
        pb.add_component(
            root,
            BuiltinComponent::Animation(AnimationBody {
                clips: clip_refs,
                default_clip,
                play_on_load: false,
            }),
        );
    }

    let prefab_rel = join_rel(dir_rel_prefix, &format!("{stem}.prefab"));
    let p_uuid = uuid(&format!("{}:prop:prefab:{stem}", target.node_prefix));
    let full_rel = paths::join(target.directory, &prefab_rel);
    let resource = paths::asset_path(target.root, &full_rel);
    documents.push(doc(
        target.directory,
        target.root,
        prefab_rel.clone(),
        pb.build(),
        StampKind::None,
    ));
    documents.push(doc(
        target.directory,
        target.root,
        format!("{prefab_rel}.meta"),
        prefab_meta(&p_uuid),
        StampKind::None,
    ));
    Element {
        name: obj.name.clone(),
        prefab: Some(resource),
    }
}

fn unique_prop_stem(name: &str, idx: usize, used: &mut BTreeSet<String>) -> String {
    let mut clean: String = name
        .trim()
        .chars()
        .map(|c| {
            if matches!(c, '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|') {
                '_'
            } else {
                c
            }
        })
        .collect();
    if clean.is_empty() {
        clean = format!("Prop_{idx}");
    }
    if used.insert(clean.clone()) {
        return clean;
    }
    let candidate = format!("{clean}_{idx}");
    used.insert(candidate.clone());
    candidate
}
