//! `.png.meta` (`1.0.27`) sprite-frame registry with slices, bottom-left pivots, 9-slice borders, and filter modes.
use super::schema::{
    AssetMeta, ImageMetaUserData, SpriteFrameSubMetas, SpriteFrameUserData, SubMeta, serialize_pretty,
};
use super::uuid::uuid;
use super::{Document, ExportTarget, StampKind, doc, join_rel, rel_prefix};
use crate::model::Rect;
use std::collections::{BTreeMap, BTreeSet};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FilterMode {
    Bilinear,
    Point,
}

#[derive(Clone, Copy, Debug)]
pub struct SliceSpec {
    pub rect: Option<Rect>,
    /// Cocos bottom-left normalized pivot (`[0..1, 0..1]`).
    pub pivot: [f64; 2],
    /// Cocos `[left, right, top, bottom]` borders.
    pub border: [f64; 4],
    pub ppu: f64,
    pub filter: FilterMode,
}

#[derive(Clone, Debug)]
pub struct SpriteKey {
    pub tex_path: String,
    pub sub_id: String,
}

struct RegisteredSlice {
    name: String,
    sub_id: String,
    spec: SliceSpec,
}

pub struct TextureRegistry<'a> {
    node_prefix: &'a str,
    dims: &'a BTreeMap<String, (u32, u32)>,
    slices: BTreeMap<String, Vec<RegisteredSlice>>,
    used_sub_ids: BTreeMap<String, BTreeSet<String>>,
}

pub struct ResolvedSprites {
    img_uuids: BTreeMap<String, String>,
}

impl ResolvedSprites {
    pub fn sprite_frame_uuid(&self, key: &SpriteKey) -> String {
        let img = &self.img_uuids[&key.tex_path];
        format!("{img}@{}", key.sub_id)
    }

    pub fn texture_uuid(&self, tex_path: &str) -> &str {
        &self.img_uuids[tex_path]
    }
}

impl<'a> TextureRegistry<'a> {
    pub fn new(node_prefix: &'a str, dims: &'a BTreeMap<String, (u32, u32)>) -> Self {
        Self {
            node_prefix,
            dims,
            slices: BTreeMap::new(),
            used_sub_ids: BTreeMap::new(),
        }
    }

    pub fn register(&mut self, tex_path: &str, name: &str, spec: SliceSpec) -> SpriteKey {
        let entry = self.slices.entry(tex_path.to_owned()).or_default();
        if let Some(existing) = entry.iter().find(|s| same_slice(s.spec, spec)) {
            return SpriteKey {
                tex_path: tex_path.to_owned(),
                sub_id: existing.sub_id.clone(),
            };
        }
        let used = self.used_sub_ids.entry(tex_path.to_owned()).or_default();
        let sub_id = if entry.is_empty() && used.insert("f9941".to_owned()) {
            "f9941".to_owned()
        } else {
            let mut n = entry.len();
            loop {
                let candidate = format!("f{:04x}", 0x9941usize + n);
                if used.insert(candidate.clone()) {
                    break candidate;
                }
                n += 1;
            }
        };
        entry.push(RegisteredSlice {
            name: name.to_owned(),
            sub_id: sub_id.clone(),
            spec,
        });
        SpriteKey {
            tex_path: tex_path.to_owned(),
            sub_id,
        }
    }

    pub fn build(self, target: ExportTarget<'_>) -> (ResolvedSprites, Vec<Document>) {
        let dir_rel_prefix = rel_prefix(target.node_dir, target.directory);
        let mut img_uuids = BTreeMap::new();
        let mut docs = Vec::with_capacity(self.slices.len());

        for (tex_path, items) in self.slices {
            let (raw_w, raw_h) = self.dims.get(&tex_path).copied().unwrap_or((1, 1));
            let img_uuid = uuid(&format!("{}:img:{tex_path}", self.node_prefix));
            let first_sub_uuid = format!("{img_uuid}@{}", items[0].sub_id);
            let mut sub_metas = SpriteFrameSubMetas::new();
            let point = items.iter().any(|s| s.spec.filter == FilterMode::Point);

            for slice in &items {
                let sub_uuid = format!("{img_uuid}@{}", slice.sub_id);
                let rect = slice.spec.rect.unwrap_or(Rect {
                    x: 0.0,
                    y: 0.0,
                    w: f64::from(raw_w),
                    h: f64::from(raw_h),
                });
                let user_data = SpriteFrameUserData {
                    trim_type: "none",
                    trim_threshold: -1,
                    rotated: false,
                    offset_x: 0,
                    offset_y: 0,
                    trim_x: rect.x.round() as i64,
                    trim_y: rect.y.round() as i64,
                    width: rect.w.max(1.0).round() as u32,
                    height: rect.h.max(1.0).round() as u32,
                    raw_width: raw_w,
                    raw_height: raw_h,
                    border_top: slice.spec.border[2].round() as u32,
                    border_bottom: slice.spec.border[3].round() as u32,
                    border_left: slice.spec.border[0].round() as u32,
                    border_right: slice.spec.border[1].round() as u32,
                    pivot_x: slice.spec.pivot[0],
                    pivot_y: slice.spec.pivot[1],
                    is_trimmed: slice.spec.rect.is_some(),
                    pixels_to_unit: slice.spec.ppu.round() as u32,
                    filter_mode: (slice.spec.filter == FilterMode::Point).then_some("point"),
                };
                sub_metas.insert(
                    slice.sub_id.clone(),
                    SubMeta {
                        importer: "sprite-frame",
                        uuid: sub_uuid,
                        display_name: &slice.name,
                        id: &slice.sub_id,
                        name: &slice.name,
                        user_data,
                    },
                );
            }

            let meta_json = serialize_pretty(&AssetMeta {
                ver: "1.0.27",
                importer: "image",
                imported: true,
                uuid: &img_uuid,
                files: vec![".json", ".png"],
                sub_metas,
                user_data: ImageMetaUserData {
                    kind: "sprite-frame",
                    fix_alpha_transparency_artifacts: !point,
                    has_alpha: true,
                    filter_mode: if point { "point" } else { "bilinear" },
                    redirect: first_sub_uuid,
                },
            });

            let rel = join_rel(dir_rel_prefix, &format!("{tex_path}.meta"));
            docs.push(doc(target.directory, target.root, rel, meta_json, StampKind::None));
            img_uuids.insert(tex_path, img_uuid);
        }

        (ResolvedSprites { img_uuids }, docs)
    }
}

fn same_slice(a: SliceSpec, b: SliceSpec) -> bool {
    let same_rect = match (a.rect, b.rect) {
        (Some(ra), Some(rb)) => {
            (ra.x - rb.x).abs() < 1e-4
                && (ra.y - rb.y).abs() < 1e-4
                && (ra.w - rb.w).abs() < 1e-4
                && (ra.h - rb.h).abs() < 1e-4
        }
        (None, None) => true,
        _ => false,
    };
    same_rect
        && a.filter == b.filter
        && (a.ppu - b.ppu).abs() < 1e-4
        && (0..2).all(|i| (a.pivot[i] - b.pivot[i]).abs() < 1e-4)
        && (0..4).all(|i| (a.border[i] - b.border[i]).abs() < 1e-4)
}
