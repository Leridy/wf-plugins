//! Minimal PNG header reader for extracting exact pixel dimensions without decoding pixels.
use crate::paths::invalid;
use plugin_guest::HostError;

const SIGNATURE: &[u8; 8] = b"\x89PNG\r\n\x1a\n";
const MAX_DIMENSION: u32 = 16_384;

/// Parse `(width, height)` from a PNG's IHDR chunk.
pub fn dimensions(bytes: &[u8]) -> Result<(u32, u32), HostError> {
    if bytes.len() < 24 || &bytes[..8] != SIGNATURE {
        return Err(invalid("expected a valid PNG file header"));
    }
    let chunk_len = u32::from_be_bytes([bytes[8], bytes[9], bytes[10], bytes[11]]);
    if chunk_len < 13 || &bytes[12..16] != b"IHDR" {
        return Err(invalid("PNG file does not start with a valid IHDR chunk"));
    }
    let width = u32::from_be_bytes([bytes[16], bytes[17], bytes[18], bytes[19]]);
    let height = u32::from_be_bytes([bytes[20], bytes[21], bytes[22], bytes[23]]);
    if width == 0 || height == 0 || width > MAX_DIMENSION || height > MAX_DIMENSION {
        return Err(invalid(format!(
            "PNG dimensions {width}x{height} are outside supported bounds (1..={MAX_DIMENSION})"
        )));
    }
    Ok((width, height))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_ihdr_dimensions_and_rejects_corrupt_headers() {
        let mut png = Vec::from(*SIGNATURE);
        png.extend_from_slice(&13u32.to_be_bytes());
        png.extend_from_slice(b"IHDR");
        png.extend_from_slice(&64u32.to_be_bytes());
        png.extend_from_slice(&32u32.to_be_bytes());
        assert_eq!(dimensions(&png).unwrap(), (64, 32));

        assert!(dimensions(b"not a png").is_err());
        let mut zero = png.clone();
        zero[16..20].copy_from_slice(&0u32.to_be_bytes());
        assert!(dimensions(&zero).is_err());
    }
}
