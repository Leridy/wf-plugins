//! Minimal, lenient readers of CLI sidecars, not dependencies on server models.
use super::{Margins, Point, Rect};
use serde::Deserialize;
use std::collections::BTreeMap;

#[derive(Deserialize)]
pub struct Animation {
    pub images: BTreeMap<String, Image>,
    pub clips: Vec<Clip>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Clip {
    pub action_id: String,
    pub direction: String,
    pub files: Vec<String>,
    pub durations_ms: Vec<f64>,
    #[serde(rename = "loop")]
    pub looped: bool,
    pub anchor: Point,
}

#[derive(Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum Image {
    Png { path: String },
    Strip { path: String, frame: Rect },
    Atlas { path: String, frame: Rect },
}

#[derive(Deserialize)]
pub struct Kit {
    pub images: BTreeMap<String, Image>,
    pub elements: Vec<Element>,
}

#[derive(Deserialize)]
pub struct Element {
    pub kind: String,
    pub name: String,
    pub size: Size,
    pub states: Vec<State>,
    pub widget: Widget,
}

#[derive(Deserialize)]
pub struct Size {
    pub width: f64,
    pub height: f64,
}

#[derive(Deserialize)]
pub struct State {
    pub name: String,
    pub file: String,
    // Snake case on disk, matching WeaveForge ui.json.
    pub text_safe: Option<Rect>,
    pub role: Option<Role>,
    pub slice: Slice,
}

#[derive(Deserialize)]
pub struct Slice {
    pub mode: SliceMode,
    pub borders: Margins,
}

#[derive(Clone, Copy, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SliceMode {
    Fixed,
    Three,
    Nine,
}

#[derive(Deserialize)]
#[serde(tag = "type", rename_all = "lowercase")]
pub enum Widget {
    Press,
    Flip,
    Bar { fills: Vec<Fill> },
    Slide,
    Switch,
    Ring,
    Stick,
    Parts,
    States,
}

#[derive(Deserialize)]
pub struct Fill {
    pub amount: f64,
    pub cell: Cell,
}

#[derive(Deserialize)]
pub struct Cell {
    pub name: String,
}

#[derive(Clone, Copy, Deserialize, Eq, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum Role {
    Rest,
    Hover,
    Pressed,
    Disabled,
    Off,
    OffHover,
    On,
    OnHover,
    OffDisabled,
    Track,
    Fill,
    Thumb,
    ThumbHover,
    ThumbDisabled,
    #[serde(other)]
    Other,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Props {
    pub images: BTreeMap<String, Image>,
    pub objects: Vec<PropObject>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PropObject {
    pub id: String,
    pub name: String,
    pub canvas: Size,
    pub anchor: Point,
    pub anchor_kind: PropAnchorKind,
    pub pixels_per_tile: u32,
    pub states: Vec<PropState>,
    #[serde(default)]
    pub animations: Vec<PropAnimation>,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum PropAnchorKind {
    Foot,
    Hang,
    Center,
}

#[derive(Deserialize)]
pub struct PropState {
    pub id: String,
    pub file: String,
    #[serde(default)]
    pub collision: Vec<Vec<Point>>,
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PropAnimation {
    pub id: String,
    pub files: Vec<String>,
    pub durations_ms: Vec<f64>,
    #[serde(rename = "loop")]
    pub looped: bool,
}
