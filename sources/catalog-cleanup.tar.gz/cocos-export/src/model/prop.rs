//! Resolve prop set objects, anchors, states, transition clips, and 2D collision polygons.
use super::{Point, Texture, parse, report, texture};
use crate::paths::invalid;
use plugin_guest::HostError;
use std::collections::{BTreeMap, BTreeSet};

#[derive(Debug)]
pub struct PropState {
    pub id: String,
    pub texture: Texture,
    pub collision: Vec<Vec<Point>>,
}

#[derive(Debug)]
pub struct PropTransition {
    pub id: String,
    pub textures: Vec<Texture>,
    pub durations_ms: Vec<f64>,
    pub looped: bool,
}

#[derive(Debug)]
pub struct PropObject {
    pub name: String,
    pub canvas_width: f64,
    pub canvas_height: f64,
    pub anchor: Point,
    pub pixels_per_tile: u32,
    pub states: Vec<PropState>,
    pub animations: Vec<PropTransition>,
}

#[derive(Debug)]
pub struct PropSet {
    pub objects: Vec<PropObject>,
    pub notes: Vec<String>,
}

impl PropSet {
    pub fn read(bytes: &[u8]) -> Result<Self, HostError> {
        let doc: report::Props = parse(bytes)?;
        if doc.objects.is_empty() {
            return Err(invalid("props.json has no objects"));
        }
        let mut seen_ids = BTreeSet::new();
        let mut objects = Vec::with_capacity(doc.objects.len());
        let mut notes = Vec::new();
        for obj in doc.objects {
            if obj.id.is_empty() || !seen_ids.insert(obj.id.clone()) {
                return Err(invalid("props.json has empty or duplicate object id"));
            }
            objects.push(parse_object(&doc.images, obj, &mut notes)?);
        }
        Ok(Self { objects, notes })
    }
}

fn parse_object(
    images: &BTreeMap<String, report::Image>,
    obj: report::PropObject,
    notes: &mut Vec<String>,
) -> Result<PropObject, HostError> {
    if obj.pixels_per_tile == 0
        || !obj.canvas.width.is_finite()
        || obj.canvas.width <= 0.0
        || !obj.canvas.height.is_finite()
        || obj.canvas.height <= 0.0
        || !obj.anchor.x.is_finite()
        || !obj.anchor.y.is_finite()
    {
        return Err(invalid(format!(
            "{}: invalid canvas, anchor or pixelsPerTile",
            obj.name
        )));
    }
    if obj.states.is_empty() {
        return Err(invalid(format!("{}: prop object has no states", obj.name)));
    }
    let mut state_ids = BTreeSet::new();
    let mut states = Vec::with_capacity(obj.states.len());
    for state in obj.states {
        if state.id.is_empty() || !state_ids.insert(state.id.clone()) {
            return Err(invalid(format!("{}: empty or duplicate prop state", obj.name)));
        }
        for poly in &state.collision {
            if poly.iter().any(|p| !p.x.is_finite() || !p.y.is_finite()) {
                return Err(invalid(format!("{}: invalid prop collision point", obj.name)));
            }
        }
        states.push(PropState {
            id: state.id,
            texture: texture(images, &state.file)?,
            collision: state.collision,
        });
    }
    let mut anim_ids = BTreeSet::new();
    let mut animations = Vec::with_capacity(obj.animations.len());
    for anim in obj.animations {
        if anim.id.is_empty() || !anim_ids.insert(anim.id.clone()) {
            return Err(invalid(format!("{}: empty or duplicate prop animation id", obj.name)));
        }
        if anim.files.is_empty()
            || anim.files.len() != anim.durations_ms.len()
            || anim.durations_ms.iter().any(|d| !d.is_finite() || *d <= 0.0)
        {
            return Err(invalid(format!("{}: invalid prop animation timing or frames", anim.id)));
        }
        let textures = anim
            .files
            .iter()
            .map(|f| texture(images, f))
            .collect::<Result<Vec<_>, _>>()?;
        animations.push(PropTransition {
            id: anim.id,
            textures,
            durations_ms: anim.durations_ms,
            looped: anim.looped,
        });
    }
    let _ = &obj.anchor_kind;
    if states.len() > 1 && animations.is_empty() {
        notes.push(format!(
            "{}: has {} states with no transition animations; the prefab defaults to state {:?}.",
            obj.name,
            states.len(),
            states[0].id
        ));
    }
    Ok(PropObject {
        name: obj.name,
        canvas_width: obj.canvas.width,
        canvas_height: obj.canvas.height,
        anchor: obj.anchor,
        pixels_per_tile: obj.pixels_per_tile,
        states,
        animations,
    })
}
