//! The official `cocos-export` plugin: turns ready `wf export` outputs into
//! deterministic Cocos Creator 3.x `.meta` assets, `.prefab` hierarchies,
//! `.anim` clips, `.tmx` tilemaps, particle/parallax/nav scripts, and
//! manifest-tracked safe writes.
#![cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "the component glue that calls into these is wasm-only")
)]

mod cocos;
#[cfg(target_arch = "wasm32")]
mod component;
mod describe;
mod gather;
mod model;
mod paths;
mod reconcile;
mod table;
mod types;

pub use gather::sync;
pub use types::{Element, File, Input, Node, Output, Plan, Status};
