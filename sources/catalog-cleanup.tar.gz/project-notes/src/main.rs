//! An intentionally small native MCP server. stdout belongs exclusively to MCP.
use rmcp::{
    ErrorData, ServerHandler, ServiceExt,
    handler::server::{router::tool::ToolRouter, wrapper::Parameters},
    model::{CallToolResult, Content, Implementation, ServerCapabilities, ServerInfo},
    tool, tool_handler, tool_router,
};
use schemars::JsonSchema;
use serde::Deserialize;
use std::{
    fs::{self, OpenOptions},
    io::Write,
    path::Path,
};

#[derive(Clone)]
struct Notes {
    tool_router: ToolRouter<Self>,
}

#[derive(Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
struct WriteNote {
    /// A new Markdown filename, e.g. ideas.md. No directory components.
    name: String,
    /// Markdown text, at most 64 KiB.
    text: String,
}

fn failed(message: impl ToString) -> CallToolResult {
    CallToolResult::error(vec![Content::text(message.to_string())])
}

#[tool_router]
impl Notes {
    fn new() -> Self {
        Self {
            tool_router: Self::tool_router(),
        }
    }

    #[tool(
        description = "List Markdown notes in the project's notes directory",
        annotations(
            read_only_hint = true,
            destructive_hint = false,
            idempotent_hint = true,
            open_world_hint = false
        )
    )]
    fn list_notes(&self) -> Result<CallToolResult, ErrorData> {
        let directory = Path::new("notes");
        if !directory.exists() {
            return Ok(CallToolResult::success(vec![Content::text("No notes yet.")]));
        }
        if directory.is_symlink() {
            return Ok(failed("The notes directory must not be a symlink."));
        }
        let entries = match fs::read_dir(directory) {
            Ok(entries) => entries,
            Err(error) => return Ok(failed(error)),
        };
        let mut names = Vec::new();
        for entry in entries {
            let entry = match entry {
                Ok(entry) => entry,
                Err(error) => return Ok(failed(error)),
            };
            if entry.file_type().is_ok_and(|kind| kind.is_file())
                && entry.path().extension().is_some_and(|ext| ext == "md")
            {
                names.push(entry.file_name().to_string_lossy().into_owned());
            }
            if names.len() > 1000 {
                return Ok(failed("Too many notes to list (limit 1000)."));
            }
        }
        names.sort();
        Ok(CallToolResult::success(vec![Content::text(if names.is_empty() {
            "No notes yet.".into()
        } else {
            names.join("\n")
        })]))
    }

    #[tool(
        description = "Create a Markdown note in notes/; never overwrite an existing file",
        annotations(
            read_only_hint = false,
            destructive_hint = false,
            idempotent_hint = false,
            open_world_hint = false
        )
    )]
    fn write_note(&self, Parameters(input): Parameters<WriteNote>) -> Result<CallToolResult, ErrorData> {
        if input.name.len() > 120
            || !input.name.ends_with(".md")
            || input.name.starts_with('.')
            || !input
                .name
                .chars()
                .all(|c| c.is_ascii_alphanumeric() || "-_ .".contains(c))
            || input.text.len() > 64 * 1024
        {
            return Ok(failed(
                "Use a simple .md filename (120 bytes maximum) and text up to 64 KiB.",
            ));
        }
        let directory = Path::new("notes");
        if directory.is_symlink() {
            return Ok(failed("The notes directory must not be a symlink."));
        }
        if let Err(error) = fs::create_dir_all(directory) {
            return Ok(failed(error));
        }
        let mut file = match OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(directory.join(&input.name))
        {
            Ok(file) => file,
            Err(error) => return Ok(failed(error)),
        };
        if let Err(error) = file.write_all(input.text.as_bytes()) {
            return Ok(failed(error));
        }
        Ok(CallToolResult::success(vec![Content::text(format!(
            "Created notes/{}",
            input.name
        ))]))
    }
}

#[tool_handler]
impl ServerHandler for Notes {
    fn get_info(&self) -> ServerInfo {
        ServerInfo {
            capabilities: ServerCapabilities::builder().enable_tools().build(),
            server_info: Implementation {
                name: "project-notes".into(),
                version: env!("CARGO_PKG_VERSION").into(),
                ..Default::default()
            },
            ..Default::default()
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let service = Notes::new().serve(rmcp::transport::stdio()).await?;
    service.waiting().await?;
    Ok(())
}
