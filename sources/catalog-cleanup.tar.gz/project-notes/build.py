#!/usr/bin/env python3
"""Build the selected target into the package layout; sign macOS after copying."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("target", choices=["macos-arm64", "windows-x64"])
parser.add_argument("--debug", action="store_true")
parser.add_argument("--offline", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parent
triple, filename = {
    "macos-arm64": ("aarch64-apple-darwin", "project-notes"),
    "windows-x64": ("x86_64-pc-windows-msvc", "project-notes.exe"),
}[args.target]
target_dir = Path(os.environ.get("CARGO_TARGET_DIR", root / "target")).resolve()
command = ["cargo", "build", "--locked", "--manifest-path", str(root / "Cargo.toml"), "--target", triple]
if not args.debug:
    command.append("--release")
if args.offline:
    command.append("--offline")
subprocess.run(command, check=True)
destination = root / "bin" / args.target / filename
destination.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(target_dir / triple / ("debug" if args.debug else "release") / filename, destination)
if args.target == "macos-arm64":
    subprocess.run(["codesign", "--force", "--sign", "-", str(destination)], check=True)
    subprocess.run(["codesign", "--verify", "--strict", str(destination)], check=True)
print(destination)
