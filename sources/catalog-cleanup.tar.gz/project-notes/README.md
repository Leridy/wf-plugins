# Project notes

Developer example only. This plugin is no longer listed in the default WeaveForge
plugin catalog. Its source and historical packages remain available for MCP development
and existing installations; this does not uninstall it from any computer.

An official example of a native stdio MCP plugin. The server uses the
[official Rust MCP SDK](https://github.com/modelcontextprotocol/rust-sdk)
(`rmcp` pinned to 0.8.5) and communicates only through stdin/stdout. It has no
network dependency, environment configuration, API key or plugin settings.

| Operation | MCP tool | Risk | Result |
| --- | --- | --- | --- |
| `list-notes` | `list_notes` | Read | Sorted Markdown filenames in the project's `notes/` directory |
| `write-note` | `write_note` | HighRisk | Creates `notes/<name>.md`; refuses to overwrite an existing file |

The program runs in the chosen project directory. It is a native program,
not sandboxed. Installing or linking it always asks a person; a write follows
the client's native-call approval rule. A dry run shows the proposed call
without starting the server. Failed writes may have left partial files.

## Build and pack

Use Rust and Python 3. On macOS arm64:

```sh
python3 build.py macos-arm64
wf plugin pack . --target macos-arm64 --out dist
```

The build copies the binary to `bin/macos-arm64/project-notes`, signs it
ad-hoc with `codesign --force --sign -`, and verifies the signature. Pack
writes `mcp-tools.json` from the running server and produces
`project-notes-0.1.1-macos-arm64.wfplugin`. The checked-in snapshot is an
example output of this handshake, not a manually maintained schema.

On Windows x64, use the MSVC Rust target and Visual Studio C++ build tools:

```sh
python build.py windows-x64
wf plugin pack . --target windows-x64 --out dist
```

This copies `bin/windows-x64/project-notes.exe` and packs
`project-notes-0.1.1-windows-x64.wfplugin`. Each archive contains only its own
platform's executable. To pack another platform on a build host, first copy
that platform's built binary into its declared path; the host binary is still
needed to obtain the common tool snapshot. Do not substitute a macOS binary
for an unbuilt Windows executable.

`build.py --debug` produces a faster local build; `--offline` prohibits Cargo
network access once dependencies have been fetched. `CARGO_TARGET_DIR` is
respected. `bin/`, `dist/` and `target/` are ignored build artifacts.

## Try it locally

After packing, link the example in a scratch project and approve the native
program grant in the client:

```sh
wf plugin link . --project /absolute/path/to/scratch --yes
wf project-notes list-notes --project /absolute/path/to/scratch
wf project-notes write-note --name ideas.md --text 'Try a shorter tutorial' --project /absolute/path/to/scratch --dry-run
wf project-notes write-note --name ideas.md --text 'Try a shorter tutorial' --project /absolute/path/to/scratch --yes
```

Rebuild → pack → relink after changing the program. Its identity binds the
manifest, snapshot and executable. Distribution additionally requires an
Ed25519 signature and an official or already trusted signed index; installing
a native archive directly by local filename is intentionally refused.

The Agent uses `Plugin` with `action: "describe", plugin: "project-notes"`,
then adds `op: "write-note"` to inspect that operation's schema. Invoke with
`action: "run", op: "write-note", input: {"name":"ideas.md","text":"..."}`.

## Offline acceptance

```sh
CARGO_TARGET_DIR=/private/tmp/wf-m5b-target/project-notes python3 build.py macos-arm64 --offline --debug
CARGO_TARGET_DIR=/private/tmp/wf-m5b-target cargo test -q -p plugin-runtime --test project_notes -- --ignored --nocapture
```

The ignored integration test requires the built host executable. It packs a
copy, links it in an isolated configuration directory, asserts native approval,
describes without starting a program, checks dry-run and unapproved-write
behavior, then reads and writes through approval. It also checks `isError`
on a duplicate filename and refusal after disabling the plugin. It does not
contact an index, mutate the user's registry, or access the network.
