//! Memory-ceiling check with multiple 4 MiB `.prefab` and `.ts` inputs.
use globset::Glob;
use plugin_api::Failure;
use plugin_guest::{Host, HostError};
use plugin_protocols::lint::LintInput;
use std::collections::BTreeMap;

struct BigHost(BTreeMap<String, Vec<u8>>);

impl Host for BigHost {
    fn list(&self, pattern: &str) -> Vec<String> {
        let matcher = Glob::new(pattern).unwrap().compile_matcher();
        self.0.keys().filter(|k| matcher.is_match(k)).cloned().collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.0
            .get(path)
            .cloned()
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }

    fn warn(&self, _: &str) {}
}

#[test]
fn hostile_four_mib_prefabs_and_scripts_lint_without_oom() {
    let mut files = BTreeMap::new();
    files.insert("package.json".into(), b"{}".to_vec());
    // 4 MiB JSON array of benign cc.Node entries + 4 MiB TypeScript file.
    let mut big_prefab = String::from("[{\"__type__\":\"cc.Prefab\",\"data\":{\"__id__\":1}}");
    for _ in 0..45_000 {
        big_prefab.push_str(",{\"__type__\":\"cc.Node\",\"_name\":\"Node\",\"_active\":true}");
    }
    big_prefab.push(']');
    let mut big_ts = String::new();
    for i in 0..80_000 {
        use std::fmt::Write;
        writeln!(big_ts, "export const v{i} = {i};").unwrap();
    }

    for k in 0..2 {
        let pf = format!("assets/Prefabs/Big{k}.prefab");
        let pfm = format!("{pf}.meta");
        files.insert(pf, big_prefab.as_bytes().to_vec());
        files.insert(
            pfm,
            format!("{{\"uuid\":\"00000000-0000-4000-8000-00000000001{k}\"}}").into_bytes(),
        );
        let ts = format!("assets/Scripts/Big{k}.ts");
        let tsm = format!("{ts}.meta");
        files.insert(ts, big_ts.as_bytes().to_vec());
        files.insert(
            tsm,
            format!("{{\"uuid\":\"00000000-0000-4000-8000-00000000002{k}\",\"importer\":\"typescript\"}}").into_bytes(),
        );
    }

    let out = wf_cocos::lint(&BigHost(files), &LintInput::default());
    assert!(out.diagnostics.is_empty(), "{:?}", out.diagnostics);
}
