//! Checks TypeScript/JavaScript `resources.load*` paths for missing targets or case mismatches.
use crate::{
    message,
    project::{Layout, in_scope},
};
use plugin_guest::Host;
use plugin_protocols::lint::{Diagnostic, Fix, Span, TextEdit};
use std::collections::BTreeMap;
use std::str::from_utf8;

const SUB_ASSET_SUFFIXES: &[&str] = &[
    "/spriteFrame",
    "/texture",
    "/imageAsset",
    "/animationClip",
    "/audioClip",
];

pub fn check_scripts(
    host: &dyn Host,
    layout: &Layout,
    paths: &[String],
    checked: &mut Vec<String>,
    diagnostics: &mut Vec<Diagnostic>,
) {
    let resources_root = format!("{}resources/", layout.assets_prefix());
    let (exact_map, lower_map) = index_resources(&resources_root, &layout.assets);

    for script in &layout.scripts {
        if !in_scope(script, paths) {
            continue;
        }
        checked.push(script.clone());
        let Ok(bytes) = host.read(script) else {
            continue;
        };
        let Ok(text) = from_utf8(&bytes) else {
            continue;
        };
        for (start, end, raw_path) in extract_resource_calls(text) {
            let clean = strip_sub_suffix(&raw_path);
            let clean_no_ext = strip_ext(clean);
            if exact_map.contains_key(clean) || exact_map.contains_key(clean_no_ext) {
                continue;
            }
            let span = Span {
                start: u32::try_from(start).unwrap_or(0),
                end: u32::try_from(end).unwrap_or(0),
            };
            let lower_key = clean_no_ext.to_ascii_lowercase();
            if let Some(actual) = lower_map.get(&lower_key) {
                let suffix = &raw_path[clean.len()..];
                let replacement = format!("{actual}{suffix}");
                diagnostics.push(message::warning(
                    "resource-path-case",
                    script,
                    Some(span),
                    format!(
                        "Case mismatch in resources path `{raw_path}`; on case-sensitive builds use `{replacement}`."
                    ),
                    Some(Fix {
                        summary: format!("Use exact resource case `{replacement}`"),
                        edits: vec![TextEdit {
                            file: script.clone(),
                            span,
                            text: replacement,
                        }],
                    }),
                ));
            } else {
                diagnostics.push(message::error(
                    "missing-resource-path",
                    script,
                    Some(span),
                    format!("Resource `{raw_path}` does not exist under `{resources_root}`."),
                    None,
                ));
            }
        }
    }
}

fn index_resources(root: &str, assets: &[String]) -> (BTreeMap<String, String>, BTreeMap<String, String>) {
    let mut exact = BTreeMap::new();
    let mut lower = BTreeMap::new();
    for path in assets {
        let Some(rel) = path.strip_prefix(root) else {
            continue;
        };
        let without_ext = strip_ext(rel);
        exact.insert(rel.to_owned(), without_ext.to_owned());
        exact.insert(without_ext.to_owned(), without_ext.to_owned());
        lower.insert(rel.to_ascii_lowercase(), without_ext.to_owned());
        lower.insert(without_ext.to_ascii_lowercase(), without_ext.to_owned());

        // Also index directory prefixes for `resources.loadDir("...")`.
        let mut cursor = without_ext;
        while let Some((dir, _)) = cursor.rsplit_once('/') {
            exact.entry(dir.to_owned()).or_insert_with(|| dir.to_owned());
            lower.entry(dir.to_ascii_lowercase()).or_insert_with(|| dir.to_owned());
            cursor = dir;
        }
    }
    (exact, lower)
}

fn strip_sub_suffix(path: &str) -> &str {
    for suffix in SUB_ASSET_SUFFIXES {
        if let Some(base) = path.strip_suffix(suffix) {
            return base;
        }
    }
    path
}

fn strip_ext(path: &str) -> &str {
    let last_slash = path.rfind('/');
    let dot = path.rfind('.');
    match (last_slash, dot) {
        (Some(s), Some(d)) if d > s => &path[..d],
        (None, Some(d)) => &path[..d],
        _ => path,
    }
}

fn extract_resource_calls(text: &str) -> Vec<(usize, usize, String)> {
    let mut hits = Vec::new();
    for needle in ["resources.loadDir", "resources.load"] {
        let mut cursor = 0;
        while let Some(rel_idx) = text[cursor..].find(needle) {
            let after_name = cursor + rel_idx + needle.len();
            cursor = after_name;
            let rest = &text[after_name..];
            let Some(paren_rel) = find_call_open_paren(rest) else {
                continue;
            };
            let args_start = after_name + paren_rel + 1;
            let args_ws = text[args_start..].bytes().take_while(u8::is_ascii_whitespace).count();
            let lit_start = args_start + args_ws;
            let Some(quote) = text.as_bytes().get(lit_start).copied() else {
                continue;
            };
            if quote != b'"' && quote != b'\'' {
                continue;
            }
            let content_start = lit_start + 1;
            if let Some(rel_end) = text[content_start..].find(quote as char) {
                let content_end = content_start + rel_end;
                let literal = &text[content_start..content_end];
                if !literal.is_empty() && !literal.contains('\n') {
                    hits.push((content_start, content_end, literal.to_owned()));
                }
            }
        }
    }
    hits
}

fn find_call_open_paren(rest: &str) -> Option<usize> {
    let mut i = 0;
    let bytes = rest.as_bytes();
    while i < bytes.len() && bytes[i].is_ascii_whitespace() {
        i += 1;
    }
    if bytes.get(i) == Some(&b'<') {
        let mut depth = 1usize;
        i += 1;
        while i < bytes.len() && depth > 0 {
            if bytes[i] == b'<' {
                depth += 1;
            } else if bytes[i] == b'>' {
                depth -= 1;
            } else if bytes[i] == b'\n' {
                return None;
            }
            i += 1;
        }
        while i < bytes.len() && bytes[i].is_ascii_whitespace() {
            i += 1;
        }
    }
    (bytes.get(i) == Some(&b'(')).then_some(i)
}
