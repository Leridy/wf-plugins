//! Built-in Cocos Creator 3.x engine component classes and internal asset UUIDs.

/// Engine-owned component / serialization types that never resolve to project `.ts` files.
pub fn is_builtin_type(ty: &str) -> bool {
    ty.starts_with("cc.")
        || ty.starts_with("sp.")
        || ty.starts_with("dragonBones.")
        || ty.starts_with("js.")
        || ty.starts_with("cce.")
        || matches!(ty, "cc.Prefab" | "cc.Scene" | "cc.SceneAsset")
}

/// Built-in Cocos Creator 3.x UUIDs (`internal/db/...` shaders, default materials, effects, primitives).
const BUILTIN_UUIDS: &[&str] = &[
    "00000000-0000-0000-0000-000000000000",
    "1baf0fc9-befa-459c-8bdd-af1a450a0319",
    "60f7195c-ec2a-45eb-ba94-8955f60e81d0",
    "6f01cf7f-81bf-4a7e-bd5d-0afc19696480",
    "7d8fd918-b4c5-4a1d-92a1-4b2393d4b378",
    "8bbdbcdd-5d47-4107-99f3-678d0c8e8c81",
    "a3cd009f-0ab0-420d-91ea-d705313f9978",
    "c27215d8-6837-4b68-bf15-5451120f93b0",
    "d1346436-ac96-4271-b863-6d4f248e7657",
    "e9ec654c-97a2-4787-9325-e6a10375219a",
    "f0416e68-0200-4b77-a926-4f9d16e49416",
];

pub fn is_builtin_uuid(uuid: &str) -> bool {
    let base = uuid.split('@').next().unwrap_or(uuid);
    BUILTIN_UUIDS.contains(&base) || base.starts_with("00000000-0000-0000-")
}
