//! Diagnostic constructors for `wf.lint/1`.
use plugin_protocols::lint::{Diagnostic, Fix, Severity, Span};

pub fn error(
    rule: &str,
    file: impl Into<String>,
    span: Option<Span>,
    message: impl Into<String>,
    fix: Option<Fix>,
) -> Diagnostic {
    Diagnostic {
        rule: rule.into(),
        severity: Severity::Error,
        message: message.into(),
        file: file.into(),
        span,
        fix,
    }
}

pub fn warning(
    rule: &str,
    file: impl Into<String>,
    span: Option<Span>,
    message: impl Into<String>,
    fix: Option<Fix>,
) -> Diagnostic {
    Diagnostic {
        rule: rule.into(),
        severity: Severity::Warning,
        message: message.into(),
        file: file.into(),
        span,
        fix,
    }
}
