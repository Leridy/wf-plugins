//! Lightweight `*` and `**` glob matcher (matching `wf` host path patterns).

pub fn matches(pattern: &str, path: &str) -> bool {
    let p_segs: Vec<&str> = pattern.split('/').filter(|s| !s.is_empty()).collect();
    let s_segs: Vec<&str> = path.split('/').filter(|s| !s.is_empty()).collect();
    match_segs(&p_segs, &s_segs)
}

fn match_segs(p: &[&str], s: &[&str]) -> bool {
    if p.is_empty() {
        return s.is_empty();
    }
    if p[0] == "**" {
        if p.len() == 1 {
            return true;
        }
        return (0..=s.len()).any(|skip| match_segs(&p[1..], &s[skip..]));
    }
    if s.is_empty() {
        return false;
    }
    match_token(p[0], s[0]) && match_segs(&p[1..], &s[1..])
}

fn match_token(pat: &str, val: &str) -> bool {
    let pb = pat.as_bytes();
    let vb = val.as_bytes();
    let (mut pi, mut vi) = (0, 0);
    let mut star: Option<(usize, usize)> = None;
    while vi < vb.len() {
        if pi < pb.len() && pb[pi] == b'*' {
            star = Some((pi, vi));
            pi += 1;
        } else if pi < pb.len() && (pb[pi] == b'?' || pb[pi] == vb[vi]) {
            pi += 1;
            vi += 1;
        } else if let Some((sp, sv)) = star {
            pi = sp + 1;
            vi = sv + 1;
            star = Some((sp, vi));
        } else {
            return false;
        }
    }
    while pi < pb.len() && pb[pi] == b'*' {
        pi += 1;
    }
    pi == pb.len()
}
