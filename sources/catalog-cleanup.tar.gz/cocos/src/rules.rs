//! Runs all Cocos Creator 3.x checks across one project layout.
use crate::{asset_json, manifest_stamp, message, meta, project::Layout, ts_refs};
use plugin_guest::Host;
use plugin_protocols::lint::Diagnostic;

pub fn check_project(
    host: &dyn Host,
    layout: &Layout,
    paths: &[String],
    checked: &mut Vec<String>,
    diagnostics: &mut Vec<Diagnostic>,
) {
    if layout.truncated {
        let fallback_file = layout.assets.first().cloned().unwrap_or_else(|| layout.assets_prefix());
        diagnostics.push(message::warning(
            "incomplete-check",
            fallback_file,
            None,
            "Project listing hit host limit; some assets may not have been checked.",
            None,
        ));
    }

    let meta_index = meta::build_and_check(host, layout, paths, checked, diagnostics);
    asset_json::check_files(host, layout, &meta_index, paths, checked, diagnostics);
    ts_refs::check_scripts(host, layout, paths, checked, diagnostics);
    manifest_stamp::check_stamps(host, layout, paths, checked, diagnostics);
}
