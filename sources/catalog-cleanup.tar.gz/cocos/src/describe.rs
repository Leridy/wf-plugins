//! What the plugin exposes: one `wf.lint/1` capability (`lint`).
use plugin_api::{Capability, Description, Example, Risk};
use plugin_protocols::lint::{LintInput, LintOutput, PROTOCOL};
use schemars::schema_for;

pub const OP: &str = "lint";

pub fn description() -> Description {
    Description {
        capabilities: vec![Capability {
            op: OP.into(),
            summary: "Check Cocos Creator 3.x .meta UUIDs, .prefab/.scene/.anim/.mtl references, scripts, and wf stamps".into(),
            when: "Check a Cocos Creator 3.x project before committing or opening it in the editor. Preferred over ad-hoc JSON checks.".into(),
            risk: Risk::Read,
            input: serde_json::to_value(schema_for!(LintInput)).expect("schema"),
            output: Some(serde_json::to_value(schema_for!(LintOutput)).expect("schema")),
            examples: vec![
                Example {
                    args: "lint".into(),
                    note: "Check every Cocos Creator 3.x asset and script in the project.".into(),
                },
                Example {
                    args: "lint --paths assets/scenes".into(),
                    note: "Restrict diagnostics to assets/scenes while still indexing all project .meta files.".into(),
                },
            ],
            implements: Some(PROTOCOL.into()),
        }],
    }
}
