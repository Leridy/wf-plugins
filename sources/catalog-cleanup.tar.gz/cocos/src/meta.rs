//! `.meta` indexing plus `missing-meta`, `orphan-meta`, `duplicate-uuid`, and `malformed-json` rules.
use crate::{
    message,
    project::{Layout, in_scope},
    uuid_codec::normalize_uuid,
};
use plugin_guest::Host;
use plugin_protocols::lint::{Diagnostic, Span};
use serde_json::{Map, Value};
use std::collections::{BTreeMap, BTreeSet};
use std::str::from_utf8;

pub struct MetaIndex {
    pub uuids: BTreeMap<String, String>,
    pub sub_uuids: BTreeMap<String, String>,
    pub script_uuids: BTreeSet<String>,
}

impl MetaIndex {
    pub fn has_uuid(&self, raw: &str) -> bool {
        let norm = normalize_uuid(raw);
        if self.uuids.contains_key(&norm) || self.sub_uuids.contains_key(&norm) {
            return true;
        }
        if let Some((base, _sub)) = norm.split_once('@') {
            return self.uuids.contains_key(base);
        }
        false
    }
}

pub fn build_and_check(
    host: &dyn Host,
    layout: &Layout,
    paths: &[String],
    checked: &mut Vec<String>,
    diagnostics: &mut Vec<Diagnostic>,
) -> MetaIndex {
    let mut index = MetaIndex {
        uuids: BTreeMap::new(),
        sub_uuids: BTreeMap::new(),
        script_uuids: BTreeSet::new(),
    };
    let asset_set: BTreeSet<&str> = layout.assets.iter().map(String::as_str).collect();
    let meta_set: BTreeSet<&str> = layout.metas.iter().map(String::as_str).collect();
    let mut seen_uuids: BTreeMap<String, String> = BTreeMap::new();

    for meta_path in &layout.metas {
        process_one_meta(
            host,
            layout,
            meta_path,
            &asset_set,
            paths,
            checked,
            &mut seen_uuids,
            &mut index,
            diagnostics,
        );
    }

    for asset in &layout.assets {
        if !in_scope(asset, paths) || !needs_meta(asset, layout) {
            continue;
        }
        let expected_meta = format!("{asset}.meta");
        if !meta_set.contains(expected_meta.as_str()) {
            diagnostics.push(message::error(
                "missing-meta",
                asset,
                None,
                format!("Cocos asset `{asset}` is missing `{expected_meta}`."),
                None,
            ));
        }
    }

    index
}

#[allow(clippy::too_many_arguments)]
fn process_one_meta(
    host: &dyn Host,
    layout: &Layout,
    meta_path: &str,
    asset_set: &BTreeSet<&str>,
    paths: &[String],
    checked: &mut Vec<String>,
    seen_uuids: &mut BTreeMap<String, String>,
    index: &mut MetaIndex,
    diagnostics: &mut Vec<Diagnostic>,
) {
    if in_scope(meta_path, paths) {
        checked.push(meta_path.to_owned());
    }
    let Ok(bytes) = host.read(meta_path) else {
        return;
    };
    let Ok(text) = from_utf8(&bytes) else {
        if in_scope(meta_path, paths) {
            diagnostics.push(message::error(
                "malformed-json",
                meta_path,
                None,
                "Meta file is not valid UTF-8 JSON.",
                None,
            ));
        }
        return;
    };
    let parsed: Value = match serde_json::from_str(text) {
        Ok(v) => v,
        Err(err) => {
            if in_scope(meta_path, paths) {
                let span = line_col_span(text, err.line(), err.column());
                diagnostics.push(message::error(
                    "malformed-json",
                    meta_path,
                    span,
                    format!("Invalid Cocos .meta JSON: {err}"),
                    None,
                ));
            }
            return;
        }
    };

    let target = meta_path.strip_suffix(".meta").unwrap_or(meta_path);
    let importer = parsed.get("importer").and_then(Value::as_str).unwrap_or_default();
    if !target_exists(target, importer, asset_set, &layout.assets) && in_scope(meta_path, paths) {
        diagnostics.push(message::warning(
            "orphan-meta",
            meta_path,
            None,
            format!("Orphan .meta file: matching asset or folder `{target}` is missing."),
            None,
        ));
    }

    if let Some(u) = parsed.get("uuid").and_then(Value::as_str) {
        let uuid = normalize_uuid(u);
        record_uuid(
            meta_path,
            target,
            &uuid,
            matches!(importer, "typescript" | "javascript"),
            text,
            paths,
            seen_uuids,
            index,
            diagnostics,
        );
    }
    if let Some(subs) = parsed.get("subMetas").and_then(Value::as_object) {
        record_sub_metas(meta_path, subs, text, paths, seen_uuids, index, diagnostics);
    }
}

fn record_sub_metas(
    meta_path: &str,
    subs: &Map<String, Value>,
    text: &str,
    paths: &[String],
    seen_uuids: &mut BTreeMap<String, String>,
    index: &mut MetaIndex,
    diagnostics: &mut Vec<Diagnostic>,
) {
    for sub in subs.values() {
        let Some(su) = sub.get("uuid").and_then(Value::as_str) else {
            continue;
        };
        let sub_uuid = normalize_uuid(su);
        if let Some(prev) = seen_uuids.get(&sub_uuid) {
            if in_scope(meta_path, paths) {
                diagnostics.push(message::error(
                    "duplicate-uuid",
                    meta_path,
                    find_literal_span(text, su),
                    format!("Duplicate sub-asset UUID `{sub_uuid}` (already used by `{prev}`)."),
                    None,
                ));
            }
        } else {
            seen_uuids.insert(sub_uuid.clone(), meta_path.to_owned());
            index.sub_uuids.insert(sub_uuid, meta_path.to_owned());
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn record_uuid(
    meta_path: &str,
    target: &str,
    uuid: &str,
    is_script: bool,
    text: &str,
    paths: &[String],
    seen: &mut BTreeMap<String, String>,
    index: &mut MetaIndex,
    diagnostics: &mut Vec<Diagnostic>,
) {
    if let Some(prev) = seen.get(uuid) {
        if in_scope(meta_path, paths) {
            diagnostics.push(message::error(
                "duplicate-uuid",
                meta_path,
                find_literal_span(text, uuid),
                format!("Duplicate UUID `{uuid}` (already defined in `{prev}`)."),
                None,
            ));
        }
        return;
    }
    seen.insert(uuid.to_owned(), meta_path.to_owned());
    index.uuids.insert(uuid.to_owned(), target.to_owned());
    if is_script {
        index.script_uuids.insert(uuid.to_owned());
    }
}

fn target_exists(target: &str, importer: &str, asset_set: &BTreeSet<&str>, all_assets: &[String]) -> bool {
    if asset_set.contains(target) || importer == "directory" {
        return true;
    }
    let dir_prefix = format!("{target}/");
    if !has_known_asset_ext(target) && all_assets.iter().any(|p| p.starts_with(&dir_prefix)) {
        return true;
    }
    false
}

fn needs_meta(asset: &str, layout: &Layout) -> bool {
    let lower = asset.to_ascii_lowercase();
    let name = lower.rsplit('/').next().unwrap_or(&lower);
    if name.starts_with('.') || matches!(name, "wf-cocos.manifest.json" | "wf.lock.json") {
        return false;
    }
    if has_known_asset_ext(asset) {
        return true;
    }
    let res_prefix = format!("{}resources/", layout.assets_prefix());
    let ext = name.rsplit_once('.').map(|(_, e)| e).unwrap_or_default();
    asset.starts_with(&res_prefix)
        && ext == "json"
        && !matches!(
            name,
            "animation.json" | "main.json" | "tilemap.json" | "props.json" | "ui.json" | "model.json"
        )
}

fn has_known_asset_ext(path: &str) -> bool {
    let Some((_, ext)) = path.rsplit_once('.') else {
        return false;
    };
    matches!(
        ext.to_ascii_lowercase().as_str(),
        "prefab"
            | "scene"
            | "anim"
            | "mtl"
            | "effect"
            | "ts"
            | "js"
            | "png"
            | "jpg"
            | "jpeg"
            | "webp"
            | "tmx"
            | "glb"
            | "gltf"
            | "fbx"
            | "mp3"
            | "ogg"
            | "wav"
            | "ttf"
            | "fnt"
            | "atlas"
    )
}

pub fn find_literal_span(text: &str, needle: &str) -> Option<Span> {
    let quoted = format!("\"{needle}\"");
    let idx = text.find(&quoted)?;
    let start = u32::try_from(idx + 1).ok()?;
    let end = u32::try_from(idx + 1 + needle.len()).ok()?;
    Some(Span { start, end })
}

pub fn line_col_span(text: &str, line_one_based: usize, col_one_based: usize) -> Option<Span> {
    let mut offset = 0usize;
    for (idx, line) in text.split_inclusive('\n').enumerate() {
        if idx + 1 == line_one_based {
            let col_off = col_one_based.saturating_sub(1).min(line.len());
            let mut pos = offset + col_off;
            while pos < text.len() && !text.is_char_boundary(pos) {
                pos += 1;
            }
            let start = u32::try_from(pos).ok()?;
            return Some(Span { start, end: start });
        }
        offset += line.len();
    }
    None
}
