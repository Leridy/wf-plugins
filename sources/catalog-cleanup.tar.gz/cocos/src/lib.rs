//! The official `cocos` plugin: checks `.meta` files, UUID & internal `__id__`
//! references, compressed `__type__` script references, `resources.load*` paths,
//! and `wf cocos-export` stamps/manifests in Cocos Creator 3.x projects (`wf.lint/1`).
#![cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "the component glue that calls into these is wasm-only")
)]

mod asset_json;
mod builtin;
#[cfg(target_arch = "wasm32")]
mod component;
mod describe;
mod gather;
mod glob;
mod manifest_stamp;
mod message;
mod meta;
mod project;
mod rules;
#[cfg(test)]
mod testing;
mod ts_refs;
mod uuid_codec;

pub use gather::lint;
