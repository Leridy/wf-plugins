//! Cocos Creator 3.x Base64 script UUID decompression (both 22- and 23-char encodings).

const BASE64_KEYS: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const HEX_CHARS: &[u8; 16] = b"0123456789abcdef";

pub fn normalize_uuid(raw: &str) -> String {
    raw.trim().to_ascii_lowercase()
}

/// Decompress a 22-char or 23-char Cocos Creator compressed UUID into canonical 36-char lowercase UUID.
pub fn decompress_uuid(compressed: &str) -> Option<String> {
    let bytes = compressed.as_bytes();
    let (prefix_len, rest) = match bytes.len() {
        23 => (5usize, &bytes[5..]),
        22 => (2usize, &bytes[2..]),
        _ => return None,
    };
    if !bytes[..prefix_len].iter().all(u8::is_ascii_hexdigit) || !rest.len().is_multiple_of(2) {
        return None;
    }
    let mut hex = Vec::with_capacity(32);
    for &b in &bytes[..prefix_len] {
        hex.push(b.to_ascii_lowercase());
    }
    for pair in rest.as_chunks::<2>().0 {
        let lhs = b64_val(pair[0])?;
        let rhs = b64_val(pair[1])?;
        hex.push(HEX_CHARS[(lhs >> 2) as usize]);
        hex.push(HEX_CHARS[(((lhs & 0x3) << 2) | (rhs >> 4)) as usize]);
        hex.push(HEX_CHARS[(rhs & 0xf) as usize]);
    }
    if hex.len() != 32 {
        return None;
    }
    let s = String::from_utf8(hex).ok()?;
    Some(format!(
        "{}-{}-{}-{}-{}",
        &s[0..8],
        &s[8..12],
        &s[12..16],
        &s[16..20],
        &s[20..32]
    ))
}

fn b64_val(b: u8) -> Option<u8> {
    BASE64_KEYS
        .iter()
        .position(|&k| k == b)
        .and_then(|pos| u8::try_from(pos).ok())
}

#[cfg(test)]
pub fn compress_for_test(raw: &str) -> String {
    let hex: Vec<u8> = raw.bytes().filter(u8::is_ascii_hexdigit).collect();
    let val = |b: u8| match b {
        b'0'..=b'9' => b - b'0',
        b'a'..=b'f' => b - b'a' + 10,
        _ => 0,
    };
    let mut out = hex[..5].to_vec();
    for chunk in hex[5..].chunks_exact(3) {
        let (a, b, c) = (val(chunk[0]), val(chunk[1]), val(chunk[2]));
        out.push(BASE64_KEYS[((a << 2) | (b >> 2)) as usize]);
        out.push(BASE64_KEYS[(((b & 0x3) << 4) | c) as usize]);
    }
    String::from_utf8(out).unwrap()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn encode(raw: &str, prefix_len: usize) -> String {
        let hex: Vec<u8> = raw.bytes().filter(u8::is_ascii_hexdigit).collect();
        let val = |b: u8| match b {
            b'0'..=b'9' => b - b'0',
            b'a'..=b'f' => b - b'a' + 10,
            _ => 0,
        };
        let mut out = hex[..prefix_len].to_vec();
        for chunk in hex[prefix_len..].chunks_exact(3) {
            let (a, b, c) = (val(chunk[0]), val(chunk[1]), val(chunk[2]));
            out.push(BASE64_KEYS[((a << 2) | (b >> 2)) as usize]);
            out.push(BASE64_KEYS[(((b & 0x3) << 4) | c) as usize]);
        }
        String::from_utf8(out).unwrap()
    }

    #[test]
    fn decodes_both_23_and_22_char_cocos_script_uuids() {
        let uuid = "f897c2f3-3a4b-45c1-9abc-def012345678";
        let c23 = encode(uuid, 5);
        let c22 = encode(uuid, 2);
        assert_eq!(c23.len(), 23);
        assert_eq!(c22.len(), 22);
        assert_eq!(decompress_uuid(&c23).as_deref(), Some(uuid));
        assert_eq!(decompress_uuid(&c22).as_deref(), Some(uuid));
        assert_eq!(decompress_uuid("cc.Sprite"), None);
    }
}
