//! Unit tests for Cocos project discovery, UUID resolution, script checks, and case fixes.
use super::*;
use plugin_api::Failure;
use plugin_guest::{Host, HostError};
use plugin_protocols::lint::LintInput;
use std::collections::BTreeMap;

struct MemHost {
    files: BTreeMap<String, String>,
}

impl MemHost {
    fn new(pairs: Vec<(&str, &str)>) -> Self {
        Self {
            files: pairs.into_iter().map(|(k, v)| (k.to_owned(), v.to_owned())).collect(),
        }
    }
}

impl Host for MemHost {
    fn list(&self, pattern: &str) -> Vec<String> {
        assert_ne!(pattern, "**", "linter never lists **");
        let matcher = globset::Glob::new(pattern).unwrap().compile_matcher();
        self.files.keys().filter(|k| matcher.is_match(k)).cloned().collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.files
            .get(path)
            .map(|v| v.as_bytes().to_vec())
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }

    fn warn(&self, _: &str) {}
}

#[test]
fn non_cocos_workspace_returns_no_diagnostics() {
    let host = MemHost::new(vec![("README.md", "# empty"), ("src/main.rs", "fn main() {}")]);
    let out = lint(&host, &LintInput::default());
    assert!(out.checked.is_empty());
    assert!(out.diagnostics.is_empty());
}

#[test]
fn valid_prefab_script_and_resource_load_pass_cleanly() {
    let script_ty = uuid_codec::compress_for_test("f897c2f3-3a4b-45c1-9abc-def012345678");
    let prefab = format!(
        "[{{\"__type__\":\"cc.Prefab\",\"data\":{{\"__id__\":1}}}},{{\"__type__\":\"cc.Node\",\"_components\":[{{\"__id__\":2}}]}},{{\"__type__\":\"{script_ty}\"}}]"
    );
    let host = MemHost::new(vec![
        ("package.json", "{}"),
        (
            "assets/Scripts/Hero.ts",
            "import { resources } from 'cc';\nresources.load('UI/Button');\n",
        ),
        (
            "assets/Scripts/Hero.ts.meta",
            "{\"ver\":\"4.0.10\",\"importer\":\"typescript\",\"uuid\":\"f897c2f3-3a4b-45c1-9abc-def012345678\"}",
        ),
        ("assets/resources/UI/Button.png", "PNG"),
        (
            "assets/resources/UI/Button.png.meta",
            "{\"ver\":\"1.0.27\",\"importer\":\"image\",\"uuid\":\"11111111-1111-4111-8111-111111111111\",\"subMetas\":{\"f9941\":{\"uuid\":\"11111111-1111-4111-8111-111111111111@f9941\"}}}",
        ),
        ("assets/Prefabs/Hero.prefab", &prefab),
        (
            "assets/Prefabs/Hero.prefab.meta",
            "{\"ver\":\"1.3.12\",\"importer\":\"prefab\",\"uuid\":\"22222222-2222-4222-8222-222222222222\"}",
        ),
    ]);
    let out = lint(&host, &LintInput::default());
    assert!(out.diagnostics.is_empty(), "{:#?}", out.diagnostics);
}
