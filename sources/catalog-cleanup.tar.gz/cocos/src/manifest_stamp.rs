//! Checks `wf cocos-export` comment stamps in `.ts`/`.effect` files and hashes in `wf-cocos.manifest.json`.
use crate::{
    message,
    meta::line_col_span,
    project::{Layout, in_scope},
};
use plugin_guest::Host;
use plugin_protocols::lint::{Diagnostic, Fix, Span, TextEdit};
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::fmt::Write;
use std::str::from_utf8;

#[derive(Deserialize)]
struct Manifest {
    schema: String,
    #[serde(default)]
    files: BTreeMap<String, ManifestEntry>,
}

#[derive(Deserialize)]
struct ManifestEntry {
    sha256: String,
}

pub fn check_stamps(
    host: &dyn Host,
    layout: &Layout,
    paths: &[String],
    checked: &mut Vec<String>,
    diagnostics: &mut Vec<Diagnostic>,
) {
    for manifest_path in &layout.manifests {
        check_manifest(host, manifest_path, paths, checked, diagnostics);
    }

    for path in &layout.scripts {
        check_slash_stamp(host, path, paths, diagnostics);
    }
    for path in layout.assets.iter().filter(|p| {
        p.rsplit_once('.')
            .is_some_and(|(_, e)| e.eq_ignore_ascii_case("effect"))
    }) {
        if in_scope(path, paths) {
            checked.push(path.clone());
        }
        check_slash_stamp(host, path, paths, diagnostics);
    }
}

fn check_manifest(
    host: &dyn Host,
    manifest_path: &str,
    paths: &[String],
    checked: &mut Vec<String>,
    diagnostics: &mut Vec<Diagnostic>,
) {
    if in_scope(manifest_path, paths) {
        checked.push(manifest_path.to_owned());
    }
    let Ok(bytes) = host.read(manifest_path) else {
        return;
    };
    let Ok(text) = from_utf8(&bytes) else {
        return;
    };
    let parsed: Manifest = match serde_json::from_str(text) {
        Ok(m) => m,
        Err(err) => {
            if in_scope(manifest_path, paths) {
                diagnostics.push(message::error(
                    "malformed-json",
                    manifest_path,
                    line_col_span(text, err.line(), err.column()),
                    format!("Invalid Cocos export manifest JSON: {err}"),
                    None,
                ));
            }
            return;
        }
    };
    if parsed.schema != "wf-cocos-manifest/1" {
        return;
    }

    for (file, entry) in parsed.files {
        if !in_scope(&file, paths) {
            continue;
        }
        let Ok(file_bytes) = host.read(&file) else {
            continue;
        };
        let actual = sha256_hex(&file_bytes);
        if actual != entry.sha256.to_ascii_lowercase() {
            diagnostics.push(message::warning(
                "stale-wf-stamp",
                file,
                None,
                "Generated file was edited after `wf cocos-export sync` (manifest hash mismatch).",
                None,
            ));
        }
    }
}

fn check_slash_stamp(host: &dyn Host, path: &str, paths: &[String], diagnostics: &mut Vec<Diagnostic>) {
    if !in_scope(path, paths) {
        return;
    }
    let Ok(bytes) = host.read(path) else {
        return;
    };
    let Ok(text) = from_utf8(&bytes) else {
        return;
    };
    let Some(first) = text.lines().next() else {
        return;
    };
    let Some(rest) = first.strip_prefix("// wf cocos-export ") else {
        return;
    };
    let Some((_, hash)) = rest.rsplit_once(" sha256=") else {
        return;
    };
    if hash.len() != 64 || !hash.bytes().all(|b| b.is_ascii_hexdigit()) {
        return;
    }
    let line_end = text.find('\n').map_or(text.len(), |i| i + 1);
    let body = &text[line_end..];
    if sha256_hex(body.as_bytes()) != hash.to_ascii_lowercase() {
        diagnostics.push(message::warning(
            "stale-wf-stamp",
            path,
            Some(Span {
                start: 0,
                end: u32::try_from(line_end).unwrap_or(0),
            }),
            "Generated file has local edits and its `wf cocos-export` stamp is stale.",
            Some(Fix {
                summary: "Remove stale wf cocos-export stamp".into(),
                edits: vec![TextEdit {
                    file: path.to_owned(),
                    span: Span {
                        start: 0,
                        end: u32::try_from(line_end).unwrap_or(0),
                    },
                    text: String::new(),
                }],
            }),
        ));
    }
}

fn sha256_hex(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    let mut out = String::with_capacity(64);
    for b in digest {
        write!(out, "{b:02x}").expect("hex");
    }
    out
}
