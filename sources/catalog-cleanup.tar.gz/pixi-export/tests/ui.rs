//! Official UI action bindings, table column types, and per-case row invariants.
mod common;

use common::Fake;
use plugin_api::{
    ConfigValue, Manifest,
    ui::{Bind, CellKind, Place, ProjectNeed, Renderer},
};
use plugin_protocols::ui::{Cell, Status as UiStatus, Tone};
use wf_pixi_export::{Input, Output, Status, sync};

fn manifest() -> Manifest {
    Manifest::parse(include_str!("../wf-plugin.toml")).unwrap()
}

fn check_table(output: &Output) {
    let manifest = manifest();
    let Renderer::Table { columns } = &manifest.ui.views[0].renderer else {
        panic!("expected table view");
    };
    let kinds: Vec<CellKind> = columns.iter().map(|c| c.kind).collect();
    assert_eq!(
        kinds,
        [CellKind::Node, CellKind::Status, CellKind::Number, CellKind::Path]
    );
    assert!(output.table.check(&kinds).is_ok());
}

#[test]
fn node_actions_bind_selection_and_force_for_all_thirteen_types() {
    let manifest = manifest();
    assert_eq!(manifest.ui.actions.len(), 2);
    for (idx, force) in [(0, false), (1, true)] {
        let action = &manifest.ui.actions[idx];
        assert_eq!(action.place, Place::NodeMenu);
        assert_eq!(action.when.project, ProjectNeed::Mirror);
        assert!(!action.when.directories);
        assert_eq!(action.when.node_types.len(), 13);
        assert_eq!(action.input.get("nodes"), Some(&Bind::Selection));
        assert_eq!(
            action.input.get("force"),
            force.then_some(&Bind::Value(ConfigValue::Bool(true)))
        );
        assert!(action.label.zh.is_some());
    }
}

#[test]
fn every_export_form_reports_typed_manifest_entry_and_unchanged_rerun() {
    for case in [
        "real-frames",
        "real-source",
        "animation-strips",
        "animation-atlas",
        "real-ui-pieces",
        "ui-pieces",
        "ui-atlas",
        "tilemap",
        "real-particles",
        "particle-builtin",
        "prop",
        "whole-map",
        "scrolling-scene",
        "scene3d-map",
        "model-3d",
    ] {
        let mut host = Fake::case(case);
        let plan = sync(&host, &Input::default()).unwrap();
        check_table(&plan.output);
        assert_eq!(plan.output.nodes[0].status, Status::Written, "{case}");
        let entry = plan.output.nodes[0].main_prefab.as_deref().unwrap();
        assert!(entry.starts_with("assets/wf/wf-assets.ts#"), "{case}: {entry}");
        assert_eq!(plan.output.table.rows[0][3], Cell::Path(entry.into()));
        assert_eq!(
            plan.output.table.rows[0][1],
            Cell::Status(UiStatus {
                tone: Tone::Ok,
                text: "Written".into(),
            })
        );

        host.apply(plan.effects);
        let rerun = sync(&host, &Input::default()).unwrap();
        assert!(rerun.effects.is_empty());
        assert_eq!(rerun.output.nodes[0].status, Status::Unchanged);
    }
}
