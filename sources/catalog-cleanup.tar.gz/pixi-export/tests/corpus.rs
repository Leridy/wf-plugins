//! Corpus tests covering all 13 PixiJS + Three.js Web node types, conditional
//! Three.js bridge emission, partial-sync preservation, and leftover cleanup.
mod common;

use common::{Fake, fake_png, make_lock, make_node};
use plugin_api::platform::LocksOutput;
use serde_json::{Value, json};
use wf_pixi_export::{Input, Status, sync};

fn verify_manifest(files: &std::collections::BTreeMap<String, Vec<u8>>, expect_three: bool) {
    let raw = files.get("assets/wf/wf-assets.json").expect("wf-assets.json missing");
    let v: Value = serde_json::from_slice(raw).expect("valid wf-assets.json");
    assert_eq!(v.get("schema").and_then(Value::as_str), Some("wf-web-assets/1"));
    assert!(!v["entries"].as_object().unwrap().is_empty());

    let ts = std::str::from_utf8(files.get("assets/wf/wf-assets.ts").expect("wf-assets.ts missing")).unwrap();
    assert!(ts.starts_with("// wf pixi-export manifest v1 sha256="));
    assert!(ts.contains("export const WF_ASSETS: WfAssetsMap"));

    for runtime in [
        "assets/wf/wf-runtime/wf-types.ts",
        "assets/wf/wf-runtime/wf-simulation.ts",
        "assets/wf/wf-runtime/wf-whole-map.ts",
        "assets/wf/wf-runtime/wf-parallax.ts",
        "assets/wf/wf-runtime/wf-pixi.ts",
    ] {
        let content = std::str::from_utf8(files.get(runtime).unwrap_or_else(|| panic!("{runtime} missing"))).unwrap();
        assert!(content.starts_with("// wf pixi-export runtime v1 sha256="));
    }

    assert_eq!(
        files.contains_key("assets/wf/wf-runtime/wf-three-bridge.ts"),
        expect_three,
        "unexpected wf-three-bridge.ts presence (expected {expect_three})"
    );
}

#[test]
fn all_sixteen_2d_and_3d_fixtures_export_valid_manifest_and_rerun_unchanged() {
    for case in [
        "real-frames",
        "real-source",
        "animation-strips",
        "animation-atlas",
        "real-ui-pieces",
        "ui-pieces",
        "ui-atlas",
        "ui-naming",
        "tilemap",
        "real-particles",
        "particle-builtin",
        "prop",
        "whole-map",
        "scrolling-scene",
        "scene3d-map",
        "model-3d",
    ] {
        let expect_three = matches!(case, "scene3d-map" | "model-3d" | "particle-builtin");
        let mut host = Fake::case(case);
        let plan = sync(&host, &Input::default()).unwrap_or_else(|e| panic!("{case}: {e:?}"));
        assert!(!plan.effects.is_empty(), "{case}: expected writes");
        assert!(
            plan.output.warnings.is_empty(),
            "{case}: unexpected warnings {:?}",
            plan.output.warnings
        );
        host.apply(plan.effects);
        verify_manifest(&host.files, expect_three);

        let rerun = sync(&host, &Input::default()).unwrap();
        assert!(rerun.effects.is_empty(), "{case}: rerun must be empty");
        assert!(rerun.output.nodes.iter().all(|n| n.status == Status::Unchanged));
    }
}

#[test]
fn word_art_icon_and_table_nodes_sync_and_partial_sync_preserves_other_locked_entries() {
    let mut host = Fake::default();
    host.files.insert("package.json".into(), b"{}".to_vec());
    host.files.insert("assets/wf/title/font.png".into(), fake_png(128, 128));
    host.files.insert(
        "assets/wf/title/font.fnt".into(),
        b"info face=\"GoldTitle\" size=48\ncommon lineHeight=52 base=40\npage id=0 file=\"font.png\"\nchar id=65 x=0 y=0 width=24 height=32 xoffset=0 yoffset=4 xadvance=25 page=0\n"
            .to_vec(),
    );
    host.files.insert("assets/wf/icons/sheet.png".into(), fake_png(64, 64));
    host.files.insert(
        "assets/wf/icons/icons.json".into(),
        serde_json::to_vec(&json!({
            "images": { "sword": { "type": "atlas", "path": "sheet.png", "frame": { "x": 0, "y": 0, "w": 32, "h": 32 } } },
            "elements": [{
                "name": "Sword",
                "kind": "states",
                "widget": { "type": "states" },
                "size": { "width": 32, "height": 32 },
                "states": [{ "name": "rest", "role": "rest", "file": "sword" }]
            }]
        }))
        .unwrap(),
    );
    host.files.insert(
        "assets/wf/items/items.json".into(),
        b"[{\"id\":1,\"name\":\"Potion\"}]\n".to_vec(),
    );

    let id_wa = "aaaa0001-0000-4000-8000-000000000001";
    let id_ic = "aaaa0002-0000-4000-8000-000000000002";
    let id_tb = "aaaa0003-0000-4000-8000-000000000003";
    host.locks = Some(LocksOutput {
        directory: "assets/wf".into(),
        lock: "assets/wf/wf.lock.json".into(),
        nodes: vec![
            make_lock(id_wa, 1, "UI/Title", "bmfont", vec!["title/font.fnt", "title/font.png"]),
            make_lock(
                id_ic,
                2,
                "UI/Icons",
                "slices",
                vec!["icons/icons.json", "icons/sheet.png"],
            ),
            make_lock(id_tb, 3, "Data/Items", "json", vec!["items/items.json"]),
        ],
    });
    host.nodes = vec![
        make_node(id_wa, 1, "UI/Title", "word_art"),
        make_node(id_ic, 2, "UI/Icons", "icon"),
        make_node(id_tb, 3, "Data/Items", "table"),
    ];

    let plan = sync(&host, &Input::default()).unwrap();
    host.apply(plan.effects);
    verify_manifest(&host.files, false);

    let partial = sync(
        &host,
        &Input {
            nodes: vec!["#1".into()],
            ..Input::default()
        },
    )
    .unwrap();
    host.apply(partial.effects);
    let after: Value = serde_json::from_slice(&host.files["assets/wf/wf-assets.json"]).unwrap();
    assert!(after["entries"]["UI/Title"].is_object());
    assert!(after["entries"]["UI/Icons"].is_object());
    assert_eq!(after["entries"]["Data/Items"]["rows"][0]["name"], "Potion");
}

#[test]
fn edits_preserved_until_force_and_three_bridge_removed_when_3d_dropped() {
    let mut host = Fake::case("model-3d");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply(first.effects);
    verify_manifest(&host.files, true);

    host.files
        .insert("assets/wf/wf-assets.ts".into(), b"// edited\n".to_vec());
    let kept = sync(&host, &Input::default()).unwrap();
    assert!(kept.output.warnings.iter().any(|w| w.contains("wf-assets.ts")));

    let forced = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    host.apply(forced.effects);
    assert!(
        std::str::from_utf8(&host.files["assets/wf/wf-assets.ts"])
            .unwrap()
            .starts_with("// wf pixi-export manifest")
    );

    host.locks.as_mut().unwrap().nodes.clear();
    let cleaned = sync(&host, &Input::default()).unwrap();
    host.apply(cleaned.effects);
    assert!(!host.files.contains_key("assets/wf/wf-runtime/wf-three-bridge.ts"));
}
