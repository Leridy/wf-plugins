//! The official `pixi-export` plugin: generates typed `wf-assets.ts` manifests,
//! `wf-assets.json`, PixiJS v8 TypeScript loaders/players, and optional Three.js 3D bridge.
#![cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "the component glue that calls into these is wasm-only")
)]

#[cfg(target_arch = "wasm32")]
mod component;
mod decode;
mod describe;
mod gather;
mod model;
mod paths;
mod reconcile;
mod table;
mod types;
mod web;

pub use gather::sync;
pub use types::{Element, File, Input, Node, Output, Plan, Status};
