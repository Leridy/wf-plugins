// Optional Three.js bridge for `model_3d`, `scene3d_map`, and spatial `particle_effect`.
// Emitted only when 3D or spatial particle nodes are exported so pure-2D PixiJS apps need no `three` dependency.
import * as THREE from "three";
import { createParticleColorCache, evaluateParticles, WfParticleSimulation } from "./wf-simulation";
import type { WfModel3dEntry, WfParticleEntry, WfScene3dMapEntry } from "./wf-types";

export interface WfModel3dHandle {
  root: THREE.Object3D;
  entry: WfModel3dEntry;
  getBoneObject(role: string): THREE.Object3D | undefined;
  getSocketWorldPosition(name: string, target?: THREE.Vector3): THREE.Vector3 | undefined;
  createColliderHelper(color?: number): THREE.Mesh;
}

export function setupWfModel3d(root: THREE.Object3D, entry: WfModel3dEntry): WfModel3dHandle {
  const box = new THREE.Box3().setFromObject(root);
  if (!box.isEmpty() && Math.abs(box.min.y - entry.bottom) > 1e-4) {
    root.position.y += entry.bottom - box.min.y;
  }

  return {
    root,
    entry,
    getBoneObject(role: string) {
      const nodeName = entry.bones[role];
      return nodeName ? root.getObjectByName(nodeName) : undefined;
    },
    getSocketWorldPosition(name: string, target = new THREE.Vector3()) {
      const socket = entry.sockets.find((s) => s.name === name);
      if (!socket) return undefined;
      target.set(socket.position[0], socket.position[1], socket.position[2]);
      return root.localToWorld(target);
    },
    createColliderHelper(color = 0x00ff88) {
      const mat = new THREE.MeshBasicMaterial({ color, wireframe: true });
      if (entry.collider.type === "capsule") {
        const cylLen = Math.max(0.01, entry.collider.height - entry.collider.radius * 2);
        const geo = new THREE.CapsuleGeometry(entry.collider.radius, cylLen, 4, 8);
        const mesh = new THREE.Mesh(geo, mat);
        mesh.position.set(entry.collider.center[0], entry.collider.center[1], entry.collider.center[2]);
        return mesh;
      }
      const geo = new THREE.BoxGeometry(entry.collider.size[0], entry.collider.size[1], entry.collider.size[2]);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(entry.collider.center[0], entry.collider.center[1], entry.collider.center[2]);
      return mesh;
    },
  };
}

export interface WfScene3dMapHandle {
  root: THREE.Object3D;
  entry: WfScene3dMapEntry;
  colliders: THREE.Box3[];
  findRoles(role: string): WfScene3dMapEntry["roles"];
  getSpawnTransform(): { position: THREE.Vector3; forward: THREE.Vector3 } | undefined;
  isDoorBlocked(doorId: string): boolean;
  createColliderDebugGroup(color?: number): THREE.Group;
}

export function setupWfScene3dMap(
  scene: THREE.Scene,
  root: THREE.Object3D,
  entry: WfScene3dMapEntry,
): WfScene3dMapHandle {
  scene.add(root);

  const env = entry.environment;
  if (env.ambientColor) {
    const color = new THREE.Color(env.ambientColor[0], env.ambientColor[1], env.ambientColor[2]);
    scene.add(new THREE.AmbientLight(color, env.ambientIntensity));
  }
  if (env.fogColor) {
    const fogColor = new THREE.Color(env.fogColor[0], env.fogColor[1], env.fogColor[2]);
    if (env.fogNear != null && env.fogFar != null) {
      scene.fog = new THREE.Fog(fogColor, env.fogNear, env.fogFar);
    } else if (env.fogDensity > 0) {
      scene.fog = new THREE.FogExp2(fogColor, env.fogDensity);
    }
  }

  const colliders = entry.colliders.map((c) => {
    const center = new THREE.Vector3(c.center[0], c.center[1], c.center[2]);
    const size = new THREE.Vector3(c.size[0], c.size[1], c.size[2]);
    return new THREE.Box3().setFromCenterAndSize(center, size);
  });

  return {
    root,
    entry,
    colliders,
    findRoles(role: string) {
      return entry.roles.filter((r) => r.role === role);
    },
    getSpawnTransform() {
      const spawn = entry.roles.find((r) => r.role === "spawn");
      if (!spawn) return undefined;
      return {
        position: new THREE.Vector3(spawn.position[0], spawn.position[1], spawn.position[2]),
        forward: new THREE.Vector3(spawn.forward[0], spawn.forward[1], spawn.forward[2]).normalize(),
      };
    },
    isDoorBlocked(doorId: string) {
      return entry.blockedDoors.includes(doorId);
    },
    createColliderDebugGroup(color = 0x33ccff) {
      const group = new THREE.Group();
      const mat = new THREE.MeshBasicMaterial({ color, wireframe: true });
      for (const c of entry.colliders) {
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(c.size[0], c.size[1], c.size[2]), mat);
        mesh.position.set(c.center[0], c.center[1], c.center[2]);
        group.add(mesh);
      }
      return group;
    },
  };
}

export class WfThreeParticleGroup {
  readonly entry: WfParticleEntry;
  readonly sim: WfParticleSimulation;
  readonly group = new THREE.Group();
  private readonly pools: THREE.Sprite[][] = [];
  private readonly textures: THREE.Texture[];
  private readonly colorCache: ReturnType<typeof createParticleColorCache>;

  constructor(entry: WfParticleEntry, textures?: THREE.Texture[]) {
    this.entry = entry;
    this.sim = new WfParticleSimulation(entry);
    this.colorCache = createParticleColorCache(entry.emitters);
    this.textures = textures ?? [];
    for (let i = 0; i < entry.emitters.length; i++) {
      this.pools.push([]);
    }
    this.syncVisuals();
  }

  step(dtSec: number): void {
    this.sim.advance(dtSec);
    this.syncVisuals();
  }

  reset(): void {
    this.sim.reset();
    this.syncVisuals();
  }

  private syncVisuals(): void {
    const evaluated = evaluateParticles(this.sim, this.colorCache, true);
    const byEmitter = this.entry.emitters.map(() => [] as typeof evaluated);
    for (const p of evaluated) byEmitter[p.emitterIndex]?.push(p);

    for (let ei = 0; ei < this.entry.emitters.length; ei++) {
      const list = byEmitter[ei];
      const pool = this.pools[ei];
      const tex = this.textures[ei] ?? null;
      const blending =
        this.entry.emitters[ei].blend === "additive" ? THREE.AdditiveBlending : THREE.NormalBlending;

      while (pool.length < list.length) {
        const mat = new THREE.SpriteMaterial({
          map: tex,
          transparent: true,
          depthWrite: false,
          blending,
        });
        const sprite = new THREE.Sprite(mat);
        this.group.add(sprite);
        pool.push(sprite);
      }

      for (let i = 0; i < pool.length; i++) {
        const sprite = pool[i];
        if (i >= list.length) {
          sprite.visible = false;
          continue;
        }
        const p = list[i];
        sprite.visible = true;
        sprite.position.set(p.x, p.y, p.z);
        sprite.material.color.setHex(p.colorInt24);
        sprite.material.opacity = p.alpha;
        sprite.material.rotation = p.rotation;
        sprite.scale.set((p.flipX ? -1 : 1) * p.size, p.size * p.stretchY, 1);
      }
    }
  }
}
