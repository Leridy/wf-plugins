// PixiJS v8 adapter for all 2D/UI/map/table WeaveForge web assets (`wf-assets.json`).
import {
  AnimatedSprite,
  Assets,
  BitmapText,
  CanvasSource,
  Container,
  NineSliceSprite,
  Rectangle,
  Sprite,
  Texture,
  TilingSprite,
  type FederatedPointerEvent,
} from "pixi.js";
import { computeParallaxTransform } from "./wf-parallax";
import { createParticleColorCache, evaluateParticles, WfParticleSimulation } from "./wf-simulation";
import type {
  WfAssetEntry,
  WfAssetManifest,
  WfFrameAnimationEntry,
  WfIconSetEntry,
  WfParticleEntry,
  WfPoint,
  WfPropSetEntry,
  WfScrollingSceneEntry,
  WfTableEntry,
  WfTextureRegion,
  WfTilemapEntry,
  WfUiKitEntry,
  WfUiState,
  WfWholeMapEntry,
  WfWordArtEntry,
} from "./wf-types";
import { composeMaskedTileCanvas, sortWholeMapParts, WfWholeMapNavRuntime } from "./wf-whole-map";

export interface WfPixiLoadOptions {
  /** URL prefix before `entry.baseDir` (e.g. `"/assets"` or `""`). Default `""`. */
  baseUrl?: string;
}

function joinUrl(baseUrl: string, baseDir: string, file: string): string {
  const cleanBase = baseUrl.replace(/\/+$/, "");
  const cleanDir = baseDir.replace(/^\/+|\/+$/g, "");
  const cleanFile = file.replace(/^\/+/, "");
  return [cleanBase, cleanDir, cleanFile].filter((s) => s.length > 0).join("/");
}

export class WfPixiAssetStore {
  private readonly baseTextures = new Map<string, Texture>();
  private readonly regionTextures = new Map<string, Texture>();
  private readonly fontNames = new Map<string, string>();

  setBaseTexture(key: string, tex: Texture): void {
    this.baseTextures.set(key, tex);
  }

  setFontName(entryId: string, face: string): void {
    this.fontNames.set(entryId, face);
  }

  getFontName(entry: Pick<WfWordArtEntry, "id" | "font">): string {
    return this.fontNames.get(entry.id) ?? entry.font?.face ?? entry.id;
  }

  getTexture(baseDir: string, tex: WfTextureRegion): Texture {
    const baseKey = joinUrl("", baseDir, tex.path);
    const base = this.baseTextures.get(baseKey);
    if (!base) {
      return Texture.EMPTY;
    }
    if (!tex.region) {
      return base;
    }
    const r = tex.region;
    const cacheKey = `${baseKey}#${r.x},${r.y},${r.w},${r.h}`;
    let cached = this.regionTextures.get(cacheKey);
    if (!cached) {
      cached = new Texture({
        source: base.source,
        frame: new Rectangle(r.x, r.y, r.w, r.h),
      });
      this.regionTextures.set(cacheKey, cached);
    }
    return cached;
  }
}

function collectImages(entry: WfAssetEntry): string[] {
  const files = new Set<string>();
  switch (entry.kind) {
    case "frame_animation":
    case "character_effect":
      for (const c of entry.clips) {
        for (const f of c.frames) files.add(f.texture.path);
      }
      break;
    case "ui":
      for (const w of entry.widgets) {
        for (const s of w.states) files.add(s.texture.path);
      }
      break;
    case "tilemap":
      for (const tex of Object.values(entry.textures)) files.add(tex.file);
      break;
    case "prop":
      for (const obj of entry.objects) {
        for (const st of obj.states) files.add(st.texture.path);
        for (const anim of obj.animations) {
          for (const tex of anim.textures) files.add(tex.path);
        }
      }
      break;
    case "particle_effect":
      for (const em of entry.emitters) {
        if (em.sprite) files.add(em.picture);
      }
      break;
    case "whole_map":
      for (const tile of entry.tiles) {
        files.add(tile.baseFile);
        if (tile.maskFile) files.add(tile.maskFile);
      }
      for (const part of entry.parts) files.add(part.textureFile);
      break;
    case "scrolling_scene":
      files.add(entry.backdrop.file);
      for (const layer of entry.layers) {
        for (const item of layer.items) files.add(item.textureFile);
      }
      if (entry.level) {
        for (const g of entry.level.artGroups) files.add(g.file);
        for (const s of entry.level.slots) files.add(s.file);
      }
      break;
    case "word_art":
      if (entry.mode === "pieces" && entry.texts) {
        for (const t of entry.texts) files.add(t.texture.path);
      }
      break;
    case "icon":
      for (const icon of entry.icons) {
        for (const tex of Object.values(icon.states)) files.add(tex.path);
      }
      break;
    case "table":
    case "model_3d":
    case "scene3d_map":
      break;
  }
  return [...files];
}

export async function loadWfPixiAssets(
  manifest: WfAssetManifest,
  options?: WfPixiLoadOptions,
): Promise<WfPixiAssetStore> {
  const store = new WfPixiAssetStore();
  const baseUrl = options?.baseUrl ?? "";
  const pending = new Map<string, string>();

  for (const entry of Object.values(manifest.entries)) {
    for (const file of collectImages(entry)) {
      const key = joinUrl("", entry.baseDir, file);
      if (!pending.has(key)) {
        pending.set(key, joinUrl(baseUrl, entry.baseDir, file));
      }
    }
    if (entry.kind === "word_art" && entry.mode === "bmfont" && entry.fntFile) {
      const fntUrl = joinUrl(baseUrl, entry.baseDir, entry.fntFile);
      await Assets.load(fntUrl);
      store.setFontName(entry.id, entry.font?.face ?? entry.id);
    }
  }

  for (const [key, url] of pending) {
    const tex = await Assets.load<Texture>(url);
    store.setBaseTexture(key, tex);
  }
  return store;
}

export function createWfAnimatedSprite(
  store: WfPixiAssetStore,
  entry: WfFrameAnimationEntry,
  clipName?: string,
): AnimatedSprite {
  const clip = (clipName ? entry.clips.find((c) => c.name === clipName) : entry.clips[0]) ?? entry.clips[0];
  const frames = clip.frames.map((frame) => ({
    texture: store.getTexture(entry.baseDir, frame.texture),
    time: frame.durationMs,
  }));
  const sprite = new AnimatedSprite(frames);
  const firstTex = frames[0]?.texture;
  const w = Math.max(1, firstTex?.width ?? 1);
  const h = Math.max(1, firstTex?.height ?? 1);
  sprite.anchor.set(clip.anchor.x / w, clip.anchor.y / h);
  sprite.loop = clip.looped;
  sprite.play();
  return sprite;
}

export interface WfUiWidgetHandle {
  root: Container;
  setState(role: string): void;
  setValue(norm: number): void;
  getChecked(): boolean;
  setChecked(next: boolean): void;
}

export interface WfUiWidgetOptions {
  onClick?: () => void;
  onToggle?: (checked: boolean) => void;
  onChange?: (value: number) => void;
  initialValue?: number;
  initialChecked?: boolean;
}

function makeUiDisplay(store: WfPixiAssetStore, baseDir: string, st: WfUiState, w: number, h: number): Sprite | NineSliceSprite {
  const texture = store.getTexture(baseDir, st.texture);
  const [left, right, top, bottom] = st.borders;
  if (left > 0 || right > 0 || top > 0 || bottom > 0) {
    return new NineSliceSprite({
      texture,
      leftWidth: left,
      rightWidth: right,
      topHeight: top,
      bottomHeight: bottom,
      width: w,
      height: h,
    });
  }
  const sp = new Sprite(texture);
  sp.width = w;
  sp.height = h;
  return sp;
}

export function createWfUiWidget(
  store: WfPixiAssetStore,
  entry: WfUiKitEntry,
  widgetName: string,
  options?: WfUiWidgetOptions,
): WfUiWidgetHandle {
  const spec = entry.widgets.find((w) => w.name === widgetName) ?? entry.widgets[0];
  if (!spec || spec.states.length === 0) {
    throw new Error(`UI widget ${widgetName} not found in ${entry.path}`);
  }
  const findState = (role: string): WfUiState | undefined => spec.states.find((s) => s.role === role);
  const root = new Container();

  let checked = Boolean(options?.initialChecked);
  let value = Math.max(0, Math.min(1, options?.initialValue ?? 1));

  if (spec.widget === "bar" || spec.widget === "slide") {
    const trackState = findState("track") ?? spec.states[0];
    const fillState = findState("fill");
    const thumbState = findState("thumb");
    const track = makeUiDisplay(store, entry.baseDir, trackState, spec.width, spec.height);
    root.addChild(track);

    let fill: (Sprite | NineSliceSprite) | null = null;
    if (fillState) {
      fill = makeUiDisplay(store, entry.baseDir, fillState, spec.width, spec.height);
      root.addChild(fill);
    }
    let thumb: (Sprite | NineSliceSprite) | null = null;
    if (thumbState && spec.widget === "slide") {
      const sz = Math.min(spec.width, spec.height);
      thumb = makeUiDisplay(store, entry.baseDir, thumbState, sz, sz);
      thumb.y = (spec.height - sz) * 0.5;
      root.addChild(thumb);
    }

    const updateBar = (next: number) => {
      value = Math.max(0, Math.min(1, next));
      if (fill) fill.width = Math.max(0.001, spec.width * value);
      if (thumb) thumb.x = spec.width * value - thumb.width * 0.5;
    };
    updateBar(value);

    if (spec.widget === "slide") {
      root.eventMode = "static";
      root.cursor = "pointer";
      let dragging = false;
      const updateFromPtr = (e: FederatedPointerEvent) => {
        const local = root.toLocal(e.global);
        updateBar(local.x / spec.width);
        options?.onChange?.(value);
      };
      root.on("pointerdown", (e) => {
        dragging = true;
        updateFromPtr(e);
      });
      root.on("globalpointermove", (e) => {
        if (dragging) updateFromPtr(e);
      });
      root.on("pointerup", () => {
        dragging = false;
      });
      root.on("pointerupoutside", () => {
        dragging = false;
      });
    }

    return {
      root,
      setState: () => {},
      setValue: updateBar,
      getChecked: () => checked,
      setChecked: () => {},
    };
  }

  const face = makeUiDisplay(
    store,
    entry.baseDir,
    (checked ? findState("hoverPressed") : findState("rest")) ?? spec.states[0],
    spec.width,
    spec.height,
  );
  root.addChild(face);
  const setState = (role: string) => {
    const st = findState(role) ?? findState("rest") ?? spec.states[0];
    face.texture = store.getTexture(entry.baseDir, st.texture);
  };

  root.eventMode = "static";
  root.cursor = "pointer";
  root.on("pointerover", () => setState(checked ? "hoverPressed" : "hover"));
  root.on("pointerout", () => setState(checked ? "hoverPressed" : "rest"));
  root.on("pointerdown", () => setState("pressed"));
  root.on("pointerup", () => {
    if (spec.widget === "flip") {
      checked = !checked;
      setState(checked ? "hoverPressed" : "rest");
      options?.onToggle?.(checked);
    } else {
      setState("hover");
      options?.onClick?.();
    }
  });

  return {
    root,
    setState,
    setValue: () => {},
    getChecked: () => checked,
    setChecked: (next: boolean) => {
      checked = next;
      setState(checked ? "hoverPressed" : "rest");
    },
  };
}

export interface WfTilemapHandle {
  container: Container;
  obstacles: WfTilemapEntry["obstacles"];
  walkable: WfTilemapEntry["walkable"];
  spawn: WfPoint | null;
}

export function createWfTilemap(store: WfPixiAssetStore, entry: WfTilemapEntry): WfTilemapHandle {
  const container = new Container();
  const sortedGround = [...entry.ground].sort((a, b) => a.level - b.level || a.cell[1] - b.cell[1] || a.cell[0] - b.cell[0]);
  for (const tile of sortedGround) {
    const tex = store.getTexture(entry.baseDir, {
      path: tile.texture,
      region: { x: tile.source.x, y: tile.source.y, w: tile.source.width, h: tile.source.height },
    });
    const sp = new Sprite(tex);
    sp.x = tile.target.x;
    sp.y = tile.target.y;
    sp.width = tile.target.width;
    sp.height = tile.target.height;
    sp.alpha = tile.opacity;
    container.addChild(sp);
  }

  const sortedSprites = [...entry.sprites].sort((a, b) => a.position.y - b.position.y);
  for (const s of sortedSprites) {
    const texFile = entry.textures[s.texture]?.file ?? s.texture;
    const tex = store.getTexture(entry.baseDir, {
      path: texFile,
      region: s.source ? { x: s.source.x, y: s.source.y, w: s.source.width, h: s.source.height } : null,
    });
    const sp = new Sprite(tex);
    sp.x = s.position.x;
    sp.y = s.position.y;
    sp.width = s.rect.width;
    sp.height = s.rect.height;
    sp.rotation = s.rotation;
    sp.scale.x = s.flipX ? -Math.abs(sp.scale.x) : Math.abs(sp.scale.x);
    sp.alpha = s.opacity;
    container.addChild(sp);
  }

  return { container, obstacles: entry.obstacles, walkable: entry.walkable, spawn: entry.spawn ?? null };
}

export interface WfPropHandle {
  container: Container;
  setState(stateId: string): void;
  playTransition(animId: string): void;
  getCollisionPolygons(): WfPoint[][];
}

export function createWfProp(
  store: WfPixiAssetStore,
  entry: WfPropSetEntry,
  objectName: string,
  initialStateId?: string,
): WfPropHandle {
  const obj = entry.objects.find((o) => o.name === objectName) ?? entry.objects[0];
  if (!obj || obj.states.length === 0) {
    throw new Error(`Prop object ${objectName} not found in ${entry.path}`);
  }
  const container = new Container();
  let current = (initialStateId ? obj.states.find((s) => s.id === initialStateId) : obj.states[0]) ?? obj.states[0];
  const sp = new Sprite(store.getTexture(entry.baseDir, current.texture));
  sp.anchor.set(obj.anchor.x / obj.canvasWidth, obj.anchor.y / obj.canvasHeight);
  container.addChild(sp);

  let activeAnim: AnimatedSprite | null = null;

  return {
    container,
    setState(stateId: string) {
      const next = obj.states.find((s) => s.id === stateId);
      if (!next) return;
      current = next;
      if (activeAnim) {
        container.removeChild(activeAnim);
        activeAnim.destroy();
        activeAnim = null;
      }
      sp.visible = true;
      sp.texture = store.getTexture(entry.baseDir, current.texture);
    },
    playTransition(animId: string) {
      const anim = obj.animations.find((a) => a.id === animId);
      if (!anim || anim.textures.length === 0) return;
      if (activeAnim) {
        container.removeChild(activeAnim);
        activeAnim.destroy();
      }
      sp.visible = false;
      activeAnim = new AnimatedSprite(
        anim.textures.map((t, i) => ({
          texture: store.getTexture(entry.baseDir, t),
          time: anim.durationsMs[i] ?? 100,
        })),
      );
      activeAnim.anchor.set(obj.anchor.x / obj.canvasWidth, obj.anchor.y / obj.canvasHeight);
      activeAnim.loop = anim.looped;
      activeAnim.play();
      container.addChild(activeAnim);
    },
    getCollisionPolygons() {
      return current.collision.map((poly) => poly.map((p) => ({ x: container.x + p.x, y: container.y + p.y })));
    },
  };
}

const builtinCache = new Map<string, Texture>();

function getBuiltinTexture(picture: string): Texture {
  const existing = builtinCache.get(picture);
  if (existing) return existing;
  const size = 32;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    const half = size / 2;
    const grad = ctx.createRadialGradient(half, half, 0, half, half, half);
    if (picture === "ring") {
      grad.addColorStop(0, "rgba(255,255,255,0)");
      grad.addColorStop(0.55, "rgba(255,255,255,0.2)");
      grad.addColorStop(0.8, "rgba(255,255,255,1)");
      grad.addColorStop(1, "rgba(255,255,255,0)");
    } else if (picture === "spark") {
      grad.addColorStop(0, "rgba(255,255,255,1)");
      grad.addColorStop(0.35, "rgba(255,255,255,0.85)");
      grad.addColorStop(1, "rgba(255,255,255,0)");
    } else {
      grad.addColorStop(0, "rgba(255,255,255,1)");
      grad.addColorStop(0.5, "rgba(255,255,255,0.5)");
      grad.addColorStop(1, "rgba(255,255,255,0)");
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
  }
  const tex = new Texture({ source: new CanvasSource({ resource: canvas }) });
  builtinCache.set(picture, tex);
  return tex;
}

export class WfPixiParticleContainer {
  readonly entry: WfParticleEntry;
  readonly sim: WfParticleSimulation;
  readonly container = new Container();
  private readonly pools: Sprite[][] = [];
  private readonly textures: Texture[];
  private readonly colorCache: ReturnType<typeof createParticleColorCache>;

  constructor(store: WfPixiAssetStore, entry: WfParticleEntry) {
    this.entry = entry;
    this.sim = new WfParticleSimulation(entry);
    this.colorCache = createParticleColorCache(entry.emitters);
    this.textures = entry.emitters.map((em) =>
      em.sprite ? store.getTexture(entry.baseDir, { path: em.picture }) : getBuiltinTexture(em.picture),
    );
    for (let i = 0; i < entry.emitters.length; i++) {
      this.pools.push([]);
    }
    this.syncVisuals();
  }

  step(dtSec: number): void {
    this.sim.advance(dtSec);
    this.syncVisuals();
  }

  reset(): void {
    this.sim.reset();
    this.syncVisuals();
  }

  private syncVisuals(): void {
    const evaluated = evaluateParticles(this.sim, this.colorCache, false);
    const byEmitter = this.entry.emitters.map(() => [] as typeof evaluated);
    for (const p of evaluated) byEmitter[p.emitterIndex]?.push(p);

    for (let ei = 0; ei < this.entry.emitters.length; ei++) {
      const list = byEmitter[ei];
      const pool = this.pools[ei];
      const tex = this.textures[ei];
      const blendMode = this.entry.emitters[ei].blend === "additive" ? "add" : "normal";

      while (pool.length < list.length) {
        const sp = new Sprite(tex);
        sp.anchor.set(0.5, 0.5);
        sp.blendMode = blendMode;
        this.container.addChild(sp);
        pool.push(sp);
      }

      for (let i = 0; i < pool.length; i++) {
        const sp = pool[i];
        if (i >= list.length) {
          sp.visible = false;
          continue;
        }
        const p = list[i];
        sp.visible = true;
        sp.x = p.x;
        sp.y = p.y;
        sp.alpha = p.alpha;
        sp.tint = p.colorInt24;
        const s = Math.max(0.01, p.size / Math.max(1, sp.texture.width));
        sp.scale.set(p.flipX ? -s : s, s * p.stretchY);
        sp.rotation = p.rotation;
      }
    }
  }
}

export interface WfWholeMapHandle {
  container: Container;
  nav: WfWholeMapNavRuntime;
  character: WfWholeMapEntry["character"];
  connections: WfWholeMapEntry["connections"];
  regions: WfWholeMapEntry["regions"];
  updateActorDepth(actor: { zIndex: number }, footY: number, layerZ?: number): void;
}

export function createWfWholeMap(store: WfPixiAssetStore, entry: WfWholeMapEntry): WfWholeMapHandle {
  const container = new Container();
  container.sortableChildren = true;

  for (const tile of entry.tiles) {
    const baseTex = store.getTexture(entry.baseDir, { path: tile.baseFile });
    const baseRes = (baseTex.source as { resource?: CanvasImageSource } | undefined)?.resource;
    let tileTex = baseTex;
    if (baseRes && tile.maskFile) {
      const maskTex = store.getTexture(entry.baseDir, { path: tile.maskFile });
      const maskRes = (maskTex.source as { resource?: CanvasImageSource } | undefined)?.resource ?? null;
      const canvas = composeMaskedTileCanvas(baseRes, maskRes, tile.width, tile.height);
      tileTex = new Texture({ source: new CanvasSource({ resource: canvas }) });
    }
    const sp = new Sprite(tileTex);
    sp.x = tile.x;
    sp.y = tile.y;
    sp.width = tile.width;
    sp.height = tile.height;
    sp.zIndex = -100_000;
    container.addChild(sp);
  }

  for (const part of sortWholeMapParts(entry.parts)) {
    const sp = new Sprite(store.getTexture(entry.baseDir, { path: part.textureFile }));
    sp.x = part.x;
    sp.y = part.y;
    const bandOffset = part.sortMode === "below" ? -10_000 : part.sortMode === "sorted" ? part.foot.y : 10_000;
    sp.zIndex = part.layerZ * 100_000 + bandOffset + part.drawOrder * 0.001;
    container.addChild(sp);
  }

  return {
    container,
    nav: new WfWholeMapNavRuntime(entry),
    character: entry.character,
    connections: entry.connections,
    regions: entry.regions,
    updateActorDepth(actor, footY, layerZ = 0) {
      actor.zIndex = layerZ * 100_000 + footY;
    },
  };
}

export interface WfScrollingSceneHandle {
  behindContainer: Container;
  levelContainer: Container;
  frontContainer: Container;
  level: WfScrollingSceneEntry["level"];
  update(elapsedSec: number, cameraX: number): void;
}

export function createWfScrollingScene(
  store: WfPixiAssetStore,
  entry: WfScrollingSceneEntry,
  options?: { viewportWidth?: number; viewportHeight?: number },
): WfScrollingSceneHandle {
  const behindContainer = new Container();
  const levelContainer = new Container();
  const frontContainer = new Container();
  const viewW = options?.viewportWidth ?? Math.max(entry.backdrop.width, 1280);
  const viewH = options?.viewportHeight ?? 720;

  let backdrop: TilingSprite | null = null;
  if (entry.backdrop.visible) {
    backdrop = new TilingSprite({
      texture: store.getTexture(entry.baseDir, { path: entry.backdrop.file }),
      width: viewW,
      height: viewH,
    });
    backdrop.alpha = entry.backdrop.opacity;
    behindContainer.addChild(backdrop);
  }

  const animated: Array<{
    sprite: Sprite;
    item: WfScrollingSceneEntry["layers"][number]["items"][number];
    speed: number;
  }> = [];

  for (const layer of entry.layers) {
    if (!layer.visible) continue;
    const parent = layer.placement === "front" ? frontContainer : behindContainer;
    for (const item of layer.items) {
      const sp = new Sprite(store.getTexture(entry.baseDir, { path: item.textureFile }));
      sp.anchor.set(0.5, 0.5);
      sp.scale.set(item.flipX ? -item.scale : item.scale, item.scale);
      sp.alpha = item.opacity * layer.opacity;
      sp.x = item.x;
      sp.y = item.y;
      parent.addChild(sp);
      animated.push({ sprite: sp, item, speed: layer.speed });
    }
  }

  if (entry.level) {
    for (const group of entry.level.artGroups) {
      const sp = new Sprite(store.getTexture(entry.baseDir, { path: group.file }));
      sp.x = group.x;
      sp.y = group.y;
      levelContainer.addChild(sp);
    }
    for (const slot of entry.level.slots) {
      const sp = new Sprite(store.getTexture(entry.baseDir, { path: slot.file }));
      sp.anchor.set(slot.anchor, slot.base);
      sp.x = slot.x;
      sp.y = slot.y;
      if (slot.depth === "front") {
        frontContainer.addChild(sp);
      } else {
        levelContainer.addChild(sp);
      }
    }
  }

  return {
    behindContainer,
    levelContainer,
    frontContainer,
    level: entry.level ?? null,
    update(elapsedSec: number, cameraX: number) {
      if (backdrop) {
        backdrop.tilePosition.x = -(cameraX * entry.backdrop.speed - entry.backdrop.drift * elapsedSec);
      }
      for (const node of animated) {
        const tr = computeParallaxTransform(node.item, node.speed, elapsedSec, cameraX);
        node.sprite.x = tr.x;
        node.sprite.y = tr.y;
        node.sprite.rotation = tr.rotationRad;
      }
    },
  };
}

export function createWfWordArt(
  store: WfPixiAssetStore,
  entry: WfWordArtEntry,
  value: string,
  fontSize?: number,
): BitmapText | Sprite {
  if (entry.mode === "bmfont") {
    return new BitmapText({
      text: value,
      style: {
        fontFamily: store.getFontName(entry),
        fontSize: fontSize ?? entry.font?.size ?? 32,
      },
    });
  }
  const item = entry.texts?.find((t) => t.name === value) ?? entry.texts?.[0];
  if (!item) {
    throw new Error(`word_art piece ${value} not found in ${entry.path}`);
  }
  const sp = new Sprite(store.getTexture(entry.baseDir, item.texture));
  sp.width = item.width;
  sp.height = item.height;
  return sp;
}

export function createWfIcon(
  store: WfPixiAssetStore,
  entry: WfIconSetEntry,
  iconName: string,
  stateRole = "rest",
): Sprite {
  const icon = entry.icons.find((i) => i.name === iconName) ?? entry.icons[0];
  if (!icon) {
    throw new Error(`Icon ${iconName} not found in ${entry.path}`);
  }
  const tex = icon.states[stateRole] ?? Object.values(icon.states)[0];
  if (!tex) {
    throw new Error(`Icon ${icon.name} has no states`);
  }
  const sp = new Sprite(store.getTexture(entry.baseDir, tex));
  sp.width = icon.width;
  sp.height = icon.height;
  return sp;
}

export function getWfTableRows<T extends Record<string, unknown> = Record<string, unknown>>(entry: WfTableEntry): T[] {
  return entry.rows as T[];
}

export function findWfTableRow<T extends Record<string, unknown> = Record<string, unknown>>(
  entry: WfTableEntry,
  field: string,
  value: unknown,
): T | undefined {
  return (entry.rows as T[]).find((row) => row[field] === value);
}
