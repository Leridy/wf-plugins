//! Node-specific sidecar decoding (including `model_3d` & `scene3d_map`), texture validation, and manifest entry construction.
use crate::{
    model::{
        Animation, Kit, Model3d, ParallaxMap, ParticleEffect, PropSet, Scene3dMap, TileMap, WholeMap, png,
        web_extra::{WordArtDoc, parse_icons, parse_table, parse_word_art_fnt, parse_word_art_texts},
    },
    paths::{self, invalid},
    types::Element,
    web::{
        ASSETS_TS_NAME, NodeMeta, animation_entry, icon_entry, model3d_entry, parallax_entry, particle_entry,
        prop_entry, scene3d_map_entry, table_entry, tilemap_entry, ui_entry, whole_map_entry, word_art_entry,
    },
};
use plugin_api::platform::LockedRow;
use plugin_guest::{Host, HostError, Platform};
use serde_json::Value;
use std::collections::BTreeSet;
use std::path::Path;

const MAX_GLB: usize = 32 << 20;

#[allow(clippy::too_many_arguments)]
pub(crate) fn decode_basic_node(
    host: &dyn Platform,
    row: &LockedRow,
    directory: &str,
    prefix: &str,
    node_type: &str,
    meta: NodeMeta<'_>,
    entry_key: &str,
    bytes: &[u8],
) -> Result<(Value, Vec<Element>, Vec<String>), HostError> {
    match node_type {
        "frame_animation" | "character_effect" => {
            let anim = Animation::read(bytes)?;
            load_textures(
                host,
                row,
                directory,
                prefix,
                anim.clips
                    .iter()
                    .flat_map(|c| &c.frames)
                    .map(|f| f.texture.path.as_str()),
            )?;
            let elems = anim
                .clips
                .iter()
                .map(|c| Element {
                    name: c.name.clone(),
                    prefab: Some(format!("{ASSETS_TS_NAME}#{entry_key}")),
                })
                .collect();
            Ok((animation_entry(meta, node_type, &anim), elems, Vec::new()))
        }
        "ui" => {
            let kit = Kit::read(bytes)?;
            load_textures(
                host,
                row,
                directory,
                prefix,
                kit.extra_textures.iter().map(|t| t.path.as_str()),
            )?;
            let elems = kit
                .widgets
                .iter()
                .map(|w| Element {
                    name: w.name.clone(),
                    prefab: Some(format!("{ASSETS_TS_NAME}#{entry_key}")),
                })
                .collect();
            Ok((ui_entry(meta, &kit), elems, kit.notes))
        }
        "tilemap" => {
            let map = TileMap::read(bytes)?;
            load_textures(
                host,
                row,
                directory,
                prefix,
                map.textures.values().map(|t| t.file.as_str()),
            )?;
            Ok((tilemap_entry(meta, &map), Vec::new(), Vec::new()))
        }
        _ => {
            let props = PropSet::read(bytes)?;
            load_textures(
                host,
                row,
                directory,
                prefix,
                props.objects.iter().flat_map(|o| {
                    o.states.iter().map(|s| s.texture.path.as_str()).chain(
                        o.animations
                            .iter()
                            .flat_map(|a| a.textures.iter().map(|t| t.path.as_str())),
                    )
                }),
            )?;
            let elems = props
                .objects
                .iter()
                .map(|o| Element {
                    name: o.name.clone(),
                    prefab: Some(format!("{ASSETS_TS_NAME}#{entry_key}")),
                })
                .collect();
            Ok((prop_entry(meta, &props), elems, props.notes))
        }
    }
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn decode_world_or_extra(
    host: &dyn Platform,
    row: &LockedRow,
    directory: &str,
    prefix: &str,
    node_type: &str,
    sidecar_name: &str,
    meta: NodeMeta<'_>,
    entry_key: &str,
    bytes: &[u8],
    locked: &BTreeSet<String>,
) -> Result<(Value, Vec<Element>, Vec<String>), HostError> {
    match node_type {
        "particle_effect" => {
            let fx = ParticleEffect::read(bytes)?;
            load_textures(
                host,
                row,
                directory,
                prefix,
                fx.emitters.iter().filter(|e| e.sprite).map(|e| e.picture.as_str()),
            )?;
            Ok((particle_entry(meta, &fx), Vec::new(), fx.notes))
        }
        "whole_map" => {
            let wm = WholeMap::read(bytes, locked, prefix)?;
            load_textures(host, row, directory, prefix, wm.texture_paths())?;
            Ok((whole_map_entry(meta, &wm), Vec::new(), Vec::new()))
        }
        "scrolling_scene" | "scroll_map" => {
            let map = ParallaxMap::read(bytes, locked, prefix)?;
            load_textures(host, row, directory, prefix, map.texture_paths())?;
            Ok((parallax_entry(meta, &map), Vec::new(), Vec::new()))
        }
        "model_3d" => {
            let glb_name = "main.glb";
            let locked_glb = paths::join(prefix, glb_name);
            if !locked.contains(&locked_glb) {
                return Err(invalid(format!("locked file {locked_glb:?} is missing")));
            }
            let glb_bytes = read_glb(host, &paths::join(directory, &locked_glb))?;
            let model = Model3d::read(bytes, &glb_bytes, glb_name.to_owned())?;
            let elems = model
                .clips
                .iter()
                .map(|c| Element {
                    name: c.name.clone(),
                    prefab: Some(format!("{ASSETS_TS_NAME}#{entry_key}")),
                })
                .collect();
            Ok((model3d_entry(meta, &model), elems, Vec::new()))
        }
        "scene3d_map" => {
            let scene = Scene3dMap::read(bytes, sidecar_name.to_owned())?;
            let notes = scene.notes.clone();
            Ok((scene3d_map_entry(meta, &scene), Vec::new(), notes))
        }
        "word_art" => decode_word_art(host, row, directory, prefix, sidecar_name, meta, entry_key, bytes),
        "icon" => {
            let (icons, extras) = parse_icons(bytes)?;
            load_textures(host, row, directory, prefix, extras.iter().map(|t| t.path.as_str()))?;
            let elems = icons
                .iter()
                .map(|i| Element {
                    name: i.name.clone(),
                    prefab: Some(format!("{ASSETS_TS_NAME}#{entry_key}")),
                })
                .collect();
            Ok((icon_entry(meta, &icons), elems, Vec::new()))
        }
        _ => {
            let doc = parse_table(sidecar_name, bytes)?;
            Ok((table_entry(meta, &doc), Vec::new(), Vec::new()))
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn decode_word_art(
    host: &dyn Platform,
    row: &LockedRow,
    directory: &str,
    prefix: &str,
    sidecar_name: &str,
    meta: NodeMeta<'_>,
    entry_key: &str,
    bytes: &[u8],
) -> Result<(Value, Vec<Element>, Vec<String>), HostError> {
    let doc = if sidecar_name == "texts.json" {
        parse_word_art_texts(bytes)?
    } else {
        parse_word_art_fnt(sidecar_name, bytes)?
    };
    match &doc {
        WordArtDoc::BmFont { font, .. } => {
            load_textures(host, row, directory, prefix, font.pages.iter().map(String::as_str))?;
        }
        WordArtDoc::Texts { texts } => {
            load_textures(
                host,
                row,
                directory,
                prefix,
                texts.iter().map(|t| t.texture.path.as_str()),
            )?;
        }
    }
    let elems = match &doc {
        WordArtDoc::BmFont { font, .. } => vec![Element {
            name: font.face.clone(),
            prefab: Some(format!("{ASSETS_TS_NAME}#{entry_key}")),
        }],
        WordArtDoc::Texts { texts } => texts
            .iter()
            .map(|t| Element {
                name: t.name.clone(),
                prefab: Some(format!("{ASSETS_TS_NAME}#{entry_key}")),
            })
            .collect(),
    };
    Ok((word_art_entry(meta, &doc), elems, Vec::new()))
}

pub(crate) fn find_sidecar(node_type: &str, row: &LockedRow) -> Option<(String, String)> {
    let fixed = match node_type {
        "frame_animation" | "character_effect" => Some("animation.json"),
        "particle_effect" | "whole_map" | "scrolling_scene" | "scroll_map" => Some("main.json"),
        "scene3d_map" => Some("engine-scene.glb"),
        "model_3d" => Some("model.json"),
        "tilemap" => Some("tilemap.json"),
        "prop" => Some("props.json"),
        "ui" => Some("ui.json"),
        "icon" => Some("icons.json"),
        _ => None,
    };
    if let Some(name) = fixed {
        return row.files.iter().find_map(|f| split_file_prefix(f, name));
    }
    if node_type == "word_art" {
        if let Some(found) = row.files.iter().find_map(|f| split_file_prefix(f, "texts.json")) {
            return Some(found);
        }
        return row
            .files
            .iter()
            .find(|f| Path::new(f).extension().is_some_and(|e| e.eq_ignore_ascii_case("fnt")))
            .map(|f| split_parent_file(f));
    }
    if node_type == "table" {
        return row
            .files
            .iter()
            .find(|f| {
                Path::new(f)
                    .extension()
                    .is_some_and(|e| e.eq_ignore_ascii_case("json") || e.eq_ignore_ascii_case("csv"))
            })
            .map(|f| split_parent_file(f));
    }
    None
}

fn split_file_prefix(path: &str, target: &str) -> Option<(String, String)> {
    if path == target {
        Some((String::new(), target.to_owned()))
    } else {
        path.strip_suffix(&format!("/{target}"))
            .map(|prefix| (prefix.to_owned(), target.to_owned()))
    }
}

fn split_parent_file(path: &str) -> (String, String) {
    match path.rsplit_once('/') {
        Some((parent, name)) => (parent.to_owned(), name.to_owned()),
        None => (String::new(), path.to_owned()),
    }
}

fn read_glb(host: &dyn Host, path: &str) -> Result<Vec<u8>, HostError> {
    let bytes = host.read(path)?;
    if bytes.len() > MAX_GLB {
        return Err(invalid(format!("{path} exceeds 32 MiB GLB limit")));
    }
    Ok(bytes)
}

pub(crate) fn load_textures<'a>(
    host: &dyn Platform,
    row: &LockedRow,
    directory: &str,
    prefix: &str,
    paths_iter: impl Iterator<Item = &'a str>,
) -> Result<(), HostError> {
    let locked: BTreeSet<&str> = row.files.iter().map(String::as_str).collect();
    let mut seen = BTreeSet::new();
    for rel in paths_iter {
        if !seen.insert(rel) {
            continue;
        }
        paths::relative(rel)?;
        let full_locked = paths::join(prefix, rel);
        if !locked.contains(full_locked.as_str()) {
            return Err(invalid(format!("locked file {full_locked:?} is missing")));
        }
        let disk_path = paths::join(directory, &full_locked);
        let bytes = host.read(&disk_path)?;
        let _ = png::dimensions(&bytes)?;
    }
    Ok(())
}
