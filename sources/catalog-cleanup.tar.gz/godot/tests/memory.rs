//! The plugin runs in a WebAssembly store with a 256 MiB memory limit. This
//! measures what hostile files of the largest size it reads (4 MiB) make it
//! allocate on the host target, where allocations are no smaller than there.
#![allow(clippy::print_stderr, reason = "the peaks are the test's result")]

use globset::Glob;
use plugin_api::Failure;
use plugin_guest::{Host, HostError, counting::Counting};
use plugin_protocols::lint::LintInput;
use std::{
    collections::BTreeMap,
    fmt::Write,
    time::{Duration, Instant},
};
use wf_godot::lint;

#[global_allocator]
static ALLOCATOR: Counting = Counting;

/// What a run may allocate above what it started with: half the store's
/// 256 MiB, which also holds the component and the host's copies, and a
/// native pointer is twice a wasm32 one.
const BUDGET: usize = 128 << 20;
const FILE: usize = 4 << 20;

struct Files(BTreeMap<String, String>);

impl Host for Files {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        self.0.keys().filter(|path| matcher.is_match(path)).cloned().collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.0
            .get(path)
            .map(|text| text.as_bytes().to_vec())
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }

    fn warn(&self, _message: &str) {}
}

/// Lints a project of `project.godot` and one hostile file; returns the peak
/// allocation above the start and the time taken.
fn measure(name: &str, text: String) -> (usize, Duration) {
    let host = Files(BTreeMap::from([
        ("project.godot".to_owned(), "config_version=5\n".to_owned()),
        (name.to_owned(), text),
    ]));
    let started = Instant::now();
    let (output, peak) = Counting::peak(|| lint(&host, &LintInput::default()));
    let elapsed = started.elapsed();
    assert!(output.checked.iter().any(|f| f == name), "{name} was checked");
    (peak, elapsed)
}

/// `head`, `unit` repeated to fill the largest file the plugin reads, and `tail`.
fn filled(head: &str, unit: &str, tail: &str) -> String {
    let count = (FILE - head.len() - tail.len()) / unit.len();
    format!("{head}{}{tail}", unit.repeat(count))
}

fn cases() -> Vec<(&'static str, String)> {
    let mut script = String::new();
    while script.len() < FILE - 64 {
        let n = script.len();
        writeln!(script, "var a{n} = \"res://x{n}.png\"").unwrap();
    }
    vec![
        (
            "big_packed_array.tscn",
            filled("[node name=\"N\"]\ntile_data = PackedInt32Array(", "0, ", ")\n"),
        ),
        ("numbers.tres", filled("[resource]\nvalues = [", "1, ", "]\n")),
        ("empty_lists.tres", filled("[resource]\nvalues = [", "[],", "]\n")),
        ("calls.tres", filled("[resource]\nvalues = [", "A(),", "]\n")),
        ("strings.tres", filled("[resource]\nvalues = [", "\"a\",", "]\n")),
        ("properties.tres", filled("", "a = 1\n", "")),
        ("headers.tscn", filled("", "[ext_resource id=\"1\"]", "")),
        ("brackets.tres", filled("[resource]\nvalues = ", "[", "")),
        ("paths.gd", script),
    ]
}

/// One test, so the cases run one after another and the peaks are not mixed.
#[test]
fn a_4_mib_file_stays_far_under_the_memory_limit() {
    for (name, text) in cases() {
        assert!(text.len() <= FILE, "{name}: {}", text.len());
        let (peak, elapsed) = measure(name, text);
        eprintln!("{name}: peak {} KiB, {elapsed:?}", peak >> 10);
        assert!(peak < BUDGET, "{name} allocated {} MiB", peak >> 20);
        assert!(elapsed < Duration::from_secs(20), "{name} took {elapsed:?}");
    }
}
