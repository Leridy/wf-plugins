# missing-resource-scene

An `ext_resource` whose path does not exist, with no uid (`.tres`), with an unknown uid (`.tscn`) and without one (`.tscn`). Godot reports `[ext_resource] referenced non-existent resource at: res://art/missing.png`; the `.tres` fails to load entirely, the `.tscn` loads with a null texture. Godot attributes the error to the line where the id is *used* (line 9, 12 and 6), not to the `[ext_resource]` line the plugin reports; for the unknown uid it also warns `invalid UID … using text path instead`.
