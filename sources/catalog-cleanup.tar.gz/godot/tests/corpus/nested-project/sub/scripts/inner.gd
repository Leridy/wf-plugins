extends SceneTree

const INNER := "res://art/inner.png"

func _init() -> void:
	print("inner: ", load(INNER))
	quit()
