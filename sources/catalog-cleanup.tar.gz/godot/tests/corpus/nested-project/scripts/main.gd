extends SceneTree

const OWN := "res://art/own.png"
const INNER := "res://sub/art/inner.png"

func _init() -> void:
	print("own: ", load(OWN))
	print("inner: ", load(INNER))
	quit()
