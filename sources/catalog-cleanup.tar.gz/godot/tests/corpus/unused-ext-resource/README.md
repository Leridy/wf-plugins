# unused-ext-resource

A `[ext_resource]` (`2_unused`) that no `ExtResource("…")` uses. Godot loads the scene without any error or warning, so this is a lint-only finding; `expected-fixed/` has the line removed (`load_steps` is left alone) and also loads cleanly.
