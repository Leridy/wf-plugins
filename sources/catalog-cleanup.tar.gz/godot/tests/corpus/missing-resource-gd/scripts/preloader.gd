const OTHER = preload("res://scripts/gone.gd")
