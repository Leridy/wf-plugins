# missing-resource-gd

`preload("res://scripts/gone.gd")` and `load("res://art/missing.png")` in GDScript. Godot reports `Parse Error: Preload file "res://scripts/gone.gd" does not exist.` for the preload at load time, and `Resource file not found: res://art/missing.png` only when the `load()` line actually runs (instantiating the script), because `load()` is a runtime call.
