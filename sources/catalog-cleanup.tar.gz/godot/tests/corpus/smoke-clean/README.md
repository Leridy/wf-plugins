Every reference resolves; comments, `^"…"` NodePaths and the computed path
`"res://levels/level_" + …` are not references. Godot 4.7.1 imports and runs
the main scene without a warning or error.
