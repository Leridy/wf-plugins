extends Sprite2D
## Loads "res://not/a/reference.png" only in this comment.

const ICON := preload("res://art/icon.svg")
const ART_DIR := "res://art/"
var target := ^"res://looks/like/a/path"
var level := "res://levels/level_" + str(1) + ".tscn"


func _ready() -> void:
	texture = ICON  # load("res://gone.png") stays a comment
