extends Node

# res://comment/only.png is not a reference
const NODE := ^"res://nodepath/not-a-file.png"
var in_text := """
# not a comment, and "res://docs/inside-text.png" does not start the value
res://docs/line-start.png
"""
var triple = load("""res://docs/triple.txt""")
var string_name = load(&"res://art/string-name.png")
var single = load('res://art/single.png')
var after_hash = ["# not a comment", load("res://art/after-hash.png")]
var ok = load("res://art/exists.png")
