# malformed-tscn

`scenes/broken.tscn` has unterminated `[ext_resource` and `[node` headers and a missing `)`, so the plugin must skip it without crashing and report nothing for it (it also names a missing path that must not be reported). Godot fails to load it: `res://scenes/broken.tscn:4 - Parse Error: Unexpected end of file.` The valid `scripts/ok.gd` next to it still gets its `missing-resource` diagnostic, which Godot confirms with `Resource file not found: res://art/missing.png` when the script runs.
