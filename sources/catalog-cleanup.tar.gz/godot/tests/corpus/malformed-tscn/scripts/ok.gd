extends Node

var texture = load("res://art/missing.png")
