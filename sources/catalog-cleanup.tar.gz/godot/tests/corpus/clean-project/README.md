# clean-project

A project where every reference is valid: `run/main_scene`, `config/icon`, an autoload `*res://` value, `preload`/`load` in `.gd` (including a `&"…"` StringName, a `'…'` string, a directory ending in `/`, a `^"…"` NodePath and a `res://` path in a comment, none of which may be reported) and a `.tscn` that uses all its `ext_resource` and `sub_resource` ids. Godot 4.7.1 imports and loads the project and instantiates the scene without any error or warning, so `expected.json` is an empty array.
