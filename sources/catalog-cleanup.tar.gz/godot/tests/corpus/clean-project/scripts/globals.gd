extends Node

const PLAYER := preload("res://scripts/player.gd")
