extends Node2D

var texture: Texture2D = load("res://art/icon.png")
var other := load('res://art/icon.png')
var dir := "res://art/"
var name_ref := &"res://art/icon.png"
var nodepath := ^"Sprite/res://not/a/file"
# res://comment/only.png is not a reference
