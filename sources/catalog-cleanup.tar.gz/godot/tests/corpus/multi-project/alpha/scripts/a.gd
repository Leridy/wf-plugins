extends Node

var shared = load("res://art/shared.png")
var other = load("res://art/only-in-beta.png")
