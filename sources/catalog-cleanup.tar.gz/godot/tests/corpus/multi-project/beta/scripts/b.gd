extends Node

var shared = load("res://art/shared.png")
var own = load("res://art/only-in-beta.png")
