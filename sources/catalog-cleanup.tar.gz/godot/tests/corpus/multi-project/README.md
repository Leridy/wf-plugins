# multi-project

Two Godot projects side by side (`alpha/`, `beta/`), each with its own `project.godot`; `res://` resolves to the nearest one. `res://art/shared.png` exists only in `alpha` and `res://art/only-in-beta.png` only in `beta`, so each project has exactly one missing reference. Godot, run on each project separately, reports `Resource file not found: res://art/only-in-beta.png` for alpha and `res://art/shared.png` for beta.
