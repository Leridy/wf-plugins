extends SceneTree

const SCENES_DIR := "res://scenes/"
const SCENES_AS_FILE := "res://scenes"
const MAIN := "res://scenes/main.tscn"

func _init() -> void:
	print("dir: ", "opened" if DirAccess.open(SCENES_DIR) else "cannot open")
	print("main: ", load(MAIN))
	print("directory as a file: ", load(SCENES_AS_FILE))
	quit()
