# reference-names-directory

A reference that names a directory is no file. `load("res://scenes")` is reported as `missing-resource`: Godot 4.7.1 logs `Resource file not found: res://scenes` and returns null, while `DirAccess.open("res://scenes/")` (the trailing `/` makes it a directory reference, not reported) opens and `res://scenes/main.tscn` loads.
