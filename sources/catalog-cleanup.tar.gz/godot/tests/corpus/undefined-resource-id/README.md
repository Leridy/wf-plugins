# undefined-resource-id

`ExtResource("9_x")` without a matching `[ext_resource]` (line 12) and `SubResource("RectangleShape2D_gone")` without a `[sub_resource]` (line 18). Godot fails to load the whole scene: `Parse Error: Parse error. [Resource file res://scenes/main.tscn:12]`; with the first removed, `Condition "!int_resources.has(id)" is true … [Resource file res://scenes/main.tscn:18]`. Godot stops at the first error, so each was confirmed separately.
