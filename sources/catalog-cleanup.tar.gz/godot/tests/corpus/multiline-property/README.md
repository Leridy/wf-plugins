# multiline-property

A `.tscn` property value spanning several lines (an array containing a dictionary) that holds `ExtResource(…)` uses and a `"res://art/icon.png"` string; ids used only inside it must not be reported unused, and the lines after it keep correct numbers. Godot parses the multi-line value, then reports `Resource file not found: res://art/missing.png` (the `ext_resource` on line 5) and `Parse Error … [Resource file res://scenes/main.tscn:16]` for the undefined `SubResource("Nope_1")` after it.
