extends Node
const GONE := preload("res://gone.png")
