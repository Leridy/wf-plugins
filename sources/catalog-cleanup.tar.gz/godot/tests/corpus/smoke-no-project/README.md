Broken references, but no `project.godot`: nothing is a Godot project, so
nothing is checked. Godot has no project to open here.
