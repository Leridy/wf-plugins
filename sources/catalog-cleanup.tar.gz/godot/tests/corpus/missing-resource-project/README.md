# missing-resource-project

`run/main_scene` and an autoload (`"*res://scripts/globals.gd"`) in `project.godot` that point at files that do not exist. Godot reports `Cannot open file 'res://scenes/main.tscn'` and `Attempt to open script 'res://scripts/globals.gd' resulted in error 'File not found'` and refuses to run the project.
