extends Node

func _ready() -> void:
	var path: String = get_meta("config")
	load(path)
