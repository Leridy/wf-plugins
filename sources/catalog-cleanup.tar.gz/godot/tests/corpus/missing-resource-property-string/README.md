# missing-resource-property-string

A `"res://…"` string in a plain node property (`metadata/config`), not an `ext_resource`. Godot does not check such strings when the scene loads; it fails only when a script uses the value (`config_loader.gd` calls `load(get_meta("config"))` in `_ready`): `Failed loading resource: res://data/gone.json`, seen when running the main scene.
