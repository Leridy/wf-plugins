One of each rule. Godot 4.7.1 on macOS warns "Case mismatch opening requested
file" for `Scripts/global.gd` and `scripts/Player.gd`, reports "Resource file
not found: res://art/missing.png", and stops loading `main.tscn` at the
undefined `SubResource("Material_none")`. The stale `res://old/enemy.gd` loads
silently through its uid.
