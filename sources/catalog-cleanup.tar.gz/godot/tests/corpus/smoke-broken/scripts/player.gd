extends Node2D

var next := load("res://scenes/next.tscn")
