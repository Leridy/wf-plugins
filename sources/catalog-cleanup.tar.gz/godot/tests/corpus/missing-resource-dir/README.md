# missing-resource-dir

A directory reference ending in `/`: `res://art/` exists (not reported), `res://levels/` does not. Run as a script, `DirAccess.open("res://art/")` opens and `DirAccess.open("res://levels/")` fails (the script prints `cannot open`); Godot logs no error line by itself.
