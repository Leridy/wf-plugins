extends SceneTree

const ART_DIR := "res://art/"
const LEVELS_DIR := "res://levels/"

func _init() -> void:
	for dir_path in [ART_DIR, LEVELS_DIR]:
		var dir := DirAccess.open(dir_path)
		print(dir_path, " -> ", "opened" if dir else "cannot open")
	quit()
