extends Node2D

var portrait = load("res://art/hero.png")
var self_ref = load("res://Scripts/hero.gd")
