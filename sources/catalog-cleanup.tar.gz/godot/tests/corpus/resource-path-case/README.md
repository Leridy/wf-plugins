# resource-path-case

References whose case differs from the file on disk (`art/Hero.png` vs `res://art/hero.png`, `scripts/` vs `res://Scripts/`) in a `.gd` and a `.tscn`. Godot on macOS (case-insensitive filesystem) still loads everything, but logs `WARNING: Case mismatch opening requested file …/hero.png.import, stored as …/Hero.png.import … This file will not open when exported to other case-sensitive platforms`. There is no Linux runner here, so the failure on a case-sensitive filesystem is not confirmed by running it. After the fixes in `expected-fixed/` Godot prints no warning.
