extends Node2D

var portrait = load("res://art/Hero.png")
var self_ref = load("res://scripts/hero.gd")
