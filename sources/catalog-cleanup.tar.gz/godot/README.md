# godot

The official `wf` plugin that checks the `res://` references of Godot
projects. It implements the `wf.lint/1` protocol, so `wf lint` runs it with
every other linter, and `wf godot lint` runs it alone. The specification is
[`docs/plans/2026-11/godot-linter.md`](https://gitlab.xqhuyu.cn/996-ugc/weaveforge/-/blob/main/docs/plans/2026-11/godot-linter.md).

## What it checks

Every directory holding a `project.godot` is a Godot project, and `res://`
in a file means the deepest such directory above it; a `wf` project may hold
several. Without a `project.godot` nothing is checked. It reads:

- `.gd`: every string literal (`"…"`, `'…'`, triple-quoted, `&"…"`, `r"…"`)
  that starts with `res://`. Comments and `^"…"` NodePaths are not
  references, and neither is a literal followed by `+`, `%` or `.`: that is
  the start of a computed path (`"res://levels/" + name`).
- `.tscn` and `.tres`: the `path` of each `[ext_resource]`, and every
  `"res://…"` string in header attributes and property values.
- `project.godot`: every `res://` string, with an autoload's leading `*`
  dropped (`run/main_scene`, `config/icon`, autoloads, translations).

A `::name` suffix (a built-in sub-resource) is ignored, and a path that ends
in `/` names a directory; one without it names a file, so `load("res://scenes")`
on a directory is `missing-resource`. A project nested inside another (its own
`project.godot`) is not part of the outer one, as in Godot's scan. Paths
through a dot directory (`res://.godot/…`) are out of the plugin's reach and not
checked.

Existence never needs a listing of the whole project, which the host cuts at
10,000 files. The plugin lists `**/project.godot`, then the kinds it checks
(`**/*.gd`, `**/*.tscn`, `**/*.tres`, narrowed to the requested paths), and
asks for any other referenced file by name: a listing of one path is a cheap
existence check. A name in the wrong case is found in its folder's listing
(`art/*`), or, when the folder is spelled wrong too, by a case-insensitive
glob; both are case-exact even on a case-insensitive filesystem. A file no
listing shows (the VCS ignores it) is read to tell it from a missing one, at
most 64 times per run.

When a listing is as long as the host allows, or a budget (2,000 names, 256
case lookups, 15 seconds, 5,000 diagnostics) runs out, the run reports an
`incomplete-check` warning saying so, on `project.godot` (or a checked file in
the requested paths), and a clean result is not a complete one.

| Rule | Level | When | Fix |
| --- | --- | --- | --- |
| `missing-resource` | error | A `res://` reference names no file or directory, and its uid (if any) names no file either. | none |
| `resource-path-case` | error | The file exists with other case: it opens on macOS and Windows but not on Linux or in an exported game. | the listed case |
| `stale-resource-path` | warning | An `[ext_resource]` path is missing but its `uid` names an existing file; Godot loads it by uid and rewrites the path on save. | the uid's path |
| `undefined-resource-id` | error | `ExtResource("id")` or `SubResource("id")` in a scene or resource has no `[ext_resource]` or `[sub_resource]` with that id. | none |
| `unused-ext-resource` | warning | No `ExtResource("id")` uses an `[ext_resource]`. | delete its line |
| `incomplete-check` | warning | A listing hit the host's limit or a lookup budget ran out, so the project was only partly checked. | none |

The host prefixes each rule with the plugin name (`godot/missing-resource`)
and applies the levels in `wf-plugins.toml`:

```toml
[lint.rules]
"godot/unused-ext-resource" = "off"
"godot/stale-resource-path" = "error"
```

A diagnostic's span is the path itself, without quotes, and its fix replaces
only that; an `[ext_resource]` diagnostic for an unused id spans the header.
The uid map is read only when a stale path needs it: `*.uid` files, `uid="…"`
in `*.import` files and the `uid` of each `[gd_scene]` or `[gd_resource]`
header, found by listing `**/*.uid`, `**/*.import`, `**/*.tscn` and `**/*.tres`. The
binary caches under `.godot/` are never read.

A file the parser cannot read whole (an unclosed header or value) still gets
its path checks; the id rules skip it, since a header it lost would make ids
look undefined. Godot reports such a file as a parse error itself.

## Why pure Rust

Two hand-written readers are compiled into the component: a GDScript lexer
that only knows strings and comments (`src/gdscript.rs`), and a reader of
Godot's text resource format (`src/resource.rs`). The rules need strings,
comments and resource sections, not a syntax tree. Tree-sitter would bring
a C runtime, and building that for `wasm32-wasip2` needs wasi-sdk: one more C
toolchain for every plugin author and for CI. Both readers recover from
malformed input instead of failing, and never panic.

## Build, test and pack

It depends on [`plugin-kit`](https://gitlab.xqhuyu.cn/996-ugc/wf-plugins/plugin-kit)
by path, so clone that repository beside this one first:

```sh
git clone ssh://git@gitlab.xqhuyu.cn:10022/996-ugc/wf-plugins/plugin-kit.git ../plugin-kit
```

Then, from this directory:

```sh
cargo test                                       # unit tests and the corpus
cargo build --release --target wasm32-wasip2     # the component
wf plugin test .                                 # description and examples
wf plugin link .                                 # shows the permissions; --yes grants them
wf godot lint --help
wf plugin pack                                   # godot-0.1.5.wfplugin, for release
```

`tests/corpus/<case>/` holds small Godot projects, each with `expected.json`
(diagnostics as `rule`, `file`, `line`, `severity`) and, when fixes change
files, `expected-fixed/` with those files after every fix. `tests/corpus.rs`
runs the rules over each case from the disk and compares both. Each case's
`README.md` says what Godot itself reports for it
(`godot --headless --path <case> --import --quit`).

The plugin binds the API in `plugin-kit/plugin-api/wit` through `plugin-kit/plugin-guest`,
which also holds the host glue and message quoting it shares with the other
official plugins, so it always follows the latest API. The built component is
not committed: the official plugin is packed, signed and published at release,
from the tag's source; bump `version` whenever its bytes change.
