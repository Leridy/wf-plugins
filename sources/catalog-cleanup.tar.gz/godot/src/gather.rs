//! Finds the Godot projects, lists the files to check by kind (never the
//! whole project), reads them one at a time and hands each to the rules with
//! what they look up. A check that could not be complete says so.
use crate::{
    glob, project,
    references::{self, FileKind, PROJECT_FILE},
    rules::{self, Checked, INCOMPLETE_CHECK},
    world::World,
};
use plugin_guest::Host;
use plugin_protocols::lint::{Diagnostic, LintInput, LintOutput, Severity};
use std::collections::BTreeSet;

/// Most diagnostics one run reports; a hostile file could name millions of
/// missing paths.
const MAX_DIAGNOSTICS: usize = 5_000;
/// The extensions of the files whose references are checked, besides `project.godot`.
const CHECKED_EXTENSIONS: [&str; 3] = ["gd", "tscn", "tres"];

pub fn lint(host: &dyn Host, input: &LintInput) -> LintOutput {
    let mut world = World::new(host);
    if world.roots().is_empty() {
        return LintOutput::default();
    }
    let scope = Scope::new(&input.paths);
    let listed = listed_files(&mut world, &scope);
    world.index(&listed);
    let files: Vec<(String, String, FileKind)> = listed
        .iter()
        .filter(|path| scope.contains(path))
        .filter_map(|path| {
            let kind = FileKind::of(path)?;
            let root = project::owner(world.roots(), path)?;
            Some((path.clone(), root.to_owned(), kind))
        })
        .collect();
    let mut checked = Vec::new();
    let mut diagnostics = Vec::new();
    for (file, root, kind) in files {
        if diagnostics.len() >= MAX_DIAGNOSTICS {
            break;
        }
        let Some(text) = world.text(&file) else {
            continue;
        };
        let facts = references::read(kind, &text);
        let target = Checked {
            file: &file,
            root: &root,
            kind,
            text: &text,
        };
        diagnostics.extend(rules::check(
            &target,
            &facts,
            &mut world,
            MAX_DIAGNOSTICS - diagnostics.len(),
        ));
        checked.push(file);
    }
    if diagnostics.len() >= MAX_DIAGNOSTICS {
        world.note(&format!(
            "The run stopped after {MAX_DIAGNOSTICS} diagnostics; fix those and run it again to see the rest."
        ));
    }
    if let Some(incomplete) = incomplete(&world, &scope, &checked) {
        diagnostics.push(incomplete);
    }
    diagnostics
        .sort_by(|a, b| (&a.file, a.span.map(|s| s.start), &a.rule).cmp(&(&b.file, b.span.map(|s| s.start), &b.rule)));
    LintOutput { checked, diagnostics }
}

/// The files of the kinds checked, in the requested paths, and the
/// `project.godot` of each project: project-relative.
fn listed_files(world: &mut World, scope: &Scope) -> BTreeSet<String> {
    let mut listed: BTreeSet<String> = world
        .roots()
        .iter()
        .map(|root| project::join(root, PROJECT_FILE))
        .collect();
    for glob in scope.globs() {
        listed.extend(world.list(&glob));
    }
    listed
}

/// The warning that the check was partial, on a file the run covers.
fn incomplete(world: &World, scope: &Scope, checked: &[String]) -> Option<Diagnostic> {
    let reasons: Vec<&str> = world.partial().iter().map(String::as_str).collect();
    if reasons.is_empty() {
        return None;
    }
    // Reported on a project file when it is in scope, else on a file that was checked.
    let file = world
        .roots()
        .iter()
        .rev()
        .map(|root| project::join(root, PROJECT_FILE))
        .find(|file| scope.contains(file))
        .or_else(|| checked.first().cloned())?;
    Some(Diagnostic {
        rule: INCOMPLETE_CHECK.to_owned(),
        severity: Severity::Warning,
        message: format!(
            "This project was only partly checked, so a clean result does not mean it is clean: {} Check one directory at a time by passing it as a path.",
            reasons.join(" ")
        ),
        file,
        span: None,
        fix: None,
    })
}

/// The requested files and directories; empty means the whole project.
struct Scope {
    paths: Vec<String>,
}

impl Scope {
    fn new(paths: &[String]) -> Self {
        Self {
            paths: paths
                .iter()
                .map(|p| p.trim_start_matches("./").trim_end_matches('/').to_owned())
                .filter(|p| !p.is_empty() && p != ".")
                .collect(),
        }
    }

    fn contains(&self, file: &str) -> bool {
        self.paths.is_empty()
            || self
                .paths
                .iter()
                .any(|p| file == p || file.strip_prefix(p.as_str()).is_some_and(|rest| rest.starts_with('/')))
    }

    /// The listings that cover the scope: each kind checked below a directory
    /// (or the project), and a file by its name.
    fn globs(&self) -> Vec<String> {
        if self.paths.is_empty() {
            return CHECKED_EXTENSIONS.iter().map(|ext| format!("**/*.{ext}")).collect();
        }
        self.paths
            .iter()
            .filter_map(|path| Some((glob::exactly(path)?, FileKind::of(path).is_some())))
            .flat_map(|(path, file)| {
                if file {
                    vec![path]
                } else {
                    CHECKED_EXTENSIONS
                        .iter()
                        .map(|ext| format!("{path}/**/*.{ext}"))
                        .collect()
                }
            })
            .collect()
    }
}

#[cfg(test)]
mod tests;
