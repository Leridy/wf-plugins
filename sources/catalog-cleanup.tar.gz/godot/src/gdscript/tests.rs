use super::*;

fn values(source: &str) -> Vec<(Prefix, String)> {
    strings(source)
        .map(|l| (l.prefix, l.value(source).into_owned()))
        .collect()
}

fn plain(text: &str) -> (Prefix, String) {
    (Prefix::None, text.to_owned())
}

#[test]
fn finds_every_quote_form_with_content_spans() {
    let source = "var a = \"res://a.png\"\nvar b = 'res://b.png'\nvar c = \"\"\"res://c\nd\"\"\"\nvar e = '''x'''\n";
    let found: Vec<Literal> = strings(source).collect();
    let texts: Vec<&str> = found.iter().map(|l| &source[l.content.clone()]).collect();
    assert_eq!(texts, ["res://a.png", "res://b.png", "res://c\nd", "x"]);
    assert!(found.iter().all(|l| !l.escaped));
    assert_eq!(&source[found[0].end - 1..found[0].end], "\"");
}

#[test]
fn prefixes_mark_string_names_and_node_paths() {
    assert_eq!(
        values("a(&\"idle\", ^\"Path/To\", r\"raw\", &'x', ^r\"y\")"),
        [
            (Prefix::StringName, "idle".to_owned()),
            (Prefix::NodePath, "Path/To".to_owned()),
            plain("raw"),
            (Prefix::StringName, "x".to_owned()),
            (Prefix::NodePath, "y".to_owned()),
        ]
    );
}

#[test]
fn comments_hide_strings_and_strings_hide_comments() {
    let source = "# load(\"res://gone.png\")\nvar a = \"res://#1.png\" # \"tail\"\n## doc \"x\"\nvar b = 'it''s'";
    assert_eq!(values(source), [plain("res://#1.png"), plain("it"), plain("s")]);
}

#[test]
fn escapes_resolve_and_raw_strings_keep_them() {
    assert_eq!(
        values(r#"a("x\"y\\z\n\u00e9\U01F600", r"a\"b\n", 'q\'s', "\q")"#),
        [
            plain("x\"y\\z\n\u{e9}\u{1F600}"),
            plain("a\\\"b\\n"),
            plain("q's"),
            plain("\\q")
        ]
    );
    let found: Vec<Literal> = strings(r#"a("x\ty")"#).collect();
    assert!(found[0].escaped);
}

#[test]
fn a_line_continuation_joins_lines() {
    assert_eq!(values("\"a\\\nb\""), [plain("ab")]);
    assert_eq!(values("\"a\\\r\nb\""), [plain("ab")]);
}

#[test]
fn r_inside_an_identifier_is_no_prefix() {
    assert_eq!(
        values("var bar\"x\"\nfor r in []: pass\nvar s = r'y'"),
        [plain("x"), plain("y")]
    );
}

#[test]
fn unterminated_strings_end_at_their_line_and_never_panic() {
    assert_eq!(values("var a = \"open\nvar b = \"ok\""), [plain("ok")]);
    assert_eq!(values("x = \"\"\"never closed\n\"ok\""), []);
    for hostile in [
        "\"",
        "'",
        "\"\"\"",
        "&",
        "^",
        "r",
        "&r",
        "\\",
        "\"\\",
        "r\"\\",
        "\"\\u12",
        "\"\\U\u{e9}\"",
        "#",
        "\"\u{e9}\\\u{e9}\"",
        "'''''",
        "&r'''x'''",
    ] {
        let _ = strings(hostile).count();
    }
    assert_eq!(values("\"\\U\u{e9}\""), [plain("\\U\u{e9}")]);
}

#[test]
fn multibyte_text_keeps_offsets_on_boundaries() {
    let source = "# é\nvar 名前 = \"res://ñ/é.png\"";
    let found: Vec<Literal> = strings(source).collect();
    assert_eq!(&source[found[0].content.clone()], "res://ñ/é.png");
}
