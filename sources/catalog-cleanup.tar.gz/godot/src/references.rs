//! What the rules need from one checked file: its `res://` references, its
//! `[ext_resource]` and `[sub_resource]` ids, and the `ExtResource("id")` and
//! `SubResource("id")` calls that use them.
use crate::{
    gdscript,
    resource::{self, Header, Prefix, Value},
};
use std::{borrow::Cow, collections::BTreeSet, ops::Range};

pub const RES: &str = "res://";
pub const PROJECT_FILE: &str = "project.godot";

/// The files the plugin checks.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FileKind {
    Script,
    /// `.tscn` and `.tres`.
    Resource,
    Project,
}

impl FileKind {
    pub fn of(path: &str) -> Option<Self> {
        let name = path.rsplit('/').next().unwrap_or(path);
        if name == PROJECT_FILE {
            return Some(Self::Project);
        }
        match name.rsplit_once('.').map(|(_, extension)| extension) {
            Some("gd") => Some(Self::Script),
            Some("tscn" | "tres") => Some(Self::Resource),
            _ => None,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Reference {
    /// `res://…`, without an autoload's leading `*` or a `::` sub-resource name.
    pub path: String,
    pub span: Range<usize>,
    /// The span holds exactly `path` (no escapes), so a fix may replace it.
    pub exact: bool,
    /// The `[ext_resource]` whose `path` this is, an index into `Facts::ext_resources`.
    pub ext: Option<usize>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExtResource {
    pub id: Option<String>,
    pub uid: Option<String>,
    /// The whole `[ext_resource …]` header.
    pub header: Range<usize>,
    pub path: Option<String>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Table {
    Ext,
    Sub,
}

/// An `ExtResource("id")` or `SubResource("id")`; the span is the id.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Use {
    pub table: Table,
    pub id: String,
    pub span: Range<usize>,
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct Facts {
    pub references: Vec<Reference>,
    pub ext_resources: Vec<ExtResource>,
    pub sub_ids: BTreeSet<String>,
    pub uses: Vec<Use>,
    /// Part of the file could not be read, so ids may be missing from the tables.
    pub malformed: bool,
}

pub fn read(kind: FileKind, text: &str) -> Facts {
    match kind {
        FileKind::Script => script(text),
        FileKind::Resource => resource(text, false),
        FileKind::Project => resource(text, true),
    }
}

/// Every string literal that starts with `res://`. One followed by `+`, `%`
/// or `.` is the start of a computed path (`"res://levels/" + name`), not a
/// path, and is left out.
fn script(text: &str) -> Facts {
    let references = gdscript::strings(text)
        .filter(|literal| literal.prefix != gdscript::Prefix::NodePath)
        .filter(|literal| {
            let next = text[literal.end..].trim_start_matches([' ', '\t']).bytes().next();
            !matches!(next, Some(b'+' | b'%' | b'.'))
        })
        .filter_map(|literal| reference(&literal.value(text), literal.content.clone(), !literal.escaped, false))
        .collect();
    Facts {
        references,
        ..Facts::default()
    }
}

fn resource(text: &str, project: bool) -> Facts {
    let document = resource::parse(text);
    let mut facts = Facts {
        malformed: document.malformed,
        ..Facts::default()
    };
    for entry in &document.entries {
        match entry {
            resource::Entry::Header(header) => {
                if header.tag == "ext_resource" {
                    ext_resource(header, text, &mut facts);
                } else if header.tag == "sub_resource"
                    && let Some(id) = header.get("id").and_then(|v| v.text(text))
                {
                    facts.sub_ids.insert(id.into_owned());
                }
                for (key, value) in &header.attributes {
                    if !(header.tag == "ext_resource" && key == "path") {
                        collect(value, text, project, &mut facts);
                    }
                }
            }
            resource::Entry::Property(property) => collect(&property.value, text, project, &mut facts),
        }
    }
    facts
}

fn ext_resource(header: &Header, text: &str, facts: &mut Facts) {
    let index = facts.ext_resources.len();
    let path = header.get("path").and_then(|value| match value {
        Value::Str(s) => reference(&s.value(text), s.content.range(), !s.escaped, false),
        _ => None,
    });
    facts.ext_resources.push(ExtResource {
        id: header.get("id").and_then(|v| v.text(text)).map(Cow::into_owned),
        uid: header
            .get("uid")
            .and_then(|v| v.text(text))
            .filter(|uid| uid.starts_with("uid://"))
            .map(Cow::into_owned),
        header: header.span.clone(),
        path: path.as_ref().map(|p| p.path.clone()),
    });
    if let Some(mut path) = path {
        path.ext = Some(index);
        facts.references.push(path);
    }
}

fn collect(value: &Value, text: &str, project: bool, facts: &mut Facts) {
    let mut references = Vec::new();
    let mut uses = Vec::new();
    value.visit(
        text,
        &mut |s| {
            if s.prefix != Prefix::NodePath {
                references.extend(reference(&s.value(text), s.content.range(), !s.escaped, project));
            }
        },
        &mut |name, args| {
            let table = match name {
                "ExtResource" => Table::Ext,
                "SubResource" => Table::Sub,
                _ => return,
            };
            if let [arg] = args
                && let (Some(id), Some(span)) = (arg.text(text), arg.text_span())
            {
                uses.push(Use {
                    table,
                    id: id.into_owned(),
                    span,
                });
            }
        },
    );
    facts.references.extend(references);
    facts.uses.extend(uses);
}

/// The reference a string holds, if it starts with `res://` (or `*res://`
/// when `star` is set, as autoloads are written).
fn reference(value: &str, content: Range<usize>, verbatim: bool, star: bool) -> Option<Reference> {
    let skip = usize::from(star && value.starts_with('*'));
    let rest = &value[skip..];
    if !rest.starts_with(RES) {
        return None;
    }
    let path = rest.find("::").map_or(rest, |n| &rest[..n]);
    let span = if verbatim {
        content.start + skip..content.start + skip + path.len()
    } else {
        content
    };
    Some(Reference {
        path: path.to_owned(),
        span,
        exact: verbatim,
        ext: None,
    })
}

#[cfg(test)]
mod tests;
