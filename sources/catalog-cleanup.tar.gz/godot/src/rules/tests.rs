use super::*;
use crate::testing::{Fake, summary};

const PROJECT: (&str, &str) = ("project.godot", "config_version=5\n");

fn fix_text(diagnostic: &Diagnostic) -> Option<(&str, u32, u32)> {
    let fix = diagnostic.fix.as_ref()?;
    let [edit] = fix.edits.as_slice() else {
        panic!("one edit")
    };
    Some((edit.text.as_str(), edit.span.start, edit.span.end))
}

#[test]
fn a_clean_project_has_no_diagnostics() {
    let fake = Fake::new(&[
        (
            "project.godot",
            "[application]\nrun/main_scene=\"res://main.tscn\"\n[autoload]\nG=\"*res://g.gd\"\n",
        ),
        (
            "g.gd",
            "extends Node\nconst S = preload(\"res://main.tscn\")\nvar d = \"res://art/\"\nvar r = \"res://\"\n",
        ),
        ("art/a.png", ""),
        (
            "main.tscn",
            "[gd_scene format=3]\n[ext_resource type=\"Texture2D\" path=\"res://art/a.png\" id=\"1\"]\n[node name=\"M\"]\ntexture = ExtResource(\"1\")\n",
        ),
    ]);
    assert_eq!(fake.lint(), []);
}

#[test]
fn missing_resource_sits_on_the_path() {
    let fake = Fake::new(&[
        PROJECT,
        ("a.gd", "var x = load(\"res://gone.png\")\nvar d = \"res://nodir/\"\n"),
        (
            "b.tscn",
            "[ext_resource path=\"res://gone.gd\" uid=\"uid://nope\" id=\"1\"]\n[node name=\"B\"]\nscript = ExtResource(\"1\")\n",
        ),
    ]);
    let diagnostics = fake.lint();
    assert_eq!(
        summary(&fake, &diagnostics),
        [
            (MISSING_RESOURCE, "a.gd", "res://gone.png"),
            (MISSING_RESOURCE, "a.gd", "res://nodir/"),
            (MISSING_RESOURCE, "b.tscn", "res://gone.gd"),
        ]
    );
    assert!(
        diagnostics
            .iter()
            .all(|d| d.severity == Severity::Error && d.fix.is_none())
    );
    assert!(diagnostics[2].message.contains("uid://nope"));
}

#[test]
fn a_case_mismatch_is_fixed_to_the_listed_case() {
    let fake = Fake::new(&[
        PROJECT,
        ("Art/Icon.png", ""),
        ("a.gd", "var x = load(\"res://art/icon.png\")\nvar d = \"res://art/\"\n"),
    ]);
    let diagnostics = fake.lint();
    assert_eq!(
        summary(&fake, &diagnostics),
        [
            (RESOURCE_PATH_CASE, "a.gd", "res://art/icon.png"),
            (RESOURCE_PATH_CASE, "a.gd", "res://art/"),
        ]
    );
    assert_eq!(fix_text(&diagnostics[0]), Some(("res://Art/Icon.png", 14, 32)));
    assert_eq!(fix_text(&diagnostics[1]).map(|f| f.0), Some("res://Art/"));
    assert_eq!(diagnostics[0].severity, Severity::Error);
}

#[test]
fn an_ambiguous_or_escaped_case_mismatch_has_no_fix() {
    let fake = Fake::new(&[
        PROJECT,
        ("a.png", ""),
        ("A.png", ""),
        ("b.png", ""),
        ("x.gd", "var a = \"res://A.PNG\"\nvar b = \"res://\\u0042.png\"\n"),
    ]);
    let diagnostics = fake.lint();
    assert_eq!(diagnostics.len(), 2);
    assert!(
        diagnostics
            .iter()
            .all(|d| d.rule == RESOURCE_PATH_CASE && d.fix.is_none())
    );
}

#[test]
fn a_stale_path_is_fixed_to_where_its_uid_points() {
    let scene = "[ext_resource type=\"Script\" uid=\"uid://abc\" path=\"res://old/player.gd\" id=\"1\"]\n[node name=\"B\"]\nscript = ExtResource(\"1\")\n";
    let fake = Fake::new(&[
        PROJECT,
        ("new/player.gd", "extends Node\n"),
        ("new/player.gd.uid", "uid://abc\n"),
        ("b.tscn", scene),
    ]);
    let diagnostics = fake.lint();
    assert_eq!(
        summary(&fake, &diagnostics),
        [(STALE_RESOURCE_PATH, "b.tscn", "res://old/player.gd")]
    );
    assert_eq!(diagnostics[0].severity, Severity::Warning);
    assert_eq!(fix_text(&diagnostics[0]).map(|f| f.0), Some("res://new/player.gd"));
}

#[test]
fn uids_come_from_import_files_and_resource_headers() {
    let scene = "[ext_resource uid=\"uid://img\" path=\"res://a.png\" id=\"1\"]\n[ext_resource uid=\"uid://scn\" path=\"res://a.tscn\" id=\"2\"]\n[node name=\"B\"]\nt = ExtResource(\"1\")\ns = ExtResource(\"2\")\n";
    let fake = Fake::new(&[
        PROJECT,
        ("img/b.png", ""),
        (
            "img/b.png.import",
            "[remap]\n\nimporter=\"texture\"\ntype=\"CompressedTexture2D\"\nuid=\"uid://img\"\n",
        ),
        (
            "s/b.tscn",
            "[gd_scene format=3 uid=\"uid://scn\"]\n\n[node name=\"S\"]\n",
        ),
        ("b.tscn", scene),
    ]);
    let diagnostics = fake.lint();
    assert!(diagnostics.iter().all(|d| d.rule == STALE_RESOURCE_PATH));
    assert_eq!(
        diagnostics
            .iter()
            .filter_map(fix_text)
            .map(|f| f.0.to_owned())
            .collect::<Vec<_>>(),
        ["res://img/b.png", "res://s/b.tscn"]
    );
}

#[test]
fn undefined_ids_sit_on_the_id() {
    let text = "[ext_resource path=\"res://a.png\" id=\"1\"]\n[sub_resource type=\"X\" id=\"S1\"]\n[node name=\"N\" instance=ExtResource(\"9\")]\na = ExtResource(\"1\")\nb = SubResource(\"S1\")\nc = SubResource(\"S2\")\n";
    let fake = Fake::new(&[PROJECT, ("a.png", ""), ("n.tscn", text)]);
    let diagnostics = fake.lint();
    assert_eq!(
        summary(&fake, &diagnostics),
        [
            (UNDEFINED_RESOURCE_ID, "n.tscn", "9"),
            (UNDEFINED_RESOURCE_ID, "n.tscn", "S2"),
        ]
    );
    assert!(
        diagnostics
            .iter()
            .all(|d| d.severity == Severity::Error && d.fix.is_none())
    );
}

#[test]
fn an_unused_ext_resource_is_deleted_with_its_line_and_drops_its_path_fix() {
    let text = "[gd_scene format=3]\n\n[ext_resource path=\"res://a.png\" id=\"1\"]\n[ext_resource path=\"res://B.png\" id=\"2\"]\n\n[node name=\"N\"]\na = ExtResource(\"1\")\n";
    let fake = Fake::new(&[PROJECT, ("a.png", ""), ("b.png", ""), ("n.tscn", text)]);
    let diagnostics = fake.lint();
    assert_eq!(
        diagnostics.iter().map(|d| d.rule.as_str()).collect::<Vec<_>>(),
        [UNUSED_EXT_RESOURCE, RESOURCE_PATH_CASE]
    );
    let unused = &diagnostics[0];
    assert_eq!(unused.severity, Severity::Warning);
    let (replacement, start, end) = fix_text(unused).unwrap();
    assert_eq!(replacement, "");
    assert_eq!(
        &text[start as usize..end as usize],
        "[ext_resource path=\"res://B.png\" id=\"2\"]\n"
    );
    assert!(diagnostics[1].fix.is_none(), "the deletion covers it");
}

#[test]
fn godot_3_integer_ids_are_ids_too() {
    let text = "[gd_scene load_steps=2 format=2]\n[ext_resource path=\"res://a.png\" type=\"Texture\" id=1]\n[node name=\"N\"]\ntexture = ExtResource( 1 )\nother = ExtResource( 2 )\n";
    let fake = Fake::new(&[PROJECT, ("a.png", ""), ("n.tscn", text)]);
    assert_eq!(summary(&fake, &fake.lint()), [(UNDEFINED_RESOURCE_ID, "n.tscn", "2")]);
}

#[test]
fn a_malformed_file_gets_path_checks_only() {
    let text = "[ext_resource path=\"res://gone.png\" id=\"1\"]\n[node name=\"N\"\nx = ExtResource(\"7\")\n";
    let fake = Fake::new(&[PROJECT, ("n.tscn", text)]);
    assert_eq!(
        summary(&fake, &fake.lint()),
        [(MISSING_RESOURCE, "n.tscn", "res://gone.png")]
    );
}

#[test]
fn dot_directories_and_paths_out_of_the_project() {
    let fake = Fake::new(&[
        PROJECT,
        (
            "a.gd",
            "var a = \"res://.godot/imported/x.ctex\"\nvar b = \"res://../outside.png\"\n",
        ),
    ]);
    assert_eq!(
        summary(&fake, &fake.lint()),
        [(MISSING_RESOURCE, "a.gd", "res://../outside.png")]
    );
}

#[test]
fn a_file_reference_that_names_a_directory_is_missing() {
    let fake = Fake::new(&[
        PROJECT,
        ("scenes/main.tscn", "[node name=\"M\"]\n"),
        ("a.gd", "var a = load(\"res://scenes\")\nvar b = \"res://scenes/\"\n"),
    ]);
    let diagnostics = fake.lint();
    assert_eq!(
        summary(&fake, &diagnostics),
        [(MISSING_RESOURCE, "a.gd", "res://scenes")]
    );
}

#[test]
fn the_outer_project_does_not_see_into_a_nested_one() {
    let fake = Fake::new(&[
        PROJECT,
        ("art/own.png", ""),
        ("sub/project.godot", ""),
        ("sub/art/inner.png", ""),
        (
            "a.gd",
            "var a = \"res://art/own.png\"\nvar b = \"res://sub/art/inner.png\"\n",
        ),
        (
            "sub/b.gd",
            "var a = \"res://art/inner.png\"\nvar b = \"res://art/own.png\"\n",
        ),
    ]);
    let diagnostics = fake.lint();
    assert_eq!(
        summary(&fake, &diagnostics),
        [
            (MISSING_RESOURCE, "a.gd", "res://sub/art/inner.png"),
            (MISSING_RESOURCE, "sub/b.gd", "res://art/own.png"),
        ]
    );
}
