//! The text of each diagnostic: what is wrong and what to do, in one or two
//! sentences. Paths and ids come from project files, so they are flattened to
//! one line and kept from closing the backticks around them.
use crate::references::Table;

const QUOTED_CHARS: usize = 200;

pub fn missing(reference: &str, uid: Option<&str>) -> String {
    let uid = uid.map_or_else(String::new, |uid| {
        format!(", and its uid {} is unknown too", quoted(uid))
    });
    format!(
        "{} does not exist in this Godot project{uid}. Fix the path or restore the file.",
        quoted(reference)
    )
}

pub fn case(reference: &str, actual: Option<&str>) -> String {
    let actual = actual.map_or_else(
        || "a file whose name differs only in case".to_owned(),
        |actual| format!("the file {}", quoted(actual)),
    );
    format!(
        "{} names {actual}: it loads on macOS and Windows, but not on Linux or in an exported game. Use the exact case.",
        quoted(reference)
    )
}

pub fn stale(reference: &str, uid: &str, target: &str) -> String {
    format!(
        "{} does not exist, but uid {} points to {}: Godot loads that by uid and rewrites the path when it saves. Update the path.",
        quoted(reference),
        quoted(uid),
        quoted(target)
    )
}

pub fn undefined(table: Table, id: &str) -> String {
    let (call, section) = match table {
        Table::Ext => ("ExtResource", "ext_resource"),
        Table::Sub => ("SubResource", "sub_resource"),
    };
    format!(
        "{call}({}) has no [{section}] with that id in this file, so Godot cannot load it. Point it at a defined id or add the resource.",
        quoted(id)
    )
}

pub fn unused(id: &str, path: Option<&str>) -> String {
    let path = path.map_or_else(String::new, |path| format!(" ({})", quoted(path)));
    format!(
        "[ext_resource] {}{path} is not used by any ExtResource in this file. Remove it.",
        quoted(id)
    )
}

/// `text` in backticks, on one line.
fn quoted(text: &str) -> String {
    plugin_guest::quoted(text, QUOTED_CHARS)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn user_text_stays_on_one_line_inside_backticks() {
        let message = missing("res://a`b\nc.png", None);
        assert_eq!(
            message,
            "`res://a'b c.png` does not exist in this Godot project. Fix the path or restore the file."
        );
        assert!(unused(&"x".repeat(300), None).contains("x..."));
    }
}
