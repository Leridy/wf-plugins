use super::*;
use crate::{
    rules::{INCOMPLETE_CHECK, MISSING_RESOURCE},
    testing::Fake,
    world::MAX_READ_PROBES,
};
use plugin_protocols::lint::Severity;

fn lint_paths(fake: &Fake, paths: &[&str]) -> LintOutput {
    lint(
        fake,
        &LintInput {
            paths: paths.iter().map(|p| (*p).to_owned()).collect(),
        },
    )
}

#[test]
fn without_project_godot_nothing_is_checked() {
    let fake = Fake::new(&[
        ("a.gd", "var x = \"res://gone.png\"\n"),
        ("b.tscn", "[node name=\"B\"]\n"),
    ]);
    assert_eq!(lint_paths(&fake, &[]), LintOutput::default());
    assert_eq!(*fake.lists.borrow(), ["**/project.godot"], "nothing else is listed");
}

#[test]
fn checks_the_godot_files_of_each_project_against_its_own_root() {
    let fake = Fake::new(&[
        (
            "game/project.godot",
            "[application]\nrun/main_scene=\"res://main.tscn\"\n",
        ),
        ("game/main.tscn", "[node name=\"M\"]\n"),
        (
            "game/a.gd",
            "var x = \"res://main.tscn\"\nvar y = \"res://game/main.tscn\"\n",
        ),
        ("game/readme.md", "res://nothing\n"),
        ("tools/project.godot", "[autoload]\nT=\"*res://t.gd\"\n"),
        ("outside.gd", "var x = \"res://gone.png\"\n"),
    ]);
    let output = lint_paths(&fake, &[]);
    assert_eq!(
        output.checked,
        [
            "game/a.gd",
            "game/main.tscn",
            "game/project.godot",
            "tools/project.godot"
        ]
    );
    let found: Vec<(&str, &str)> = output
        .diagnostics
        .iter()
        .map(|d| (d.file.as_str(), d.message.split('`').nth(1).unwrap_or_default()))
        .collect();
    assert_eq!(
        found,
        [
            ("game/a.gd", "res://game/main.tscn"),
            ("tools/project.godot", "res://t.gd")
        ]
    );
}

#[test]
fn paths_limit_the_files_checked_not_the_files_known() {
    let fake = Fake::new(&[
        ("project.godot", ""),
        ("scenes/a.tscn", "[node name=\"A\"]\nx = \"res://scripts/s.gd\"\n"),
        ("scripts/s.gd", "var x = \"res://gone.png\"\n"),
    ]);
    let output = lint_paths(&fake, &["./scenes/"]);
    assert_eq!(output.checked, ["scenes/a.tscn"]);
    assert_eq!(output.diagnostics, []);
    let output = lint_paths(&fake, &["scripts/s.gd"]);
    assert_eq!(output.checked, ["scripts/s.gd"]);
    assert_eq!(output.diagnostics.len(), 1);
}

#[test]
fn an_unlisted_file_is_probed_before_it_is_called_missing() {
    let mut fake = Fake::new(&[
        (
            "project.godot",
            "[internationalization]\nlocale/translations=PackedStringArray(\"res://t.en.translation\")\n",
        ),
        ("t.en.translation", "binary"),
    ]);
    fake.unlisted.push("t.en.translation".to_owned());
    assert_eq!(fake.lint(), []);
    assert!(fake.reads.borrow().contains(&"t.en.translation".to_owned()));
}

#[test]
fn read_probes_are_bounded_and_the_rest_taken_to_exist() {
    let script = (0..MAX_READ_PROBES + 5)
        .map(|n| format!("var a{n} = \"res://gone{n}.png\""))
        .collect::<Vec<_>>()
        .join("\n");
    let fake = Fake::new(&[("project.godot", ""), ("a.gd", &script)]);
    let diagnostics = fake.lint();
    let missing = diagnostics.iter().filter(|d| d.rule == MISSING_RESOURCE).count();
    assert_eq!(missing, MAX_READ_PROBES);
    // The run says it could not tell for the rest.
    assert_eq!(diagnostics.len(), MAX_READ_PROBES + 1);
    let incomplete = diagnostics.iter().find(|d| d.rule == INCOMPLETE_CHECK).unwrap();
    assert!(incomplete.message.contains("taken to exist"), "{}", incomplete.message);
    assert_eq!(fake.warnings.borrow().len(), 1);
}

#[test]
fn the_uid_map_is_read_only_when_a_rule_needs_it() {
    let fake = Fake::new(&[
        ("project.godot", ""),
        ("a.gd", "extends Node\n"),
        ("a.gd.uid", "uid://a\n"),
        (
            "n.tscn",
            "[ext_resource uid=\"uid://a\" path=\"res://a.gd\" id=\"1\"]\n[node name=\"N\"]\ns = ExtResource(\"1\")\n",
        ),
    ]);
    assert_eq!(fake.lint(), []);
    assert!(!fake.reads.borrow().iter().any(|r| r == "a.gd.uid"));
    assert!(
        !fake
            .lists
            .borrow()
            .iter()
            .any(|g| g.contains(".uid") || g.contains(".import"))
    );
}

fn listing_globs(fake: &Fake) -> Vec<String> {
    fake.lists.borrow().clone()
}

#[test]
fn only_the_kinds_checked_are_listed_and_other_files_are_asked_for_by_name() {
    for strict in [false, true] {
        let mut fake = Fake::new(&[
            ("project.godot", ""),
            ("a.gd", "var x = load(\"res://art/icon.png\")\n"),
            ("art/icon.png", ""),
        ]);
        fake.strict = strict;
        assert_eq!(fake.lint(), []);
        assert_eq!(
            listing_globs(&fake),
            ["**/project.godot", "**/*.gd", "**/*.tscn", "**/*.tres", "art/icon.png"]
        );
    }
}

#[test]
fn a_big_project_is_checked_though_project_godot_lies_past_the_listing_limit() {
    // Many files sort before project.godot, as an addons/ directory does.
    let mut files: Vec<(String, String)> = (0..50)
        .map(|n| (format!("addons/x/{n:03}.png.import"), String::new()))
        .collect();
    files.push(("project.godot".to_owned(), String::new()));
    files.push(("a.gd".to_owned(), "var x = load(\"res://gone.png\")\n".to_owned()));
    let fake = Fake {
        files: files.into_iter().collect(),
        limit: Some(10),
        ..Fake::default()
    };
    let output = lint(&fake, &LintInput::default());
    assert_eq!(output.checked, ["a.gd", "project.godot"]);
    let rules: Vec<&str> = output.diagnostics.iter().map(|d| d.rule.as_str()).collect();
    assert_eq!(rules, [MISSING_RESOURCE]);
}

#[test]
fn a_listing_cut_short_is_reported_as_a_partial_check() {
    let mut files = vec![("project.godot".to_owned(), String::new())];
    files.extend((0..8).map(|n| (format!("s{n}.gd"), "extends Node\n".to_owned())));
    let mut fake = Fake {
        files: files.into_iter().collect(),
        limit: Some(5),
        ..Fake::default()
    };
    let output = lint(&fake, &LintInput::default());
    let [incomplete] = output.diagnostics.as_slice() else {
        panic!("one diagnostic: {:?}", output.diagnostics)
    };
    assert_eq!(
        (incomplete.rule.as_str(), incomplete.file.as_str(), incomplete.severity),
        (INCOMPLETE_CHECK, "project.godot", Severity::Warning)
    );
    assert!(incomplete.span.is_none());
    assert!(incomplete.message.contains("`**/*.gd`"), "{}", incomplete.message);
    assert!(incomplete.message.contains("only partly checked"));
    assert!(fake.warnings.borrow().iter().any(|w| w.contains("`**/*.gd`")));
    // Not cut short: nothing to report.
    fake.limit = Some(9);
    assert_eq!(lint(&fake, &LintInput::default()).diagnostics, []);
}

#[test]
fn the_partial_check_note_sits_on_a_file_inside_the_requested_paths() {
    let mut fake = Fake::new(&[
        ("project.godot", ""),
        ("s/a.gd", "extends Node\n"),
        ("s/b.gd", "extends Node\n"),
        ("s/c.gd", "extends Node\n"),
    ]);
    fake.limit = Some(3);
    let output = lint_paths(&fake, &["s"]);
    assert_eq!(output.checked, ["s/a.gd", "s/b.gd", "s/c.gd"]);
    assert_eq!(output.diagnostics.len(), 1);
    assert_eq!(output.diagnostics[0].file, "s/a.gd");
    assert!(fake.lists.borrow().contains(&"s/**/*.gd".to_owned()));
}

#[test]
fn paths_narrow_the_listings() {
    let fake = Fake::new(&[
        ("project.godot", ""),
        ("scenes/a.tscn", "[node name=\"A\"]\n"),
        ("other/b.gd", "var x = \"res://gone.png\"\n"),
    ]);
    let output = lint_paths(&fake, &["scenes", "other/b.gd"]);
    assert_eq!(output.checked, ["other/b.gd", "scenes/a.tscn"]);
    assert_eq!(
        listing_globs(&fake),
        [
            "**/project.godot",
            "scenes/**/*.gd",
            "scenes/**/*.tscn",
            "scenes/**/*.tres",
            "other/b.gd",
            "gone.png",
            "[gG][oO][nN][eE].[pP][nN][gG]",
        ]
    );
}
