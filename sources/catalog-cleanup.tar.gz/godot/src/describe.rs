//! What `describe()` returns: one capability, `lint`, that implements `wf.lint/1`.
use plugin_api::{Capability, Description, Example, Risk};
use plugin_protocols::lint::{LintInput, LintOutput, PROTOCOL};
use schemars::{JsonSchema, schema_for};
use serde_json::Value;

pub const OP: &str = "lint";

pub fn description() -> Description {
    Description {
        capabilities: vec![Capability {
            op: OP.to_owned(),
            summary: "Check the res:// references of Godot projects".to_owned(),
            when: "Use it to find res:// paths in GDScript, scenes, resources and project.godot that name a missing \
                   file, differ from the file in case (fine on macOS and Windows, broken on Linux and in exports) \
                   or are stale behind a uid, and ExtResource or SubResource ids that are undefined or unused. \
                   The `lint` command runs it with the other linters."
                .to_owned(),
            risk: Risk::Read,
            input: schema::<LintInput>(),
            output: Some(schema::<LintOutput>()),
            examples: vec![
                Example {
                    args: "lint".to_owned(),
                    note: "check every Godot project under the project root".to_owned(),
                },
                Example {
                    args: "lint --paths scenes --paths player.gd".to_owned(),
                    note: "report only on these files and directories".to_owned(),
                },
            ],
            implements: Some(PROTOCOL.to_owned()),
        }],
    }
}

fn schema<T: JsonSchema>() -> Value {
    serde_json::to_value(schema_for!(T)).expect("a schema serializes")
}

#[cfg(test)]
mod tests {
    use super::*;
    use plugin_api::is_name;

    #[test]
    fn declares_one_read_only_lint_capability() {
        let description = description();
        let [capability] = description.capabilities.as_slice() else {
            panic!("exactly one capability")
        };
        assert!(is_name(&capability.op));
        assert_eq!(capability.implements.as_deref(), Some("wf.lint/1"));
        assert_eq!(capability.risk, Risk::Read);
        assert!(!capability.examples.is_empty());
        assert_eq!(capability.input["properties"]["paths"]["type"], "array");
        assert!(capability.output.is_some());
        assert!(is_name("godot"));
    }
}
