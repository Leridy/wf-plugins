//! The official `godot` plugin: checks the `res://` references of Godot
//! projects. It implements `wf.lint/1` with hand-written, pure Rust readers of
//! GDScript strings and Godot's text resource format, so the component needs
//! no C toolchain.
#![cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "the component glue that calls into these is wasm-only")
)]

mod describe;
mod gather;
mod gdscript;
mod glob;
mod message;
mod project;
mod references;
mod resource;
mod rules;
#[cfg(test)]
mod testing;
mod world;

pub use gather::lint;

#[cfg(target_arch = "wasm32")]
mod component;
