use super::*;
use crate::testing::Fake;

fn world_of<'h>(fake: &'h Fake, files: &[&str]) -> World<'h> {
    let mut world = World::new(fake);
    world.index(&files.iter().map(|f| (*f).to_owned()).collect());
    world
}

fn lists(fake: &Fake) -> Vec<String> {
    fake.lists.borrow().clone()
}

/// Both ways a host may match `*`: across `/` as globset does by default, or within a segment.
fn hosts(files: &[(&str, &str)]) -> [Fake; 2] {
    let loose = Fake::new(files);
    let mut strict = Fake::new(files);
    strict.strict = true;
    [loose, strict]
}

#[test]
fn a_file_is_asked_for_by_name_once() {
    let fake = Fake::new(&[("project.godot", ""), ("art/icon.png", "")]);
    let mut world = world_of(&fake, &["project.godot"]);
    assert_eq!(world.find("", "art/icon.png", false), Found::Exact);
    assert_eq!(world.find("", "art/icon.png", false), Found::Exact);
    assert_eq!(lists(&fake), ["**/project.godot", "art/icon.png"]);
    assert!(fake.reads.borrow().is_empty());
}

#[test]
fn a_name_with_glob_characters_is_asked_for_literally() {
    let fake = Fake::new(&[("project.godot", ""), ("a[1]/b*.png", ""), ("a1/bx.png", "")]);
    let mut world = world_of(&fake, &["project.godot"]);
    assert_eq!(world.find("", "a[1]/b*.png", false), Found::Exact);
    assert_eq!(world.find("", "a1/b*.png", false), Found::Absent);
}

#[test]
fn only_the_file_name_in_the_wrong_case_is_found_in_its_folder() {
    for fake in hosts(&[("project.godot", ""), ("art/Icon.png", ""), ("art/deep/x.png", "")]) {
        let mut world = world_of(&fake, &["project.godot"]);
        assert_eq!(
            world.find("", "art/icon.png", false),
            Found::Case(Some("art/Icon.png".to_owned()))
        );
        assert_eq!(world.find("", "art/other.png", false), Found::Absent);
        // The folder is listed once for both names, and no listing walks the whole project.
        assert_eq!(
            lists(&fake),
            ["**/project.godot", "art/icon.png", "art/*", "art/other.png"]
        );
    }
}

#[test]
fn a_folder_in_the_wrong_case_is_found_by_the_name_in_any_case() {
    for fake in hosts(&[("project.godot", ""), ("Art/Sub/Icon.png", "")]) {
        let mut world = world_of(&fake, &["project.godot"]);
        assert_eq!(
            world.find("", "art/sub/icon.png", false),
            Found::Case(Some("Art/Sub/Icon.png".to_owned()))
        );
        assert_eq!(world.find("", "art/sub", true), Found::Case(Some("Art/Sub".to_owned())));
        assert_eq!(world.find("", "Art/Sub", true), Found::Exact);
        assert_eq!(world.find("", "art/none", true), Found::Absent);
    }
}

#[test]
fn a_name_that_differs_in_case_from_several_files_has_no_single_answer() {
    for fake in hosts(&[("project.godot", ""), ("art/a.png", ""), ("art/A.png", "")]) {
        let mut world = world_of(&fake, &["project.godot"]);
        assert_eq!(world.find("", "art/A.PNG", false), Found::Case(None));
        assert_eq!(world.find("", "art/a.png", false), Found::Exact);
    }
}

#[test]
fn a_root_level_name_is_found_without_listing_the_project() {
    let fake = Fake::new(&[("project.godot", ""), ("icon.svg", ""), ("deep/ICON.svg", "")]);
    let mut world = world_of(&fake, &["project.godot"]);
    assert_eq!(
        world.find("", "Icon.svg", false),
        Found::Case(Some("icon.svg".to_owned()))
    );
    assert_eq!(
        lists(&fake),
        ["**/project.godot", "Icon.svg", "[iI][cC][oO][nN].[sS][vV][gG]"]
    );
}

#[test]
fn a_directory_is_no_file_and_a_file_no_directory() {
    let fake = Fake::new(&[("project.godot", ""), ("scenes/main.tscn", ""), ("art/icon.png", "")]);
    let mut world = world_of(&fake, &["project.godot", "scenes/main.tscn"]);
    assert_eq!(world.find("", "scenes", false), Found::Absent);
    assert_eq!(world.find("", "art", false), Found::Absent);
    assert_eq!(world.find("", "scenes", true), Found::Exact);
    assert_eq!(world.find("", "art", true), Found::Exact);
    assert_eq!(world.find("", "art/icon.png", true), Found::Absent);
}

#[test]
fn a_nested_project_is_not_part_of_the_outer_one() {
    let fake = Fake::new(&[
        ("project.godot", ""),
        ("sub/project.godot", ""),
        ("sub/art/x.png", ""),
        ("sub/s.gd", ""),
        ("art/y.png", ""),
    ]);
    let mut world = world_of(&fake, &["project.godot", "sub/project.godot", "sub/s.gd"]);
    assert_eq!(world.roots(), ["sub", ""]);
    assert_eq!(world.find("", "sub/art/x.png", false), Found::Absent);
    assert_eq!(world.find("", "sub/s.gd", false), Found::Absent);
    assert_eq!(world.find("", "sub/art", true), Found::Absent);
    assert_eq!(world.find("", "sub", true), Found::Exact, "the directory itself exists");
    assert_eq!(world.find("", "art/y.png", false), Found::Exact);
    assert_eq!(world.find("sub", "art/x.png", false), Found::Exact);
    assert_eq!(world.find("sub", "art/y.png", false), Found::Absent);
}

#[test]
fn a_file_the_listings_lack_is_read_before_it_is_called_missing() {
    let mut fake = Fake::new(&[("project.godot", ""), ("ignored/a.png", "")]);
    fake.unlisted.push("ignored/a.png".to_owned());
    let mut world = world_of(&fake, &["project.godot"]);
    assert_eq!(world.find("", "ignored/a.png", false), Found::Exact);
    assert_eq!(world.find("", "ignored/b.png", false), Found::Absent);
    assert_eq!(*fake.reads.borrow(), ["ignored/a.png", "ignored/b.png"]);
}

#[test]
fn asking_about_files_stops_when_the_questions_are_used_up() {
    let names: Vec<String> = (0..MAX_EXISTENCE_PROBES).map(|n| format!("art/{n}.png")).collect();
    let mut files: Vec<(&str, &str)> = names.iter().map(|n| (n.as_str(), "")).collect();
    files.push(("project.godot", ""));
    let fake = Fake::new(&files);
    let mut world = world_of(&fake, &["project.godot"]);
    for name in &names[..MAX_EXISTENCE_PROBES - 1] {
        assert_eq!(world.find("", name, false), Found::Exact);
    }
    assert!(world.partial().is_empty());
    assert_eq!(world.find("", "art/x.png", false), Found::Absent);
    assert_eq!(world.find("", "art/y.png", false), Found::Exact, "taken to exist");
    assert_eq!(world.partial().len(), 1);
    assert!(world.partial().iter().all(|r| r.contains("taken to exist")));
}
