//! Godot's text resource format, as `.tscn`, `.tres`, `.import` and
//! `project.godot` use it: section headers `[tag key=value …]` and property
//! lines `key = value`, whose values may span lines. Values keep only the
//! shape the rules need: strings, words, calls such as `ExtResource("1")`, and
//! lists (arrays, dictionaries and call arguments, flattened).
//!
//! The parser never fails: what it cannot read it skips, and marks the
//! document `malformed` so the rules that need the whole file can stay quiet.
mod lexer;

use lexer::{Bracket, Kind, Lexer, Token};
pub use lexer::{Prefix, Span, Str};
use std::{borrow::Cow, collections::VecDeque, ops::Range};

/// Deeper values are skipped rather than parsed, so hostile nesting cannot
/// exhaust the stack.
const MAX_DEPTH: usize = 64;
/// Most entries and values one document keeps. Generated data (millions of
/// array items) stops the reading here, with the document `malformed`, rather
/// than filling the plugin's memory.
const MAX_ITEMS: usize = 500_000;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Value {
    Str(Str),
    /// A number, `true`, an identifier: its byte span.
    Word(Span),
    Call {
        /// The span of the callee's name.
        name: Span,
        /// Strings and nested values; words only for `ExtResource` and `SubResource`.
        args: Box<[Value]>,
    },
    /// An array, a dictionary (keys and values in turn) or a skipped value;
    /// its numbers and words are not kept.
    List(Box<[Value]>),
}

impl Value {
    /// A string's value or a word's text, as attribute values like `id` are written in either form.
    pub fn text<'a>(&self, source: &'a str) -> Option<Cow<'a, str>> {
        match self {
            Self::Str(s) => Some(s.value(source)),
            Self::Word(span) => source.get(span.range()).map(Cow::Borrowed),
            _ => None,
        }
    }

    /// The span `text` came from: a string's content or the word.
    pub fn text_span(&self) -> Option<Range<usize>> {
        match self {
            Self::Str(s) => Some(s.content.range()),
            Self::Word(span) => Some(span.range()),
            _ => None,
        }
    }

    /// Every string in this value, outside `NodePath(…)` calls, and every call, depth first.
    pub fn visit<'a>(
        &'a self,
        source: &'a str,
        strings: &mut impl FnMut(&'a Str),
        calls: &mut impl FnMut(&'a str, &'a [Value]),
    ) {
        match self {
            Self::Str(s) => strings(s),
            Self::Word(_) => {}
            Self::Call { name, args } => {
                let name = source.get(name.range()).unwrap_or_default();
                calls(name, args);
                if name != "NodePath" {
                    for arg in args {
                        arg.visit(source, strings, calls);
                    }
                }
            }
            Self::List(items) => {
                for item in items {
                    item.visit(source, strings, calls);
                }
            }
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Header {
    pub tag: String,
    /// From `[` to `]`.
    pub span: Range<usize>,
    pub attributes: Vec<(String, Value)>,
}

impl Header {
    pub fn get(&self, key: &str) -> Option<&Value> {
        self.attributes.iter().find(|(k, _)| k == key).map(|(_, v)| v)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Property {
    pub key: String,
    pub value: Value,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Entry {
    Header(Header),
    Property(Property),
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct Document {
    pub entries: Vec<Entry>,
    /// Some of the text could not be read and was skipped.
    pub malformed: bool,
}

impl Document {
    pub fn headers(&self) -> impl Iterator<Item = &Header> {
        self.entries.iter().filter_map(|e| match e {
            Entry::Header(h) => Some(h),
            Entry::Property(_) => None,
        })
    }

    pub fn properties(&self) -> impl Iterator<Item = &Property> {
        self.entries.iter().filter_map(|e| match e {
            Entry::Property(p) => Some(p),
            Entry::Header(_) => None,
        })
    }
}

pub fn parse(text: &str) -> Document {
    parse_from(text, 0)
}

/// The first section header, read from the first line only: the `uid` of a
/// scene or resource without parsing the rest of a possibly large file.
pub fn first_header(text: &str) -> Option<Header> {
    let line = text.lines().find(|l| !l.trim().is_empty())?;
    let offset = line.as_ptr() as usize - text.as_ptr() as usize;
    parse_from(&text[..offset + line.len()], offset)
        .headers()
        .next()
        .cloned()
}

/// The entries of `text` from the line starting at `from`.
fn parse_from(text: &str, from: usize) -> Document {
    if u32::try_from(text.len()).is_err() {
        return Document {
            entries: Vec::new(),
            malformed: true,
        };
    }
    let mut parser = Parser {
        text,
        lexer: Lexer::new(text, from),
        ahead: VecDeque::new(),
        malformed: false,
        spent: 0,
    };
    let mut entries = Vec::new();
    while parser.token(0).is_some() {
        entries.extend(parser.entry());
    }
    Document {
        entries,
        malformed: parser.malformed || parser.lexer.broken(),
    }
}

struct Parser<'a> {
    text: &'a str,
    lexer: Lexer<'a>,
    /// Tokens read ahead of the parser, a few at most.
    ahead: VecDeque<Token>,
    malformed: bool,
    /// Entries and values kept so far.
    spent: usize,
}

impl<'a> Parser<'a> {
    /// The token `ahead` places after the current one.
    fn token(&mut self, ahead: usize) -> Option<Token> {
        while self.ahead.len() <= ahead {
            let token = self.lexer.next()?;
            self.ahead.push_back(token);
        }
        self.ahead.get(ahead).copied()
    }

    fn kind(&mut self, ahead: usize) -> Option<Kind> {
        self.token(ahead).map(|t| t.kind)
    }

    fn word(&mut self, ahead: usize) -> Option<&'a str> {
        let token = self.token(ahead)?;
        let text = self.text;
        (token.kind == Kind::Word).then(|| &text[token.span.range()])
    }

    /// Moves past the current token.
    fn bump(&mut self) {
        if self.ahead.pop_front().is_none() {
            self.lexer.next();
        }
    }

    /// Counts a kept entry or value; past the limit the rest is dropped.
    fn spend(&mut self) {
        self.spent += 1;
        if self.spent > MAX_ITEMS {
            self.malformed = true;
            self.ahead.clear();
            self.lexer.finish();
        }
    }

    /// The next entry, or `None` after skipping what it could not read.
    fn entry(&mut self) -> Option<Entry> {
        let token = self.token(0)?;
        match token.kind {
            Kind::Open(Bracket::Square) => {
                self.spend();
                self.header().map(Entry::Header)
            }
            Kind::Word | Kind::Str(_) if self.kind(1) == Some(Kind::Equals) => {
                let key = match token.kind {
                    Kind::Str(s) => s.value(self.text).into_owned(),
                    _ => self.text[token.span.range()].to_owned(),
                };
                self.bump();
                self.bump();
                if self.token(0).is_none() || self.header_ahead() {
                    self.malformed = true;
                    return None;
                }
                self.spend();
                let value = self.value(0);
                Some(Entry::Property(Property { key, value }))
            }
            _ => {
                self.malformed = true;
                self.bump();
                None
            }
        }
    }

    fn header(&mut self) -> Option<Header> {
        let start = self.token(0)?.span.range().start;
        self.bump();
        let Some(tag) = self.word(0).map(str::to_owned) else {
            self.malformed = true;
            return None;
        };
        self.bump();
        let mut attributes = Vec::new();
        loop {
            match self.kind(0) {
                Some(Kind::Close(Bracket::Square)) => {
                    let end = self.token(0)?.span.range().end;
                    self.bump();
                    return Some(Header {
                        tag,
                        span: start..end,
                        attributes,
                    });
                }
                Some(Kind::Word) if self.kind(1) == Some(Kind::Equals) => {
                    let key = self.word(0).unwrap_or_default().to_owned();
                    self.bump();
                    self.bump();
                    if self.token(0).is_none() || self.header_ahead() {
                        break;
                    }
                    self.spend();
                    let value = self.value(0);
                    attributes.push((key, value));
                }
                _ => break,
            }
        }
        // An unclosed or garbled header: skip to the end of its line.
        self.malformed = true;
        let line = self.text[start..].find('\n').map_or(self.text.len(), |n| start + n);
        while self.token(0).is_some_and(|t| (t.span.start as usize) < line) {
            self.bump();
        }
        None
    }

    /// Whether a section header starts here: `[` first on its line, then a
    /// tag, then `]` or `key=`. An array value never looks like that, so a
    /// value left open stops at the next header instead of swallowing it.
    fn header_ahead(&mut self) -> bool {
        let Some(token) = self.token(0) else {
            return false;
        };
        if token.kind != Kind::Open(Bracket::Square) || !token.first {
            return false;
        }
        let tag = self.word(1).is_some_and(|w| {
            w.starts_with(|c: char| c.is_ascii_alphabetic() || c == '_')
                && w.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
                && !matches!(w, "true" | "false" | "null")
        });
        tag && match self.kind(2) {
            Some(Kind::Close(Bracket::Square)) => true,
            Some(Kind::Word) => self.kind(3) == Some(Kind::Equals),
            _ => false,
        }
    }

    fn value(&mut self, depth: usize) -> Value {
        let Some(token) = self.token(0) else {
            self.malformed = true;
            return Value::List(Box::default());
        };
        match token.kind {
            Kind::Str(s) => {
                self.bump();
                Value::Str(s)
            }
            Kind::Word if self.kind(1) == Some(Kind::Open(Bracket::Round)) => {
                // Godot 3 writes ids as numbers, `ExtResource( 1 )`: the only words kept.
                let ids = matches!(&self.text[token.span.range()], "ExtResource" | "SubResource");
                self.bump();
                let args = self.list(depth, ids);
                Value::Call { name: token.span, args }
            }
            Kind::Word => {
                self.bump();
                Value::Word(token.span)
            }
            Kind::Open(_) => Value::List(self.list(depth, false)),
            _ => {
                self.malformed = true;
                self.bump();
                Value::List(Box::default())
            }
        }
    }

    /// The items of the bracketed list opening here, separated by `,` or `:`.
    /// Words are dropped unless `words`: nothing reads the numbers of an array.
    fn list(&mut self, depth: usize, words: bool) -> Box<[Value]> {
        self.bump();
        if depth >= MAX_DEPTH {
            self.malformed = true;
            self.skip_nested();
            return Box::default();
        }
        let mut items = Vec::new();
        loop {
            match self.kind(0) {
                None => {
                    self.malformed = true;
                    break;
                }
                Some(Kind::Close(_)) => {
                    self.bump();
                    break;
                }
                Some(Kind::Comma | Kind::Colon) => self.bump(),
                Some(Kind::Equals) => {
                    self.malformed = true;
                    self.bump();
                }
                Some(_) if self.header_ahead() => {
                    self.malformed = true;
                    break;
                }
                Some(_) => {
                    let item = self.value(depth + 1);
                    if words || !matches!(item, Value::Word(_)) {
                        self.spend();
                        items.push(item);
                    }
                }
            }
        }
        items.into_boxed_slice()
    }

    /// Skips to the close of the list just opened, without recursing.
    fn skip_nested(&mut self) {
        let mut open = 1usize;
        while let Some(kind) = self.kind(0) {
            if self.header_ahead() {
                return;
            }
            match kind {
                Kind::Open(_) => open += 1,
                Kind::Close(_) => open -= 1,
                _ => {}
            }
            self.bump();
            if open == 0 {
                return;
            }
        }
    }
}

#[cfg(test)]
mod tests;
