//! Tokens of Godot's text resource format (`VariantParser`): brackets,
//! punctuation, strings and words. A word is any run of other characters:
//! keys (`theme_override_colors/font_color`), numbers, `true`, `#ff0000`.
//!
//! The lexer is lazy and its tokens are small and `Copy`: a string is a range
//! of the source, decoded only when asked, and the numbers of the packed
//! arrays that hold large data (`PackedInt32Array(…)`) are skipped without
//! becoming tokens. Every byte is scanned a bounded number of times, so
//! hostile files cost time linear in their size.
use std::{borrow::Cow, mem, ops::Range};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Bracket {
    Square,
    Round,
    Curly,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Prefix {
    None,
    /// `&"…"`
    StringName,
    /// `^"…"`
    NodePath,
}

/// A byte range of the source; the callers keep files far below 4 GiB.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct Span {
    pub start: u32,
    pub end: u32,
}

impl Span {
    pub fn new(range: Range<usize>) -> Self {
        Self {
            start: range.start as u32,
            end: range.end as u32,
        }
    }

    pub fn range(self) -> Range<usize> {
        self.start as usize..self.end as usize
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Str {
    pub prefix: Prefix,
    /// The text between the quotes, as written.
    pub content: Span,
    /// The content holds backslash escapes, so its value differs from it.
    pub escaped: bool,
}

impl Str {
    /// The text with escapes resolved: the source itself unless it has escapes.
    pub fn value<'a>(&self, source: &'a str) -> Cow<'a, str> {
        let content = source.get(self.content.range()).unwrap_or_default();
        if self.escaped {
            Cow::Owned(unescape(content))
        } else {
            Cow::Borrowed(content)
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Kind {
    Open(Bracket),
    Close(Bracket),
    Comma,
    Colon,
    Equals,
    Str(Str),
    Word,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Token {
    pub kind: Kind,
    pub span: Span,
    /// Only whitespace precedes it on its line.
    pub first: bool,
}

pub struct Lexer<'a> {
    text: &'a str,
    at: usize,
    /// Nothing but whitespace has been read on the current line.
    first: bool,
    /// The previous token was the name of a packed array of numbers.
    packed: bool,
    damage: Damage,
}

/// What the lexer could not read so far.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Damage {
    None,
    /// A packed array without its `)`.
    Array,
    /// A string scan reached the end of the text: no later string can end.
    String,
}

impl<'a> Lexer<'a> {
    /// Lexes `text` from the byte offset `from`, which starts a line.
    pub fn new(text: &'a str, from: usize) -> Self {
        Self {
            text,
            at: from,
            first: true,
            packed: false,
            damage: Damage::None,
        }
    }

    /// Some of the text could not be read: a string without a closing quote
    /// (taken to end at its line) or a packed array without its `)`.
    pub fn broken(&self) -> bool {
        self.damage != Damage::None
    }

    /// Ends the input, as when a document is too large to keep reading.
    pub fn finish(&mut self) {
        self.at = self.text.len();
    }

    fn token(&mut self, kind: Kind, start: usize, end: usize) -> Token {
        self.at = end;
        self.packed = false;
        Token {
            kind,
            span: Span::new(start..end),
            first: mem::replace(&mut self.first, false),
        }
    }

    /// Past the numbers of a packed array whose `(` was just read, up to its `)`.
    fn skip_numbers(&mut self) {
        let bytes = self.text.as_bytes();
        let rest = &bytes[self.at..];
        match rest.iter().position(|b| matches!(b, b')' | b'[')) {
            Some(n) if rest[n] == b')' => self.at += n,
            // Numbers hold no bracket: this is the next section header.
            Some(n) => {
                self.damage(Damage::Array);
                self.at += n;
                self.first = rest[..n]
                    .iter()
                    .rposition(|b| *b == b'\n')
                    .is_some_and(|line| rest[line..n].iter().all(u8::is_ascii_whitespace));
            }
            None => {
                self.damage(Damage::Array);
                self.at = bytes.len();
            }
        }
    }

    fn damage(&mut self, damage: Damage) {
        if self.damage != Damage::String {
            self.damage = damage;
        }
    }

    /// The string starting at `start` whose quote is at `open`; on a missing
    /// closing quote the rest of the line is skipped.
    fn string(&mut self, start: usize, prefix: Prefix, open: usize) -> Option<Token> {
        let bytes = self.text.as_bytes();
        let found = if self.damage == Damage::String {
            None
        } else {
            scan_string(bytes, open)
        };
        let Some((close, escaped)) = found else {
            self.damage = Damage::String;
            self.at = line_end(bytes, start);
            return None;
        };
        let kind = Kind::Str(Str {
            prefix,
            content: Span::new(open + 1..close),
            escaped,
        });
        Some(self.token(kind, start, close + 1))
    }
}

impl Iterator for Lexer<'_> {
    type Item = Token;

    fn next(&mut self) -> Option<Token> {
        let bytes = self.text.as_bytes();
        loop {
            let i = self.at;
            let b = *bytes.get(i)?;
            let single = match b {
                b'[' => Some(Kind::Open(Bracket::Square)),
                b']' => Some(Kind::Close(Bracket::Square)),
                b'(' => Some(Kind::Open(Bracket::Round)),
                b')' => Some(Kind::Close(Bracket::Round)),
                b'{' => Some(Kind::Open(Bracket::Curly)),
                b'}' => Some(Kind::Close(Bracket::Curly)),
                b',' => Some(Kind::Comma),
                b':' => Some(Kind::Colon),
                b'=' => Some(Kind::Equals),
                _ => None,
            };
            if let Some(kind) = single {
                let numbers = self.packed && kind == Kind::Open(Bracket::Round);
                let token = self.token(kind, i, i + 1);
                if numbers {
                    self.skip_numbers();
                }
                return Some(token);
            }
            if b == b'\n' {
                self.first = true;
                self.at += 1;
            } else if b.is_ascii_whitespace() {
                self.at += 1;
            } else if b == b';' {
                self.at = line_end(bytes, i);
            } else if b == b'"' || (matches!(b, b'&' | b'^') && bytes.get(i + 1) == Some(&b'"')) {
                let prefix = match b {
                    b'&' => Prefix::StringName,
                    b'^' => Prefix::NodePath,
                    _ => Prefix::None,
                };
                let open = if prefix == Prefix::None { i } else { i + 1 };
                if let Some(token) = self.string(i, prefix, open) {
                    return Some(token);
                }
            } else {
                let end = bytes[i..]
                    .iter()
                    .position(|b| delimiter(*b))
                    .map_or(bytes.len(), |n| i + n);
                let numbers = packed_numbers(&self.text[i..end]);
                let token = self.token(Kind::Word, i, end);
                self.packed = numbers;
                return Some(token);
            }
        }
    }
}

/// The types whose `(…)` holds only numbers (or one base64 string), which
/// nothing reads and large files fill with millions.
fn packed_numbers(word: &str) -> bool {
    matches!(
        word,
        "PackedByteArray"
            | "PackedInt32Array"
            | "PackedInt64Array"
            | "PackedFloat32Array"
            | "PackedFloat64Array"
            | "PackedVector2Array"
            | "PackedVector3Array"
            | "PackedVector4Array"
            | "PackedColorArray"
            | "PoolByteArray"
            | "PoolIntArray"
            | "PoolRealArray"
            | "PoolVector2Array"
            | "PoolVector3Array"
            | "PoolColorArray"
    )
}

fn delimiter(b: u8) -> bool {
    b.is_ascii_whitespace()
        || matches!(
            b,
            b'[' | b']' | b'(' | b')' | b'{' | b'}' | b',' | b':' | b'=' | b'"' | b';'
        )
}

/// The offset of the line break at or after `from`, or the end.
fn line_end(bytes: &[u8], from: usize) -> usize {
    bytes[from..]
        .iter()
        .position(|b| *b == b'\n')
        .map_or(bytes.len(), |n| from + n)
}

/// Where the string whose quote is at `open` ends: the offset of its closing
/// quote, and whether it holds an escape; `None` when the text ends first.
/// Strings may span lines (a built-in script's source does).
///
/// When this fails, so does every later scan: from any quote the first scan
/// passed over (an escaped one) it is in the same state as the scan itself.
fn scan_string(bytes: &[u8], open: usize) -> Option<(usize, bool)> {
    let mut i = open + 1;
    let mut escaped = false;
    while let Some(b) = bytes.get(i) {
        match b {
            b'"' => return Some((i, escaped)),
            // The next byte is escaped; the rest of a multi-byte character, or
            // the digits of `\u`, can be neither a quote nor a backslash.
            b'\\' => {
                escaped = true;
                i += 2;
            }
            _ => i += 1,
        }
    }
    None
}

/// The value of a string's content: escapes resolved.
fn unescape(content: &str) -> String {
    let mut value = String::with_capacity(content.len());
    let mut chars = content.chars();
    while let Some(c) = chars.next() {
        if c != '\\' {
            value.push(c);
            continue;
        }
        let Some(next) = chars.next() else {
            break;
        };
        match next {
            'n' => value.push('\n'),
            't' => value.push('\t'),
            'r' => value.push('\r'),
            'b' => value.push('\u{8}'),
            'f' => value.push('\u{c}'),
            'u' | 'U' => {
                let digits = if next == 'u' { 4 } else { 6 };
                let code = chars
                    .as_str()
                    .get(..digits)
                    .filter(|h| h.bytes().all(|b| b.is_ascii_hexdigit()))
                    .and_then(|h| u32::from_str_radix(h, 16).ok())
                    .and_then(char::from_u32);
                if let Some(code) = code {
                    value.push(code);
                    for _ in 0..digits {
                        chars.next();
                    }
                } else {
                    value.push(next);
                }
            }
            other => value.push(other),
        }
    }
    value
}

#[cfg(test)]
mod tests;
