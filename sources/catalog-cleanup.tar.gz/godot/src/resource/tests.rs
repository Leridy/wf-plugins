use super::*;
use std::time::Instant;

const SCENE: &str = r#"[gd_scene load_steps=3 format=3 uid="uid://cecaux1sm7mo0"]

[ext_resource type="Script" path="res://player.gd" id="1_abc"]
[ext_resource type="Texture2D" uid="uid://b4x" path="res://icon.svg" id="2_def"]

[sub_resource type="RectangleShape2D" id="RectangleShape2D_1"]
size = Vector2(10, 20)

[node name="Main" type="Node2D" groups=["enemies", "boss"]]
script = ExtResource("1_abc")
metadata/_edit_lock_ = true

[node name="Sprite" type="Sprite2D" parent="."]
texture = ExtResource("2_def")
shape = SubResource("RectangleShape2D_1")
path = NodePath("res://not/a/file")
tracks/0/keys = {
"times": PackedFloat32Array(0, 1),
"values": [ExtResource("1_abc"), "res://anim.png"]
}
label = &"res://name"
node = ^"res://path"
"#;

fn strings_in(doc: &Document, text: &str) -> Vec<String> {
    let mut found = Vec::new();
    for entry in &doc.entries {
        let mut take = |s: &Str| found.push(s.value(text).into_owned());
        match entry {
            Entry::Header(h) => h
                .attributes
                .iter()
                .for_each(|(_, v)| v.visit(text, &mut take, &mut |_, _| {})),
            Entry::Property(p) => p.value.visit(text, &mut take, &mut |_, _| {}),
        }
    }
    found
}

#[test]
fn reads_headers_with_typed_attributes_and_spans() {
    let doc = parse(SCENE);
    assert!(!doc.malformed);
    let headers: Vec<&Header> = doc.headers().collect();
    assert_eq!(
        headers.iter().map(|h| h.tag.as_str()).collect::<Vec<_>>(),
        [
            "gd_scene",
            "ext_resource",
            "ext_resource",
            "sub_resource",
            "node",
            "node"
        ]
    );
    assert_eq!(
        headers[0].get("load_steps").and_then(|v| v.text(SCENE)).as_deref(),
        Some("3")
    );
    assert_eq!(
        headers[0].get("uid").and_then(|v| v.text(SCENE)).as_deref(),
        Some("uid://cecaux1sm7mo0")
    );
    let ext = headers[2];
    assert_eq!(
        &SCENE[ext.span.clone()],
        r#"[ext_resource type="Texture2D" uid="uid://b4x" path="res://icon.svg" id="2_def"]"#
    );
    let path = ext.get("path").unwrap();
    assert_eq!(&SCENE[path.text_span().unwrap()], "res://icon.svg");
    assert_eq!(ext.get("id").and_then(|v| v.text(SCENE)).as_deref(), Some("2_def"));
    assert!(matches!(headers[4].get("groups"), Some(Value::List(items)) if items.len() == 2));
}

#[test]
fn reads_multiline_property_values_with_calls_and_strings() {
    let doc = parse(SCENE);
    let keys: Vec<&str> = doc.properties().map(|p| p.key.as_str()).collect();
    assert_eq!(
        keys,
        [
            "size",
            "script",
            "metadata/_edit_lock_",
            "texture",
            "shape",
            "path",
            "tracks/0/keys",
            "label",
            "node"
        ]
    );
    let mut calls = Vec::new();
    for property in doc.properties() {
        property.value.visit(SCENE, &mut |_| {}, &mut |name, args| {
            calls.push((
                name.to_owned(),
                args.first()
                    .and_then(|a| a.text(SCENE))
                    .map(Cow::into_owned)
                    .unwrap_or_default(),
            ));
        });
    }
    let ids: Vec<(&str, &str)> = calls
        .iter()
        .filter(|(n, _)| n.ends_with("Resource"))
        .map(|(n, a)| (n.as_str(), a.as_str()))
        .collect();
    assert_eq!(
        ids,
        [
            ("ExtResource", "1_abc"),
            ("ExtResource", "2_def"),
            ("SubResource", "RectangleShape2D_1"),
            ("ExtResource", "1_abc"),
        ]
    );
    let strings = strings_in(&doc, SCENE);
    assert!(strings.contains(&"res://anim.png".to_owned()));
    assert!(
        !strings.contains(&"res://not/a/file".to_owned()),
        "NodePath(…) arguments are not visited"
    );
}

#[test]
fn string_prefixes_and_escapes() {
    let text = "a = &\"x\"\nb = ^\"y\"\nc = \"q\\\"uo\\\\te\\n\\u00e9\"\n";
    let doc = parse(text);
    let values: Vec<(Prefix, String)> = doc
        .properties()
        .map(|p| match &p.value {
            Value::Str(s) => (s.prefix, s.value(text).into_owned()),
            other => panic!("not a string: {other:?}"),
        })
        .collect();
    assert_eq!(
        values,
        [
            (Prefix::StringName, "x".to_owned()),
            (Prefix::NodePath, "y".to_owned()),
            (Prefix::None, "q\"uo\\te\n\u{e9}".to_owned()),
        ]
    );
}

#[test]
fn reads_project_godot_with_comments_quoted_keys_and_objects() {
    let text = r#"; Engine configuration file.
; It's best edited using the editor UI.

config_version=5

[application]

config/name="Demo"
run/main_scene="res://main.tscn"
config/features=PackedStringArray("4.7", "Forward Plus")
config/icon="res://icon.svg"

[autoload]

Global="*res://global.gd"

[input]

jump={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"keycode":0,"unicode":32,"script":null)
]
}
"#;
    let doc = parse(text);
    assert!(!doc.malformed);
    let strings = strings_in(&doc, text);
    for expected in ["res://main.tscn", "res://icon.svg", "*res://global.gd", "Demo"] {
        assert!(strings.contains(&expected.to_owned()), "{expected}");
    }
    assert_eq!(doc.headers().count(), 3);
    assert_eq!(doc.properties().last().map(|p| p.key.as_str()), Some("jump"));
}

#[test]
fn godot_3_integer_ids() {
    let text =
        "[ext_resource path=\"res://a.png\" type=\"Texture\" id=1]\n[node name=\"A\"]\ntexture = ExtResource( 1 )\n";
    let doc = parse(text);
    assert!(!doc.malformed);
    let header = doc.headers().next().unwrap();
    assert_eq!(header.get("id").and_then(|v| v.text(text)).as_deref(), Some("1"));
    let Some(Value::Call { name, args }) = doc.properties().next().map(|p| &p.value) else {
        panic!("a call")
    };
    assert_eq!(
        (&text[name.range()], args[0].text(text).as_deref()),
        ("ExtResource", Some("1"))
    );
}

#[test]
fn an_unclosed_value_stops_at_the_next_header() {
    let text = "[resource]\nvalues = [1, 2,\n[ext_resource path=\"res://a.png\" id=\"1\"]\nnext = 3\n";
    let doc = parse(text);
    assert!(doc.malformed);
    let tags: Vec<&str> = doc.headers().map(|h| h.tag.as_str()).collect();
    assert_eq!(tags, ["resource", "ext_resource"]);
    assert_eq!(
        doc.properties().map(|p| p.key.as_str()).collect::<Vec<_>>(),
        ["values", "next"]
    );
}

#[test]
fn a_string_left_open_at_the_end_ends_at_its_line() {
    let text = "[ext_resource path=\"res://a.png\" id=\"1\"]\n[node name=\"A]\n";
    let doc = parse(text);
    assert!(doc.malformed);
    assert_eq!(
        doc.headers().map(|h| h.tag.as_str()).collect::<Vec<_>>(),
        ["ext_resource"]
    );
}

#[test]
fn first_header_reads_the_first_line_with_offsets() {
    let text = "\n[gd_resource type=\"Theme\" uid=\"uid://abc\"]\n[resource]\n";
    let header = first_header(text).unwrap();
    assert_eq!(header.tag, "gd_resource");
    let uid = header.get("uid").unwrap();
    assert_eq!(&text[uid.text_span().unwrap()], "uid://abc");
    assert_eq!(&text[header.span], "[gd_resource type=\"Theme\" uid=\"uid://abc\"]");
    assert_eq!(first_header("key = 1"), None);
}

#[test]
fn hostile_input_never_panics() {
    let deep = "a = ".to_owned() + &"[".repeat(100_000);
    let closed = "a = ".to_owned() + &"[".repeat(5_000) + &"]".repeat(5_000) + "\nb = \"res://x\"\n";
    let inputs = [
        "",
        "[",
        "]",
        "[[",
        "[a",
        "[a b",
        "[a b=",
        "[a b=]",
        "=",
        "a =",
        "a = (",
        "a = )",
        "\"",
        "&\"",
        "^",
        "[a b=\"\n",
        "a = {:,}",
        "a = b(c(d(",
        "a = \"\\u12\"",
        "a = \"\\",
        "\u{e9}=\u{e9}",
        ";",
        "[a]\n=\n]",
        "[ext_resource id=ExtResource(]",
        "a = \"\\U\u{e9}\u{e9}\"",
    ];
    for text in inputs.iter().copied().chain([deep.as_str(), closed.as_str()]) {
        let _ = parse(text);
        let _ = first_header(text);
    }
    let doc = parse(&closed);
    assert!(doc.malformed, "nesting beyond the limit is skipped");
    assert_eq!(doc.properties().map(|p| p.key.as_str()).collect::<Vec<_>>(), ["a", "b"]);
}

/// Hostile files of a few MB must parse in time linear in their size; a
/// quadratic scan of one would take minutes, so the bound is generous.
fn within_seconds(limit: u64, run: impl FnOnce()) {
    let started = Instant::now();
    run();
    assert!(started.elapsed().as_secs() < limit, "took {:?}", started.elapsed());
}

const MEGABYTES_4: usize = 4 << 20;

#[test]
fn long_lines_of_brackets_and_headers_parse_in_linear_time() {
    let open = "a = ".to_owned() + &"[".repeat(MEGABYTES_4);
    let lines = "a = [\n".repeat(MEGABYTES_4 / 6);
    let headers = "[a b=".repeat(MEGABYTES_4 / 5);
    let unclosed = "[a b=\"c".repeat(MEGABYTES_4 / 7);
    let sections = "[a]".repeat(MEGABYTES_4 / 3);
    let backslashes = "\\\"\n".repeat(MEGABYTES_4 / 3);
    for (name, text) in [
        ("open", open),
        ("lines", lines),
        ("headers", headers),
        ("unclosed", unclosed),
        ("sections", sections),
        ("backslashes", backslashes),
    ] {
        within_seconds(10, || {
            let doc = parse(&text);
            assert!(doc.malformed || name == "sections", "{name}");
        });
    }
}

#[test]
fn a_big_packed_array_is_a_call_without_arguments() {
    let text = format!(
        "[node name=\"N\"]\ntile_data = PackedInt32Array({})\nnext = \"res://after.png\"\n",
        "0, ".repeat(MEGABYTES_4 / 3)
    );
    within_seconds(10, || {
        let doc = parse(&text);
        assert!(!doc.malformed);
        let properties: Vec<&Property> = doc.properties().collect();
        assert_eq!(properties.len(), 2);
        let Value::Call { name, args } = &properties[0].value else {
            panic!("a call")
        };
        assert_eq!(&text[name.range()], "PackedInt32Array");
        assert!(args.is_empty());
        assert_eq!(strings_in(&doc, &text), ["N", "res://after.png"]);
    });
}

#[test]
fn arrays_keep_their_strings_and_calls_but_not_their_numbers() {
    let text = "[resource]\nvalues = [1, 2.5, \"a\", Vector2(1, 2), ExtResource( 3 ), true, [4, \"b\"], {\"k\": 5}]\n";
    let doc = parse(text);
    let Some(Value::List(items)) = doc.properties().next().map(|p| &p.value) else {
        panic!("a list")
    };
    // "a", Vector2(), ExtResource(3), ["b"], {"k"}
    assert_eq!(items.len(), 5);
    let Value::Call { args, .. } = &items[1] else {
        panic!("a call")
    };
    assert!(args.is_empty(), "the numbers of Vector2 are dropped");
    let Value::Call { args, .. } = &items[2] else {
        panic!("a call")
    };
    assert_eq!(args[0].text(text).as_deref(), Some("3"), "the id of ExtResource stays");
}

#[test]
fn a_document_stops_being_kept_past_the_item_limit() {
    let text = format!("a = [{}]\nb = 1\n", "\"s\",".repeat(MAX_ITEMS));
    let doc = parse(&text);
    assert!(doc.malformed);
    assert!(doc.properties().count() <= 1);
    let kept: usize = doc
        .properties()
        .map(|p| match &p.value {
            Value::List(items) => items.len(),
            _ => 0,
        })
        .sum();
    assert!(kept <= MAX_ITEMS, "{kept}");
}
