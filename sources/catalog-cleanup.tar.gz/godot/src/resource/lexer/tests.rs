use super::*;
use std::time::{Duration, Instant};

/// Hostile files of a few MB must lex in time linear in their size; a
/// quadratic scan of one would take minutes, so the bound is generous.
const FAST: Duration = Duration::from_secs(10);
const MEGABYTES_4: usize = 4 << 20;

fn kinds(text: &str) -> Vec<Kind> {
    Lexer::new(text, 0).map(|t| t.kind).collect()
}

fn within(limit: Duration, run: impl FnOnce()) {
    let started = Instant::now();
    run();
    assert!(started.elapsed() < limit, "took {:?}", started.elapsed());
}

#[test]
fn tokens_are_punctuation_strings_and_words() {
    let text = "a/b = [1, \"x\"] ; comment\n&\"n\" ^\"p\" {k:v}";
    let tokens: Vec<Token> = Lexer::new(text, 0).collect();
    let strings: Vec<(Prefix, &str)> = tokens
        .iter()
        .filter_map(|t| match t.kind {
            Kind::Str(s) => Some((s.prefix, &text[s.content.range()])),
            _ => None,
        })
        .collect();
    assert_eq!(
        strings,
        [(Prefix::None, "x"), (Prefix::StringName, "n"), (Prefix::NodePath, "p")]
    );
    assert_eq!(&text[tokens[0].span.range()], "a/b");
    assert_eq!(tokens[1].kind, Kind::Equals);
    assert_eq!(tokens.iter().filter(|t| t.kind == Kind::Word).count(), 4);
    assert_eq!(&text[tokens[tokens.len() - 1].span.range()], "}");
}

#[test]
fn strings_decode_only_when_asked_and_only_when_they_have_escapes() {
    let text = r#"a = "plain" b = "q\"xé\n" c = "é""#;
    let strings: Vec<Str> = Lexer::new(text, 0)
        .filter_map(|t| match t.kind {
            Kind::Str(s) => Some(s),
            _ => None,
        })
        .collect();
    assert_eq!(
        strings.iter().map(|s| s.escaped).collect::<Vec<_>>(),
        [false, true, false]
    );
    assert!(matches!(strings[0].value(text), Cow::Borrowed("plain")));
    assert_eq!(strings[1].value(text), "q\"x\u{e9}\n");
    assert!(matches!(strings[2].value(text), Cow::Borrowed("é")));
}

#[test]
fn a_token_knows_whether_it_starts_its_line() {
    let text = "[a]\n  [b] [c]\n\"s\n\" [d]\n; x\n[e]";
    let firsts: Vec<(char, bool)> = Lexer::new(text, 0)
        .filter(|t| t.kind == Kind::Open(Bracket::Square))
        .map(|t| (text.as_bytes()[t.span.start as usize + 1] as char, t.first))
        .collect();
    assert_eq!(
        firsts,
        [('a', true), ('b', true), ('c', false), ('d', false), ('e', true)]
    );
}

#[test]
fn the_numbers_of_a_packed_array_are_not_tokens() {
    let text = "a = PackedInt32Array(0, 1, 2)\nb = PackedStringArray(\"res://x.png\")\nc = PackedByteArray(\"AAEC\")";
    assert_eq!(
        kinds(text).iter().filter(|k| **k == Kind::Word).count(),
        // a, PackedInt32Array, b, PackedStringArray, c, PackedByteArray
        6
    );
    let tokens: Vec<Token> = Lexer::new(text, 0).collect();
    assert!(
        tokens
            .iter()
            .any(|t| matches!(t.kind, Kind::Str(s) if &text[s.content.range()] == "res://x.png"))
    );
    let mut lexer = Lexer::new(text, 0);
    assert_eq!(lexer.by_ref().count(), tokens.len());
    assert!(!lexer.broken());
}

#[test]
fn a_packed_array_left_open_stops_at_the_next_header() {
    let text = "a = PackedInt32Array(0, 1,\n\n  [node name=\"N\"]\n";
    let mut lexer = Lexer::new(text, 0);
    let tokens: Vec<Token> = lexer.by_ref().collect();
    assert!(lexer.broken());
    let header = tokens.iter().find(|t| t.kind == Kind::Open(Bracket::Square)).unwrap();
    assert!(header.first);
    assert!(
        tokens
            .iter()
            .any(|t| t.kind == Kind::Word && &text[t.span.range()] == "node")
    );
    let mut lexer = Lexer::new("a = PackedInt32Array(1, 2", 0);
    assert_eq!(lexer.by_ref().count(), 4);
    assert!(lexer.broken());
}

#[test]
fn an_unterminated_string_costs_its_line_not_the_rest_of_the_file() {
    // Each line opens a string whose every quote is escaped, so none ends: the
    // scan of each once ran to the end of the file.
    for line in ["\\\"\n", "a = \\\"x\\\"\n", "\\\"\\\"\\\"\n"] {
        let text = line.repeat(MEGABYTES_4 / line.len());
        within(FAST, || {
            let mut lexer = Lexer::new(&text, 0);
            assert!(lexer.by_ref().all(|t| !matches!(t.kind, Kind::Str(_))));
            assert!(lexer.broken());
        });
    }
    // The lines that do not close stay unread; the string before them is read.
    let text = "a = \"ok\"\nb = \"x\nc = \\\"y\nd = \\\"z\n";
    let mut lexer = Lexer::new(text, 0);
    let strings = lexer.by_ref().filter(|t| matches!(t.kind, Kind::Str(_))).count();
    assert_eq!(strings, 1);
    assert!(lexer.broken());
}

#[test]
fn hostile_one_line_files_lex_in_linear_time() {
    for filler in ["[", "(", ",", "a", "\"\"", "&", ";x", "\\\"", "=", ":"] {
        let text = filler.repeat(MEGABYTES_4 / filler.len());
        within(FAST, || {
            let _ = Lexer::new(&text, 0).count();
        });
    }
}
