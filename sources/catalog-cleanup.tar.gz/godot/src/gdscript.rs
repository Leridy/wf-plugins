//! Just enough of a GDScript lexer to find string literals: it knows comments,
//! the quote forms and the `&`, `^` and `r` prefixes, and skips everything else
//! byte by byte. Delimiters are ASCII, so every offset it returns sits on a
//! character boundary of the UTF-8 source.
use std::{borrow::Cow, ops::Range};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Prefix {
    None,
    /// `&"…"`
    StringName,
    /// `^"…"`
    NodePath,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Literal {
    pub prefix: Prefix,
    /// Byte offsets of the text between the quotes.
    pub content: Range<usize>,
    /// The offset just after the closing quote.
    pub end: usize,
    /// The value is not the content as written, so an offset into one is not
    /// an offset into the other. (A raw string keeps its escapes as written.)
    pub escaped: bool,
}

impl Literal {
    /// The text with escapes resolved; a raw string keeps them as written.
    pub fn value<'a>(&self, source: &'a str) -> Cow<'a, str> {
        let content = source.get(self.content.clone()).unwrap_or_default();
        if self.escaped {
            let mut value = String::with_capacity(content.len());
            let mut i = 0;
            while i < content.len() {
                if content.as_bytes()[i] == b'\\' {
                    i = escape(content, i, &mut value);
                } else {
                    let c = content[i..].chars().next().unwrap_or('\u{fffd}');
                    value.push(c);
                    i += c.len_utf8();
                }
            }
            Cow::Owned(value)
        } else {
            Cow::Borrowed(content)
        }
    }
}

/// Every terminated string literal outside comments, in source order. An
/// unterminated one is dropped: a one-line string ends at its line, so the
/// next line lexes normally. The literals are found as they are asked for and
/// their values decoded on demand, so a large file holds none of them.
pub fn strings(source: &str) -> Strings<'_> {
    Strings { source, at: 0 }
}

pub struct Strings<'a> {
    source: &'a str,
    at: usize,
}

impl Iterator for Strings<'_> {
    type Item = Literal;

    fn next(&mut self) -> Option<Literal> {
        let source = self.source;
        let bytes = source.as_bytes();
        while self.at < bytes.len() {
            let i = self.at;
            let (next, found) = match bytes[i] {
                b'#' => (line_end(bytes, i), None),
                b'"' | b'\'' => string(source, i, Prefix::None, false),
                b'&' | b'^' => {
                    let prefix = if bytes[i] == b'&' {
                        Prefix::StringName
                    } else {
                        Prefix::NodePath
                    };
                    match (bytes.get(i + 1), bytes.get(i + 2)) {
                        (Some(b'"' | b'\''), _) => string(source, i + 1, prefix, false),
                        (Some(b'r'), Some(b'"' | b'\'')) => string(source, i + 2, prefix, true),
                        _ => (i + 1, None),
                    }
                }
                b'r' if matches!(bytes.get(i + 1), Some(b'"' | b'\'')) && !identifier_before(bytes, i) => {
                    string(source, i + 1, Prefix::None, true)
                }
                _ => (i + 1, None),
            };
            self.at = next;
            if found.is_some() {
                return found;
            }
        }
        None
    }
}

fn line_end(bytes: &[u8], from: usize) -> usize {
    bytes[from..]
        .iter()
        .position(|b| *b == b'\n')
        .map_or(bytes.len(), |n| from + n)
}

/// Whether the byte before `at` continues an identifier, as in `bar"x"`.
fn identifier_before(bytes: &[u8], at: usize) -> bool {
    at > 0 && (bytes[at - 1].is_ascii_alphanumeric() || bytes[at - 1] == b'_' || bytes[at - 1] >= 0x80)
}

/// Lexes the string whose opening quote is at `open`; returns where lexing
/// goes on, and the literal when it is terminated.
fn string(source: &str, open: usize, prefix: Prefix, raw: bool) -> (usize, Option<Literal>) {
    let bytes = source.as_bytes();
    let quote = bytes[open];
    let triple = bytes[open..].starts_with(&[quote; 3]);
    let width = if triple { 3 } else { 1 };
    let start = open + width;
    let mut escaped = false;
    let mut i = start;
    while i < bytes.len() {
        let b = bytes[i];
        if b == quote && (!triple || bytes[i..].starts_with(&[quote; 3])) {
            let literal = Literal {
                prefix,
                content: start..i,
                end: i + width,
                // A raw string's value is its content.
                escaped: escaped && !raw,
            };
            return (i + width, Some(literal));
        }
        if b == b'\n' && !triple {
            return (i, None);
        }
        if b == b'\\' {
            escaped = true;
            // The escaped character, or a line continuation, is never the end.
            i += if bytes.get(i + 1) == Some(&b'\r') && bytes.get(i + 2) == Some(&b'\n') {
                3
            } else {
                2
            };
        } else {
            i += 1;
        }
    }
    (bytes.len(), None)
}

/// Reads the escape at `at` (a backslash) into `value`; returns the offset after it.
fn escape(source: &str, at: usize, value: &mut String) -> usize {
    let rest = &source[at + 1..];
    let Some(next) = rest.chars().next() else {
        return source.len();
    };
    let after = at + 1 + next.len_utf8();
    let simple = match next {
        'n' => Some('\n'),
        't' => Some('\t'),
        'r' => Some('\r'),
        'a' => Some('\u{7}'),
        'b' => Some('\u{8}'),
        'f' => Some('\u{c}'),
        'v' => Some('\u{b}'),
        '"' | '\'' | '\\' => Some(next),
        _ => None,
    };
    if let Some(c) = simple {
        value.push(c);
        return after;
    }
    match next {
        // A line continuation.
        '\n' => after,
        '\r' if rest[1..].starts_with('\n') => after + 1,
        'u' | 'U' => {
            let digits = if next == 'u' { 4 } else { 6 };
            let hex = rest[1..]
                .get(..digits)
                .filter(|h| h.bytes().all(|b| b.is_ascii_hexdigit()));
            if let Some(c) = hex
                .and_then(|h| u32::from_str_radix(h, 16).ok())
                .and_then(char::from_u32)
            {
                value.push(c);
                after + digits
            } else {
                value.push('\\');
                value.push(next);
                after
            }
        }
        // Godot rejects an unknown escape; keeping it as written is enough to go on.
        _ => {
            value.push('\\');
            value.push(next);
            after
        }
    }
}

#[cfg(test)]
mod tests;
