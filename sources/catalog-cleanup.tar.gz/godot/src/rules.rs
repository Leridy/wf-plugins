//! The five rules, judged per checked file. A path diagnostic sits on the
//! reference itself (without quotes), and its fix replaces only that; the fix
//! of an unused `[ext_resource]` deletes its line.
use crate::{
    message,
    project::{self, Found},
    references::{Facts, FileKind, RES, Reference, Table},
    world::World,
};
use plugin_protocols::lint::{Diagnostic, Fix, Severity, Span, TextEdit};
use std::{collections::BTreeSet, iter, ops::Range};

pub const MISSING_RESOURCE: &str = "missing-resource";
pub const RESOURCE_PATH_CASE: &str = "resource-path-case";
pub const STALE_RESOURCE_PATH: &str = "stale-resource-path";
pub const UNDEFINED_RESOURCE_ID: &str = "undefined-resource-id";
pub const UNUSED_EXT_RESOURCE: &str = "unused-ext-resource";
/// Not about a reference: the run could not look at everything.
pub const INCOMPLETE_CHECK: &str = "incomplete-check";

/// A file being checked: project-relative, in the Godot project at `root`.
pub struct Checked<'a> {
    pub file: &'a str,
    pub root: &'a str,
    pub kind: FileKind,
    pub text: &'a str,
}

impl Checked<'_> {
    fn diagnostic(&self, rule: &str, severity: Severity, message: String, span: &Range<usize>) -> Diagnostic {
        Diagnostic {
            rule: rule.to_owned(),
            severity,
            message,
            file: self.file.to_owned(),
            span: Some(span_of(span)),
            fix: None,
        }
    }

    fn fix(&self, summary: String, span: &Range<usize>, text: String) -> Fix {
        Fix {
            summary,
            edits: vec![TextEdit {
                file: self.file.to_owned(),
                span: span_of(span),
                text,
            }],
        }
    }
}

/// The diagnostics of one file, at most `limit`.
pub fn check(file: &Checked, facts: &Facts, world: &mut World, limit: usize) -> Vec<Diagnostic> {
    // Ids are judged only on a file read whole: a skipped header would look undefined.
    let ids = file.kind == FileKind::Resource && !facts.malformed;
    let unused: BTreeSet<usize> = if ids { unused(facts) } else { BTreeSet::new() };
    let lines = Lines::new(file.text, !unused.is_empty());
    let mut diagnostics = Vec::new();
    for reference in &facts.references {
        // A fix there would overlap the deletion of the line.
        let fixable = reference.exact && !reference.ext.is_some_and(|i| unused.contains(&i));
        diagnostics.extend(path(file, facts, reference, fixable, world));
        if diagnostics.len() >= limit {
            diagnostics.truncate(limit);
            return diagnostics;
        }
    }
    if ids {
        diagnostics.extend(undefined(file, facts, limit));
        for index in unused {
            diagnostics.push(unused_diagnostic(file, facts, &lines, index));
            if diagnostics.len() >= limit {
                break;
            }
        }
    }
    diagnostics.truncate(limit);
    diagnostics
}

/// The diagnostic about one `res://` reference, if anything is wrong with it.
fn path(file: &Checked, facts: &Facts, reference: &Reference, fixable: bool, world: &mut World) -> Option<Diagnostic> {
    let missing = |uid: Option<&str>| {
        file.diagnostic(
            MISSING_RESOURCE,
            Severity::Error,
            message::missing(&reference.path, uid),
            &reference.span,
        )
    };
    let Some((path, directory)) = project::normalize(&reference.path) else {
        return Some(missing(None));
    };
    // `.godot/` and other dot directories are out of the plugin's reach.
    if path.split('/').any(|segment| segment.starts_with('.')) {
        return None;
    }
    match world.find(file.root, &path, directory) {
        Found::Exact => None,
        Found::Case(actual) => {
            let target = actual.map(|actual| format!("{RES}{actual}{}", if directory { "/" } else { "" }));
            let mut diagnostic = file.diagnostic(
                RESOURCE_PATH_CASE,
                Severity::Error,
                message::case(&reference.path, target.as_deref()),
                &reference.span,
            );
            diagnostic.fix = target
                .filter(|target| fixable && plain(target))
                .map(|target| file.fix(format!("use `{target}`"), &reference.span, target));
            Some(diagnostic)
        }
        Found::Absent => {
            let uid = reference.ext.and_then(|i| facts.ext_resources[i].uid.as_deref());
            let Some(uid) = uid else {
                return Some(missing(None));
            };
            let Some(target) = world.uid(file.root, uid).filter(|t| world.file_exists(file.root, t)) else {
                return Some(missing(Some(uid)));
            };
            let target = format!("{RES}{target}");
            let mut diagnostic = file.diagnostic(
                STALE_RESOURCE_PATH,
                Severity::Warning,
                message::stale(&reference.path, uid, &target),
                &reference.span,
            );
            if fixable && plain(&target) {
                diagnostic.fix = Some(file.fix(format!("use `{target}`"), &reference.span, target));
            }
            Some(diagnostic)
        }
    }
}

/// Whether a path can replace a string's content as is, with nothing to escape.
fn plain(path: &str) -> bool {
    !path.chars().any(|c| matches!(c, '"' | '\'' | '\\') || c.is_control())
}

fn undefined(file: &Checked, facts: &Facts, limit: usize) -> Vec<Diagnostic> {
    let ext: BTreeSet<&str> = facts.ext_resources.iter().filter_map(|e| e.id.as_deref()).collect();
    facts
        .uses
        .iter()
        .filter(|u| match u.table {
            Table::Ext => !ext.contains(u.id.as_str()),
            Table::Sub => !facts.sub_ids.contains(&u.id),
        })
        .map(|u| {
            file.diagnostic(
                UNDEFINED_RESOURCE_ID,
                Severity::Error,
                message::undefined(u.table, &u.id),
                &u.span,
            )
        })
        .take(limit)
        .collect()
}

/// The `[ext_resource]`s, by index, that no `ExtResource("id")` uses.
fn unused(facts: &Facts) -> BTreeSet<usize> {
    let used: BTreeSet<&str> = facts
        .uses
        .iter()
        .filter(|u| u.table == Table::Ext)
        .map(|u| u.id.as_str())
        .collect();
    facts
        .ext_resources
        .iter()
        .enumerate()
        .filter(|(_, e)| e.id.as_deref().is_some_and(|id| !used.contains(id)))
        .map(|(i, _)| i)
        .collect()
}

fn unused_diagnostic(file: &Checked, facts: &Facts, lines: &Lines, index: usize) -> Diagnostic {
    let ext = &facts.ext_resources[index];
    let mut diagnostic = file.diagnostic(
        UNUSED_EXT_RESOURCE,
        Severity::Warning,
        message::unused(ext.id.as_deref().unwrap_or_default(), ext.path.as_deref()),
        &ext.header,
    );
    let line = lines.whole(file.text, &ext.header);
    diagnostic.fix = Some(file.fix("remove the unused [ext_resource]".to_owned(), &line, String::new()));
    diagnostic
}

/// Where the lines of a text start, so the line of an offset is a lookup and
/// not a scan back through a long line.
struct Lines {
    starts: Vec<usize>,
}

impl Lines {
    /// Indexes `text`, or nothing when `wanted` is false.
    fn new(text: &str, wanted: bool) -> Self {
        let starts = if wanted {
            iter::once(0)
                .chain(text.match_indices('\n').map(|(at, _)| at + 1))
                .collect()
        } else {
            Vec::new()
        };
        Self { starts }
    }

    /// The header's line with its line break, when nothing else is on it; else the header alone.
    fn whole(&self, text: &str, header: &Range<usize>) -> Range<usize> {
        let before = self.starts.partition_point(|start| *start <= header.start);
        let start = self.starts[before - 1];
        let end = self
            .starts
            .get(self.starts.partition_point(|s| *s <= header.end))
            .copied()
            .unwrap_or(text.len());
        let alone = text[start..header.start].trim().is_empty() && text[header.end..end].trim().is_empty();
        if alone { start..end } else { header.clone() }
    }
}

fn span_of(range: &Range<usize>) -> Span {
    Span {
        start: range.start as u32,
        end: range.end as u32,
    }
}

#[cfg(test)]
mod tests;
