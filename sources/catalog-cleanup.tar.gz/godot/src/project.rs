//! Godot projects inside the `wf` project, and the files `res://` can reach in
//! each.
use crate::references::{PROJECT_FILE, RES};
use std::collections::BTreeSet;

/// The directories holding a `project.godot`, project-relative (`""` for the
/// root), deepest first so the first that contains a file owns it.
pub fn roots(listing: &[String]) -> Vec<String> {
    let mut roots: Vec<String> = listing
        .iter()
        .filter_map(|path| {
            if path == PROJECT_FILE {
                Some(String::new())
            } else {
                path.strip_suffix(&format!("/{PROJECT_FILE}")).map(str::to_owned)
            }
        })
        .collect();
    roots.sort_by(|a, b| b.len().cmp(&a.len()).then_with(|| a.cmp(b)));
    roots
}

/// The deepest Godot project containing `path`.
pub fn owner<'a>(roots: &'a [String], path: &str) -> Option<&'a str> {
    roots
        .iter()
        .find(|root| {
            root.is_empty()
                || path
                    .strip_prefix(root.as_str())
                    .is_some_and(|rest| rest.starts_with('/'))
        })
        .map(String::as_str)
}

/// `root`-relative `path` made project-relative.
pub fn join(root: &str, path: &str) -> String {
    match (root.is_empty(), path.is_empty()) {
        (true, _) => path.to_owned(),
        (false, true) => root.to_owned(),
        (false, false) => format!("{root}/{path}"),
    }
}

/// A `res://` path as Godot resolves it: `root`-relative, with empty and `.`
/// segments dropped and `..` applied, and whether it names a directory
/// (ends in `/`). `None` for a path that climbs out of the project.
pub fn normalize(reference: &str) -> Option<(String, bool)> {
    let rest = reference.strip_prefix(RES)?;
    let mut segments: Vec<&str> = Vec::new();
    for segment in rest.split('/') {
        match segment {
            "" | "." => {}
            ".." => {
                segments.pop()?;
            }
            segment => segments.push(segment),
        }
    }
    Some((segments.join("/"), rest.ends_with('/') || rest.is_empty()))
}

/// What the project's files say about a `root`-relative path.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Found {
    Exact,
    /// Only with another case; the real path when exactly one matches.
    Case(Option<String>),
    Absent,
}

/// The files of one Godot project that the plugin has listed, `root`-relative.
/// Godot's own scan does not enter a directory with another `project.godot`,
/// so the files of nested projects are not part of the outer one.
#[derive(Clone, Debug, Default)]
pub struct Tree {
    files: BTreeSet<String>,
    directories: BTreeSet<String>,
}

impl Tree {
    /// The files of `listing` (project-relative) that `root` owns among `roots`.
    pub fn new<'a>(root: &str, roots: &[String], listing: impl IntoIterator<Item = &'a String>) -> Self {
        let mut tree = Self::default();
        for path in listing {
            if owner(roots, path) != Some(root) {
                continue;
            }
            let relative = if root.is_empty() {
                Some(path.as_str())
            } else {
                path.strip_prefix(root).and_then(|rest| rest.strip_prefix('/'))
            };
            if let Some(relative) = relative {
                tree.add(relative);
            }
        }
        tree
    }

    fn add(&mut self, file: &str) {
        self.files.insert(file.to_owned());
        let mut end = file.len();
        while let Some(slash) = file[..end].rfind('/') {
            if !self.directories.insert(file[..slash].to_owned()) {
                break;
            }
            end = slash;
        }
    }

    pub fn contains_file(&self, path: &str) -> bool {
        self.files.contains(path)
    }

    pub fn contains_directory(&self, path: &str) -> bool {
        self.directories.contains(path)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn listing(paths: &[&str]) -> Vec<String> {
        paths.iter().map(|p| (*p).to_owned()).collect()
    }

    #[test]
    fn roots_are_deepest_first_and_own_their_files() {
        let files = listing(&["project.godot", "game/project.godot", "game/a.gd", "b.gd", "gamer/c.gd"]);
        let roots = roots(&files);
        assert_eq!(roots, ["game", ""]);
        assert_eq!(owner(&roots, "game/a.gd"), Some("game"));
        assert_eq!(owner(&roots, "gamer/c.gd"), Some(""));
        assert_eq!(owner(&roots[..1], "b.gd"), None);
        assert_eq!(join("game", "a.gd"), "game/a.gd");
        assert_eq!(join("", "a.gd"), "a.gd");
        assert_eq!(join("game", ""), "game");
    }

    #[test]
    fn normalizes_like_godot() {
        assert_eq!(normalize("res://a//./b/../c.png"), Some(("a/c.png".to_owned(), false)));
        assert_eq!(normalize("res://levels/"), Some(("levels".to_owned(), true)));
        assert_eq!(normalize("res://"), Some((String::new(), true)));
        assert_eq!(normalize("res://../x"), None);
        assert_eq!(normalize("user://x"), None);
    }

    #[test]
    fn a_tree_holds_the_files_its_project_owns() {
        let files: BTreeSet<String> = listing(&[
            "game/Art/Icon.png",
            "game/art2/a.png",
            "game/sub/project.godot",
            "game/sub/b.gd",
            "other/x.png",
        ])
        .into_iter()
        .collect();
        let roots = roots(&files.iter().cloned().collect::<Vec<_>>());
        assert_eq!(roots, ["game/sub"]);
        let roots = ["game/sub".to_owned(), "game".to_owned()];
        let tree = Tree::new("game", &roots, &files);
        assert!(tree.contains_file("Art/Icon.png"));
        assert!(tree.contains_directory("Art") && tree.contains_directory("art2"));
        assert!(!tree.contains_file("Art"));
        assert!(
            !tree.contains_file("sub/b.gd"),
            "a nested project is not part of the outer one"
        );
        assert!(!tree.contains_directory("sub"));
        assert!(!tree.contains_file("x.png"));
        assert!(Tree::new("game/sub", &roots, &files).contains_file("b.gd"));
    }
}
