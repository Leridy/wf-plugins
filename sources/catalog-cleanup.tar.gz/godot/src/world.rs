//! What the rules look up, gathered lazily through the host: the Godot
//! projects, the files they hold, whether a referenced file exists, under
//! which spelling, and the uid map. The project is never listed whole: the
//! plugin lists the kinds it checks, and asks about any other file by name.
use crate::{
    glob,
    project::{self, Found, Tree},
    references::{FileKind, PROJECT_FILE},
    resource,
};
use plugin_guest::Host;
use std::{
    collections::{BTreeMap, BTreeSet},
    time::{Duration, Instant},
};

/// Larger files are generated data, not hand-written references.
const MAX_FILE_BYTES: usize = 4 * 1024 * 1024;
/// Listings that name one file, to tell a file the listings lack from a missing one.
const MAX_EXISTENCE_PROBES: usize = 2_000;
/// Listings for the real spelling of a name; each may walk the project.
const MAX_CASE_LOOKUPS: usize = 256;
/// Reads of referenced files the listings lack (the VCS ignores them): a read
/// costs the whole file.
pub(crate) const MAX_READ_PROBES: usize = 64;
/// Answers kept for the references that name the same file again.
const MAX_CACHED: usize = 20_000;
/// Lookups stop after this long, whatever a slow host makes of them; the plugin has 30 seconds.
const LOOKUP_TIME: Duration = Duration::from_secs(15);

pub struct World<'h> {
    host: &'h dyn Host,
    roots: Vec<String>,
    trees: BTreeMap<String, Tree>,
    /// Per Godot project: uid to the `root`-relative file it names.
    uids: BTreeMap<String, BTreeMap<String, String>>,
    /// The files that can carry a uid, once listed.
    uid_files: Option<BTreeSet<String>>,
    found: BTreeMap<(String, String, bool), Found>,
    exists: BTreeMap<String, bool>,
    directories: BTreeMap<String, bool>,
    children: BTreeMap<String, Vec<String>>,
    probes: usize,
    case_lookups: usize,
    reads: usize,
    started: Instant,
    /// Why the check may be incomplete, each once.
    partial: BTreeSet<String>,
}

impl<'h> World<'h> {
    /// Finds the Godot projects among the project's files.
    pub fn new(host: &'h dyn Host) -> Self {
        let mut world = Self {
            host,
            roots: Vec::new(),
            trees: BTreeMap::new(),
            uids: BTreeMap::new(),
            uid_files: None,
            found: BTreeMap::new(),
            exists: BTreeMap::new(),
            directories: BTreeMap::new(),
            children: BTreeMap::new(),
            probes: 0,
            case_lookups: 0,
            reads: 0,
            started: Instant::now(),
            partial: BTreeSet::new(),
        };
        let listing = world.list(&format!("**/{PROJECT_FILE}"));
        world.roots = project::roots(&listing);
        world
    }

    /// The directories holding a `project.godot`, deepest first.
    pub fn roots(&self) -> &[String] {
        &self.roots
    }

    /// Why the check may be incomplete.
    pub fn partial(&self) -> &BTreeSet<String> {
        &self.partial
    }

    pub fn note(&mut self, reason: &str) {
        if self.partial.insert(reason.to_owned()) {
            self.host.warn(reason);
        }
    }

    /// The files matching `glob`; one as long as the host allows may be cut short.
    pub fn list(&mut self, glob: &str) -> Vec<String> {
        let found = self.host.list(glob);
        let limit = self.host.list_limit();
        if found.len() >= limit {
            self.note(&format!(
                "`{glob}` matched {limit} files, the most the host lists, so some files were not seen."
            ));
        }
        found
    }

    /// Records the files each project holds: `files` are the listed ones, project-relative.
    pub fn index(&mut self, files: &BTreeSet<String>) {
        self.trees = self
            .roots
            .iter()
            .map(|root| (root.clone(), Tree::new(root, &self.roots, files)))
            .collect();
    }

    /// A project-relative file as UTF-8 text, if readable and not too large.
    pub fn text(&self, path: &str) -> Option<String> {
        let bytes = self.host.read(path).ok().filter(|b| b.len() <= MAX_FILE_BYTES)?;
        String::from_utf8(bytes).ok()
    }

    /// Looks up a normalized `root`-relative path: a file, or a directory when
    /// the reference ends in `/`.
    pub fn find(&mut self, root: &str, path: &str, directory: bool) -> Found {
        if path.is_empty() {
            return Found::Exact;
        }
        // Godot does not enter a directory with a `project.godot` of its own.
        if !self.owns(root, &project::join(root, path)) {
            return Found::Absent;
        }
        let key = (root.to_owned(), path.to_owned(), directory);
        if let Some(known) = self.found.get(&key) {
            return known.clone();
        }
        let answer = if directory {
            self.find_directory(root, path)
        } else {
            self.find_file(root, path)
        };
        if self.found.len() < MAX_CACHED {
            self.found.insert(key, answer.clone());
        }
        answer
    }

    fn find_directory(&mut self, root: &str, path: &str) -> Found {
        if self.directory_exists(root, path) {
            return Found::Exact;
        }
        spelled(&self.spellings(root, path, true))
    }

    fn find_file(&mut self, root: &str, path: &str) -> Found {
        if self.listed_file(root, path) {
            return Found::Exact;
        }
        match spelled(&self.spellings(root, path, false)) {
            Found::Absent if self.readable_file(root, path) => Found::Exact,
            found => found,
        }
    }

    /// Whether a `root`-relative file exists, under exactly this name.
    pub fn file_exists(&mut self, root: &str, path: &str) -> bool {
        self.listed_file(root, path) || self.readable_file(root, path)
    }

    /// Whether the listings show the file, or a listing that names it does.
    fn listed_file(&mut self, root: &str, path: &str) -> bool {
        if self.trees[root].contains_file(path) {
            return true;
        }
        let full = project::join(root, path);
        if let Some(known) = self.exists.get(&full) {
            return *known;
        }
        let Some(glob) = glob::exactly(&full) else {
            return false;
        };
        let Some(found) = self.ask(&glob) else {
            return true;
        };
        let exists = found.contains(&full) && self.owns(root, &full);
        self.exists.insert(full, exists);
        exists
    }

    /// Whether the file reads though no listing shows it (the VCS ignores it).
    fn readable_file(&mut self, root: &str, path: &str) -> bool {
        if self.reads == MAX_READ_PROBES {
            self.note(&format!(
                "More than {MAX_READ_PROBES} referenced files are not listed (ignored by the VCS?); the rest are taken to exist."
            ));
        }
        self.reads += 1;
        if self.reads > MAX_READ_PROBES {
            return true;
        }
        !matches!(self.host.read(&project::join(root, path)), Err(error) if error.not_found())
    }

    fn directory_exists(&mut self, root: &str, path: &str) -> bool {
        if self.trees[root].contains_directory(path) {
            return true;
        }
        let full = project::join(root, path);
        if let Some(known) = self.directories.get(&full) {
            return *known;
        }
        let Some(glob) = glob::exactly(&full) else {
            return false;
        };
        let Some(found) = self.ask(&format!("{glob}/**")) else {
            return true;
        };
        let exists = !found.is_empty();
        self.directories.insert(full, exists);
        exists
    }

    /// The other spellings of a `root`-relative path that exist: the real
    /// paths, `root`-relative, that differ from it only in case.
    fn spellings(&mut self, root: &str, path: &str, directory: bool) -> Vec<String> {
        if self.case_lookups >= MAX_CASE_LOOKUPS || self.out_of_time() {
            self.note(&format!(
                "Case differences in references were checked for the first {MAX_CASE_LOOKUPS} missing files only; the rest are reported as missing."
            ));
            return Vec::new();
        }
        self.case_lookups += 1;
        let wanted = glob::fold(path);
        if !directory && let Some((parent, name)) = path.rsplit_once('/') {
            // Usually the folder is spelled right and only the file name is not.
            let names = self.names_in(root, parent);
            if !names.is_empty() {
                let wanted = glob::fold(name);
                return names
                    .into_iter()
                    .filter(|real| *real != name && glob::fold(real) == wanted)
                    .map(|real| format!("{parent}/{real}"))
                    .collect();
            }
        }
        let (Some(base), Some(any_case)) = (glob::exactly(root), glob::any_case(path)) else {
            return Vec::new();
        };
        let any_case = if root.is_empty() {
            any_case
        } else {
            format!("{base}/{any_case}")
        };
        let listing = self.list(&if directory { format!("{any_case}/**") } else { any_case });
        let depth = path.matches('/').count() + 1;
        let prefix = if root.is_empty() { 0 } else { root.len() + 1 };
        let real: BTreeSet<String> = listing
            .iter()
            .filter(|found| self.owns(root, found))
            .filter_map(|found| {
                let relative = found.get(prefix..)?;
                // A directory is named by the first segments of the files below it.
                let named = if directory {
                    relative
                        .splitn(depth + 1, '/')
                        .take(depth)
                        .collect::<Vec<_>>()
                        .join("/")
                } else {
                    relative.to_owned()
                };
                (glob::fold(&named) == wanted && named != path).then_some(named)
            })
            .collect();
        real.into_iter().collect()
    }

    /// The names of the files directly in a `root`-relative directory.
    fn names_in(&mut self, root: &str, directory: &str) -> Vec<String> {
        let full = project::join(root, directory);
        if let Some(known) = self.children.get(&full) {
            return known.clone();
        }
        let names = glob::exactly(&full)
            .map(|glob| self.list(&format!("{glob}/*")))
            .unwrap_or_default()
            .iter()
            .filter(|found| self.owns(root, found))
            .filter_map(|found| {
                let name = found.strip_prefix(&full)?.strip_prefix('/')?;
                // A `*` that crosses `/` lists the files below too.
                (!name.contains('/')).then(|| name.to_owned())
            })
            .collect::<Vec<_>>();
        self.children.insert(full, names.clone());
        names
    }

    /// Whether `root` is the Godot project the project-relative `path` belongs to.
    fn owns(&self, root: &str, path: &str) -> bool {
        project::owner(&self.roots, path) == Some(root)
    }

    /// Lists `glob` as a question about one file or directory, unless the
    /// questions are used up; then the caller takes the answer to be yes.
    fn ask(&mut self, glob: &str) -> Option<Vec<String>> {
        if self.probes >= MAX_EXISTENCE_PROBES || self.out_of_time() {
            self.probes = MAX_EXISTENCE_PROBES;
            self.note(&format!(
                "Whether referenced files exist was looked up for the first {MAX_EXISTENCE_PROBES} unlisted files only; the rest are taken to exist."
            ));
            return None;
        }
        self.probes += 1;
        Some(self.list(glob))
    }

    fn out_of_time(&self) -> bool {
        self.started.elapsed() >= LOOKUP_TIME
    }

    /// The `root`-relative file a uid names in a Godot project.
    pub fn uid(&mut self, root: &str, uid: &str) -> Option<String> {
        if !self.uids.contains_key(root) {
            let map = self.uid_map(root);
            self.uids.insert(root.to_owned(), map);
        }
        self.uids[root].get(uid).cloned()
    }

    /// From `*.uid` files, `uid="…"` in `*.import` files and the headers of
    /// scenes and resources; the first file listed wins a duplicate uid.
    fn uid_map(&mut self, root: &str) -> BTreeMap<String, String> {
        if self.uid_files.is_none() {
            let mut files = BTreeSet::new();
            for glob in ["**/*.uid", "**/*.import", "**/*.tscn", "**/*.tres"] {
                files.extend(self.list(glob));
            }
            self.uid_files = Some(files);
        }
        let mut map = BTreeMap::new();
        for path in self.uid_files.iter().flatten() {
            if !self.owns(root, path) {
                continue;
            }
            let file = if root.is_empty() {
                path.as_str()
            } else {
                path.strip_prefix(root)
                    .and_then(|rest| rest.strip_prefix('/'))
                    .unwrap_or(path)
            };
            let found = if let Some(source) = file.strip_suffix(".uid") {
                self.text(path)
                    .map(|text| text.trim().to_owned())
                    .filter(|uid| uid.starts_with("uid://"))
                    .map(|uid| (uid, source.to_owned()))
            } else if let Some(source) = file.strip_suffix(".import") {
                self.text(path).and_then(|text| {
                    resource::parse(&text)
                        .properties()
                        .find(|p| p.key == "uid")
                        .and_then(|p| p.value.text(&text).map(std::borrow::Cow::into_owned))
                        .map(|uid| (uid, source.to_owned()))
                })
            } else if FileKind::of(file) == Some(FileKind::Resource) {
                self.text(path).and_then(|text| {
                    resource::first_header(&text)
                        .filter(|h| matches!(h.tag.as_str(), "gd_scene" | "gd_resource"))
                        .and_then(|h| {
                            h.get("uid")
                                .and_then(|v| v.text(&text))
                                .map(std::borrow::Cow::into_owned)
                        })
                        .map(|uid| (uid, file.to_owned()))
                })
            } else {
                None
            };
            if let Some((uid, source)) = found {
                map.entry(uid).or_insert(source);
            }
        }
        map
    }
}

/// What a set of other spellings says about a path.
fn spelled(real: &[String]) -> Found {
    match real {
        [] => Found::Absent,
        [only] => Found::Case(Some(only.clone())),
        _ => Found::Case(None),
    }
}

#[cfg(test)]
mod tests;
