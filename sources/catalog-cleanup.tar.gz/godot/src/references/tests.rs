use super::*;

fn paths(facts: &Facts) -> Vec<&str> {
    facts.references.iter().map(|r| r.path.as_str()).collect()
}

#[test]
fn kinds_by_name() {
    assert_eq!(FileKind::of("a/player.gd"), Some(FileKind::Script));
    assert_eq!(FileKind::of("main.tscn"), Some(FileKind::Resource));
    assert_eq!(FileKind::of("x/theme.tres"), Some(FileKind::Resource));
    assert_eq!(FileKind::of("game/project.godot"), Some(FileKind::Project));
    assert_eq!(FileKind::of("other.godot"), None);
    assert_eq!(FileKind::of("icon.png.import"), None);
}

#[test]
fn script_strings_that_are_whole_paths() {
    let text = r#"extends Node
const A = preload("res://a.gd")
var b = load('res://b.png') # load("res://comment.png")
var c = &"res://name"
var d = ^"res://node/path"
var e = "res://levels/" + name
var f = "res://level_%d.tscn" % n
var g = "res://{0}.tscn".format([n])
var h = "user://save"
var i = "res://dir/"
var j = "res://scene.tscn::Resource_1"
"#;
    let facts = read(FileKind::Script, text);
    assert_eq!(
        paths(&facts),
        [
            "res://a.gd",
            "res://b.png",
            "res://name",
            "res://dir/",
            "res://scene.tscn"
        ]
    );
    for reference in &facts.references {
        assert_eq!(&text[reference.span.clone()], reference.path);
        assert!(reference.exact);
    }
}

#[test]
fn an_escaped_string_spans_its_whole_content_and_is_not_exact() {
    let text = "var a = \"res://a\\u0062.png\"";
    let facts = read(FileKind::Script, text);
    let [reference] = facts.references.as_slice() else {
        panic!("one reference")
    };
    assert_eq!(reference.path, "res://ab.png");
    assert_eq!(&text[reference.span.clone()], "res://a\\u0062.png");
    assert!(!reference.exact);
}

#[test]
fn scene_references_ids_and_uses() {
    let text = r#"[gd_scene format=3 uid="uid://main"]

[ext_resource type="Script" uid="uid://s" path="res://player.gd" id="1_a"]
[ext_resource type="Texture2D" path="res://icon.svg" id="2_b"]
[ext_resource type="PackedScene" path="res://enemy.tscn" id="3_c"]

[sub_resource type="CircleShape2D" id="Circle_1"]

[node name="Main" type="Node2D"]
script = ExtResource("1_a")
shape = SubResource("Circle_1")
other = SubResource("Missing")
path = NodePath("res://not")
texture_path = "res://textures/grass.png"

[node name="Enemy" parent="." instance=ExtResource("3_c")]
"#;
    let facts = read(FileKind::Resource, text);
    assert!(!facts.malformed);
    assert_eq!(
        paths(&facts),
        [
            "res://player.gd",
            "res://icon.svg",
            "res://enemy.tscn",
            "res://textures/grass.png"
        ]
    );
    assert_eq!(facts.references[0].ext, Some(0));
    assert_eq!(facts.references[3].ext, None);
    assert_eq!(facts.ext_resources[0].uid.as_deref(), Some("uid://s"));
    assert_eq!(facts.ext_resources[1].uid, None);
    assert_eq!(facts.ext_resources[2].id.as_deref(), Some("3_c"));
    assert_eq!(
        &text[facts.ext_resources[1].header.clone()],
        r#"[ext_resource type="Texture2D" path="res://icon.svg" id="2_b"]"#
    );
    assert_eq!(facts.sub_ids.iter().collect::<Vec<_>>(), ["Circle_1"]);
    let uses: Vec<(Table, &str)> = facts.uses.iter().map(|u| (u.table, u.id.as_str())).collect();
    assert_eq!(
        uses,
        [
            (Table::Ext, "1_a"),
            (Table::Sub, "Circle_1"),
            (Table::Sub, "Missing"),
            (Table::Ext, "3_c"),
        ]
    );
    assert_eq!(&text[facts.uses[2].span.clone()], "Missing");
}

#[test]
fn project_values_drop_the_autoload_star() {
    let text = "[application]\nrun/main_scene=\"res://main.tscn\"\n[autoload]\nGlobal=\"*res://global.gd\"\n[internationalization]\nlocale/translations=PackedStringArray(\"res://text.en.translation\")\n";
    let facts = read(FileKind::Project, text);
    assert_eq!(
        paths(&facts),
        ["res://main.tscn", "res://global.gd", "res://text.en.translation"]
    );
    assert_eq!(&text[facts.references[1].span.clone()], "res://global.gd");
}
