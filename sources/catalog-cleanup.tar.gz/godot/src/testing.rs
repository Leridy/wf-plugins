//! An in-memory project for the unit tests, listed the way the host lists it.
use crate::gather::lint;
use globset::GlobBuilder;
use plugin_api::{Failure, LIST_LIMIT};
use plugin_guest::{Host, HostError};
use plugin_protocols::lint::{Diagnostic, LintInput};
use std::{cell::RefCell, collections::BTreeMap};

#[derive(Default)]
pub struct Fake {
    pub files: BTreeMap<String, String>,
    /// Readable but left out of the listing, like files the VCS ignores.
    pub unlisted: Vec<String>,
    /// Paths a listing holds at most, when not the host's.
    pub limit: Option<usize>,
    /// A `*` stays within a segment, as a host may choose to match it.
    pub strict: bool,
    pub lists: RefCell<Vec<String>>,
    pub reads: RefCell<Vec<String>>,
    pub warnings: RefCell<Vec<String>>,
}

impl Fake {
    pub fn new(files: &[(&str, &str)]) -> Self {
        Self {
            files: files.iter().map(|(p, t)| ((*p).to_owned(), (*t).to_owned())).collect(),
            ..Self::default()
        }
    }

    pub fn lint(&self) -> Vec<Diagnostic> {
        lint(self, &LintInput::default()).diagnostics
    }
}

impl Host for Fake {
    fn list(&self, glob: &str) -> Vec<String> {
        self.lists.borrow_mut().push(glob.to_owned());
        let matcher = GlobBuilder::new(glob)
            .literal_separator(self.strict)
            .build()
            .expect("the plugin builds valid globs")
            .compile_matcher();
        self.files
            .keys()
            .filter(|path| !self.unlisted.contains(path) && matcher.is_match(path))
            .take(self.list_limit())
            .cloned()
            .collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.reads.borrow_mut().push(path.to_owned());
        self.files
            .get(path)
            .map(|text| text.as_bytes().to_vec())
            .ok_or_else(|| HostError::new(Failure::NotFound, format!("no {path}")))
    }

    fn warn(&self, message: &str) {
        self.warnings.borrow_mut().push(message.to_owned());
    }

    fn list_limit(&self) -> usize {
        self.limit.unwrap_or(LIST_LIMIT)
    }
}

/// `(rule, file, the text under the span)` of each diagnostic.
pub fn summary<'a>(fake: &'a Fake, diagnostics: &'a [Diagnostic]) -> Vec<(&'a str, &'a str, &'a str)> {
    diagnostics
        .iter()
        .map(|d| {
            let span = d.span.expect("every diagnostic has a span");
            let text = &fake.files[&d.file][span.start as usize..span.end as usize];
            (d.rule.as_str(), d.file.as_str(), text)
        })
        .collect()
}
