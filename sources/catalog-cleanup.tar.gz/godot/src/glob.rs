//! Globs for `list-files` built from paths: one that matches exactly a path,
//! one that matches it in any case, and the lowercase form both compare by.

/// The glob that matches only `path`, so a listing with it is an existence
/// probe. `None` for a path the host never reads (it holds a backslash).
pub fn exactly(path: &str) -> Option<String> {
    (!path.contains('\\')).then(|| {
        path.chars()
            .map(|c| escaped(c).unwrap_or_else(|| c.to_string()))
            .collect()
    })
}

/// The glob that matches `path` in any letter case (the letters of its
/// name; a few characters change length with case and are not covered).
pub fn any_case(path: &str) -> Option<String> {
    if path.contains('\\') {
        return None;
    }
    Some(
        path.chars()
            .map(|c| {
                if let Some(escape) = escaped(c) {
                    return escape;
                }
                match (single(c.to_lowercase()), single(c.to_uppercase())) {
                    // A class works on bytes, so a letter of more than one byte needs the other form.
                    (Some(lower), Some(upper)) if lower != upper && c.is_ascii() => format!("[{lower}{upper}]"),
                    (Some(lower), Some(upper)) if lower != upper => format!("{{{lower},{upper}}}"),
                    _ => c.to_string(),
                }
            })
            .collect(),
    )
}

/// What two paths are compared by when only their case may differ.
pub fn fold(path: &str) -> String {
    path.to_lowercase()
}

/// `[c]` for a character a glob reads as syntax.
fn escaped(c: char) -> Option<String> {
    matches!(c, '*' | '?' | '[' | ']' | '{' | '}').then(|| format!("[{c}]"))
}

fn single(mut chars: impl Iterator<Item = char>) -> Option<char> {
    let first = chars.next()?;
    chars.next().is_none().then_some(first)
}

#[cfg(test)]
mod tests {
    use super::*;
    use globset::Glob;

    fn matches(glob: &str, path: &str) -> bool {
        Glob::new(glob).unwrap().compile_matcher().is_match(path)
    }

    #[test]
    fn an_exact_glob_matches_only_its_path() {
        let glob = exactly("a b/[x]{y}*?.png").unwrap();
        assert!(matches(&glob, "a b/[x]{y}*?.png"));
        assert!(!matches(&glob, "a b/x.png"));
        assert!(!matches(&glob, "a b/[x]{y}zz.png"));
        assert!(matches(&exactly("art/icon.png").unwrap(), "art/icon.png"));
        assert_eq!(exactly("a\\b"), None);
    }

    #[test]
    fn an_any_case_glob_matches_each_spelling_of_its_path() {
        let glob = any_case("Art/icon.PNG").unwrap();
        for path in ["Art/icon.PNG", "art/ICON.png", "ART/Icon.Png"] {
            assert!(matches(&glob, path), "{path}");
        }
        assert!(!matches(&glob, "Art/icons.png"));
        assert!(!matches(&glob, "Art/x/icon.png"));
        assert!(matches(&any_case("\u{e9}.png").unwrap(), "\u{c9}.png"));
        assert!(matches(&any_case("a*b").unwrap(), "A*B"));
        assert!(!matches(&any_case("a*b").unwrap(), "Axb"));
        assert_eq!(fold("Art/\u{c9}"), "art/\u{e9}");
    }
}
