//! `roguelike-develop`: a wf plugin for Godot 4 roguelikes and roguelites,
//! built on `wf-game-kit` (game-develop/kit).
//!
//! - `new` writes one of three playable projects (a turn-based dungeon, a
//!   survivors-like horde, a room-based action roguelite), returned as file
//!   writes; wf previews and applies them.
//! - `lint` implements `wf.lint/1` with checks for what breaks a roguelike:
//!   rolls that escape the run seed, seeds nobody can read back and
//!   per-frame group scans in hordes. The checks every game shares are
//!   game-develop's.
//!
//! Everything is plain Rust tested on the host; the kit turns
//! [`RoguelikeDevelop`] into the component's exports.

mod describe;
mod rules;
mod scaffold;

use wf_game_kit::{
    CallError, Description, Hint, Host, Plugin, Reply,
    lint::{self, LINT},
    plugin::parse,
    scaffold::NEW,
};

pub use rules::check;
pub use scaffold::{NewInput, NewOutput, Template, plan};

/// The files `lint` reads.
const KINDS: [&str; 1] = ["*.gd"];

/// The plugin.
pub struct RoguelikeDevelop;

impl Plugin for RoguelikeDevelop {
    const NAME: &'static str = "roguelike-develop";

    fn description() -> Description {
        describe::description()
    }

    fn call(op: &str, input: &[u8], host: &dyn Host) -> Result<Reply, CallError> {
        match op {
            NEW => {
                let (output, writes) = plan(&parse(input)?)?;
                let hints = vec![
                    Hint::skill(
                        "roguelike-develop/guide",
                        "how to extend the project without breaking seeds, saves and the run loop",
                    ),
                    Hint::skill(
                        "roguelike-develop/assets",
                        "which UI kits, word art, icons and art to ask the platform for, and how to wire them in",
                    ),
                    Hint::install(
                        "game-develop",
                        "the checks every game needs (paused timers, saves, export presets, cursors)",
                    ),
                    Hint::lint(Self::NAME, &output.dir),
                ];
                Ok(Reply::json(&output).with_writes(writes).with_hints(hints))
            }
            LINT => Ok(Reply::json(&lint::run(host, &parse(input)?, &KINDS, check))),
            _ => Err(CallError::unknown_op(op, &[NEW, LINT])),
        }
    }
}

wf_game_kit::export_plugin!(RoguelikeDevelop);
