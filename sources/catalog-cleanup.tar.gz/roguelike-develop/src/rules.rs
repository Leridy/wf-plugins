//! The roguelike rules. Each takes one script's text and returns its
//! diagnostics; spans are UTF-8 byte offsets into that text. The checks every
//! game shares (timers that run while paused among them) belong to game-develop.
use wf_game_kit::{
    Diagnostic, Severity,
    gdscript::{calls, closing_paren, code_only, functions, is_identifier_byte},
    lint::Source,
    span,
};

pub const GLOBAL_RANDOM_IGNORES_SEED: &str = "global-random-ignores-seed";
pub const UNRECORDED_RANDOM_SEED: &str = "unrecorded-random-seed";
pub const GROUP_SCAN_PER_FRAME: &str = "group-scan-per-frame";

/// Global functions that roll on Godot's one shared generator.
const GLOBAL_RANDOM: [&str; 5] = ["randi", "randf", "randi_range", "randf_range", "randfn"];
/// Array methods that roll on the shared generator; they take no generator.
const ARRAY_RANDOM: [&str; 2] = ["shuffle", "pick_random"];
/// A trailing comment that marks a roll as presentation only.
const COSMETIC: &str = "cosmetic";

/// What the rules know about the checked scripts as a whole.
#[derive(Clone, Copy, Debug, Default)]
pub struct Project {
    /// Some checked script uses a `RandomNumberGenerator`: the game seeds its
    /// own generators, so a roll on the shared one escapes the seed.
    pub seeded: bool,
}

impl Project {
    pub fn of(texts: &[&str]) -> Self {
        Self {
            seeded: texts
                .iter()
                .any(|text| code_only(text).contains("RandomNumberGenerator")),
        }
    }
}

/// Every rule over the checked scripts.
pub fn check(sources: &[Source]) -> Vec<Diagnostic> {
    let project = Project::of(&sources.iter().map(|s| s.text.as_str()).collect::<Vec<_>>());
    sources
        .iter()
        .flat_map(|source| script(&source.file, &source.text, project))
        .collect()
}

/// Rules for a GDScript file.
pub fn script(file: &str, text: &str, project: Project) -> Vec<Diagnostic> {
    let code = code_only(text);
    let mut diagnostics = Vec::new();
    if project.seeded {
        diagnostics.extend(global_random(file, text, &code));
    }
    diagnostics.extend(unrecorded_seeds(file, &code));
    diagnostics.extend(group_scans_per_frame(file, &code));
    diagnostics.sort_by_key(|d| d.span.map(|s| s.start));
    diagnostics
}

/// In a game that seeds its own generators, `randi()`, `randf_range()`,
/// `shuffle()` or `pick_random()` roll on Godot's shared generator instead:
/// that roll ignores the run seed, so the same seed stops giving the same
/// map, loot or enemy choice, and a saved game rolls differently after
/// loading. A line whose comment says `cosmetic` (screen shake, particles)
/// is left alone.
fn global_random(file: &str, text: &str, code: &str) -> Vec<Diagnostic> {
    let mut diagnostics = Vec::new();
    for (at, name, method) in
        calls(code, &GLOBAL_RANDOM, Some(false))
            .into_iter()
            .chain(calls(code, &ARRAY_RANDOM, Some(true)))
    {
        if line_of(text, at).contains('#') && comment_of(text, at).contains(COSMETIC) {
            continue;
        }
        let what = if method {
            format!("{name}() uses Godot's shared random generator")
        } else {
            format!("{name}() rolls on Godot's shared random generator")
        };
        diagnostics.push(Diagnostic {
            rule: GLOBAL_RANDOM_IGNORES_SEED.into(),
            severity: Severity::Warning,
            message: format!(
                "{what}, not the run's seeded RandomNumberGenerator, so this roll is not reproduced by the seed and \
                 is not restored from a save. Roll on the stream for this system (map, loot, combat); if it only \
                 changes how things look, add a `# cosmetic` comment on the line."
            ),
            file: file.into(),
            span: Some(span(at, at + name.len())),
            fix: None,
        });
    }
    diagnostics
}

/// `rng.randomize()` picks a seed nobody can see. Unless the script reads
/// `rng.seed` back (to show it, log it or save it), the run can never be
/// replayed, reported or shared. A generator declared in the same function
/// is a throwaway that picks a value for the caller to record, and is left
/// alone.
fn unrecorded_seeds(file: &str, code: &str) -> Vec<Diagnostic> {
    const CALL: &str = ".randomize";
    let mut diagnostics = Vec::new();
    for (at, _) in code.match_indices(CALL) {
        let end = at + CALL.len();
        let receiver = receiver_before(code, at);
        let rest = code[end..].trim_start();
        if receiver.is_empty() || !rest.starts_with('(') || !rest[1..].trim_start().starts_with(')') {
            continue;
        }
        if reads_seed(code, receiver) || declared_locally(code, at, receiver) {
            continue;
        }
        let open = code.len() - rest.len();
        let Some(close) = closing_paren(code, open) else {
            continue;
        };
        diagnostics.push(Diagnostic {
            rule: UNRECORDED_RANDOM_SEED.into(),
            severity: Severity::Warning,
            message: format!(
                "{receiver}.randomize() picks a seed that is never read back, so this run cannot be replayed, \
                 reported or shared. Pick the run seed once, show or save it, and seed each generator from it \
                 (for example hash([run_seed, floor])); or read {receiver}.seed after randomizing."
            ),
            file: file.into(),
            span: Some(span(at - receiver.len(), close + 1)),
            fix: None,
        });
    }
    diagnostics
}

/// Whether `name` is a `var` of the function holding `at`: a throwaway
/// generator that only picks a value (the run seed) the caller records.
fn declared_locally(code: &str, at: usize, name: &str) -> bool {
    let Some((start, end)) = functions(code)
        .into_iter()
        .find(|(start, end)| (*start..*end).contains(&at))
    else {
        return false;
    };
    let declaration = format!("var {name}");
    code[start..end].match_indices(&declaration).any(|(found, _)| {
        let after = code.as_bytes()[start + found + declaration.len()..].first();
        after.is_none_or(|&b| !is_identifier_byte(b))
    })
}

/// Whether `receiver.seed` appears other than as the target of `=`.
fn reads_seed(code: &str, receiver: &str) -> bool {
    let read = format!("{receiver}.seed");
    code.match_indices(&read).any(|(at, _)| {
        let after = &code[at + read.len()..];
        let whole_word = after.as_bytes().first().is_none_or(|&b| !is_identifier_byte(b));
        let assigned = after.trim_start().starts_with('=') && !after.trim_start().starts_with("==");
        whole_word && !assigned
    })
}

/// `get_nodes_in_group()` or `find_children()` in `_process` or
/// `_physics_process` walks every member each frame. Once per frame in one
/// manager is fine; once per enemy or bullet it is quadratic, the usual cause
/// of a horde game slowing down at a few hundred enemies.
fn group_scans_per_frame(file: &str, code: &str) -> Vec<Diagnostic> {
    let mut diagnostics = Vec::new();
    for (start, end) in functions(code) {
        let header = code[start..end].lines().next().unwrap_or_default();
        let per_frame = ["_process", "_physics_process"].iter().any(|name| {
            header
                .split_once("func")
                .is_some_and(|(_, rest)| rest.trim_start().starts_with(&format!("{name}(")))
        });
        if !per_frame {
            continue;
        }
        for (at, name, _) in calls(&code[start..end], &["get_nodes_in_group", "find_children"], Some(true)) {
            let at = start + at;
            diagnostics.push(Diagnostic {
                rule: GROUP_SCAN_PER_FRAME.into(),
                severity: Severity::Info,
                message: format!(
                    "{name}() runs every frame here. If every enemy or projectile does this, the cost grows with \
                     the square of their number; keep one list or a spatial grid updated once per frame and query \
                     that instead."
                ),
                file: file.into(),
                span: Some(span(at, at + name.len())),
                fix: None,
            });
        }
    }
    diagnostics
}

fn line_of(text: &str, at: usize) -> &str {
    let start = text[..at].rfind('\n').map_or(0, |n| n + 1);
    let end = text[at..].find('\n').map_or(text.len(), |n| at + n);
    &text[start..end]
}

/// The comment on the line holding `at`: what follows the first `#` that
/// `code_only` blanked as a comment start. Approximated by the last `#`.
fn comment_of(text: &str, at: usize) -> &str {
    let line = line_of(text, at);
    line.rfind('#').map_or("", |n| &line[n + 1..])
}

/// The expression a method is called on, such as `_rng` or `self.map.rng`,
/// ending just before `dot`.
fn receiver_before(text: &str, dot: usize) -> &str {
    let start = text[..dot]
        .bytes()
        .rposition(|b| !(is_identifier_byte(b) || b == b'.' || b == b'$'))
        .map_or(0, |i| i + 1);
    text[start..dot].trim_start_matches('.')
}

#[cfg(test)]
mod tests;
