use super::*;

const SEEDED: Project = Project { seeded: true };
const UNSEEDED: Project = Project { seeded: false };

fn rules(diagnostics: &[Diagnostic]) -> Vec<&str> {
    diagnostics.iter().map(|d| d.rule.as_str()).collect()
}

fn spanned<'a>(text: &'a str, diagnostic: &Diagnostic) -> &'a str {
    let span = diagnostic.span.unwrap();
    &text[span.start as usize..span.end as usize]
}

#[test]
fn global_rolls_are_reported_only_in_a_seeded_game() {
    let text = "func roll():\n\tvar a = randi_range(0, 3)\n\tvar b = rng.randi_range(0, 3)\n\
                \tdirections.shuffle()\n\tvar d = items.pick_random()\n\
                \tvar shake = randf() # cosmetic: camera shake\n\tprint(\"randi()\")\n\
                func randf_range(a, b):\n\tpass\n\tvar e = my_randi(2)\n";
    let diagnostics = script("loot.gd", text, SEEDED);
    assert_eq!(rules(&diagnostics), [GLOBAL_RANDOM_IGNORES_SEED; 3]);
    let named: Vec<&str> = diagnostics.iter().map(|d| spanned(text, d)).collect();
    assert_eq!(named, ["randi_range", "shuffle", "pick_random"]);
    assert!(script("loot.gd", text, UNSEEDED).is_empty());
}

#[test]
fn the_project_is_seeded_when_any_script_uses_a_generator() {
    assert!(Project::of(&["var x = 1", "var rng := RandomNumberGenerator.new()"]).seeded);
    assert!(
        !Project::of(&[
            "# RandomNumberGenerator in a comment",
            "var s = \"RandomNumberGenerator\""
        ])
        .seeded
    );
}

#[test]
fn a_randomized_seed_must_be_read_back() {
    let unread = "var _rng := RandomNumberGenerator.new()\nfunc _ready():\n\t_rng.randomize()\n\t_rng.seed = 4\n";
    let diagnostics = script("gen.gd", unread, UNSEEDED);
    assert_eq!(rules(&diagnostics), [UNRECORDED_RANDOM_SEED]);
    assert_eq!(spanned(unread, &diagnostics[0]), "_rng.randomize()");
    let read = "func start():\n\tpicker.randomize()\n\trun_seed = picker.seed\n";
    assert!(script("run.gd", read, UNSEEDED).is_empty());
    assert!(script("g.gd", "func f():\n\trandomize()\n", UNSEEDED).is_empty());
    let local = "func new_seed():\n\tvar picker := RandomNumberGenerator.new()\n\tpicker.randomize()\n\treturn picker.randi()\n";
    assert!(script("run.gd", local, UNSEEDED).is_empty());
}

#[test]
fn group_scans_count_only_in_per_frame_functions() {
    let text = "func _ready():\n\tvar all = get_tree().get_nodes_in_group(\"enemies\")\n\
                func _physics_process(delta):\n\tfor e in get_tree().get_nodes_in_group(\"enemies\"):\n\t\tpass\n\
                func _process(_d):\n\tvar n = find_children(\"*\")\n\tvar m = owner.find_children(\"*\")\n";
    let diagnostics = script("enemy.gd", text, UNSEEDED);
    assert_eq!(rules(&diagnostics), [GROUP_SCAN_PER_FRAME, GROUP_SCAN_PER_FRAME]);
    assert!(diagnostics.iter().all(|d| d.severity == Severity::Info));
}
