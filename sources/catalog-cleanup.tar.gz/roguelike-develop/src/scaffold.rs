//! `new`: one of three playable Godot 4 roguelike projects, from the
//! templates embedded at build time (`template/<name>`). The plugin only plans
//! the files; wf previews them and creates them.
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use wf_game_kit::{
    FileWrite,
    scaffold::{self, File, InputError, Templates},
};

static TEMPLATES: Templates = include!(concat!(env!("OUT_DIR"), "/templates.rs"));

const PROJECT_FILE: &str = "project.godot";

/// Which kind of roguelike to start from.
#[derive(Clone, Copy, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum Template {
    /// Turn-based grid dungeon: generated floors, field of view, bump
    /// combat, items, equipment, levels, stairs and permadeath with a save.
    Dungeon,
    /// Survivors-like horde: auto-firing weapons, a timed wave table,
    /// experience gems, a pick-one-of-three upgrade on each level, and
    /// optional persistent PowerUps.
    Survivors,
    /// Room-based action roguelite: generated floors of rooms, doors that
    /// lock until a room is cleared, treasure blessings, a boss per floor
    /// and embers that buy upgrades between runs.
    Rooms,
}

impl Template {
    pub const ALL: [Self; 3] = [Self::Dungeon, Self::Survivors, Self::Rooms];

    pub fn name(self) -> &'static str {
        match self {
            Self::Dungeon => "dungeon",
            Self::Survivors => "survivors",
            Self::Rooms => "rooms",
        }
    }

    /// The template's files: path inside the project directory, and bytes.
    pub fn files(self) -> &'static [File] {
        scaffold::template(TEMPLATES, self.name())
    }

    fn main_scene(self) -> &'static str {
        match self {
            Self::Dungeon => "res://src/Game/game_manager.tscn",
            Self::Survivors | Self::Rooms => "res://main.tscn",
        }
    }
}

/// Input of `new`.
#[derive(Debug, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct NewInput {
    /// Which roguelike to start from: `dungeon` (turn-based grid),
    /// `survivors` (horde with auto weapons) or `rooms` (room-based action).
    pub template: Template,
    /// Project-relative directory to create the Godot project in (default
    /// `roguelike-<template>`); it must not hold any of the template's files yet.
    #[serde(default)]
    pub dir: Option<String>,
    /// The game's name, written to project.godot (`config/name`).
    #[serde(default)]
    pub name: Option<String>,
}

/// Output of `new`.
#[derive(Debug, Serialize, JsonSchema)]
pub struct NewOutput {
    /// The template the project was made from.
    pub template: Template,
    /// The Godot project directory, project-relative.
    pub dir: String,
    /// Its project file: open it with Godot 4.
    pub project: String,
    /// The scene the game starts in.
    pub main_scene: String,
    /// The headless rule tests; run with `godot --headless --path <dir> <tests>`.
    pub tests: String,
    /// The balance bots; run the same way.
    pub bots: String,
    /// How many files are created.
    pub files: usize,
}

/// The template's files under the requested directory.
pub fn plan(input: &NewInput) -> Result<(NewOutput, Vec<FileWrite>), InputError> {
    let template = input.template;
    let requested = input
        .dir
        .clone()
        .unwrap_or_else(|| format!("roguelike-{}", template.name()));
    let dir = scaffold::directory(&requested)?;
    let name = input.name.as_deref().map(scaffold::game_name).transpose()?;
    let writes = scaffold::writes(&dir, template.files(), name.as_deref());
    let output = NewOutput {
        template,
        project: scaffold::join(&dir, PROJECT_FILE),
        main_scene: template.main_scene().into(),
        tests: "tests/run_tests.tscn".into(),
        bots: "tests/bots.tscn".into(),
        files: writes.len(),
        dir,
    };
    Ok((output, writes))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn input(template: Template, dir: Option<&str>, name: Option<&str>) -> NewInput {
        NewInput {
            template,
            dir: dir.map(str::to_owned),
            name: name.map(str::to_owned),
        }
    }

    #[test]
    fn every_template_is_a_godot_project_with_tests_and_without_hidden_files() {
        for template in Template::ALL {
            let paths: Vec<&str> = template.files().iter().map(|(path, _)| *path).collect();
            for required in [
                PROJECT_FILE,
                "LICENSE",
                "tests/run_tests.tscn",
                "tests/bots.tscn",
                "export_presets.cfg",
            ] {
                assert!(paths.contains(&required), "{template:?} lacks {required}");
            }
            assert!(paths.iter().all(|path| !path.split('/').any(|s| s.starts_with('.'))));
            let project = template.files().iter().find(|(p, _)| *p == PROJECT_FILE).unwrap().1;
            let text = String::from_utf8_lossy(project);
            assert!(text.contains("config/name="));
            let scene = template.main_scene().trim_start_matches("res://");
            assert!(paths.contains(&scene), "{template:?} lacks its main scene {scene}");
        }
    }

    #[test]
    fn files_go_under_the_directory_and_the_name_is_quoted() {
        let (output, writes) = plan(&input(Template::Rooms, Some("./games/rl/"), Some("Sky Keep"))).unwrap();
        assert_eq!(output.dir, "games/rl");
        assert_eq!(output.project, "games/rl/project.godot");
        assert_eq!(writes.len(), Template::Rooms.files().len());
        assert!(
            writes
                .iter()
                .all(|write| write.path.starts_with("games/rl/") && !write.overwrite)
        );
        let project = &writes
            .iter()
            .find(|w| w.path == "games/rl/project.godot")
            .unwrap()
            .bytes;
        let text = String::from_utf8_lossy(project);
        assert!(text.contains(r#"config/name="Sky Keep""#));
        assert_eq!(text.matches("config/name=").count(), 1);
        assert_eq!(
            plan(&input(Template::Dungeon, None, None)).unwrap().0.dir,
            "roguelike-dungeon"
        );
        assert_eq!(
            plan(&input(Template::Survivors, Some("."), None)).unwrap().0.project,
            "project.godot"
        );
    }

    #[test]
    fn unsafe_directories_and_names_are_refused() {
        for dir in ["/abs", "a/../b", ".hidden/rl", "a//b", "c:\\rl"] {
            let refused = plan(&input(Template::Dungeon, Some(dir), None)).err().map(|e| e.param);
            assert_eq!(refused, Some("dir"), "{dir}");
        }
        let refused = plan(&input(Template::Dungeon, None, Some("a\nb")))
            .err()
            .map(|e| e.param);
        assert_eq!(refused, Some("name"));
    }
}
