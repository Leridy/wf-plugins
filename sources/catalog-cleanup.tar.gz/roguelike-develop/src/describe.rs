//! What `describe()` returns: `new` and the `wf.lint/1` provider `lint`.
use crate::scaffold::{NewInput, NewOutput};
use schemars::{JsonSchema, schema_for};
use serde_json::Value;
use wf_game_kit::{
    Capability, Description, Example, LintInput, LintOutput, Risk, lint::LINT, protocol::PROTOCOL, scaffold::NEW,
};

pub fn description() -> Description {
    Description {
        capabilities: vec![
            Capability {
                op: NEW.into(),
                summary: "Create a playable Godot 4 roguelike project".into(),
                when: "Start a roguelike or roguelite, or get a working reference for one. --template dungeon is a \
                       turn-based grid dungeon (generated floors, field of view, items, levels, permadeath with a \
                       save); survivors is a horde game (auto weapons, a wave table, pick-one-of-three upgrades, optional \
                       persistent PowerUps); \
                       rooms is a room-based action roguelite (generated floors of rooms, locked doors, blessings, \
                       bosses, three permanent upgrade tracks). Every project has seeded runs, headless rule tests, balance \
                       bots and a Web export preset. It only creates files and refuses to replace any; read the \
                       roguelike-develop/guide skill before changing it."
                    .into(),
                risk: Risk::Write,
                input: schema::<NewInput>(),
                output: Some(schema::<NewOutput>()),
                examples: vec![
                    Example {
                        args: "new --template dungeon".into(),
                        note: "a turn-based dungeon in roguelike-dungeon/".into(),
                    },
                    Example {
                        args: "new --template survivors --dir games/horde --name Horde".into(),
                        note: "a horde game with its own directory and name".into(),
                    },
                    Example {
                        args: "new --template rooms".into(),
                        note: "a room-based action roguelite in roguelike-rooms/".into(),
                    },
                ],
                implements: None,
            },
            Capability {
                op: LINT.into(),
                summary: "Find roguelike pitfalls in GDScript".into(),
                when: "Check a Godot roguelike for rolls that escape the run seed (global randi, shuffle, \
                       pick_random in a game with its own RandomNumberGenerator), seeds that are randomized but \
                       never recorded, and per-frame group scans that grow quadratically with the horde. The \
                       checks every game needs (timers that run while paused, saves, export presets, cursors) are \
                       game-develop's lint. `wf lint` runs both with the other linters and `wf lint --fix` \
                       applies their fixes."
                    .into(),
                risk: Risk::Read,
                input: schema::<LintInput>(),
                output: Some(schema::<LintOutput>()),
                examples: vec![
                    Example {
                        args: "lint".into(),
                        note: "check every script".into(),
                    },
                    Example {
                        args: "lint --paths roguelike-dungeon".into(),
                        note: "check one Godot project".into(),
                    },
                ],
                implements: Some(PROTOCOL.into()),
            },
        ],
    }
}

fn schema<T: JsonSchema>() -> Value {
    schema_for!(T).into()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_description_round_trips_through_the_host_contract() {
        let text = serde_json::to_string(&description()).unwrap();
        let parsed: Description = serde_json::from_str(&text).unwrap();
        assert_eq!(parsed.protocols(), [PROTOCOL]);
        assert_eq!(parsed.capability(NEW).unwrap().risk, Risk::Write);
        let new = &parsed.capability(NEW).unwrap().input;
        assert_eq!(new["required"], serde_json::json!(["template"]));
        assert!(text.contains("\"survivors\""));
        assert!(text.len() < 64 << 10);
    }
}
