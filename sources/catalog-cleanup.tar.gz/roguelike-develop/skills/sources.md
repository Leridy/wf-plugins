# 来源与验证边界

整理日期：2026-11-06，2026-11-07、2026-11-12 补充。区分来源方法、源码发现和本插件实测。

## 模板来源

| 模板 | 来源 | 许可 |
| --- | --- | --- |
| `dungeon` | [SelinaDev/Godot-Roguelike-Tutorial](https://github.com/SelinaDev/Godot-Roguelike-Tutorial) 最终章 `part_13`，提交 `25cf7f70`（2024-10-07），181★；r/roguelikedev “Complete Roguelike Tutorial” 的 Godot 4 版 | 代码 MIT（模板内 `LICENSE`）；Kenney 1-Bit Pack 与 Kenney Fonts 为 CC0 |
| `survivors`、`rooms` | 本插件原创 | MIT（模板内 `LICENSE`）；美术为 Kenney 1-Bit Pack（CC0），去掉了黑底 |

候选中没有采用的：brannotaylor/SurvivorsClone_Complete（代码 CC0、104★），它的导入缓存里有一张来源可疑的图片（文件名署名他人的卡通形象），美术来源说不清，不能随插件分发；房间式没有成熟的开源 Godot 4 项目（GitHub 搜索到的大多是个位数星标的学习原型，或者使用原作美术）。

`dungeon` 相对原教程的改动：每层从局种子派生种子；战斗用独立的随机流，并随存档保存；迷惑 AI 不再用全局 `pick_random()`；死亡时删档，死后退出不存档，换层和关窗时自动存档；修正 `unregister_blocking_entity` 把路径权重设为 0 的问题；修正首帧没有地图时鼠标悬停检查报错；玩家改回 tcod 原教程的攻 2、防 1，药水从回 4 点改为回 10 点（理由见 `balance-and-runs`）；删除没有用到的 11 个字体和两份早期章节的脚本；加了测试、机器人和 Web 预设。

## 论文与第一手资料

| 来源 | 采用了什么 | 边界 |
| --- | --- | --- |
| van der Linden, Lopes, Bidarra，“Procedural Generation of Dungeons”，IEEE TCIAIG 6(1), 2014，DOI 10.1109/TCIAIG.2013.2290371 | 综述的结论：地牢生成缺的是可控性，而不是速度；因此先写出要保住的性质，再用测试守住 | 只读了摘要和他人的引用，没有逐节核对分类 |
| Smith, Whitehead，“Analyzing the Expressive Range of a Level Generator”，PCG Workshop 2010，DOI 10.1145/1814256.1814260 | 表现范围分析：多种子生成、用整图指标看分布（`dungeon` 机器人的 `range`） | 原文没有逐页读；做法依据后续论文的转述 |
| Boris the Brave，[Dungeon Generation in Binding of Isaac](https://www.boristhebrave.com/2020/09/12/dungeon-generation-in-binding-of-isaac/)（2020） | 9×8 网格、广度优先生长、拒绝会形成环的格子、按死胡同放 Boss 与特殊房、不合格就重画（`rooms` 的 `FloorPlan`） | 文章分析的是初代以撒；Rebirth 的细节（每层至少 5 个死胡同等）来自 wiki，模板只要求 3 个 |
| Joris Dormans，循环式地牢生成（《Unexplored》，ProcJam 2016 演讲；Boris the Brave 的 [Dungeon Generation in Unexplored](https://www.boristhebrave.com/2021/04/10/dungeon-generation-in-unexplored/)） | 用回路代替分支，来获得节奏；写进了 `generation` 的选型表 | 模板没有实现 |
| Derek Yu《Spelunky》，Game Maker's Toolkit “How and Why Spelunky Makes its Own Levels” 与 [Tiny Subversions 的生成器拆解](https://tinysubversions.com/spelunkyGen/) | 先生成关键路径，再用模板房间填充 | 来自转述，不是书原文 |
| Brian Walker（Pender），[The Incredible Power of Dijkstra Maps](https://roguebasin.com/index.php/Dijkstra)（RogueBasin，2010） | 一张距离图可以供所有怪物共用，并能叠加多个目标 | 模板的怪物仍用 AStarGrid2D，没有改成距离图 |
| Albert Ford，[Symmetric Shadowcasting](https://www.albertford.com/shadowcasting/)（2021） | 对称的视野可以避免“我看得见它、它看不见我”；地面看中心、墙看任意部分的判定规则，以及对称性测试（写进 `generation`） | `dungeon` 用的是原教程的递归阴影投射，没有换成对称版本；这是已知的差异 |
| [gamedev-skills/awesome-gamedev-agent-skills](https://github.com/gamedev-skills/awesome-gamedev-agent-skills)（Apache-2.0）固定提交 `19d93f9`：`genres/roguelike` 及其 `generation-fov-loot.md`、`godot/godot-gdscript-headless-testing`、`disciplines/save-systems` | 元胞自动机要双缓冲、能量制调度的饿死问题、掉落表的权重与独立掷骰、读档即作废的严格永久死亡、存档保留 `.bak`；检查函数报运行时错误后测试仍判通过（本插件在 Godot 4.7.1 上复现后，用 `tests/script_errors.gd` 修正） | 只借鉴思路，中文重写，没有复制原文；Windows 上改名会先删目标这一点来自 `save-systems`，没有在 Windows 上验证 |
| r/roguelikedev FAQ Friday [#11 随机数](https://www.reddit.com/r/roguelikedev/comments/33nscp/faq_friday_11_random_number_generation/)、[#53 种子](https://www.reddit.com/r/roguelikedev/comments/5haqeo/faq_friday_53_seeds/)（Cogmind 作者 Kyzrati 等） | 多条专用随机流、每层单独的种子、表现用随机与状态随机分开 | 2015～2016 年的讨论 |
| Berlin Interpretation（2008 年国际 Roguelike 开发会议） | 用来区分 roguelike 与 roguelite：随机生成、永久死亡、回合制等高价值因素 | 社区对它作为标准有争议，只用来术语对齐 |
| Anthony Giovannetti，“Slay the Spire: Metrics Driven Design and Balance”（GDC 2019） | 用数据检验平衡假设；开发期用机器人代替玩家数据 | GDC Vault 需要登录，依据的是会议介绍和报道 |
| Greg Kasavin 关于《Hades》叙事与死亡循环的访谈（GDC Podcast ep.16、Game Developer） | 局外成长与剧情让死亡也成为进度 | 没有找到 Mirror of Night 的第一手设计资料 |
| Vampire Survivors 社区 wiki（Enemies 页） | 每分钟一波、每波有最少数量和刷怪间隔、在屏幕外刷出、同屏约 300 上限 | 非官方，数值来自数据挖掘 |

## 本插件实测（Godot 4.7.1，macOS）

- 三个模板在 Godot 4.7.1 下无头导入零报错，窗口模式截图检查了画面。
- 规则测试：`dungeon` 18 项、`survivors` 82 项、`rooms` 42 项，全部通过；三个模板的测试和机器人都会把运行时脚本错误算作失败（同样的接法在 rpg-develop 的 `jrpg` 和 tower-develop 模板的临时副本里故意制造错误验证过，本插件的模板没有单独再做）。反向验证：在 tower-develop 的同类测试里，把出怪计时改回不传 `false`、把敌人改成循环，测试都能报错；本插件的测试没有逐项做这种反向验证。
- 机器人结果见 `balance-and-runs`；都是无头运行的统计，不代表真人体验。
- 没有覆盖：真人试玩、手柄、触屏、浏览器里实际打开 Web 导出、Windows 实机、大规模性能（幸存者模板只验证到同屏 300 个敌人以内能跑完，没有测帧时）。

## 0.5.0 跨局成长验证（2026-11-12）

| 同策略档位 | rooms 通关 / 平均余烬 | survivors 通关 / 平均金币 |
| --- | --- | --- |
| 零强化 | 4/8 / 31.6 | 6/6 / 203.5 |
| 各条 1 级 | 5/8 / 34.6 | 6/6 / 201.5 |
| 各条 3 级 | 7/8 / 38.2 | 6/6 / 217.5 |

房间种子 1–8，幸存者种子 1–6；战斗／走位决策间隔均 0.25 秒。收入不是随强化严格单调：击杀时机改变后，拾取、路线和升级顺序也会改变。房间仍符合满级有帮助但保留失败的示例目标；幸存者基线对该策略已经容易通关，三档同胜率不能证明难度分层完成。

新增测试覆盖购买存档重载、余额不足、满级、独立强化轨道、开局属性冻结、永久与局内倍率叠加、关闭成长、重复结算、保存失败回滚与重试、截断／缺字段主档回退、恢复后保护备份；房间还覆盖旧单生命等级存档迁移。原生 640×360 窗口自动操作检查了大厅入口、购买、返回、开局属性、战斗隐藏入口、结算入口与重开加载，截图核对了文字边界。这不是手工通关或真人多局试玩。

成长实现是本插件的原创示例；《王座防线》的落地经验用于提炼约束，没有复制其专属数值或美术。尚未做云端账户、多设备冲突、断电恢复或浏览器存储持久性验证。
