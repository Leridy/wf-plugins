# Roguelike 开发与调优

用于开发或优化 roguelike／roguelite：回合制格子地牢、幸存者式割草（自动攻击＋怪潮＋升级三选一）、房间式动作肉鸽（以撒、哈迪斯一类），以及它们共有的随机种子、程序生成、奖励选择、永久死亡与局外成长。不用于没有随机内容和单局循环的普通动作或 RPG。

**做成自己的游戏之前，先读 `wf skill show roguelike-develop/assets`**：按画面列出要向平台要的角色、怪物、道具、界面和文字，用 `wf agent send` 一次要齐，再用官方插件 `godot-export` 接进 Godot。模板自带的美术和界面只是占位；不要自己拼界面、用系统字体写标题，也不要自己写脚本裁帧动画。

跨局成长与数值系统先读 `wf skill show roguelike-develop/progression`：局内与局外分层、购买和存档、开局快照、全局入口、经济与零／中／满强化验收。

## 插件命令

| 命令 | 做什么 |
| --- | --- |
| `wf roguelike-develop new --template dungeon\|survivors\|rooms [--dir 目录] [--name 名字]` | 生成可运行的 Godot 4 工程（默认目录 `roguelike-<模板>`）。只新建文件，目录里已有同名文件时整体不写。先加 `--dry-run` 给用户看文件清单 |
| `wf roguelike-develop lint [--paths 路径]` | 查 `.gd` 里破坏 roguelike 的写法；`wf lint` 会把它和其他 linter 一起跑，`wf lint --fix --dry-run` 预览修复 |

三个模板怎么选：

| 模板 | 玩法 | 来源 |
| --- | --- | --- |
| `dungeon` | 回合制、80×45 格地牢、阴影投射视野、碰撞即攻击、药水与卷轴、装备、升级三选一、楼梯、存档与永久死亡 | SelinaDev《Yet Another Roguelike Tutorial》（MIT，r/roguelikedev 年度教程的 Godot 4 版）改编 |
| `survivors` | 移动躲避、武器自动开火、5 分钟波次表、经验宝石、升级三选一、Boss、同屏上限 300、可关闭的 PowerUps | 原创（MIT），做法参考 Vampire Survivors 社区资料与本团队《加班求生》 |
| `rooms` | 双摇杆射击、9×8 网格生成的楼层、进房锁门清房开门、宝藏房二选一、每层 Boss、余烬购买生命／伤害／攻击间隔三条强化 | 原创（MIT），楼层生成按 Boris the Brave 对以撒的分析 |

lint 规则（可在 `wf-plugins.toml` 的 `[lint.rules]` 里改级别或关掉）：

- `roguelike-develop/global-random-ignores-seed`（warning）：项目里有脚本用了 `RandomNumberGenerator`，另一处却调用全局 `randi()`、`randf_range()`，或数组的 `shuffle()`、`pick_random()`。这些用的是 Godot 共享的生成器，种子复现不了、存档也恢复不了。改成该系统自己的随机流；只影响表现的（震屏、粒子）在行尾写 `# cosmetic` 注释即可。
- `roguelike-develop/unrecorded-random-seed`（warning）：`rng.randomize()` 之后脚本从未读取 `rng.seed`，这一局无法重放、反馈或分享。改为每局只选一次种子，显示并存下来。
- `roguelike-develop/group-scan-per-frame`（info）：`_process`/`_physics_process` 里调用 `get_nodes_in_group()` 或 `find_children()`。如果每个敌人或子弹都这样做，开销随数量平方增长，改用每帧更新一次的列表或空间网格。

所有游戏都会犯的错（暂停时照走的计时器、存档能执行代码、共享 Resource 被改、导出预设、鼠标指针）由 `game-develop` 的 lint 检查，和本插件一起装（`wf plugin install game-develop --save`），规则说明见 `wf skill show game-develop/guide`。

## 生成的工程

每个工程都有：

- **种子**：每局一个种子，显示在界面上；启动加 `-- --seed=N` 重放（`godot --path <目录> -- --seed=123`）。各系统使用各自的随机流，例如 `dungeon` 用 `hash([run_seed, 楼层, "map"])`，`survivors`/`rooms` 用 `RunRng.stream("spawn")` 这类按名字区分的流。
- **规则测试** `tests/run_tests.tscn`：末行打印 `TESTS: PASS`，退出码为 0 或 1。
- **平衡机器人** `tests/bots.tscn`：末行打印 `BOTS: PASS`，期望写在脚本开头。
- **Web 导出预设**：不开多线程，`tests/` 和 `build/` 不进包。不排除 `build/` 的话，导出到工程内的上一次产物会被导入，并打进下一次的包里。

```sh
godot --headless --path <目录> --editor --import --quit                 # 新克隆后先导入一次
godot --headless --fixed-fps 60 --path <目录> tests/run_tests.tscn       # 规则测试
godot --headless --fixed-fps 60 --path <目录> tests/bots.tscn            # 机器人，可加 -- <策略名>
```

测试用场景运行，而不是 `-s`：`-s` 不加载 autoload，`dungeon` 的 `SignalBus` 会找不到。`--fixed-fps 60` 去掉实时同步，五分钟的一局几十秒就能跑完。

| 模板 | 改动入口 |
| --- | --- |
| `dungeon` | 生成与掉落表 `src/Map/dungeon_generator.gd`；怪物与物品数值 `assets/definitions/`；回合循环 `src/Game/game.gd`；存档与永久死亡 `src/Map/map_data.gd`、`escape_action.gd` |
| `survivors` | 全部数值 `data/content.gd`（时长、波次表、敌人、升级）；模拟 `scripts/world.gd`；局外成长 `scripts/meta.gd`；界面 `scripts/main.gd`、`scripts/power_up_menu.gd` |
| `rooms` | 全部数值 `data/content.gd`（楼层、敌人、房间布局、祝福、局外成长）；楼层生成 `scripts/floor_plan.gd`；一局 `scripts/room_game.gd`；局外存档 `scripts/meta.gd`、强化界面 `scripts/power_up_menu.gd` |

改完依次跑 `wf roguelike-develop lint --paths <目录>`、规则测试、机器人，最后在 Godot 里实际玩一局：开局 → 战斗 → 奖励选择 → 下一层或下一波 → 死亡或胜利 → 重开，并核对重开后种子会变、局外成长保留。

## 方法

### 先定一局的形状

1. 先确定单局多长、怎样结束、死后保留什么。死亡就是结束的就是 roguelike；带局外成长的是 roguelite。不要两边都做一半。
2. 用最小闭环先跑通：开局 → 遭遇 → 奖励 → 推进 → 结束 → 重开。可以先用一种敌人、一种奖励，再扩内容。
3. 先建种子与随机流，再写生成器。后补种子要改遍所有随机调用，而且旧存档恢复不了。

### 容易把 roguelike 做坏的边界

| 系统 | 规则 | 必验情况 |
| --- | --- | --- |
| 种子 | 每局一个种子；每个系统、每层、每个房间各用一条从种子派生的流；表现用的随机可以用全局生成器 | 同种子同层地图一致；先玩第一层再生成第三层，与直接生成第三层一致；读档后下一层不变 |
| 程序生成 | 生成后校验，不合格就重画并设上限：可达、出口与起点不重合、数量在范围内；记录重画次数 | 几百个种子统计最差情况，不只看一张图（见 `roguelike-develop/generation`） |
| 永久死亡 | 死亡时删档；死后退出不能把死档写回；退出、关窗、换层时自动存档 | 死后按 Esc、死后直接关窗、读档后马上死 |
| 回合调度 | 速度不同就用能量制：每轮先让已攒够能量的角色行动；没有人够，再给所有角色一起加能量 | 把加能量和找行动者写在同一个循环里，排在后面的角色会永远轮不到；两个同速角色要交替行动（`dungeon` 是玩家走一步、所有怪物再走一步的固定轮替，没有速度属性） |
| 奖励选择 | 选项互不重复，不出满级项，没得选时有兜底；选择期间暂停，计时器传 `false` | 全部满级、连续升级、选择界面打开时被怪碰到 |
| 结算 | 击杀、清房、拾取、局外货币都只结算一次 | 同帧两次命中、离开后再进房、结束函数被调用两次 |
| 局外成长 | 让后续局更顺，但不能把一局变成走过场；单独存档，与本局存档分开 | 同种子同策略下比较零／中／满强化，胜率、容错和收入符合事先约定的目标 |

### 交付标准

测试和机器人里的某个检查函数一旦报运行时错误（例如对 null 调方法），Godot 只会中止这一个函数，后面的检查照常跑完，最后仍然打印 PASS。模板的 `tests/script_errors.gd` 会统计这类 `SCRIPT ERROR`，有一次就判失败。自己写新的测试入口时也要把它接上。


交付可运行入口、种子怎样复现、数值表位置、已完成与缺失的模块，以及“规则测试通过＋机器人结果表＋真人玩过一局”的证据。改平衡时附同样种子下的前后机器人结果。三种证据分开记录；没跑的写明未测。难度与机器人方法见 `roguelike-develop/balance-and-runs`。
