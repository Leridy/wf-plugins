class_name MainMenu
extends Control

signal game_requested(load)

@onready var first_button: Button = $"%NewButton"
@onready var load_button: Button = $"%LoadButton"


func _ready():
	first_button.grab_focus()
	load_button.disabled = not MapData.has_save()
	load_button.mouse_default_cursor_shape = Control.CURSOR_FORBIDDEN if load_button.disabled else Control.CURSOR_POINTING_HAND


func _on_new_button_pressed():
	game_requested.emit(false)


func _on_load_button_pressed():
	game_requested.emit(true)


func _on_quit_button_pressed():
	get_tree().quit()
