class_name EscapeAction
extends Action


func perform() -> bool:
	#entity.get_tree().quit()
	# A dead player's run is over: its save was deleted and must not come back.
	if entity.is_alive():
		entity.map_data.save()
	SignalBus.escape_requested.emit()
	return false
