# 回合制地牢（roguelike-develop/dungeon）

> **素材**：模板自带的美术和界面只是占位。做成自己的游戏前，先读 `wf skill show roguelike-develop/assets`：按画面向平台要 UI 组件、艺术字、图标和帧动画，用官方插件 `godot-export` 接进来，不要自己拼界面、用系统字体写标题。

改编自 [SelinaDev/Godot-Roguelike-Tutorial](https://github.com/SelinaDev/Godot-Roguelike-Tutorial) `25cf7f70` 的最终章 `part_13`（MIT，见 `LICENSE`），美术与字体为 Kenney CC0。Godot 4.7.1，入口 `src/Game/game_manager.tscn`。

## 操作

方向键、小键盘或 vi 键（hjkl yubn）移动，撞上怪物即攻击；`.` 或小键盘 5 原地等待；G 拾取，I 使用，D 丢弃，V 查看消息记录，`/` 或 S 查看，`<` 下楼，Esc 存档并回主菜单。

## 改动入口

| 要改什么 | 入口 |
| --- | --- |
| 楼层生成、怪物与物品表 | `src/Map/dungeon_generator.gd` |
| 怪物、物品、玩家数值 | `assets/definitions/entities/` |
| 回合循环、种子、开局 | `src/Game/game.gd` |
| 存档、永久死亡、随机流状态 | `src/Map/map_data.gd`、`src/Entities/Actors/Actions/escape_action.gd` |
| 视野 | `src/Map/field_of_view.gd`（递归阴影投射，非对称） |

## 相对原教程的改动

- 每层种子为 `hash([run_seed, 层, "map"])`，与前面几层掷了几次骰子无关；战斗另用一条流（`MapData.combat_rng`），状态随存档保存；迷惑 AI 不再用全局 `pick_random()`。
- 开局在消息里显示种子；`godot --path . -- --seed=N` 可以重放。
- 永久死亡：死亡时删档，死后退出不再存档；换层和关窗时自动存档。原版死后按 Esc 会把尸体存进去，死后直接关窗则保留着上一次的存档。
- 修正 `unregister_blocking_entity` 把路径权重设为 0、首帧没有地图时鼠标悬停检查报错。
- 平衡：玩家攻 2、防 1（python tcod 原教程的值，原版为 5／2，兽人打不动初始玩家），药水回 10 点（原为 4）。理由见插件技能 `roguelike-develop/balance-and-runs`。
- 删除没有用到的字体和早期章节的脚本；加了 `tests/`、Web 导出预设。

## 测试与机器人

```sh
godot --headless --path . --editor --import --quit
godot --headless --path . tests/run_tests.tscn              # 18 项，末行 TESTS: PASS
godot --headless --path . tests/bots.tscn                   # 末行 BOTS: PASS；-- range / diver / fighter
```

规则测试：同种子同层生成相同；楼层之间互不影响；40 个种子 × 4 层里楼梯都可达、地面全部连通、实体不重叠也不在墙里、楼梯不在起点；存档往返保留种子、随机流和楼梯，读档后下一层不变；死亡删档，死后退出不存档。

机器人：`range` 统计 100 个种子 × 6 层的生成指标；`diver` 只冲楼梯，`fighter` 打怪、喝药、换装。当前：diver 中位数第 4 层，fighter 12 个种子里 10 个到达第 10 层。
