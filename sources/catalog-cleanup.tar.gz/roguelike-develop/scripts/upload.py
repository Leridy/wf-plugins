#!/usr/bin/env python3
"""Upload dist/site to the `ugc` plugin index with the script every game
plugin shares (game-develop/kit/scripts/upload.py, checked out beside this
repository); its docstring lists the settings.

Usage: scripts/upload.py [--env-file PATH] [SITE_DIR]
"""
import os
import sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
shared = root.parent / "game-develop" / "kit" / "scripts" / "upload.py"
os.chdir(root)
os.execv(sys.executable, [sys.executable, "-I", str(shared), *sys.argv[1:]])
