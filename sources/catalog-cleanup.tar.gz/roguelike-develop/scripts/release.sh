#!/bin/sh
# Build, pack and sign this plugin, and add it to the `ugc` plugin index, with
# the script every game plugin shares (game-develop/kit/scripts/release.sh,
# checked out beside this repository). Its header lists the settings:
#
#   WF_INDEX_URL=https://<host>/<dir>/index.json \
#   WF_INDEX_KEY=~/.config/wf-plugins/996-ugc-index.pem \
#   PLUGIN_PUBLISH=~/workspace/weaveForge/target/debug/plugin-publish \
#   scripts/release.sh
set -eu
here=$(cd "$(dirname "$0")/.." && pwd)
exec "$here/../game-develop/kit/scripts/release.sh" "$here"
