# roguelike-develop

Roguelike／roguelite 开发用的 `wf` 插件（WebAssembly 组件，`wf:plugin@0.1.3`）。

| 命令 | 风险 | 做什么 |
| --- | --- | --- |
| `wf roguelike-develop new --template dungeon\|survivors\|rooms [--dir 目录] [--name 名字]` | write | 生成可运行的 Godot 4 工程：回合制格子地牢、幸存者式割草、房间式动作肉鸽三选一；每个都带种子复现、规则测试、平衡机器人和 Web 导出预设 |
| `wf roguelike-develop lint [--paths 路径]` | read | 实现 `wf.lint/1`，检查 `.gd` 里破坏 roguelike 的写法；`wf lint` 会一起运行 |
| `wf skill show roguelike-develop/guide` | read | 开发与调优方法、三个模板的改动入口 |
| `wf skill show roguelike-develop/assets` | read | 按画面列出要向平台要的 UI 组件、艺术字、图标、动画或模型、地图和声音，`wf agent send` 需求怎么写，怎么用官方 `godot-export` 接进 Godot |
| `wf skill show roguelike-develop/generation` | read | 种子与随机流、生成器选型、生成后校验、表现范围分析 |
| `wf skill show roguelike-develop/balance-and-runs` | read | 机器人定难度、奖励选择、永久死亡与局外成长 |
| `wf skill show roguelike-develop/progression` | read | 局内升级与跨局成长、价格与奖励、存档迁移、全局入口、零／中／满强化验收 |
| `wf skill show roguelike-develop/sources` | read | 模板、论文与资料来源，验证边界 |

## 安装

插件发布在 996-ugc 自建的 `ugc` 插件索引里（与 `tower-develop` 同一个）。每台机器登记一次：

```sh
wf plugin source add ugc https://ai996cs-1329868075.cos.ap-shanghai.myqcloud.com/wf-plugins/ugc/index.json
```

第一次运行会以退出码 10 停下并显示签名者，核对指纹是 `144ce7f6a9b0554a` 后加 `--yes` 重跑。在游戏项目根目录：

```sh
wf plugin install roguelike-develop --save
wf plugin install game-develop --save     # 所有游戏共有的检查：暂停计时、存档、共享 Resource、导出预设、鼠标指针
```

确认显示的版本、签名者和读取权限（`**/*.gd`）后加 `--yes` 重跑，然后把 `wf-plugins.toml` 和 `wf-plugins.lock`
提交到游戏仓库。授权按项目记录：在另一个项目里第一次运行会以 `PLUGIN_UNTRUSTED` 停下，核对后运行
`wf plugin trust roguelike-develop --yes`。

```sh
wf roguelike-develop new --template survivors --dry-run                # 先看要建哪些文件
wf roguelike-develop new --template survivors --name 我的肉鸽
godot --editor --path roguelike-survivors                               # Godot 4.7.1，F5 运行
godot --headless --path roguelike-survivors --editor --import --quit    # 跑测试前导入一次
godot --headless --fixed-fps 60 --path roguelike-survivors tests/run_tests.tscn
godot --headless --fixed-fps 60 --path roguelike-survivors tests/bots.tscn
wf lint roguelike-survivors
```

## 模板

| 模板 | 操作 | 内容 | 机器人（当前） |
| --- | --- | --- | --- |
| `dungeon` | 方向键／vi 键移动与攻击，G 拾取，I 使用，D 丢弃，`<` 下楼，Esc 存档退出 | 改编自 SelinaDev 的 MIT 教程：生成楼层、视野、药水与卷轴、装备、升级、楼梯、存档；加了逐层种子、战斗随机流、永久死亡修复 | 冲楼梯中位数第 4 层；认真打的 12 个种子里 10 个到达第 10 层 |
| `survivors` | WASD／方向键移动，P 暂停，R 开始／重开，大厅与结算页右上角 PowerUps（U） | 原创：5 分钟波次表、自动武器（法杖、环绕刃、新星）、被动、经验宝石、升级三选一、Boss、同屏上限 300；可关闭的三条跨局强化 | 站着不动约 40 秒死亡；走位同策略零／中／满强化均 6/6，仍是易通关的演示基线 |
| `rooms` | WASD 移动，方向键射击，R 开始／重开，大厅与结算页右上角 PowerUps（U） | 原创：以撒式楼层生成、进房锁门、宝藏房二选一、3 层各一个 Boss、余烬购买生命／伤害／攻击间隔三条强化 | 直奔 Boss 3/8；清图零／中／满强化分别 4/8、5/8、7/8 |

每局的种子显示在界面上，`godot --path <目录> -- --seed=N` 可以重放这一局。

0.5.0 新增成长专题及可运行闭环：购买保存 → 新局属性快照 → 胜败结算 → 回大厅。`META_ENABLED` 可关闭跨局成长；旧房间模板的余烬和生命等级自动迁移。价格、加成、奖励都在各模板 `data/content.gd`，没有复制《王座防线》的棋子专属参数。

## lint 规则

| 规则 | 发现什么 | 自动修复 |
| --- | --- | --- |
| `global-random-ignores-seed` | 项目用了 `RandomNumberGenerator`，却还有全局 `randi()`／`randf_range()` 或 `shuffle()`／`pick_random()`：这次掷骰不跟种子走，存档也恢复不了。行尾写 `# cosmetic` 表示只影响表现 | 无 |
| `unrecorded-random-seed` | `rng.randomize()` 之后从未读取 `rng.seed`：这一局无法重放或分享 | 无 |
| `group-scan-per-frame`（info） | `_process`/`_physics_process` 里调用 `get_nodes_in_group()`／`find_children()`：如果每个敌人都这样做，开销随数量平方增长 | 无 |

可在 `wf-plugins.toml` 的 `[lint.rules]` 调整，例如 `"roguelike-develop/group-scan-per-frame" = "off"`。
lint 只申请读取 `**/*.gd`；`new` 不读文件，只返回新建文件的副作用，由 `wf` 预览后写入，已有同名文件时整体拒绝。
用它检查原版 SelinaDev 教程，会报出生成器里的 `_rng.randomize()` 和迷惑 AI 里的 `pick_random()`。

所有游戏都会犯的错（暂停时照走的计时器、存档能执行代码、共享 Resource 被改、导出预设、鼠标指针）由 `game-develop` 检查，和本插件一起装；0.4.0 起本插件不再重复检查它们，原来写在 `wf-plugins.toml` 里的 `roguelike-develop/…` 级别设置改写成 `game-develop/…`。

## 开发

插件代码建在 `wf-game-kit` 上（`game-develop` 仓库的 `kit/`，路径依赖 `../game-develop/kit`），先把 `game-develop` 克隆到本仓库旁边。

```sh
cargo build --release --target wasm32-wasip2   # rust-toolchain.toml 会装好目标
cargo test                                     # 规则与模板规划在宿主上测试
wf plugin test .                               # 校验清单、描述，并 dry-run 每个示例
wf plugin link .                               # 列出读取权限后退出码 10，确认后加 --yes
```

改模板后，在模板的 `files/` 目录副本里跑一遍规则测试和机器人（命令同上），再重新构建插件；`build.rs` 会把
各模板 `files/` 下除隐藏文件（`.godot/` 导入缓存）以外的所有文件嵌进组件。

本地开发版本：0.5.0（尚未发布到插件索引）。

## 发布新版本

与 `tower-develop` 共用 `ugc` 索引、签名私钥和脚本，步骤见 tower-develop 的 README：

```sh
WF_INDEX_URL=https://ai996cs-1329868075.cos.ap-shanghai.myqcloud.com/wf-plugins/ugc/index.json \
WF_INDEX_KEY=~/.config/wf-plugins/996-ugc-index.pem \
scripts/release.sh                                        # 构建、测试、打包、签名，追加到线上索引
scripts/upload.py --env-file <部署仓库>/config/dev.env      # 公开读上传到公司 COS 的 wf-plugins/ugc/
```

已发布：0.1.0（2026-11-06）；0.2.0（2026-11-07，测试把脚本错误算作失败、地牢与局外成长存档保留 `.bak`、技能补视野、洞穴、掉落表、回合调度与防反复读档）；0.2.1（2026-11-07，Web 导出预设排除 `build/*`，重复导出不再把上次的产物打进包）；0.3.0（2026-11-08，素材清单 `roguelike-develop/assets`）；0.3.1（2026-11-08，按插件接口 0.1.3 构建，当前客户端才装得上）；0.3.2（2026-11-08，瓦片地图经 `godot-export` 的 TileSet 和场景接入）。同一版本号发布后不能再改；权限或行为有变就升次版本号，发布后更新这里和 tower-develop README 的“已发布”；0.4.0（2026-11-09，建在 `game-develop` 的 `wf-game-kit` 上；所有游戏共有的检查移到 `game-develop`；可点控件配好鼠标指针）。

## 目录

```text
wf-plugin.toml                 清单：权限与技能页
src/lib.rs                     插件：new 与 lint，经 wf-game-kit 导出为组件
src/describe.rs                两个能力的描述
src/scaffold.rs                new：模板 → 新建文件计划
src/rules.rs, src/rules/       lint：先读全部脚本判断是否自带种子，再跑三条规则
template/dungeon|survivors|rooms/
                               new 写出的工程，build.rs 编译时嵌入；各自带 WEAVEFORGE.md
skills/                        技能页
scripts/                       发布脚本：调用 game-develop/kit/scripts 里的共用脚本
```

协议、lint 驱动、GDScript 扫描、WIT 胶水和宿主契约都在 `wf-game-kit` 里，本仓库不再有副本。

## 来源与许可

- `template/dungeon/`：[SelinaDev/Godot-Roguelike-Tutorial](https://github.com/SelinaDev/Godot-Roguelike-Tutorial) `25cf7f70` 的 `part_13`，MIT（模板内 `LICENSE`）；Kenney 1-Bit Pack 与 Kenney Fonts 为 CC0。
- `template/survivors/`、`template/rooms/`：原创，MIT；美术是 Kenney 1-Bit Pack（CC0），去掉了黑底。
- `skills/`：原创；论文与资料出处见 `skills/sources.md`。

## Unified template entry

Install this plugin, then open **Plugins → Templates**. Each project template appears
with the other game templates and uses the shared directory selection and preview flow.
The existing `new` and `lint` commands remain compatible. Template project files now live
under `template/<name>/files/`; `template.toml` describes the entry shown by the client.
Both the native CLI scaffolder and the data contribution use this same file tree.
No engine process runs while creating these templates; open the generated project in Godot.
