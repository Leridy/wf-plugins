# gdscript

The official `wf` plugin that lints GDScript style and quality, in the manner
of ESLint and of gdtoolkit's `gdlint`. It implements the `wf.lint/1` protocol,
so `wf lint` runs it with every other linter, and `wf gdscript lint` runs it
alone. The specification is
[`docs/plans/2026-11/gdscript-linter.md`](https://gitlab.xqhuyu.cn/996-ugc/weaveforge/-/blob/main/docs/plans/2026-11/gdscript-linter.md).

## What it checks

Every `.gd` file in the project (narrowed by the paths given to `wf lint`, e.g. `wf lint scripts/`), with or without a
`project.godot`; scripts embedded in `.tscn` files are not checked. The
plugin is conservative: when a construct is ambiguous it reports nothing.

| Rule | Level | When | Fix |
| --- | --- | --- | --- |
| `trailing-whitespace` | warning | A line ends with spaces or tabs (the inside of a multi-line string is data, not counted). | remove it |
| `max-line-length` | warning | A line is wider than `max-line-length` (default 100; a tab counts `tab-width`, default 4; characters, not bytes). | none |
| `max-file-lines` | warning | The file has more than `max-file-lines` lines (default 1000); reported on the first line over. | none |
| `mixed-indentation` | error | A line is indented with tabs and spaces, or with the other character than the file's first indentation: Godot refuses both. | none |
| `class-name`, `sub-class-name`, `enum-name` | warning | The `class_name`, an inner `class` or a named `enum` is not PascalCase. | none |
| `function-name`, `signal-name` | warning | Not snake_case (leading `_` allowed). | none |
| `class-variable-name`, `function-variable-name`, `function-argument-name`, `loop-variable-name` | warning | Not snake_case. Variables of a class body are class variables, the others function variables; lambda parameters are not judged. | none |
| `constant-name`, `enum-element-name` | warning | Not CONSTANT_CASE. A `const` whose value is a `preload(...)` or `load(...)` call may be PascalCase. | none |
| `unnecessary-pass` | warning | A block holds `pass` and other statements. | delete the line, when it holds only the `pass` and a comment |
| `duplicated-load` | warning | The same literal path is passed to `load` or `preload` more than once in a file; every one after the first is reported (method calls such as `ResourceLoader.load` are not). | none |
| `unused-argument` | warning | A function argument is not an identifier anywhere in the function's body (nested lambdas included); a name that starts with `_` is not judged. | rename it `_name`, unless that name is taken |
| `function-arguments-number` | warning | A function has more than `function-arguments-number` arguments (default 10). | none |
| `max-returns` | warning | A function has more than `max-returns` `return` statements (default 6; those of nested lambdas do not count). | none |
| `max-public-methods` | warning | A class (the script, and each inner class separately) has more than `max-public-methods` methods that do not start with `_` (default 20); reported on the `class_name`/`extends` line, or on the inner class's name. | none |
| `invalid-config` | error | A `gdscript-lint.toml` does not parse or has an unknown key or value; the default options apply below it. | none |

Snake case is `_*[a-z0-9]+(_[a-z0-9]+)*`, PascalCase `_?[A-Z][A-Za-z0-9]*`
(`HTTPClient` passes), CONSTANT_CASE `_*[A-Z0-9]+(_[A-Z0-9]+)*`. Names with
non-ASCII characters and names of underscores only are not judged, and
virtual methods (`_ready`) pass as snake case.

The host prefixes each rule with the plugin name (`gdscript/unused-argument`)
and applies the levels in `wf-plugins.toml`:

```toml
[lint.rules]
"gdscript/max-line-length" = "off"
"gdscript/unused-argument" = "error"
```

## Options: `gdscript-lint.toml`

The `[lint]` table of `wf-plugins.toml` only sets rule levels, so the options
come from the plugin's own file. A script uses the nearest `gdscript-lint.toml`
from its directory upwards, usually the one beside `project.godot`; files are
not merged. An unknown key or value is `invalid-config` on that file.

```toml
max-line-length = 120
tab-width = 4
max-file-lines = 1000
function-arguments-number = 10
max-returns = 6
max-public-methods = 20

[naming]              # snake_case | PascalCase | CONSTANT_CASE
function = "snake_case"
constant = "CONSTANT_CASE"
```

The `[naming]` keys are `class`, `sub-class`, `enum`, `enum-element`,
`function`, `signal`, `class-variable`, `function-variable`,
`function-argument`, `loop-variable` and `constant`. Every number must be at
least 1. A file that the given paths leave out is still read for the scripts below
it; if it is invalid, the plugin says so on stderr instead of reporting it.

## Suppressions

As in gdtoolkit, so old suppressions keep working:

```gdscript
# gdlint: ignore=function-name           <- covers the next line
func BadName(): pass
var Loose = 1  # gdlint: ignore=class-variable-name,gdscript/constant-name

# gdlint: disable=max-line-length         <- covers the lines up to the enable
# ...
# gdlint: enable=max-line-length
```

`ignore` alone on a line covers the next line, at the end of a code line it
covers that line. `disable` runs to the matching `enable`, or to the end of
the file. A rule name may carry the `gdscript/` prefix; unknown names do
nothing. A diagnostic is on the line its span starts on.

## How it reads a script

Two hand-written layers in pure Rust, without a C toolchain (tree-sitter would
bring one):

- `src/lexer.rs`: GDScript 2.0 tokens with Godot's `NEWLINE`, `INDENT` and
  `DEDENT`: newlines inside brackets are ignored, `\` continues a line, and a
  multi-line lambda inside brackets is read as indented statements until a line
  is shallower than its first line, or until a closing bracket ends it. Spans are
  bytes. It never panics, and refuses more than 1,000,000 tokens or deep nesting.
- `src/block.rs`: the kind and token range of every statement, the names a
  declaration introduces, and blocks nested into a tree. There is no expression
  syntax tree.

A file whose tokenizing fails (an unterminated string, unbalanced brackets, a
dedent to no enclosing level), whose indentation Godot rejects, or whose block
structure is broken (an unexpected indent, a header without its block) runs only
the line rules: `trailing-whitespace` (before the point the tokenizer stopped),
`max-line-length`, `max-file-lines` and `mixed-indentation`. Godot reports such
a file itself.

At most 5,000 diagnostics are reported per run, and a script that is not valid
UTF-8 is skipped with a warning on stderr.

## Build, test and pack

It depends on [`plugin-kit`](https://gitlab.xqhuyu.cn/996-ugc/wf-plugins/plugin-kit)
by path, so clone that repository beside this one first:

```sh
git clone ssh://git@gitlab.xqhuyu.cn:10022/996-ugc/wf-plugins/plugin-kit.git ../plugin-kit
```

Then, from this directory:

```sh
cargo test                                       # unit tests, the corpus, the memory test
cargo build --release --target wasm32-wasip2     # the component
wf plugin test .                                 # description and examples
wf plugin link .                                 # shows the permissions; --yes grants them
wf gdscript lint --help
wf plugin pack                                   # gdscript-0.1.2.wfplugin, for release
```

`tests/corpus/<case>/` holds small Godot projects, each with `expected.json`
(diagnostics as `rule`, `file`, `line`, `severity`) and, when fixes change
files, `expected-fixed/` with those files after every fix. `tests/corpus.rs`
runs the rules over each case from the disk and compares both. Each case's
`README.md` says what Godot itself reports for it
(`godot --headless --path <case> --check-only -s res://<file>`): every case,
and every `expected-fixed/`, parses except the cases that exist to show what
Godot rejects (`mixed-indentation`, `unparsable-file`).
`tests/memory.rs` lints hostile 4 MiB scripts (deep nesting, huge lines,
unbalanced brackets) and checks the allocation peak stays far below the
component's 256 MiB limit.

The plugin binds the API in `plugin-kit/plugin-api/wit` through
`plugin-kit/plugin-guest`, so it always follows the latest API. The built
component is not committed: the official plugin is packed, signed and
published at release, from the tag's source; bump `version` whenever its bytes
change.
