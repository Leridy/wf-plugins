//! The plugin runs in a WebAssembly store with a 256 MiB memory limit. This
//! measures what hostile files of the largest size it reads (4 MiB) make it
//! allocate on the host target, where allocations are no smaller than there.
#![allow(clippy::print_stderr, reason = "the peaks are the test's result")]

use globset::Glob;
use plugin_api::Failure;
use plugin_guest::{Host, HostError, counting::Counting};
use plugin_protocols::lint::LintInput;
use std::{
    collections::BTreeMap,
    time::{Duration, Instant},
};
use wf_gdscript::lint;

#[global_allocator]
static ALLOCATOR: Counting = Counting;

/// What a run may allocate above what it started with: half the store's
/// 256 MiB, which also holds the component and the host's copies, and a
/// native pointer is twice a wasm32 one.
const BUDGET: usize = 128 << 20;
const FILE: usize = 4 << 20;

struct Files(BTreeMap<String, String>);

impl Host for Files {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        self.0.keys().filter(|path| matcher.is_match(path)).cloned().collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.0
            .get(path)
            .map(|text| text.as_bytes().to_vec())
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }

    fn warn(&self, _message: &str) {}
}

/// Lints one hostile script; returns the peak allocation above the start and the time taken.
fn measure(name: &str, text: String) -> (usize, Duration) {
    let host = Files(BTreeMap::from([(name.to_owned(), text)]));
    let started = Instant::now();
    let (output, peak) = Counting::peak(|| lint(&host, &LintInput::default()));
    let elapsed = started.elapsed();
    assert!(output.checked.iter().any(|f| f == name), "{name} was checked");
    (peak, elapsed)
}

/// `head`, `unit` repeated to fill the largest file the plugin reads, and `tail`.
fn filled(head: &str, unit: &str, tail: &str) -> String {
    let count = (FILE - head.len() - tail.len()) / unit.len();
    format!("{head}{}{tail}", unit.repeat(count))
}

/// `if a:` lines, each one level deeper, until the file is full.
fn staircase(indent: &str) -> String {
    let mut text = String::new();
    let mut level = 0;
    while text.len() < FILE - 4_000 {
        text.push_str(&indent.repeat(level));
        text.push_str("if a:\n");
        level += 1;
    }
    text
}

fn cases() -> Vec<(&'static str, String)> {
    vec![
        ("staircase_tabs.gd", staircase("\t")),
        ("staircase_spaces.gd", staircase(" ")),
        ("nested_brackets.gd", filled("var a = ", "[", "")),
        ("unclosed_calls.gd", filled("", "foo(\n", "")),
        ("closers.gd", filled("var a = 1", ")", "\n")),
        ("nested_lambdas.gd", filled("", "a(func():\n", "")),
        ("huge_line.gd", filled("var a = [", "1, ", "]\n")),
        ("huge_identifier.gd", filled("var ", "x", " = 1\n")),
        ("huge_string.gd", filled("var a = \"", "x", "\"\n")),
        ("huge_comment.gd", filled("#", "x", "\n")),
        ("unterminated_triple.gd", filled("var a = \"\"\"", "x \n", "")),
        ("trailing_whitespace.gd", filled("", " \n", "")),
        ("blank_lines.gd", filled("", "\n", "")),
        (
            "many_functions.gd",
            filled("", "func fffffffffff(aaaaaaaaaaaa): pass\n", ""),
        ),
        ("many_loads.gd", filled("", "var a = load(\"res://x.gd\")\n", "")),
        ("many_parameters.gd", filled("func f(", "aaaaaaaa, ", "): pass\n")),
        ("many_enum_elements.gd", filled("enum E {", "AAAAAAAA, ", "}\n")),
        ("long_class_chain.gd", filled("", "class C:\n\tpass\n", "")),
        ("mixed_indentation.gd", filled("func f():\n", "\t x()\n", "")),
    ]
}

/// One test, so the cases run one after another and the peaks are not mixed.
#[test]
fn a_4_mib_file_stays_far_under_the_memory_limit() {
    for (name, text) in cases() {
        assert!(text.len() <= FILE, "{name}: {}", text.len());
        let (peak, elapsed) = measure(name, text);
        eprintln!("{name}: peak {} KiB, {elapsed:?}", peak >> 10);
        assert!(peak < BUDGET, "{name} allocated {} MiB", peak >> 20);
        assert!(elapsed < Duration::from_secs(20), "{name} took {elapsed:?}");
    }
}
