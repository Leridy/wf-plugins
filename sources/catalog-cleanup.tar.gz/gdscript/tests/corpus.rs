//! Runs the rules over every case in `tests/corpus/<case>/`: a Godot project
//! tree with `expected.json` and, when fixes change files, `expected-fixed/`.
//! Diagnostics compare as `(rule, file, line, severity)`; all fixes are
//! applied and the changed files compared with `expected-fixed/`.
use globset::Glob;
use plugin_api::Failure;
use plugin_guest::{Host, HostError};
use plugin_protocols::lint::{Diagnostic, LintInput, Severity};
use serde::Deserialize;
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
};
use wf_gdscript::lint;

const EXPECTED: &str = "expected.json";
const EXPECTED_FIXED: &str = "expected-fixed";

#[derive(Debug, Deserialize)]
struct Expected {
    diagnostics: Vec<Row>,
}

#[derive(Clone, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd)]
struct Row {
    file: String,
    line: usize,
    rule: String,
    severity: Severity,
}

/// A case directory as the host would show it: dot segments and the
/// expectations stay out of the listing.
struct Disk {
    root: PathBuf,
    files: Vec<String>,
}

impl Disk {
    fn new(root: &Path) -> Self {
        let mut files = files_under(root);
        files.retain(|f| f != EXPECTED && !f.starts_with(&format!("{EXPECTED_FIXED}/")));
        Self {
            root: root.to_owned(),
            files,
        }
    }
}

impl Host for Disk {
    fn list(&self, glob: &str) -> Vec<String> {
        assert_ne!(glob, "**", "the plugin never lists the whole project");
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        self.files
            .iter()
            .filter(|file| matcher.is_match(file))
            .cloned()
            .collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        if path.split('/').any(|s| s.starts_with('.') || s == EXPECTED_FIXED) {
            return Err(HostError::new(Failure::NotFound, path));
        }
        fs::read(self.root.join(path)).map_err(|e| HostError::new(Failure::NotFound, e.to_string()))
    }

    fn warn(&self, _message: &str) {}
}

/// Files below `root`, `/`-separated and sorted, skipping dot segments.
fn files_under(root: &Path) -> Vec<String> {
    let mut found = Vec::new();
    let mut pending = vec![root.to_owned()];
    while let Some(directory) = pending.pop() {
        for entry in fs::read_dir(&directory).unwrap().map(Result::unwrap) {
            if entry.file_name().to_string_lossy().starts_with('.') {
                continue;
            }
            let path = entry.path();
            if path.is_dir() {
                pending.push(path);
            } else {
                let relative = path.strip_prefix(root).unwrap();
                let parts: Vec<String> = relative
                    .components()
                    .map(|c| c.as_os_str().to_string_lossy().into_owned())
                    .collect();
                found.push(parts.join("/"));
            }
        }
    }
    found.sort();
    found
}

fn line(text: &str, offset: u32) -> usize {
    text[..offset as usize].matches('\n').count() + 1
}

/// Each changed file's text after applying every fix, last edit first.
fn fixed(case: &Path, diagnostics: &[Diagnostic]) -> BTreeMap<String, String> {
    let mut edits: BTreeMap<&str, Vec<(u32, u32, &str)>> = BTreeMap::new();
    for fix in diagnostics.iter().filter_map(|d| d.fix.as_ref()) {
        for edit in &fix.edits {
            edits
                .entry(edit.file.as_str())
                .or_default()
                .push((edit.span.start, edit.span.end, edit.text.as_str()));
        }
    }
    edits
        .into_iter()
        .map(|(file, mut edits)| {
            let mut text = fs::read_to_string(case.join(file)).unwrap();
            edits.sort_unstable();
            for pair in edits.windows(2) {
                assert!(pair[0].1 <= pair[1].0, "{}: fixes overlap in {file}", case.display());
            }
            for (start, end, replacement) in edits.into_iter().rev() {
                text.replace_range(start as usize..end as usize, replacement);
            }
            (file.to_owned(), text)
        })
        .collect()
}

fn run(case: &Path) {
    let name = case.display();
    let expected: Expected = serde_json::from_slice(&fs::read(case.join(EXPECTED)).unwrap())
        .map_err(|e| format!("{name}/{EXPECTED}: {e}"))
        .unwrap();
    let output = lint(&Disk::new(case), &LintInput::default());
    let mut found: Vec<Row> = output
        .diagnostics
        .iter()
        .map(|d| {
            let text = fs::read_to_string(case.join(&d.file)).unwrap();
            Row {
                file: d.file.clone(),
                line: d.span.map_or(1, |s| line(&text, s.start)),
                rule: d.rule.clone(),
                severity: d.severity,
            }
        })
        .collect();
    found.sort();
    let mut wanted = expected.diagnostics;
    wanted.sort();
    assert_eq!(found, wanted, "{name}: diagnostics");

    let changed = fixed(case, &output.diagnostics);
    let fixed_dir = case.join(EXPECTED_FIXED);
    let wanted: BTreeMap<String, String> = if fixed_dir.is_dir() {
        files_under(&fixed_dir)
            .into_iter()
            .map(|f| {
                let text = fs::read_to_string(fixed_dir.join(&f)).unwrap();
                (f, text)
            })
            .collect()
    } else {
        BTreeMap::new()
    };
    assert_eq!(
        changed.keys().collect::<Vec<_>>(),
        wanted.keys().collect::<Vec<_>>(),
        "{name}: files the fixes change"
    );
    for (file, text) in &changed {
        assert_eq!(text, &wanted[file], "{name}: {file} after the fixes");
    }
}

#[test]
fn corpus() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/corpus");
    let mut cases: Vec<PathBuf> = fs::read_dir(&root)
        .unwrap()
        .map(|e| e.unwrap().path())
        .filter(|p| p.is_dir())
        .collect();
    cases.sort();
    assert!(!cases.is_empty(), "no corpus cases");
    for case in &cases {
        run(case);
    }
}
