extends Node

const Item = preload("res://item.gd")
const Other = preload("res://other.gd")


func make(path):
	var again = load("res://item.gd")
	var single_quoted = load('res://item.gd')
	var by_variable = load(path)
	var by_loader = ResourceLoader.load("res://item.gd")
	return [again, single_quoted, by_variable, by_loader, Item, Other]
