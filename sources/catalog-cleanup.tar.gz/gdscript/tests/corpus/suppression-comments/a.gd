extends Node

# gdlint: ignore=function-name
func BadOne():
	pass


func BadTwo():
	pass


func BadThree(): # gdlint: ignore=function-name
	pass


# gdlint: disable=function-name,gdscript/constant-name
func BadFour():
	pass
const lower_one = 1
# gdlint: enable=function-name


func BadFive():
	pass
const lower_two = 2

# gdlint: ignore=unknown-rule, gdscript/function-name
func BadSix(): pass
func BadSeven(): pass
