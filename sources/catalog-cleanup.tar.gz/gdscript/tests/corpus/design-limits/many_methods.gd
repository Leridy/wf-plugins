class_name ManyMethods
extends Node

func m0(): pass
func m1(): pass
func m2(): pass
func m3(): pass
func m4(): pass
func m5(): pass
func m6(): pass
func m7(): pass
func m8(): pass
func m9(): pass
func m10(): pass
func m11(): pass
func m12(): pass
func m13(): pass
func m14(): pass
func m15(): pass
func m16(): pass
func m17(): pass
func m18(): pass
func m19(): pass
func m20(): pass
