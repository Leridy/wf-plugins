extends Node


func ten(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10):
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10


func eleven(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11):
	return a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11
