extends Node


func six(x):
	if x == 0:
		return 0
	if x == 1:
		return 1
	if x == 2:
		return 2
	if x == 3:
		return 3
	if x == 4:
		return 4
	return 6


func seven(x):
	if x == 0:
		return 0
	if x == 1:
		return 1
	if x == 2:
		return 2
	if x == 3:
		return 3
	if x == 4:
		return 4
	if x == 5:
		return 5
	return 7


func lambdas(x):
	if x:
		return 1
	var f = func(y):
		if y == 0:
			return 0
		if y == 1:
			return 1
		if y == 2:
			return 2
		if y == 3:
			return 3
		if y == 4:
			return 4
		if y == 5:
			return 5
		if y == 6:
			return 6
		if y == 7:
			return 7
		return 9
	return f.call(x)
