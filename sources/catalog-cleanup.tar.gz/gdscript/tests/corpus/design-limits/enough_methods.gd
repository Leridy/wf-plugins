class_name EnoughMethods
extends Node

func m0(): pass
func m1(): pass
func m2(): pass
func m3(): pass
func m4(): pass
func m5(): pass
func m6(): pass
func m7(): pass
func m8(): pass
func m9(): pass
func m10(): pass
func m11(): pass
func m12(): pass
func m13(): pass
func m14(): pass
func m15(): pass
func m16(): pass
func m17(): pass
func m18(): pass
func m19(): pass
func _p0(): pass
func _p1(): pass
func _p2(): pass
func _p3(): pass
func _p4(): pass

class Inner:
	func i0(): pass
	func i1(): pass
	func i2(): pass
	func i3(): pass
	func i4(): pass
	func i5(): pass
	func i6(): pass
	func i7(): pass
	func i8(): pass
	func i9(): pass
	func i10(): pass
	func i11(): pass
	func i12(): pass
	func i13(): pass
	func i14(): pass
	func i15(): pass
	func i16(): pass
	func i17(): pass
	func i18(): pass
	func i19(): pass
