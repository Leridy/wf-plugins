extends Node

class Big:
	func b0(): pass
	func b1(): pass
	func b2(): pass
	func b3(): pass
	func b4(): pass
	func b5(): pass
	func b6(): pass
	func b7(): pass
	func b8(): pass
	func b9(): pass
	func b10(): pass
	func b11(): pass
	func b12(): pass
	func b13(): pass
	func b14(): pass
	func b15(): pass
	func b16(): pass
	func b17(): pass
	func b18(): pass
	func b19(): pass
	func b20(): pass

func own(): pass
