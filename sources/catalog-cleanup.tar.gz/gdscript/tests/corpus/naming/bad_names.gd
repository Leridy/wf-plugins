class_name bad_class_name
extends Node

signal BadSignal
enum bad_enum { lower_element, UPPER }
const lowerConst = 1
const Loose = 2
const Preloaded = preload("res://item.gd")
var BadClassVar = 1

class bad_inner:
	var Fine_Not = 1


func BadFunction(BadArg, good_arg):
	var BadLocal = BadArg + good_arg
	for BadLoop in range(BadLocal):
		print(BadLoop, lowerConst, Loose, Preloaded)
