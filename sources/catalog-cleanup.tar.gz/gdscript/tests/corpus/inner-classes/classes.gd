extends Node


class Outer:
	var BadOuterVar = 1

	func go():
		var BadLocal = 2
		print(BadLocal)

	class bad_nested:
		var BadNestedVar = 3
