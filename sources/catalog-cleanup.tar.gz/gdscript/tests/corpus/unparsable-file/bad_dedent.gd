extends Node

func f():
    if true:
        print(1)
      print(2)
var BadName = 1
