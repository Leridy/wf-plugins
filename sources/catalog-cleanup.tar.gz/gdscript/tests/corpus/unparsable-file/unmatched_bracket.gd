extends Node
var a = (1]
var BadName = 2 
