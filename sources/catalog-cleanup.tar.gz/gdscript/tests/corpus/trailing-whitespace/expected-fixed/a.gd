extends Node

var padded = 1
var tabbed = 2

# comment with a trailing space
var text = """kept  
also kept  
"""

func f():
	var y = [1,
		2]
	print(y, text)
