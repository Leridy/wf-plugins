extends Node


func unused_one(used, unused):
	print(used)


func all_unused(a, b = 2, c: int = 3):
	print(1)


func used_in_lambda(callback_arg):
	return func(): return callback_arg


func prefixed(_ignored, used):
	print(used)


func name_taken(value, _value):
	print(_value)


func used_in_format(x):
	print("%s" % x)


func used_in_default(first, second = first):
	print(second)
