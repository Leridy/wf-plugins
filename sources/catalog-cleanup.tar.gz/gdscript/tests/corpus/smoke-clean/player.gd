class_name Player
extends CharacterBody2D
## A clean script that touches most constructs.

signal health_changed(old_value: int, new_value: int)

enum State { IDLE, WALKING = 2 }

const SPEED := 300.0
const Bullet = preload("res://bullet.gd")

@export var max_health: int = 100
@onready var _label: Label = $Hud/Label

var health := 100:
	set(value):
		health_changed.emit(health, value)
		health = value


func _ready() -> void:
	_label.text = "HP"


func take_damage(amount: int) -> void:
	health -= amount
	if health <= 0:
		die()


func die() -> void:
	queue_free()
