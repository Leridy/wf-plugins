extends Node2D

var speed := 10.0
