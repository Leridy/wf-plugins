class_name HTTPRoutes
extends Node

signal _private_signal
signal state_changed(new_state: int)
enum Direction { UP, DOWN_LEFT, _HIDDEN }
enum { ANON_ONE, ANON_TWO }
const MAX_SPEED = 10
const _PRIVATE_LIMIT = 1
const ItemScript = preload("res://item.gd")
var _private_var = 1
var speed2d = 2
var __dunder_var = 3

class _InnerClass:
	var value = 1

class Inner2D:
	const SIZE = 2


func _ready() -> void:
	print(_private_var, speed2d, __dunder_var, MAX_SPEED, _PRIVATE_LIMIT, ItemScript)


func do_thing(_unused, used_arg, arg2):
	var local_value = used_arg + arg2
	for index_2 in range(local_value):
		print(index_2)
	var callback = func(NotJudged): return NotJudged
	return callback.call(local_value)
