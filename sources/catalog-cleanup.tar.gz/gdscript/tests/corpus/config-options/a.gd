extends Node

const snake_const = 1
const UPPER_CONST = 2


func PascalFunc(a, b, c):
	var near_limit_with_one_tab_of_width_two = "x"  # 60
	if a:
		return b
	return c + snake_const + UPPER_CONST


func snake_func(): pass
func PublicOne(): pass


func long_line():
	var s = "this line is long enough to go over the limit of sixty"
