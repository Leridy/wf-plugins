extends Node

const snake_const = 1


func PascalFunc(a, b, c):
	var s = "this line would be long for the parent file but not for this one at all"
	return a + b + c + snake_const + len(s)
