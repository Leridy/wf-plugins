extends Node

func f():
	print(1)

func g():
    print(2)
