extends Node

func f():
	print(1)
	 print(2)
