extends Node


func only_pass():
	pass


func with_others():
	print(1)
	pass
	print(2)
	pass # trailing comment


func branches(x):
	if x:
		pass
	else:
		print(x)
		pass
	for i in range(3):
		print(i); pass
	match x:
		1:
			pass
		_:
			print(x)
			pass


class Inner:
	pass
