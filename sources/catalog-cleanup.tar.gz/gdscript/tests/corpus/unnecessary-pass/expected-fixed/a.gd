extends Node


func only_pass():
	pass


func with_others():
	print(1)
	print(2)


func branches(x):
	if x:
		pass
	else:
		print(x)
	for i in range(3):
		print(i); pass
	match x:
		1:
			pass
		_:
			print(x)


class Inner:
	pass
