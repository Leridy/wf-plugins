extends Node

func f():
	print(1)
