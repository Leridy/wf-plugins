`over.gd` has 1001 lines and is reported on the 1001st; `exact.gd` has 1000. Godot 4.7.1 (`godot --headless --path <case> --check-only -s res://<file>`) parses both.
