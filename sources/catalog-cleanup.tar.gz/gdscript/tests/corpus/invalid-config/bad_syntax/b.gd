extends Node

var fine = 1
