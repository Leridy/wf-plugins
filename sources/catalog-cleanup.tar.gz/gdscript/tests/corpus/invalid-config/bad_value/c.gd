extends Node

func BadName(): pass
