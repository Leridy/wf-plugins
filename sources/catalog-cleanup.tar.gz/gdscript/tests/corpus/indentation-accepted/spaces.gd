extends Node

func f():
    var x = 1
    if x:
        print(x,
			"tab-aligned continuation")
