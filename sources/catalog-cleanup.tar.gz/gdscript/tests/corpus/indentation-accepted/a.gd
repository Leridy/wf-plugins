extends Node

func f():
	print(1,
			2)
	# comment
  # a space-indented comment in a tab file
	var x = [
        1,
        2,
	]
	print(x)
