Non-ASCII names are not judged, and an `@abstract` function without a body is read. Godot 4.7.1 (`godot --headless --path <case> --check-only -s res://<file>`) parses the script.
