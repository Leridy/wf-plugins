@abstract class_name AbstractShape
extends Node

var 变量 = 1

@abstract func area() -> float


func 函数(参数):
	return 参数 + 变量
