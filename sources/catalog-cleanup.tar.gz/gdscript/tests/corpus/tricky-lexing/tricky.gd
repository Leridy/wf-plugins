@tool
class_name TrickyLexing
extends Node
## Strings with comment signs, multi-line strings with trailing spaces, lambdas, node paths.

signal fired(by: Node)

enum Kind {
	A,
	B = 2, # a comment inside the enum
	C,
}

const HASH := "# not a comment"
const SINGLE := '# nor this'
const RAW := r"C:\temp\# raw"
const NAME := &"string#name"
const PATH := ^"Node#Path"
const ESCAPED := "quote \" # still a string"
const TABLE := {
	"a": 1,
	"b": [1, 2, 3], # trailing comment
}

@export_range(0, 10, 1) var amount: int = 3
@export_group("Group # one")
@export var label_text := "x"

@onready var _child: Node = $Child/Sub
@onready var _unique: Node = %Unique
@onready var _quoted: Node = $"Spaced Name/Sub"
@onready var _parent: Node = $"../Sibling"

var multi := """first line   
second line with # hash   
third"""

var lines := '''trailing spaces here    
'''

var health := 100:
	set(value):
		health = clampi(value, 0, 100)
	get:
		return health

static var counter := 0


class Inner:
	var inner_value := 1

	func get_value() -> int:
		return inner_value

	class Deeper:
		const DEEP := 1


func _ready() -> void:
	var total := 1 + \
		2
	var items := [
		1, 2,
		3, # three
	]
	var table := {
		"double": func(x): return x * 2,
		"named": func named(x): return x + 1,
	}
	var run := func(value: int) -> int:
		var doubled := value * 2
		return doubled
	connect_all([1, 2], func(item):
		print(item)
		print(items, table, total, run)
	)
	connect_all([3], func(item): print(item))
	var ratio := 10 % 3
	if total > 1 and \
			items.size() > 0:
		print("ok", ratio)
	_child.name = "c"
	_unique.name = "u"
	%Unique.name = "again"
	$Child.name = "d"
	print(HASH, SINGLE, RAW, NAME, PATH, ESCAPED, multi, lines)
	print(_quoted, _parent, amount, label_text)


func connect_all(list: Array, callback: Callable) -> void:
	for item in list:
		callback.call(item)


func describe(x) -> String:
	match x:
		1, 2:
			return "small"
		[var first, ..]:
			return str(first)
		{"key": var found}:
			return str(found)
		_:
			return "other"


func operators(a: int, b: Array) -> bool:
	var c := 1 if a > 1 else 2
	var d := a as float
	return not (c in b) and d > 0.5 and (a is int)


static func make() -> Node:
	return Node.new()
