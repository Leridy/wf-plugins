use super::*;
use std::collections::BTreeSet;

#[test]
fn options_are_set_over_the_defaults() {
    let options = parse(
        "max-line-length = 120\ntab-width = 2\nmax-returns = 3\n\n[naming]\nfunction = \"PascalCase\"\nenum = \"snake_case\"\n",
    )
    .unwrap();
    assert_eq!(options.max_line_length, 120);
    assert_eq!(options.tab_width, 2);
    assert_eq!(options.max_returns, 3);
    assert_eq!(options.max_file_lines, 1000);
    assert_eq!(options.naming.function, Style::Pascal);
    assert_eq!(options.naming.enum_name, Style::Snake);
    assert_eq!(options.naming.constant, Style::Constant);
    assert_eq!(parse("").unwrap(), Options::default());
}

#[test]
fn unknown_keys_and_bad_values_are_errors() {
    for (text, needle) in [
        ("max-line-lenght = 1\n", "unknown field"),
        ("[naming]\nfunctions = \"snake_case\"\n", "unknown field"),
        ("[naming]\nfunction = \"camelCase\"\n", "unknown variant"),
        ("max-returns = 0\n", "at least 1"),
        ("max-returns = \"six\"\n", "invalid type"),
        ("max-returns = \n", ""),
    ] {
        let error = parse(text).unwrap_err();
        assert!(error.message.contains(needle), "{text}: {}", error.message);
    }
    let error = parse("max-line-length = 100\nbogus = 1\n").unwrap_err();
    assert_eq!(error.span, Some(22..27));
}

#[test]
fn the_nearest_file_above_a_script_applies() {
    let files: BTreeSet<String> = ["gdscript-lint.toml", "game/gdscript-lint.toml", "game/ui/other.toml"]
        .into_iter()
        .map(str::to_owned)
        .collect();
    assert_eq!(nearest(&files, "game/ui/menu.gd"), Some("game/gdscript-lint.toml"));
    assert_eq!(nearest(&files, "game/player.gd"), Some("game/gdscript-lint.toml"));
    assert_eq!(nearest(&files, "tools/x.gd"), Some("gdscript-lint.toml"));
    assert_eq!(nearest(&files, "x.gd"), Some("gdscript-lint.toml"));
    assert_eq!(nearest(&BTreeSet::new(), "x.gd"), None);
}
