//! The tokenizer: GDScript 2.0 tokens with the `NEWLINE`, `INDENT` and
//! `DEDENT` Godot's own tokenizer produces. Brackets suppress newlines, a `\`
//! continues a line, and a multi-line lambda inside brackets opens an
//! indentation context of its own until a line is no deeper than the line that
//! started it. Spans are byte offsets, and every delimiter is ASCII, so each
//! one sits on a character boundary.
//!
//! The lexer stops at the first thing it cannot read (an unterminated string,
//! an unbalanced bracket, an unaligned dedent) and says where; what it found
//! before that point stays valid. Indentation Godot rejects is no lexing
//! failure but a fault recorded for the `mixed-indentation` rule.
use scan::is_quote;
use std::{mem::take, ops::Range};

/// Most tokens one file may hold; a hostile file could hold millions.
const MAX_TOKENS: usize = 1_000_000;
/// Most open brackets, indentation levels and lambda contexts at once.
const MAX_BRACKETS: usize = 200;
const MAX_LEVELS: usize = 100;
const MAX_CONTEXTS: usize = 64;
/// What a tab counts for next to a space when comparing indentation.
const TAB_WIDTH: u32 = 4;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Kind {
    Ident,
    Number,
    /// `"…"`, `'…'`, triple-quoted, with an `r`, `&` or `^` prefix.
    Str,
    /// `@name`
    Annotation,
    /// `$Node/path` or `$"Node/path"`
    NodePath,
    /// `%Name`
    Unique,
    /// An operator or bracket.
    Punct,
    Newline,
    Indent,
    Dedent,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Token {
    pub kind: Kind,
    pub start: u32,
    pub end: u32,
}

impl Token {
    pub fn text<'a>(&self, source: &'a str) -> &'a str {
        &source[self.start as usize..self.end as usize]
    }

    pub fn is_layout(&self) -> bool {
        matches!(self.kind, Kind::Newline | Kind::Indent | Kind::Dedent)
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ErrorKind {
    UnterminatedString,
    UnclosedBracket,
    UnmatchedBracket,
    /// A dedent to a column no enclosing block has.
    BadDedent,
    UnexpectedChar,
    /// More tokens or nesting than a script can sensibly hold.
    TooLarge,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct LexError {
    pub at: u32,
    pub kind: ErrorKind,
}

/// Indentation Godot refuses.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum IndentFault {
    /// Tabs and spaces in one line's indentation.
    Mixed,
    /// The other character than the file's first indentation used (`b'\t'` or `b' '`).
    Switched { expected: u8 },
}

/// The indentation of one logical line that Godot rejects.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Fault {
    pub start: u32,
    pub end: u32,
    pub kind: IndentFault,
}

#[derive(Debug, Default)]
pub struct Lexed {
    pub tokens: Vec<Token>,
    /// Every comment, from its `#` to the end of its line.
    pub comments: Vec<Range<u32>>,
    /// The strings that contain a line break.
    pub multiline_strings: Vec<Range<u32>>,
    pub faults: Vec<Fault>,
    pub error: Option<LexError>,
}

pub fn lex(source: &str) -> Lexed {
    let mut lexer = Lexer {
        source,
        bytes: source.as_bytes(),
        pos: 0,
        out: Lexed::default(),
        brackets: Vec::new(),
        lambdas: Vec::new(),
        contexts: Vec::new(),
        levels: vec![0],
        indent_char: None,
    };
    lexer.run();
    lexer.out
}

/// A `func` seen inside brackets: a lambda whose signature ends at the first
/// `:` after its parameters, at the depth it began.
struct Lambda {
    depth: usize,
    params_closed: bool,
}

/// The brackets around a multi-line lambda body, parked while the body is
/// read as statements.
struct Context {
    brackets: Vec<(u8, u32)>,
    lambdas: Vec<Lambda>,
    /// How many indentation levels existed when the body began.
    base: usize,
}

struct Lexer<'a> {
    source: &'a str,
    bytes: &'a [u8],
    pos: usize,
    out: Lexed,
    brackets: Vec<(u8, u32)>,
    lambdas: Vec<Lambda>,
    contexts: Vec<Context>,
    levels: Vec<u32>,
    indent_char: Option<u8>,
}

impl Lexer<'_> {
    fn peek(&self, n: usize) -> u8 {
        self.bytes.get(self.pos + n).copied().unwrap_or(0)
    }

    fn fail(&mut self, at: usize, kind: ErrorKind) {
        if self.out.error.is_none() {
            self.out.error = Some(LexError { at: at as u32, kind });
        }
    }

    fn push(&mut self, kind: Kind, start: usize, end: usize) {
        self.out.tokens.push(Token {
            kind,
            start: start as u32,
            end: end as u32,
        });
    }

    fn last_is_layout(&self) -> bool {
        self.out.tokens.last().is_none_or(Token::is_layout)
    }

    fn run(&mut self) {
        if self.source.starts_with('\u{feff}') {
            self.pos = '\u{feff}'.len_utf8();
        }
        self.line_start();
        while self.pos < self.bytes.len() && self.out.error.is_none() {
            self.step();
            if self.out.tokens.len() > MAX_TOKENS {
                self.fail(self.pos, ErrorKind::TooLarge);
            }
        }
        self.finish();
    }

    fn step(&mut self) {
        let b = self.bytes[self.pos];
        match b {
            b' ' | b'\t' | b'\r' | 0x0c => self.pos += 1,
            b'\n' => self.newline(),
            b'#' => self.comment(),
            b'\\' => self.continuation(),
            b'"' | b'\'' => self.string(self.pos, self.pos),
            b'r' | b'&' | b'^' if is_quote(self.peek(1)) => self.string(self.pos, self.pos + 1),
            b'0'..=b'9' => self.number(),
            b'.' if self.peek(1).is_ascii_digit() => self.number(),
            b'@' => self.annotation(),
            b'$' => self.node_path(),
            b'%' if self.unique_follows() => self.unique(),
            b'(' | b'[' | b'{' => self.open(b),
            b')' | b']' | b'}' => self.close(b),
            _ => self.word_or_punct(),
        }
    }

    // --- lines and indentation ---

    fn newline(&mut self) {
        let at = self.pos;
        self.pos += 1;
        if !self.brackets.is_empty() {
            return;
        }
        if !self.last_is_layout() {
            self.push(Kind::Newline, at, self.pos);
        }
        self.line_start();
    }

    fn continuation(&mut self) {
        let mut next = self.pos + 1;
        if self.bytes.get(next) == Some(&b'\r') {
            next += 1;
        }
        if self.bytes.get(next) == Some(&b'\n') {
            self.pos = next + 1;
        } else {
            self.fail(self.pos, ErrorKind::UnexpectedChar);
        }
    }

    fn comment(&mut self) {
        let start = self.pos;
        let mut end = start;
        while end < self.bytes.len() && self.bytes[end] != b'\n' {
            end += 1;
        }
        self.pos = end;
        if end > start && self.bytes[end - 1] == b'\r' {
            end -= 1;
        }
        self.out.comments.push(start as u32..end as u32);
    }

    /// At the start of a physical line outside brackets: skips blank and
    /// comment-only lines, then compares the first code line's indentation
    /// with the enclosing blocks'.
    fn line_start(&mut self) {
        loop {
            let line = self.pos;
            let mut ws_end = line;
            while matches!(self.bytes.get(ws_end), Some(b' ' | b'\t')) {
                ws_end += 1;
            }
            let mut probe = ws_end;
            if self.bytes.get(probe) == Some(&b'\r') {
                probe += 1;
            }
            match self.bytes.get(probe) {
                None => {
                    self.pos = self.bytes.len();
                    return;
                }
                Some(b'\n') => self.pos = probe + 1,
                Some(b'#') => {
                    self.pos = ws_end;
                    self.comment();
                    if self.pos >= self.bytes.len() {
                        return;
                    }
                    self.pos += 1;
                }
                Some(_) => {
                    self.pos = ws_end;
                    self.indent(line, ws_end);
                    return;
                }
            }
        }
    }

    fn indent(&mut self, line: usize, ws_end: usize) {
        let ws = &self.bytes[line..ws_end];
        let tabs = ws.iter().fold(0, |count, &b| count + u32::from(b == b'\t'));
        let spaces = ws.len() as u32 - tabs;
        let width = tabs * TAB_WIDTH + spaces;
        if self.ends_lambda_body(width) {
            return;
        }
        if let Some(kind) = self.fault(tabs, spaces) {
            self.out.faults.push(Fault {
                start: line as u32,
                end: ws_end as u32,
                kind,
            });
        }
        let top = self.levels.last().copied().unwrap_or(0);
        if width > top {
            if self.levels.len() >= MAX_LEVELS {
                return self.fail(line, ErrorKind::TooLarge);
            }
            self.levels.push(width);
            self.push(Kind::Indent, line, ws_end);
        } else if width < top {
            while self.levels.last().is_some_and(|&level| level > width) {
                self.levels.pop();
                self.push(Kind::Dedent, line, ws_end);
            }
            if self.levels.last().copied().unwrap_or(0) != width {
                if self.out.faults.is_empty() {
                    return self.fail(line, ErrorKind::BadDedent);
                }
                self.levels.push(width);
            }
        }
    }

    /// What Godot rejects in a logical line's indentation of `tabs` and `spaces`.
    fn fault(&mut self, tabs: u32, spaces: u32) -> Option<IndentFault> {
        if tabs > 0 && spaces > 0 {
            return Some(IndentFault::Mixed);
        }
        if tabs + spaces == 0 {
            return None;
        }
        let used = if tabs > 0 { b'\t' } else { b' ' };
        match self.indent_char {
            Some(expected) if expected != used => Some(IndentFault::Switched { expected }),
            Some(_) => None,
            None => {
                self.indent_char = Some(used);
                None
            }
        }
    }

    /// A body ends at a line shallower than its first line; a body that has no
    /// first line yet ends at a line no deeper than the one that began it. The
    /// brackets around the lambda are open again and the line continues them.
    fn ends_lambda_body(&mut self, width: u32) -> bool {
        let Some(context) = self.contexts.last() else {
            return false;
        };
        let limit = self
            .levels
            .get(context.base)
            .map_or(self.levels[context.base - 1] + 1, |&first| first);
        if width >= limit {
            return false;
        }
        self.end_lambda_body();
        true
    }

    /// Closes the innermost lambda body: its statement and blocks end, and the
    /// brackets around the lambda are open again.
    fn end_lambda_body(&mut self) {
        let Some(context) = self.contexts.pop() else {
            return;
        };
        let at = self.pos;
        if !self.last_is_layout() {
            self.push(Kind::Newline, at, at);
        }
        while self.levels.len() > context.base {
            self.levels.pop();
            self.push(Kind::Dedent, at, at);
        }
        self.brackets = context.brackets;
        self.lambdas = context.lambdas;
    }

    fn finish(&mut self) {
        if self.out.error.is_some() {
            return;
        }
        let unclosed = self
            .brackets
            .last()
            .or_else(|| self.contexts.last().and_then(|c| c.brackets.last()));
        if let Some(&(_, at)) = unclosed {
            return self.fail(at as usize, ErrorKind::UnclosedBracket);
        }
        let end = self.bytes.len();
        if !self.last_is_layout() {
            self.push(Kind::Newline, end, end);
        }
        while self.levels.len() > 1 {
            self.levels.pop();
            self.push(Kind::Dedent, end, end);
        }
    }

    // --- brackets and lambdas ---

    fn open(&mut self, b: u8) {
        if self.brackets.len() >= MAX_BRACKETS {
            return self.fail(self.pos, ErrorKind::TooLarge);
        }
        self.brackets.push((b, self.pos as u32));
        self.push(Kind::Punct, self.pos, self.pos + 1);
        self.pos += 1;
    }

    fn close(&mut self, b: u8) {
        let opener = match b {
            b')' => b'(',
            b']' => b'[',
            _ => b'{',
        };
        if self.brackets.is_empty() && !self.contexts.is_empty() {
            // The last line of a lambda body closes the brackets around the lambda.
            self.end_lambda_body();
        }
        if self.brackets.last().map(|&(open, _)| open) != Some(opener) {
            return self.fail(self.pos, ErrorKind::UnmatchedBracket);
        }
        self.brackets.pop();
        self.push(Kind::Punct, self.pos, self.pos + 1);
        self.pos += 1;
        let depth = self.brackets.len();
        while self.lambdas.last().is_some_and(|lambda| lambda.depth > depth) {
            self.lambdas.pop();
        }
        if let Some(lambda) = self.lambdas.last_mut()
            && lambda.depth == depth
            && b == b')'
        {
            lambda.params_closed = true;
        }
    }

    /// A lone `:` that ends a lambda's signature, followed by the end of the
    /// line, begins a body read as statements.
    fn colon(&mut self) {
        let depth = self.brackets.len();
        let ends_signature = self
            .lambdas
            .last()
            .is_some_and(|lambda| lambda.params_closed && lambda.depth == depth);
        if !ends_signature {
            return;
        }
        self.lambdas.pop();
        let mut at = self.pos;
        while matches!(self.bytes.get(at), Some(b' ' | b'\t' | b'\r')) {
            at += 1;
        }
        if self.bytes.get(at) == Some(&b'#') {
            while self.bytes.get(at).is_some_and(|&b| b != b'\n') {
                at += 1;
            }
        }
        if self.bytes.get(at) != Some(&b'\n') {
            return;
        }
        if self.contexts.len() >= MAX_CONTEXTS {
            return self.fail(self.pos, ErrorKind::TooLarge);
        }
        self.contexts.push(Context {
            brackets: take(&mut self.brackets),
            lambdas: take(&mut self.lambdas),
            base: self.levels.len(),
        });
    }
}

mod scan;
#[cfg(test)]
mod tests;
