//! The rules, judged per file. Every rule runs on the lines; the rules that
//! need the structure of the script run only when the tokenizer and the block
//! layer both read the whole file and Godot accepts its indentation, since a
//! guess at a broken file would be a false report.
mod basic;
mod design;
mod format;
mod naming;

use crate::{block, config::Options, lexer::Lexed, lines::Lines};
use plugin_protocols::lint::{Diagnostic, Fix, Severity, Span, TextEdit};
use std::ops::Range;

/// A file being checked.
pub struct Checked<'a> {
    pub file: &'a str,
    pub source: &'a str,
    pub options: &'a Options,
    pub lexed: &'a Lexed,
    pub lines: &'a Lines<'a>,
}

/// The diagnostics of one file, which stops taking more at `limit`.
pub struct Sink<'a> {
    file: &'a str,
    limit: usize,
    pub diagnostics: Vec<Diagnostic>,
}

impl<'a> Sink<'a> {
    pub fn new(file: &'a str, limit: usize) -> Self {
        Self {
            file,
            limit,
            diagnostics: Vec::new(),
        }
    }

    pub fn full(&self) -> bool {
        self.diagnostics.len() >= self.limit
    }

    pub fn report(&mut self, rule: &str, severity: Severity, message: String, span: Range<usize>) {
        self.add(rule, severity, message, span, None);
    }

    /// A diagnostic that replaces the bytes `edit` with `text`.
    pub fn report_fixed(
        &mut self,
        rule: &str,
        severity: Severity,
        message: String,
        span: Range<usize>,
        fix: (&str, Range<usize>, &str),
    ) {
        let (summary, edit, text) = fix;
        let fix = Fix {
            summary: summary.to_owned(),
            edits: vec![TextEdit {
                file: self.file.to_owned(),
                span: span_of(&edit),
                text: text.to_owned(),
            }],
        };
        self.add(rule, severity, message, span, Some(fix));
    }

    fn add(&mut self, rule: &str, severity: Severity, message: String, span: Range<usize>, fix: Option<Fix>) {
        if self.full() {
            return;
        }
        self.diagnostics.push(Diagnostic {
            rule: rule.to_owned(),
            severity,
            message,
            file: self.file.to_owned(),
            span: Some(span_of(&span)),
            fix,
        });
    }
}

fn span_of(range: &Range<usize>) -> Span {
    Span {
        start: range.start as u32,
        end: range.end as u32,
    }
}

/// The diagnostics of one file, at most `limit`.
pub fn check(file: &Checked, limit: usize) -> Vec<Diagnostic> {
    let mut sink = Sink::new(file.file, limit);
    format::check(file, &mut sink);
    let readable = file.lexed.error.is_none() && file.lexed.faults.is_empty();
    if let Some(tree) = readable
        .then(|| block::parse(file.source, &file.lexed.tokens))
        .flatten()
    {
        naming::check(file, &tree, &mut sink);
        basic::check(file, &tree, &mut sink);
        design::check(file, &tree, &mut sink);
    }
    let mut diagnostics = sink.diagnostics;
    drop_overlapping_fixes(&mut diagnostics);
    diagnostics
}

/// A trailing-whitespace fix inside a line another fix deletes is not offered:
/// the line goes away anyway, and two fixes must not overlap.
fn drop_overlapping_fixes(diagnostics: &mut [Diagnostic]) {
    let mut deleted: Vec<(u32, u32)> = diagnostics
        .iter()
        .filter(|d| d.rule == basic::UNNECESSARY_PASS)
        .filter_map(|d| d.fix.as_ref()?.edits.first())
        .map(|edit| (edit.span.start, edit.span.end))
        .collect();
    deleted.sort_unstable();
    for diagnostic in diagnostics.iter_mut().filter(|d| d.rule == format::TRAILING_WHITESPACE) {
        let Some(start) = diagnostic
            .fix
            .as_ref()
            .and_then(|fix| fix.edits.first())
            .map(|e| e.span.start)
        else {
            continue;
        };
        let before = deleted.partition_point(|&(from, _)| from <= start);
        if before > 0 && start < deleted[before - 1].1 {
            diagnostic.fix = None;
        }
    }
}

/// The byte range of the tokens `from..to` of a tree.
fn tokens_span(tree: &block::Tree, from: usize, to: usize) -> Range<usize> {
    tree.tokens[from].start as usize..tree.tokens[to - 1].end as usize
}

#[cfg(test)]
mod tests;
