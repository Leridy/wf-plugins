use super::*;
use crate::testing::Fake;

const BAD: &str = "var a = 1 \n";

fn lint_paths(fake: &Fake, paths: &[&str]) -> LintOutput {
    lint(
        fake,
        &LintInput {
            paths: paths.iter().map(|p| (*p).to_owned()).collect(),
        },
    )
}

fn rules(output: &LintOutput) -> Vec<(&str, &str)> {
    output
        .diagnostics
        .iter()
        .map(|d| (d.file.as_str(), d.rule.as_str()))
        .collect()
}

#[test]
fn every_script_is_checked_and_listed() {
    let fake = Fake::new(&[("a.gd", BAD), ("sub/b.gd", "var b = 1\n"), ("scene.tscn", BAD)]);
    let output = lint_paths(&fake, &[]);
    assert_eq!(output.checked, ["a.gd", "sub/b.gd"]);
    assert_eq!(rules(&output), [("a.gd", "trailing-whitespace")]);
    assert_eq!(*fake.lists.borrow(), ["**/*.gd", "**/gdscript-lint.toml"]);
}

#[test]
fn paths_narrow_the_scripts() {
    let fake = Fake::new(&[
        ("a.gd", BAD),
        ("sub/b.gd", BAD),
        ("sub/deep/c.gd", BAD),
        ("subway/d.gd", BAD),
    ]);
    let output = lint_paths(&fake, &["sub/", "a.gd"]);
    assert_eq!(output.checked, ["a.gd", "sub/b.gd", "sub/deep/c.gd"]);
    assert_eq!(*fake.lists.borrow(), ["sub/**/*.gd", "a.gd", "**/gdscript-lint.toml"]);
    assert!(lint_paths(&fake, &["nothing"]).checked.is_empty());
}

#[test]
fn the_nearest_option_file_sets_the_limits() {
    let fake = Fake::new(&[
        ("gdscript-lint.toml", "max-line-length = 10\n"),
        ("a.gd", "var long_name = 1\n"),
        ("sub/gdscript-lint.toml", "max-line-length = 200\n"),
        ("sub/b.gd", "var long_name = 1\n"),
        ("c/c.gd", "var long_name = 1\n"),
    ]);
    let output = lint_paths(&fake, &[]);
    assert_eq!(
        rules(&output),
        [("a.gd", "max-line-length"), ("c/c.gd", "max-line-length")]
    );
    assert!(output.checked.contains(&"sub/gdscript-lint.toml".to_owned()));
}

#[test]
fn an_invalid_option_file_is_reported_and_the_defaults_apply() {
    let fake = Fake::new(&[
        ("gdscript-lint.toml", "max-line-length = 10\nmax-lines = 1\n"),
        ("a.gd", "var long_name = 1\n"),
    ]);
    let output = lint_paths(&fake, &[]);
    assert_eq!(rules(&output), [("gdscript-lint.toml", "invalid-config")]);
    let diagnostic = &output.diagnostics[0];
    assert_eq!(diagnostic.severity, Severity::Error);
    assert_eq!(diagnostic.span, Some(Span { start: 21, end: 30 }));
    assert!(diagnostic.message.contains("unknown field"), "{}", diagnostic.message);
    // Outside the requested paths it is only told on stderr.
    let narrowed = lint_paths(&fake, &["a.gd"]);
    assert!(narrowed.diagnostics.is_empty());
    assert_eq!(narrowed.checked, ["a.gd"]);
    assert!(
        fake.warnings
            .borrow()
            .iter()
            .any(|w| w.contains("gdscript-lint.toml is invalid"))
    );
}

#[test]
fn diagnostics_are_capped_and_a_full_listing_is_warned_about() {
    let many = " \n".repeat(MAX_DIAGNOSTICS + 100);
    let fake = Fake::new(&[("a.gd", &many), ("b.gd", BAD)]);
    let output = lint_paths(&fake, &[]);
    assert_eq!(output.diagnostics.len(), MAX_DIAGNOSTICS);
    assert_eq!(output.checked, ["a.gd"]);
    assert!(fake.warnings.borrow().iter().any(|w| w.contains("stopped after")));

    let fake = Fake {
        limit: Some(2),
        ..Fake::new(&[("a.gd", BAD), ("b.gd", BAD)])
    };
    lint_paths(&fake, &[]);
    assert!(
        fake.warnings
            .borrow()
            .iter()
            .any(|w| w.contains("as long as the host allows"))
    );
}

#[test]
fn scripts_that_are_not_utf8_are_skipped_with_a_warning() {
    struct Binary;
    impl Host for Binary {
        fn list(&self, glob: &str) -> Vec<String> {
            if glob.contains(".gd") {
                vec!["a.gd".to_owned()]
            } else {
                Vec::new()
            }
        }
        fn read(&self, _path: &str) -> Result<Vec<u8>, plugin_guest::HostError> {
            Ok(vec![0xff, 0xfe])
        }
        fn warn(&self, _message: &str) {}
    }
    let output = lint(&Binary, &LintInput::default());
    assert!(output.checked.is_empty() && output.diagnostics.is_empty());
}
