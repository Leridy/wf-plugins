//! The physical lines of a file: where each starts, and which line an offset is on.
use std::ops::Range;

pub struct Lines<'a> {
    source: &'a str,
    starts: Vec<u32>,
}

impl<'a> Lines<'a> {
    pub fn new(source: &'a str) -> Self {
        let mut starts = vec![0];
        starts.extend(
            source
                .bytes()
                .enumerate()
                .filter(|&(_, b)| b == b'\n')
                .map(|(i, _)| i as u32 + 1),
        );
        Self { source, starts }
    }

    /// How many lines the file has: a final line break does not begin another.
    pub fn count(&self) -> usize {
        let last_is_empty = self
            .starts
            .last()
            .is_some_and(|&start| start as usize == self.source.len());
        self.starts.len() - usize::from(last_is_empty && self.starts.len() > 1)
    }

    /// The 1-based line `offset` is on.
    pub fn line_of(&self, offset: u32) -> usize {
        self.starts.partition_point(|&start| start <= offset)
    }

    /// The text of the 0-based `index`th line, without its line break (`\n` or `\r\n`).
    pub fn text(&self, index: usize) -> Range<usize> {
        let start = self.starts[index] as usize;
        let mut end = self
            .starts
            .get(index + 1)
            .map_or(self.source.len(), |&next| next as usize - 1);
        if end > start && self.source.as_bytes()[end - 1] == b'\r' && end < self.source.len() {
            end -= 1;
        }
        start..end
    }

    /// Where the line `offset` is on begins, and where the next begins.
    pub fn around(&self, offset: u32) -> Range<usize> {
        let line = self.line_of(offset) - 1;
        let end = self
            .starts
            .get(line + 1)
            .map_or(self.source.len(), |&next| next as usize);
        self.starts[line] as usize..end
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn lines_are_counted_and_found() {
        let lines = Lines::new("a\r\nbb\n\nc");
        assert_eq!(lines.count(), 4);
        assert_eq!(lines.text(0), 0..1);
        assert_eq!(lines.text(1), 3..5);
        assert_eq!(lines.text(3), 7..8);
        assert_eq!(lines.line_of(0), 1);
        assert_eq!(lines.line_of(4), 2);
        assert_eq!(lines.line_of(7), 4);
        assert_eq!(lines.around(4), 3..6);
        assert_eq!(Lines::new("a\n").count(), 1);
        assert_eq!(Lines::new("").count(), 1);
    }
}
