//! The official `gdscript` plugin: an ESLint-style linter for GDScript. It
//! implements `wf.lint/1` with a hand-written tokenizer and a statement/block
//! layer in pure Rust, so the component needs no C toolchain.
#![cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "the component glue that calls into these is wasm-only")
)]

mod block;
mod config;
mod describe;
mod gather;
mod lexer;
mod lines;
mod rules;
mod style;
mod suppress;
#[cfg(test)]
mod testing;

pub use gather::lint;

#[cfg(target_arch = "wasm32")]
mod component;
