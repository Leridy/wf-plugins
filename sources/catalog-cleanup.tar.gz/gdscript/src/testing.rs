//! An in-memory project for the unit tests, listed the way the host lists it.
use crate::gather::lint;
use globset::Glob;
use plugin_api::{Failure, LIST_LIMIT};
use plugin_guest::{Host, HostError};
use plugin_protocols::lint::{Diagnostic, LintInput};
use std::{cell::RefCell, collections::BTreeMap};

#[derive(Default)]
pub struct Fake {
    pub files: BTreeMap<String, String>,
    /// Paths a listing holds at most, when not the host's.
    pub limit: Option<usize>,
    pub lists: RefCell<Vec<String>>,
    pub reads: RefCell<Vec<String>>,
    pub warnings: RefCell<Vec<String>>,
}

impl Fake {
    pub fn new(files: &[(&str, &str)]) -> Self {
        Self {
            files: files.iter().map(|(p, t)| ((*p).to_owned(), (*t).to_owned())).collect(),
            ..Self::default()
        }
    }

    pub fn lint(&self) -> Vec<Diagnostic> {
        lint(self, &LintInput::default()).diagnostics
    }
}

impl Host for Fake {
    fn list(&self, glob: &str) -> Vec<String> {
        self.lists.borrow_mut().push(glob.to_owned());
        let matcher = Glob::new(glob)
            .expect("the plugin builds valid globs")
            .compile_matcher();
        self.files
            .keys()
            .filter(|path| matcher.is_match(path))
            .take(self.list_limit())
            .cloned()
            .collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.reads.borrow_mut().push(path.to_owned());
        self.files
            .get(path)
            .map(|text| text.as_bytes().to_vec())
            .ok_or_else(|| HostError::new(Failure::NotFound, format!("no {path}")))
    }

    fn warn(&self, message: &str) {
        self.warnings.borrow_mut().push(message.to_owned());
    }

    fn list_limit(&self) -> usize {
        self.limit.unwrap_or(LIST_LIMIT)
    }
}

/// `(rule, the text under the span)` of the diagnostics of one script's text, linted alone.
pub fn found(source: &str) -> Vec<(String, String)> {
    let fake = Fake::new(&[("a.gd", source)]);
    fake.lint()
        .into_iter()
        .map(|d| {
            let span = d.span.expect("every diagnostic has a span");
            (d.rule, source[span.start as usize..span.end as usize].to_owned())
        })
        .collect()
}

/// The rules of a script's diagnostics, in order.
pub fn rules_of(source: &str) -> Vec<String> {
    found(source).into_iter().map(|(rule, _)| rule).collect()
}

/// The text after applying every fix of `source`'s diagnostics, last edit first.
pub fn fixed(source: &str) -> String {
    let fake = Fake::new(&[("a.gd", source)]);
    let mut edits: Vec<(usize, usize, String)> = fake
        .lint()
        .into_iter()
        .filter_map(|d| d.fix)
        .flat_map(|fix| fix.edits)
        .map(|e| (e.span.start as usize, e.span.end as usize, e.text))
        .collect();
    edits.sort();
    let mut text = source.to_owned();
    for (start, end, replacement) in edits.into_iter().rev() {
        text.replace_range(start..end, &replacement);
    }
    text
}
