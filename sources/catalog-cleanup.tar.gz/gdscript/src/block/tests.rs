use super::*;
use crate::lexer::lex;

/// The tree as `Kind(name)[children]`, one line.
fn shape(source: &str) -> Option<String> {
    let lexed = lex(source);
    assert!(lexed.error.is_none(), "{:?}", lexed.error);
    let tree = parse(source, &lexed.tokens)?;
    Some(describe(&tree, &tree.block))
}

fn describe(tree: &Tree, block: &[Stmt]) -> String {
    block
        .iter()
        .map(|stmt| {
            let name = stmt.name.map_or(String::new(), |n| format!("({})", tree.text(n)));
            let lambda = if stmt.lambda { "~" } else { "" };
            let body = stmt
                .body
                .as_ref()
                .map_or(String::new(), |body| format!("[{}]", describe(tree, body)));
            format!("{:?}{name}{lambda}{body}", stmt.kind)
        })
        .collect::<Vec<_>>()
        .join(" ")
}

#[test]
fn declarations_get_their_kinds_and_names() {
    let source = "@tool\nclass_name Foo extends Node\nsignal done(a)\nenum Dir { UP, DOWN = 2 }\nenum { A }\n\
                  const MAX := 1\n@export var hp: int = 3\nstatic var count = 0\n\
                  class Inner:\n\tvar x\n\tfunc f(a, b = 1) -> void:\n\t\tfor i in a:\n\t\t\tpass\n\
                  static func g(): return 1\n";
    assert_eq!(
        shape(source).unwrap(),
        "Other ClassName(Foo) Signal(done) Enum(Dir) Enum Const(MAX) Var(hp) Var(count) \
         Class(Inner)[Var(x) Func(f)[For(i)[Pass]]] Func(g)[Return]"
    );
}

#[test]
fn control_flow_and_match_arms_nest() {
    let source = "func f(x):\n\tif x:\n\t\treturn 1\n\telif x > 2: return 2\n\telse:\n\t\tpass\n\
                  \tmatch x:\n\t\t1, 2:\n\t\t\tprint(1)\n\t\t_: pass\n\twhile true: break\n";
    assert_eq!(
        shape(source).unwrap(),
        "Func(f)[If[Return] Elif[Return] Else[Pass] Match[Arm[Other] Arm[Pass]] While[Other]]"
    );
}

#[test]
fn statements_split_at_semicolons_outside_brackets() {
    assert!(shape("var a = 1; var b = [1, 2]\n").is_some());
    assert_eq!(shape("a = 1; return; pass\n").unwrap(), "Other Return Pass");
    assert_eq!(shape("if a: b(); c()\n").unwrap(), "If[Other Other]");
}

#[test]
fn a_lambda_body_belongs_to_its_statement() {
    let source = "func f():\n\tvar g = func(x):\n\t\treturn x\n\tbar(1, func():\n\t\t\tprint(1)\n\t\t\treturn 2\n\t)\n\treturn 3\n";
    assert_eq!(shape(source).unwrap(), "Func(f)[Var(g)~[Return] Other Return]");
}

#[test]
fn structure_godot_rejects_gives_no_tree() {
    for source in [
        "\tvar a\n",
        "var a\n\tvar b\n",
        "func f():\nvar a\n",
        "if a:\n\tpass\n\t\tpass\n",
        "if a\n\tpass\n",
        "if a: pass\n\tpass\n",
    ] {
        let lexed = lex(source);
        assert!(parse(source, &lexed.tokens).is_none(), "{source:?}");
    }
}

#[test]
fn helpers_read_headers() {
    let source = "func f(a: Array[int] = [1, 2], b := 3, ...rest) -> void: pass\n\
                  enum E { X = 1 << 2, Y, Z, }\nconst A = preload(\"a.gd\")\nconst B := 1\n";
    let lexed = lex(source);
    let tree = parse(source, &lexed.tokens).unwrap();
    let names = |tokens: Vec<usize>| tokens.into_iter().map(|t| tree.text(t).to_owned()).collect::<Vec<_>>();
    assert_eq!(names(tree.params(&tree.block[0])), ["a", "b", "rest"]);
    assert_eq!(names(tree.enum_elements(&tree.block[1])), ["X", "Y", "Z"]);
    assert!(tree.loads_resource(&tree.block[2]));
    assert!(!tree.loads_resource(&tree.block[3]));
    assert_eq!(tree.functions().len(), 1);
}

#[test]
fn the_deepest_blocks_still_parse() {
    let mut deep = String::new();
    for level in 0..99 {
        deep.push_str(&"\t".repeat(level));
        deep.push_str("if a:\n");
    }
    deep.push_str(&"\t".repeat(99));
    deep.push_str("pass\n");
    let lexed = lex(&deep);
    assert!(lexed.error.is_none());
    assert!(parse(&deep, &lexed.tokens).is_some());
}

#[test]
fn a_typed_loop_variable_has_its_own_colon() {
    let source = "func f():\n\tfor key: String in data.keys():\n\t\tp(key)\n\tfor i in range(2): p(i)\n";
    assert_eq!(shape(source).unwrap(), "Func(f)[For(key)[Other] For(i)[Other]]");
}
