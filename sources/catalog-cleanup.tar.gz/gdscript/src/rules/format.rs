//! The rules that read lines: `trailing-whitespace`, `max-line-length`,
//! `max-file-lines` and `mixed-indentation`. They need no structure, so they
//! also run on a file the tokenizer could not read; only what the tokenizer
//! learned (multi-line strings, logical lines) is trusted, up to where it stopped.
use super::{Checked, Sink};
use crate::lexer::IndentFault;
use plugin_protocols::lint::Severity;

pub const TRAILING_WHITESPACE: &str = "trailing-whitespace";
pub const MAX_LINE_LENGTH: &str = "max-line-length";
pub const MAX_FILE_LINES: &str = "max-file-lines";
pub const MIXED_INDENTATION: &str = "mixed-indentation";

pub fn check(file: &Checked, sink: &mut Sink) {
    for fault in &file.lexed.faults {
        let message = match fault.kind {
            IndentFault::Mixed => {
                "This line is indented with both tabs and spaces, which Godot rejects. Indent with one of them."
                    .to_owned()
            }
            IndentFault::Switched { expected } => format!(
                "This line is indented with {}, but the first indentation in the file used {}, which Godot rejects. Use {} throughout.",
                name_of(other(expected)),
                name_of(expected),
                name_of(expected),
            ),
        };
        sink.report(
            MIXED_INDENTATION,
            Severity::Error,
            message,
            fault.start as usize..fault.end as usize,
        );
    }
    let horizon = file.lexed.error.map_or(u32::MAX, |error| error.at);
    for index in 0..file.lines.count() {
        if sink.full() {
            return;
        }
        let range = file.lines.text(index);
        let text = &file.source[range.clone()];
        long_line(file, sink, text, range.start);
        let kept = text.trim_end_matches([' ', '\t']).len();
        let from = range.start + kept;
        if kept < text.len() && (from as u32) < horizon && !in_string(file, from as u32) {
            sink.report_fixed(
                TRAILING_WHITESPACE,
                Severity::Warning,
                "The line ends with whitespace. Remove it.".to_owned(),
                from..range.end,
                ("remove the trailing whitespace", from..range.end, ""),
            );
        }
    }
    let count = file.lines.count();
    if count > file.options.max_file_lines {
        let line = file.lines.text(file.options.max_file_lines);
        sink.report(
            MAX_FILE_LINES,
            Severity::Warning,
            format!(
                "The file has {count} lines; the limit is {}. Split it into smaller scripts.",
                file.options.max_file_lines
            ),
            line,
        );
    }
}

fn long_line(file: &Checked, sink: &mut Sink, text: &str, offset: usize) {
    let (max, tab) = (file.options.max_line_length, file.options.tab_width);
    if text.len().saturating_mul(tab) <= max {
        return;
    }
    let mut width = 0usize;
    let mut over = None;
    for (at, c) in text.char_indices() {
        let advance = if c == '\t' { tab } else { 1 };
        if over.is_none() && width + advance > max {
            over = Some(at);
        }
        width += advance;
    }
    if width > max {
        sink.report(
            MAX_LINE_LENGTH,
            Severity::Warning,
            format!("The line is {width} characters wide; the limit is {max}. Break it up or shorten it."),
            offset + over.unwrap_or(0)..offset + text.len(),
        );
    }
}

/// Whether `at` is inside a string that spans lines (its lines are data).
fn in_string(file: &Checked, at: u32) -> bool {
    let strings = &file.lexed.multiline_strings;
    let before = strings.partition_point(|string| string.start <= at);
    before > 0 && at < strings[before - 1].end
}

fn name_of(indent: u8) -> &'static str {
    if indent == b'\t' { "tabs" } else { "spaces" }
}

fn other(indent: u8) -> u8 {
    if indent == b'\t' { b' ' } else { b'\t' }
}
