use crate::{
    config::{Naming, Options},
    gather::check_script,
    style::Style,
    testing::{Fake, fixed, found, rules_of},
};

fn with(options: Options, source: &str) -> Vec<String> {
    check_script("a.gd", source, &options, 1000)
        .into_iter()
        .map(|d| d.rule)
        .collect()
}

fn pair(rule: &str, text: &str) -> (String, String) {
    (rule.to_owned(), text.to_owned())
}

#[test]
fn trailing_whitespace_skips_string_interiors_and_line_breaks() {
    assert_eq!(found("var a = 1 \t\n"), [pair("trailing-whitespace", " \t")]);
    assert_eq!(found("func f():\n\tpass  \n"), [pair("trailing-whitespace", "  ")]);
    assert_eq!(found("var a = 1\r\nvar b = 2\r\n"), []);
    assert_eq!(found("var a = \"\"\"x  \n  \n\"\"\"\n"), []);
    // After the closing quotes it counts again, and so does a comment.
    assert_eq!(
        found("var a = \"\"\"x\n\"\"\"  \n"),
        [pair("trailing-whitespace", "  ")]
    );
    assert_eq!(found("# note \nvar a = [1, \n2]\n").len(), 2);
    assert_eq!(fixed("var a = 1 \nvar b = 2\t\n  \n"), "var a = 1\nvar b = 2\n\n");
}

#[test]
fn line_length_counts_characters_and_tabs() {
    let long = format!("var a = \"{}\"\n", "x".repeat(95));
    assert_eq!(rules_of(&long), ["max-line-length"]);
    assert_eq!(found(&long)[0].1, "xxxx\"");
    assert!(rules_of(&format!("var a = \"{}\"\n", "x".repeat(90))).is_empty());
    // Non-ASCII characters count once, a tab counts `tab-width`.
    assert!(rules_of(&format!("# {}\n", "\u{4e2d}".repeat(97))).is_empty());
    let tabs = format!(
        "func f():\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{}\n",
        "x".repeat(10)
    );
    assert_eq!(rules_of(&tabs), ["max-line-length"]);
    let options = Options {
        max_line_length: 120,
        ..Options::default()
    };
    assert!(with(options, &long).is_empty());
}

#[test]
fn file_length_reports_the_first_line_over() {
    let options = Options {
        max_file_lines: 3,
        ..Options::default()
    };
    assert!(with(options, "a\nb\nc\n").is_empty());
    assert_eq!(with(options, "a\nb\nc\nd\n"), ["max-file-lines"]);
}

#[test]
fn mixed_indentation_is_an_error_and_stops_the_structure_rules() {
    assert_eq!(found("func f():\n\t pass\n"), [pair("mixed-indentation", "\t ")]);
    let switched = "func f():\n\tvar x = 1\n\nfunc g(Bad):\n    pass\n";
    assert_eq!(rules_of(switched), ["mixed-indentation"]);
    assert!(rules_of("func f():\n\tvar x = foo(1,\n\t  2)\n\t# note\n  # note\n\tprint(x)\n").is_empty());
}

#[test]
fn an_unreadable_file_runs_only_the_line_rules() {
    // Unterminated string: the bad name is not reported, the long line is.
    let source = format!("var BadName = 1\nvar s = \"{}\n", "x".repeat(120));
    assert_eq!(rules_of(&source), ["max-line-length"]);
    assert_eq!(rules_of("var BadName = (1,\n"), Vec::<String>::new());
    // Whitespace after the point the lexer gave up is not trusted.
    assert!(rules_of("var s = \"\"\"abc\n  \n").is_empty());
    assert_eq!(rules_of("var a = 1 \nvar s = \"\"\"abc\n  \n"), ["trailing-whitespace"]);
    // So is a broken block structure.
    assert_eq!(rules_of("var BadName = 1\nif a\n\tpass\n"), Vec::<String>::new());
}

#[test]
fn names_are_judged_per_kind() {
    let source = "class_name bad_class\nextends Node\nsignal BadSignal\nenum bad_enum { lower, UPPER }\n\
                  const lower_const = 1\nconst Pre = preload(\"a.gd\")\nconst Loose = 1\nvar BadVar\n\
                  class bad_inner:\n\tvar Ok_not\nfunc BadFunc(BadArg, _Fine, good):\n\tvar BadLocal\n\tfor Bad in good:\n\t\tpass\n\
                  \tvar f = func(NotJudged): return NotJudged\n";
    let rules: Vec<(String, String)> = found(source).into_iter().filter(|(r, _)| r.ends_with("name")).collect();
    assert_eq!(
        rules,
        [
            pair("class-name", "bad_class"),
            pair("signal-name", "BadSignal"),
            pair("enum-name", "bad_enum"),
            pair("enum-element-name", "lower"),
            pair("constant-name", "lower_const"),
            pair("constant-name", "Loose"),
            pair("class-variable-name", "BadVar"),
            pair("sub-class-name", "bad_inner"),
            pair("class-variable-name", "Ok_not"),
            pair("function-name", "BadFunc"),
            pair("function-argument-name", "BadArg"),
            pair("function-argument-name", "_Fine"),
            pair("function-variable-name", "BadLocal"),
            pair("loop-variable-name", "Bad"),
        ]
    );
    assert!(
        rules_of("class_name HTTPClient\nvar _x2\nvar \u{53d8}\u{91cf}\nfunc _ready(): pass\nconst A_B = 1\n")
            .is_empty()
    );
}

#[test]
fn the_naming_styles_are_configurable() {
    let options = Options {
        naming: Naming {
            function: Style::Pascal,
            constant: Style::Snake,
            ..Naming::default()
        },
        ..Options::default()
    };
    assert_eq!(
        with(
            options,
            "func MyFunc(): pass\nfunc other(): pass\nconst a_b = 1\nconst A_B = 2\n"
        ),
        ["function-name", "constant-name"]
    );
}

#[test]
fn a_pass_beside_other_statements_is_unnecessary() {
    assert_eq!(rules_of("func f():\n\tpass\n"), Vec::<String>::new());
    assert_eq!(rules_of("func f():\n\tpass\n\tpass\n"), Vec::<String>::new());
    assert_eq!(
        found("func f():\n\tpass\n\tprint(1)\n"),
        [pair("unnecessary-pass", "pass")]
    );
    assert_eq!(rules_of("if a:\n\tpass\nelse:\n\tprint(1)\n"), Vec::<String>::new());
    assert_eq!(
        fixed("func f():\n\tpass # todo\n\tprint(1)\n\tpass\n"),
        "func f():\n\tprint(1)\n"
    );
    // On a shared line there is no fix.
    let source = "func f():\n\tprint(1); pass\n";
    assert_eq!(found(source), [pair("unnecessary-pass", "pass")]);
    assert_eq!(fixed(source), source);
    assert_eq!(fixed("func f():\n\tprint(1)\r\n\tpass"), "func f():\n\tprint(1)\r\n");
}

#[test]
fn a_literal_path_loaded_twice_is_reported_from_the_second_load() {
    let source = "const A = preload(\"res://a.gd\")\nvar b = load('res://b.gd')\nfunc f():\n\treturn load(\"res://a.gd\")\n\
                  func g(path):\n\treturn load(path) + ResourceLoader.load(\"res://b.gd\") + load(\"res://b.gd\")\n";
    assert_eq!(
        found(source),
        [
            pair("duplicated-load", "load(\"res://a.gd\")"),
            pair("duplicated-load", "load(\"res://b.gd\")")
        ]
    );
}

#[test]
fn an_unused_argument_is_renamed_unless_the_name_is_taken() {
    let source = "func f(used, unused, _ok):\n\treturn used\n";
    assert_eq!(found(source), [pair("unused-argument", "unused")]);
    assert_eq!(fixed(source), "func f(used, _unused, _ok):\n\treturn used\n");
    // Used by a nested lambda: used.
    assert!(rules_of("func f(a):\n\treturn func(): return a\n").is_empty());
    let taken = "func f(a, _a):\n\tprint(_a)\n";
    assert_eq!(found(taken), [pair("unused-argument", "a")]);
    assert_eq!(fixed(taken), taken);
    assert_eq!(found("func f(a): pass\n"), [pair("unused-argument", "a")]);
}

#[test]
fn design_limits_come_from_the_options() {
    let options = Options {
        function_arguments_number: 2,
        max_returns: 2,
        max_public_methods: 1,
        ..Options::default()
    };
    let source = "class_name X\nfunc a(p, q, r):\n\tif p:\n\t\treturn 1\n\tif q:\n\t\treturn 2\n\
                  \tvar l = func(): return 3\n\treturn r\nfunc b(): pass\nfunc _c(): pass\n\
                  class In:\n\tfunc d(): pass\n\tfunc e(): pass\n";
    assert_eq!(
        with(options, source),
        [
            "function-arguments-number",
            "max-returns",
            "max-public-methods",
            "max-public-methods"
        ]
    );
    let defaults = rules_of(source);
    assert!(defaults.is_empty(), "{defaults:?}");
}

#[test]
fn comments_suppress_diagnostics() {
    let source = "var a = 1 \n# gdlint: ignore=trailing-whitespace\nvar b = 1 \nvar c = 1 # gdlint: ignore=gdscript/trailing-whitespace\n\
                  var d = 1 \n# gdlint: disable=trailing-whitespace\nvar e = 1 \n# gdlint: enable=trailing-whitespace\nvar f = 1 \n";
    let lines: Vec<usize> = Fake::new(&[("a.gd", source)])
        .lint()
        .into_iter()
        .map(|d| source[..d.span.unwrap().start as usize].matches('\n').count() + 1)
        .collect();
    assert_eq!(lines, [1, 5, 9]);
}

#[test]
fn a_fix_inside_a_deleted_line_is_not_offered_twice() {
    let source = "func f():\n\tprint(1)\n\tpass   \n";
    assert_eq!(rules_of(source), ["unnecessary-pass", "trailing-whitespace"]);
    assert_eq!(fixed(source), "func f():\n\tprint(1)\n");
}

#[test]
fn abstract_declarations_have_no_body() {
    assert!(rules_of("@abstract class Base:\n\t@abstract func area() -> float\n\tfunc other(): pass\n").is_empty());
    assert_eq!(
        rules_of("@abstract func BadName()\nvar BadVar\n"),
        ["class-variable-name"]
    );
}

#[test]
fn an_argument_used_in_another_default_value_is_used() {
    assert!(rules_of("func f(a, b = a):\n\tprint(b)\n").is_empty());
}
