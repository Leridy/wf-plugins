//! The naming rules: each declared name is judged against the style its kind
//! has in the options. Lambda parameters and `match` bindings are not judged.
use super::{Checked, Sink};
use crate::{
    block::{Block, Stmt, StmtKind, Tree},
    style::Style,
};
use plugin_protocols::lint::Severity;

#[derive(Clone, Copy, PartialEq)]
enum Scope {
    Class,
    Function,
}

pub fn check(file: &Checked, tree: &Tree, sink: &mut Sink) {
    walk(file, tree, &tree.block, Scope::Class, sink);
}

fn walk(file: &Checked, tree: &Tree, block: &Block, scope: Scope, sink: &mut Sink) {
    let naming = &file.options.naming;
    for stmt in block {
        if sink.full() {
            return;
        }
        match stmt.kind {
            StmtKind::ClassName => judge(tree, sink, stmt.name, "class-name", "Class name", naming.class),
            StmtKind::Class => judge(
                tree,
                sink,
                stmt.name,
                "sub-class-name",
                "Inner class name",
                naming.sub_class,
            ),
            StmtKind::Func => {
                judge(tree, sink, stmt.name, "function-name", "Function name", naming.function);
                for param in tree.params(stmt) {
                    judge(
                        tree,
                        sink,
                        Some(param),
                        "function-argument-name",
                        "Argument name",
                        naming.function_argument,
                    );
                }
            }
            StmtKind::Signal => judge(tree, sink, stmt.name, "signal-name", "Signal name", naming.signal),
            StmtKind::Enum => enumeration(file, tree, stmt, sink),
            StmtKind::Const => constant(file, tree, stmt, sink),
            StmtKind::Var if scope == Scope::Class => {
                judge(
                    tree,
                    sink,
                    stmt.name,
                    "class-variable-name",
                    "Class variable name",
                    naming.class_variable,
                );
            }
            StmtKind::Var => {
                judge(
                    tree,
                    sink,
                    stmt.name,
                    "function-variable-name",
                    "Variable name",
                    naming.function_variable,
                );
            }
            StmtKind::For => judge(
                tree,
                sink,
                stmt.name,
                "loop-variable-name",
                "Loop variable name",
                naming.loop_variable,
            ),
            _ => {}
        }
        if let Some(body) = &stmt.body {
            let inner = match stmt.kind {
                StmtKind::Class => Scope::Class,
                StmtKind::Func => Scope::Function,
                _ if stmt.lambda => Scope::Function,
                _ => scope,
            };
            walk(file, tree, body, inner, sink);
        }
    }
}

fn enumeration(file: &Checked, tree: &Tree, stmt: &Stmt, sink: &mut Sink) {
    let naming = &file.options.naming;
    judge(tree, sink, stmt.name, "enum-name", "Enum name", naming.enum_name);
    for element in tree.enum_elements(stmt) {
        judge(
            tree,
            sink,
            Some(element),
            "enum-element-name",
            "Enum element name",
            naming.enum_element,
        );
    }
}

/// A constant that holds a loaded resource may be named like a class.
fn constant(file: &Checked, tree: &Tree, stmt: &Stmt, sink: &mut Sink) {
    let Some(name) = stmt.name else {
        return;
    };
    let style = file.options.naming.constant;
    if tree.loads_resource(stmt) && Style::Pascal.accepts(tree.text(name)) {
        return;
    }
    judge(tree, sink, Some(name), "constant-name", "Constant name", style);
}

fn judge(tree: &Tree, sink: &mut Sink, name: Option<usize>, rule: &str, what: &str, style: Style) {
    let Some(index) = name else {
        return;
    };
    let text = tree.text(index);
    if !style.accepts(text) {
        let token = tree.tokens[index];
        sink.report(
            rule,
            Severity::Warning,
            format!("{what} {} should be {}.", plugin_guest::quoted(text, 60), style.label()),
            token.start as usize..token.end as usize,
        );
    }
}
