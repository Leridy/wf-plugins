//! `function-arguments-number`, `max-returns` and `max-public-methods`.
use super::{Checked, Sink, tokens_span};
use crate::block::{Stmt, StmtKind, Tree};
use plugin_protocols::lint::Severity;

pub const FUNCTION_ARGUMENTS_NUMBER: &str = "function-arguments-number";
pub const MAX_RETURNS: &str = "max-returns";
pub const MAX_PUBLIC_METHODS: &str = "max-public-methods";

pub fn check(file: &Checked, tree: &Tree, sink: &mut Sink) {
    for func in tree.functions() {
        if sink.full() {
            return;
        }
        let Some(name) = func.name else {
            continue;
        };
        let span = tokens_span(tree, name, name + 1);
        let arguments = tree.params(func).len();
        if arguments > file.options.function_arguments_number {
            sink.report(
                FUNCTION_ARGUMENTS_NUMBER,
                Severity::Warning,
                format!(
                    "{} takes {arguments} arguments; the limit is {}. Group some of them or split the function.",
                    plugin_guest::quoted(tree.text(name), 60),
                    file.options.function_arguments_number
                ),
                span.clone(),
            );
        }
        let returns = returns(func.body.as_deref().unwrap_or_default());
        if returns > file.options.max_returns {
            sink.report(
                MAX_RETURNS,
                Severity::Warning,
                format!(
                    "{} has {returns} `return` statements; the limit is {}. Simplify its control flow.",
                    plugin_guest::quoted(tree.text(name), 60),
                    file.options.max_returns
                ),
                span,
            );
        }
    }
    public_methods(file, tree, tree.anchor(), &tree.block, sink);
}

/// The `return` statements of a block and the blocks nested in it, not those
/// of a lambda.
fn returns(block: &[Stmt]) -> usize {
    block
        .iter()
        .map(|stmt| {
            let own = usize::from(stmt.kind == StmtKind::Return);
            let nested = stmt.body.as_deref().filter(|_| !stmt.lambda).map_or(0, returns);
            own + nested
        })
        .sum()
}

/// A class with too many public methods is reported once, where it is
/// declared; inner classes count their own.
fn public_methods(file: &Checked, tree: &Tree, anchor: Option<&Stmt>, block: &[Stmt], sink: &mut Sink) {
    let public = block
        .iter()
        .filter(|stmt| stmt.kind == StmtKind::Func)
        .filter(|stmt| stmt.name.is_some_and(|name| !tree.text(name).starts_with('_')))
        .count();
    let max = file.options.max_public_methods;
    if public > max
        && let Some(anchor) = anchor
    {
        let (from, to) = anchor.name.map_or((anchor.start, anchor.end), |name| (name, name + 1));
        sink.report(
            MAX_PUBLIC_METHODS,
            Severity::Warning,
            format!("This class has {public} public methods; the limit is {max}. Split it into smaller classes."),
            tokens_span(tree, from, to),
        );
    }
    for stmt in block.iter().filter(|stmt| stmt.kind == StmtKind::Class) {
        if let Some(body) = &stmt.body {
            public_methods(file, tree, Some(stmt), body, sink);
        }
    }
}
