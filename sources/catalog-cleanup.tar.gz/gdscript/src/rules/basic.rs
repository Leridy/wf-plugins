//! `unnecessary-pass`, `duplicated-load` and `unused-argument`.
use super::{Checked, Sink, tokens_span};
use crate::{
    block::{Block, Stmt, StmtKind, Tree},
    lexer::Kind,
};
use plugin_protocols::lint::Severity;
use std::{collections::HashMap, ops::Range};

pub const UNNECESSARY_PASS: &str = "unnecessary-pass";
pub const DUPLICATED_LOAD: &str = "duplicated-load";
pub const UNUSED_ARGUMENT: &str = "unused-argument";

pub fn check(file: &Checked, tree: &Tree, sink: &mut Sink) {
    passes(file, tree, &tree.block, sink);
    duplicated_loads(file, tree, sink);
    for func in tree.functions() {
        if sink.full() {
            return;
        }
        unused_arguments(tree, func, sink);
    }
}

/// A `pass` in a block that holds other statements. The fix deletes its line
/// when it holds nothing but the `pass` and a comment.
fn passes(file: &Checked, tree: &Tree, block: &Block, sink: &mut Sink) {
    let others = block.iter().any(|stmt| stmt.kind != StmtKind::Pass);
    for stmt in block {
        if sink.full() {
            return;
        }
        if others && stmt.kind == StmtKind::Pass {
            let span = tokens_span(tree, stmt.start, stmt.end);
            let message = "`pass` does nothing in a block that has other statements. Remove it.".to_owned();
            match own_line(file, &span) {
                Some(line) => sink.report_fixed(
                    UNNECESSARY_PASS,
                    Severity::Warning,
                    message,
                    span,
                    ("delete the line with `pass`", line, ""),
                ),
                None => sink.report(UNNECESSARY_PASS, Severity::Warning, message, span),
            }
        }
        if let Some(body) = &stmt.body {
            passes(file, tree, body, sink);
        }
    }
}

/// The line (with its line break) that holds only the statement at `span` and
/// perhaps a comment.
fn own_line(file: &Checked, span: &Range<usize>) -> Option<Range<usize>> {
    let line = file.lines.around(span.start as u32);
    let before = &file.source[line.start..span.start];
    let after = file.source[span.end..line.end].trim_start_matches([' ', '\t']);
    let alone = before.trim_matches([' ', '\t']).is_empty() && (after.starts_with('#') || after.trim().is_empty());
    alone.then_some(line)
}

/// Loads of the same literal path: every one after the first is reported.
fn duplicated_loads(file: &Checked, tree: &Tree, sink: &mut Sink) {
    let mut seen: HashMap<&str, usize> = HashMap::new();
    let tokens = tree.tokens;
    for i in 0..tokens.len().saturating_sub(3) {
        if sink.full() {
            return;
        }
        let call = tree.text(i);
        let literal = tokens[i + 2];
        let plain = literal.kind == Kind::Str && !tree.text(i + 2).starts_with(['r', '&', '^']);
        if tokens[i].kind != Kind::Ident
            || !matches!(call, "load" | "preload")
            || !tree.is(i + 1, "(")
            || !plain
            || !tree.is(i + 3, ")")
            || (i > 0 && tree.is(i - 1, "."))
        {
            continue;
        }
        let text = tree.text(i + 2);
        let path = text.trim_matches(['"', '\'']);
        match seen.get(path) {
            None => {
                seen.insert(path, file.lines.line_of(tokens[i].start));
            }
            Some(&first) => sink.report(
                DUPLICATED_LOAD,
                Severity::Warning,
                format!(
                    "{} is already loaded on line {first}. Load it once and reuse the result.",
                    plugin_guest::quoted(path, 80)
                ),
                tokens_span(tree, i, i + 4),
            ),
        }
    }
}

/// A parameter whose name appears nowhere else in the function (body and
/// default values of other parameters included). The fix
/// renames it with a leading `_` unless that name is taken.
fn unused_arguments(tree: &Tree, func: &Stmt, sink: &mut Sink) {
    let params = tree.params(func);
    if params.is_empty() {
        return;
    }
    // Every identifier of the whole function, default values included; the
    // declaring token of a parameter is the one use that does not count.
    let mut seen: HashMap<&str, usize> = HashMap::new();
    for i in (func.start..func.span_end).filter(|&i| tree.tokens[i].kind == Kind::Ident) {
        *seen.entry(tree.text(i)).or_default() += 1;
    }
    let function = func.name.map_or("", |name| tree.text(name));
    for param in params {
        let name = tree.text(param);
        if name.starts_with('_') || seen.get(name).is_some_and(|&n| n > 1) {
            continue;
        }
        let token = tree.tokens[param];
        let span = token.start as usize..token.end as usize;
        let message = format!(
            "Argument {} of {} is never used. Rename it to `_{name}` to say so, or remove it.",
            plugin_guest::quoted(name, 60),
            plugin_guest::quoted(function, 60),
        );
        let renamed = format!("_{name}");
        if seen.contains_key(renamed.as_str()) {
            sink.report(UNUSED_ARGUMENT, Severity::Warning, message, span);
        } else {
            let summary = format!("rename it to `{renamed}`");
            sink.report_fixed(
                UNUSED_ARGUMENT,
                Severity::Warning,
                message,
                span.clone(),
                (&summary, span, &renamed),
            );
        }
        if sink.full() {
            return;
        }
    }
}
