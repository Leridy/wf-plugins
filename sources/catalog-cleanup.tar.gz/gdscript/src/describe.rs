//! What `describe()` returns: one capability, `lint`, that implements `wf.lint/1`.
use plugin_api::{Capability, Description, Example, Risk};
use plugin_protocols::lint::{LintInput, LintOutput, PROTOCOL};
use schemars::{JsonSchema, schema_for};
use serde_json::Value;

pub const OP: &str = "lint";

pub fn description() -> Description {
    Description {
        capabilities: vec![Capability {
            op: OP.to_owned(),
            summary: "Lint GDScript style and quality".to_owned(),
            when: "Use it to find style and quality problems in GDScript files: trailing whitespace, long lines and files, \
                   mixed tabs and spaces, names that break the naming style, an unnecessary `pass`, a script loaded \
                   twice, unused function arguments and functions that are too long or too wide. Options are read \
                   from `gdscript-lint.toml`, and `# gdlint: ignore=rule` comments suppress a finding. The `lint` \
                   command runs it with the other linters."
                .to_owned(),
            risk: Risk::Read,
            input: schema::<LintInput>(),
            output: Some(schema::<LintOutput>()),
            examples: vec![
                Example {
                    args: "lint".to_owned(),
                    note: "check every GDScript file under the project root".to_owned(),
                },
                Example {
                    args: "lint --paths scripts --paths player.gd".to_owned(),
                    note: "report only on these files and directories".to_owned(),
                },
            ],
            implements: Some(PROTOCOL.to_owned()),
        }],
    }
}

fn schema<T: JsonSchema>() -> Value {
    serde_json::to_value(schema_for!(T)).expect("a schema serializes")
}

#[cfg(test)]
mod tests {
    use super::*;
    use plugin_api::is_name;

    #[test]
    fn declares_one_read_only_lint_capability() {
        let description = description();
        let [capability] = description.capabilities.as_slice() else {
            panic!("exactly one capability")
        };
        assert!(is_name(&capability.op));
        assert_eq!(capability.implements.as_deref(), Some("wf.lint/1"));
        assert_eq!(capability.risk, Risk::Read);
        assert!(!capability.examples.is_empty());
        assert_eq!(capability.input["properties"]["paths"]["type"], "array");
        assert!(capability.output.is_some());
        assert!(is_name("gdscript"));
    }
}
