//! The options of `gdscript-lint.toml`. A script uses the nearest file from
//! its own directory up; the files are not merged. A file that does not parse,
//! or holds a key this plugin does not know, is `invalid-config` and the
//! defaults apply below it.
use crate::style::Style;
use serde::Deserialize;
use std::{collections::BTreeSet, ops::Range};

pub const CONFIG_FILE: &str = "gdscript-lint.toml";

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Naming {
    pub class: Style,
    pub sub_class: Style,
    pub enum_name: Style,
    pub enum_element: Style,
    pub function: Style,
    pub signal: Style,
    pub class_variable: Style,
    pub function_variable: Style,
    pub function_argument: Style,
    pub loop_variable: Style,
    pub constant: Style,
}

impl Default for Naming {
    fn default() -> Self {
        Self {
            class: Style::Pascal,
            sub_class: Style::Pascal,
            enum_name: Style::Pascal,
            enum_element: Style::Constant,
            function: Style::Snake,
            signal: Style::Snake,
            class_variable: Style::Snake,
            function_variable: Style::Snake,
            function_argument: Style::Snake,
            loop_variable: Style::Snake,
            constant: Style::Constant,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Options {
    pub max_line_length: usize,
    pub tab_width: usize,
    pub max_file_lines: usize,
    pub function_arguments_number: usize,
    pub max_returns: usize,
    pub max_public_methods: usize,
    pub naming: Naming,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            max_line_length: 100,
            tab_width: 4,
            max_file_lines: 1000,
            function_arguments_number: 10,
            max_returns: 6,
            max_public_methods: 20,
            naming: Naming::default(),
        }
    }
}

/// Why a file was not used: the message, and where in the file when known.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ConfigError {
    pub message: String,
    pub span: Option<Range<usize>>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields, rename_all = "kebab-case")]
struct File {
    max_line_length: Option<usize>,
    tab_width: Option<usize>,
    max_file_lines: Option<usize>,
    function_arguments_number: Option<usize>,
    max_returns: Option<usize>,
    max_public_methods: Option<usize>,
    #[serde(default)]
    naming: Styles,
}

#[derive(Default, Deserialize)]
#[serde(deny_unknown_fields, rename_all = "kebab-case")]
struct Styles {
    class: Option<Style>,
    sub_class: Option<Style>,
    #[serde(rename = "enum")]
    enum_name: Option<Style>,
    enum_element: Option<Style>,
    function: Option<Style>,
    signal: Option<Style>,
    class_variable: Option<Style>,
    function_variable: Option<Style>,
    function_argument: Option<Style>,
    loop_variable: Option<Style>,
    constant: Option<Style>,
}

/// The options a `gdscript-lint.toml` text sets over the defaults.
pub fn parse(text: &str) -> Result<Options, ConfigError> {
    let file: File = toml::from_str(text).map_err(|e| ConfigError {
        message: e.message().trim().to_owned(),
        span: e.span(),
    })?;
    let defaults = Options::default();
    let limit = |name: &str, value: Option<usize>, default: usize| match value {
        Some(0) => Err(ConfigError {
            message: format!("`{name}` must be at least 1"),
            span: None,
        }),
        Some(value) => Ok(value),
        None => Ok(default),
    };
    let base = defaults.naming;
    let naming = file.naming;
    Ok(Options {
        max_line_length: limit("max-line-length", file.max_line_length, defaults.max_line_length)?,
        tab_width: limit("tab-width", file.tab_width, defaults.tab_width)?,
        max_file_lines: limit("max-file-lines", file.max_file_lines, defaults.max_file_lines)?,
        function_arguments_number: limit(
            "function-arguments-number",
            file.function_arguments_number,
            defaults.function_arguments_number,
        )?,
        max_returns: limit("max-returns", file.max_returns, defaults.max_returns)?,
        max_public_methods: limit(
            "max-public-methods",
            file.max_public_methods,
            defaults.max_public_methods,
        )?,
        naming: Naming {
            class: naming.class.unwrap_or(base.class),
            sub_class: naming.sub_class.unwrap_or(base.sub_class),
            enum_name: naming.enum_name.unwrap_or(base.enum_name),
            enum_element: naming.enum_element.unwrap_or(base.enum_element),
            function: naming.function.unwrap_or(base.function),
            signal: naming.signal.unwrap_or(base.signal),
            class_variable: naming.class_variable.unwrap_or(base.class_variable),
            function_variable: naming.function_variable.unwrap_or(base.function_variable),
            function_argument: naming.function_argument.unwrap_or(base.function_argument),
            loop_variable: naming.loop_variable.unwrap_or(base.loop_variable),
            constant: naming.constant.unwrap_or(base.constant),
        },
    })
}

/// The config file that applies to a script: the nearest `gdscript-lint.toml`
/// in its directory or above, among `configs` (project-relative paths).
pub fn nearest<'a>(configs: &'a BTreeSet<String>, script: &str) -> Option<&'a str> {
    let mut directory = script;
    loop {
        directory = directory.rsplit_once('/').map_or("", |(parent, _)| parent);
        let candidate = if directory.is_empty() {
            CONFIG_FILE.to_owned()
        } else {
            format!("{directory}/{CONFIG_FILE}")
        };
        if let Some(found) = configs.get(&candidate) {
            return Some(found);
        }
        if directory.is_empty() {
            return None;
        }
    }
}

#[cfg(test)]
mod tests;
