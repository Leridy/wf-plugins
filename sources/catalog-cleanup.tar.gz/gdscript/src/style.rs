//! The three name styles and how a name is judged against one. No regular
//! expressions: each style is a few lines over the characters.
use serde::Deserialize;

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq)]
pub enum Style {
    #[serde(rename = "snake_case")]
    Snake,
    #[serde(rename = "PascalCase")]
    Pascal,
    #[serde(rename = "CONSTANT_CASE")]
    Constant,
}

impl Style {
    pub fn label(self) -> &'static str {
        match self {
            Self::Snake => "snake_case",
            Self::Pascal => "PascalCase",
            Self::Constant => "CONSTANT_CASE",
        }
    }

    /// Whether `name` is in this style. Names of other scripts (non-ASCII) and
    /// names of underscores only are not judged.
    pub fn accepts(self, name: &str) -> bool {
        if !name.is_ascii() || name.bytes().all(|b| b == b'_') {
            return true;
        }
        match self {
            Self::Snake => words(name, |b| b.is_ascii_lowercase() || b.is_ascii_digit()),
            Self::Constant => words(name, |b| b.is_ascii_uppercase() || b.is_ascii_digit()),
            Self::Pascal => pascal(name),
        }
    }
}

/// `_*` then groups of `allowed` bytes joined by single underscores.
fn words(name: &str, allowed: fn(u8) -> bool) -> bool {
    let body = name.trim_start_matches('_');
    !body.is_empty()
        && body
            .split('_')
            .all(|word| !word.is_empty() && word.bytes().all(allowed))
}

/// `_?` then an uppercase letter and letters and digits.
fn pascal(name: &str) -> bool {
    let body = name.strip_prefix('_').unwrap_or(name);
    body.bytes().next().is_some_and(|b| b.is_ascii_uppercase()) && body.bytes().all(|b| b.is_ascii_alphanumeric())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn each_style_judges_its_own_names() {
        for ok in ["foo", "_foo", "__foo_bar2", "a1_b2", "_2d"] {
            assert!(Style::Snake.accepts(ok), "{ok}");
        }
        for bad in ["Foo", "fooBar", "foo__bar", "foo_", "foo-bar"] {
            assert!(!Style::Snake.accepts(bad), "{bad}");
        }
        for ok in ["FOO", "_FOO", "MAX_SPEED_2", "A"] {
            assert!(Style::Constant.accepts(ok), "{ok}");
        }
        for bad in ["Foo", "FOO_", "foo", "MAX__SPEED"] {
            assert!(!Style::Constant.accepts(bad), "{bad}");
        }
        for ok in ["Foo", "_Foo", "HTTPClient", "Foo2D", "A"] {
            assert!(Style::Pascal.accepts(ok), "{ok}");
        }
        for bad in ["foo", "Foo_Bar", "_", "foo_bar", "Foo-"] {
            // `_` alone is not judged at all.
            assert_eq!(Style::Pascal.accepts(bad), bad == "_", "{bad}");
        }
    }

    #[test]
    fn other_scripts_and_bare_underscores_pass() {
        assert!(Style::Snake.accepts("\u{53d8}\u{91cf}"));
        assert!(Style::Constant.accepts("_"));
        assert!(Style::Snake.accepts("__"));
    }
}
