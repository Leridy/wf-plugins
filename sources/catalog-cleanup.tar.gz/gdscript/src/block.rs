//! The statement and block layer above the tokenizer: each statement's kind
//! and token range, the names a declaration header introduces, and blocks
//! composed into a tree, so a class scope differs from a function scope.
//! There is no expression syntax tree; an expression is just the tokens of
//! its statement. A block structure Godot would reject (an unexpected indent, a
//! header without its block) is no tree at all.
use crate::lexer::{Kind, Token};
use std::ops::Range;

/// Deepest nesting of blocks the layer follows.
const MAX_DEPTH: usize = 100;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StmtKind {
    ClassName,
    Extends,
    Class,
    Func,
    Signal,
    Enum,
    Const,
    Var,
    Pass,
    Return,
    If,
    Elif,
    Else,
    For,
    While,
    Match,
    /// One `pattern:` arm of a `match`.
    Arm,
    Other,
}

impl StmtKind {
    /// Whether a header ends in `:` and owns a block.
    fn is_compound(self) -> bool {
        matches!(
            self,
            Self::Class
                | Self::Func
                | Self::If
                | Self::Elif
                | Self::Else
                | Self::For
                | Self::While
                | Self::Match
                | Self::Arm
        )
    }
}

pub type Block = Vec<Stmt>;

#[derive(Debug)]
pub struct Stmt {
    pub kind: StmtKind,
    /// Token indices: the first token (annotations included) and one past the
    /// header's last token (the `:` of a compound statement is excluded).
    pub start: usize,
    pub end: usize,
    /// One past the last token of the whole statement, its block included.
    pub span_end: usize,
    /// The declared name: a class, function, signal, enum, constant,
    /// variable or loop variable.
    pub name: Option<usize>,
    pub body: Option<Block>,
    /// The body is that of a lambda in an expression statement
    /// (`var f = func(x):` and its indented lines), not of a header.
    pub lambda: bool,
}

pub struct Tree<'a> {
    pub source: &'a str,
    pub tokens: &'a [Token],
    pub block: Block,
}

/// The block structure of a lexed file, or `None` when Godot would reject it.
pub fn parse<'a>(source: &'a str, tokens: &'a [Token]) -> Option<Tree<'a>> {
    let mut parser = Parser { source, tokens, at: 0 };
    let block = parser.block(StmtKind::Other, 0)?;
    (parser.at >= tokens.len()).then_some(Tree { source, tokens, block })
}

impl Tree<'_> {
    pub fn text(&self, index: usize) -> &str {
        self.tokens[index].text(self.source)
    }

    pub fn is(&self, index: usize, text: &str) -> bool {
        self.tokens.get(index).is_some_and(|t| t.text(self.source) == text)
    }

    /// Every function declared in a class scope: the script's and its inner classes'.
    pub fn functions(&self) -> Vec<&Stmt> {
        fn collect<'t>(block: &'t [Stmt], found: &mut Vec<&'t Stmt>) {
            for stmt in block {
                match (stmt.kind, &stmt.body) {
                    (StmtKind::Func, _) => found.push(stmt),
                    (StmtKind::Class, Some(body)) => collect(body, found),
                    _ => {}
                }
            }
        }
        let mut found = Vec::new();
        collect(&self.block, &mut found);
        found
    }

    /// The statement a script-wide finding is reported on: its `class_name` or
    /// `extends` line, else its first statement.
    pub fn anchor(&self) -> Option<&Stmt> {
        let header = |stmt: &&Stmt| matches!(stmt.kind, StmtKind::ClassName | StmtKind::Extends);
        self.block.iter().find(header).or(self.block.first())
    }

    /// The name tokens of a function's parameters, in order.
    pub fn params(&self, func: &Stmt) -> Vec<usize> {
        let Some(open) = func.name.map(|name| name + 1).filter(|&open| self.is(open, "(")) else {
            return Vec::new();
        };
        self.segments(open, func.end)
            .into_iter()
            .filter_map(|s| self.first_ident(s))
            .collect()
    }

    /// The element name tokens of an enum.
    pub fn enum_elements(&self, decl: &Stmt) -> Vec<usize> {
        let Some(open) = (decl.start..decl.end).find(|&i| self.is(i, "{")) else {
            return Vec::new();
        };
        self.segments(open, decl.end)
            .into_iter()
            .filter_map(|s| self.first_ident(s))
            .collect()
    }

    /// Whether a constant's value begins with a `preload(` or `load(` call.
    pub fn loads_resource(&self, decl: &Stmt) -> bool {
        let Some(name) = decl.name else {
            return false;
        };
        let value = (name + 1..decl.end).find(|&i| self.is(i, "=") || self.is(i, ":="));
        value.is_some_and(|i| (self.is(i + 1, "preload") || self.is(i + 1, "load")) && self.is(i + 2, "("))
    }

    /// The token ranges between the commas directly inside the bracket at
    /// `open`, up to its closer (empty segments left out).
    fn segments(&self, open: usize, limit: usize) -> Vec<Range<usize>> {
        let mut found = Vec::new();
        let mut depth = 0usize;
        let mut from = open + 1;
        for i in open..limit.min(self.tokens.len()) {
            match self.depth_change(i) {
                1 => depth += 1,
                -1 => {
                    depth = depth.saturating_sub(1);
                    if depth == 0 {
                        found.push(from..i);
                        break;
                    }
                }
                _ if depth == 1 && self.is(i, ",") => {
                    found.push(from..i);
                    from = i + 1;
                }
                _ => {}
            }
        }
        found.retain(|range| !range.is_empty());
        found
    }

    /// The first identifier of a segment: a parameter's or element's name.
    fn first_ident(&self, range: Range<usize>) -> Option<usize> {
        range.into_iter().find(|&i| self.tokens[i].kind == Kind::Ident)
    }

    fn depth_change(&self, index: usize) -> i32 {
        if self.tokens[index].kind != Kind::Punct {
            return 0;
        }
        match self.text(index) {
            "(" | "[" | "{" => 1,
            ")" | "]" | "}" => -1,
            _ => 0,
        }
    }
}

struct Parser<'a> {
    source: &'a str,
    tokens: &'a [Token],
    at: usize,
}

impl Parser<'_> {
    fn kind(&self, index: usize) -> Option<Kind> {
        self.tokens.get(index).map(|t| t.kind)
    }

    fn text(&self, index: usize) -> &str {
        self.tokens[index].text(self.source)
    }

    fn is(&self, index: usize, text: &str) -> bool {
        index < self.tokens.len() && self.text(index) == text
    }

    /// The statements up to the block's `Dedent` (left unconsumed) or the end.
    fn block(&mut self, parent: StmtKind, depth: usize) -> Option<Block> {
        let mut stmts = Vec::new();
        loop {
            match self.kind(self.at) {
                None => return Some(stmts),
                Some(Kind::Dedent) => return (depth > 0).then_some(stmts),
                Some(Kind::Indent) => return None,
                Some(Kind::Newline) => self.at += 1,
                Some(_) => self.line(parent, depth, &mut stmts)?,
            }
        }
    }

    /// One logical line: its statements, and the indented block that follows.
    fn line(&mut self, parent: StmtKind, depth: usize, out: &mut Block) -> Option<()> {
        let start = self.at;
        let end = self.line_end(start);
        self.at = end + usize::from(end < self.tokens.len());
        let mut stmts = self.statements(start, end, parent)?;
        let indented = self.kind(self.at) == Some(Kind::Indent);
        let (open_header, lambda_colon) = stmts.last().map_or((false, false), |last| {
            let compound = last.kind.is_compound();
            (
                compound && last.body.is_none(),
                !compound && last.end == end && end > start && self.is(end - 1, ":"),
            )
        });
        match stmts.last_mut() {
            Some(last) if indented && (open_header || lambda_colon) => {
                if depth >= MAX_DEPTH {
                    return None;
                }
                self.at += 1;
                last.lambda = lambda_colon;
                last.body = Some(self.block(last.kind, depth + 1)?);
                if self.kind(self.at) != Some(Kind::Dedent) {
                    return None;
                }
                self.at += 1;
                last.span_end = self.at;
            }
            _ if indented || open_header => return None,
            _ => {}
        }
        out.extend(stmts);
        Some(())
    }

    /// The index of the `Newline` ending the line that begins at `from`, or
    /// the token count. Layout inside brackets (a lambda body) belongs to the
    /// statement.
    fn line_end(&self, from: usize) -> usize {
        let mut depth = 0usize;
        for (i, token) in self.tokens.iter().enumerate().skip(from) {
            if token.kind == Kind::Newline && depth == 0 {
                return i;
            }
            if token.kind == Kind::Punct {
                match token.text(self.source) {
                    "(" | "[" | "{" => depth += 1,
                    ")" | "]" | "}" => depth = depth.saturating_sub(1),
                    _ => {}
                }
            }
        }
        self.tokens.len()
    }

    /// The index of the first `needle` punctuation outside brackets in `[from, to)`.
    fn find_top(&self, from: usize, to: usize, needle: &str) -> Option<usize> {
        let mut depth = 0usize;
        for i in from..to {
            if self.tokens[i].kind != Kind::Punct {
                continue;
            }
            let text = self.text(i);
            if depth == 0 && text == needle {
                return Some(i);
            }
            match text {
                "(" | "[" | "{" => depth += 1,
                ")" | "]" | "}" => depth = depth.saturating_sub(1),
                _ => {}
            }
        }
        None
    }

    /// The statements of the tokens `[from, to)`, headers without their blocks.
    fn statements(&self, mut from: usize, to: usize, parent: StmtKind) -> Option<Vec<Stmt>> {
        let mut stmts = Vec::new();
        let mut first = true;
        while from < to {
            let kind = if first && parent == StmtKind::Match {
                StmtKind::Arm
            } else {
                self.kind_at(from, to)
            };
            if first && kind.is_compound() {
                stmts.push(self.compound(kind, from, to)?);
                return Some(stmts);
            }
            first = false;
            let end = self.find_top(from, to, ";").unwrap_or(to);
            stmts.push(self.simple(kind, from, end));
            from = end + 1;
            if from < to {
                let kind = self.kind_at(from, to);
                if kind.is_compound() {
                    // `a; if b:` is not GDScript; keep the rest as one expression.
                    stmts.push(self.simple(StmtKind::Other, from, to));
                    break;
                }
            }
        }
        Some(stmts)
    }

    /// `if x: a(); b()`: the header up to the first `:` outside brackets, and
    /// the statements after it as an inline body.
    fn compound(&self, kind: StmtKind, from: usize, to: usize) -> Option<Stmt> {
        // A typed loop variable (`for x: int in xs:`) has a colon of its own.
        let header = match kind {
            StmtKind::For => (from..to).find(|&i| self.tokens[i].kind == Kind::Ident && self.text(i) == "in"),
            _ => Some(from),
        };
        let Some(colon) = header.and_then(|header| self.find_top(header, to, ":")) else {
            // An `@abstract` declaration has no body; its names are not judged.
            let declaration = matches!(kind, StmtKind::Func | StmtKind::Class);
            return declaration.then(|| self.simple(StmtKind::Other, from, to));
        };
        let mut stmt = self.simple(kind, from, colon);
        stmt.span_end = to;
        if colon + 1 < to {
            stmt.body = Some(self.statements(colon + 1, to, StmtKind::Other)?);
        }
        Some(stmt)
    }

    fn simple(&self, kind: StmtKind, from: usize, end: usize) -> Stmt {
        let keyword = self.keyword_index(from, end);
        let name = keyword
            .map(|k| k + 1)
            .filter(|&n| n < end && self.tokens[n].kind == Kind::Ident)
            .filter(|_| {
                matches!(
                    kind,
                    StmtKind::ClassName
                        | StmtKind::Class
                        | StmtKind::Func
                        | StmtKind::Signal
                        | StmtKind::Enum
                        | StmtKind::Const
                        | StmtKind::Var
                        | StmtKind::For
                )
            });
        Stmt {
            kind,
            start: from,
            end,
            span_end: end,
            name,
            body: None,
            lambda: false,
        }
    }

    /// The first token after annotations (and their arguments) and `static`.
    fn keyword_index(&self, from: usize, to: usize) -> Option<usize> {
        let mut i = from;
        while i < to && self.tokens[i].kind == Kind::Annotation {
            i += 1;
            if self.is(i, "(") {
                let close = self.matching(i, to)?;
                i = close + 1;
            }
        }
        if i < to && self.is(i, "static") {
            i += 1;
        }
        (i < to).then_some(i)
    }

    fn matching(&self, open: usize, to: usize) -> Option<usize> {
        let mut depth = 0usize;
        for i in open..to {
            if self.tokens[i].kind != Kind::Punct {
                continue;
            }
            match self.text(i) {
                "(" | "[" | "{" => depth += 1,
                ")" | "]" | "}" => {
                    depth = depth.saturating_sub(1);
                    if depth == 0 {
                        return Some(i);
                    }
                }
                _ => {}
            }
        }
        None
    }

    fn kind_at(&self, from: usize, to: usize) -> StmtKind {
        let Some(k) = self.keyword_index(from, to) else {
            return StmtKind::Other;
        };
        if self.tokens[k].kind != Kind::Ident {
            return StmtKind::Other;
        }
        match self.text(k) {
            "class_name" => StmtKind::ClassName,
            "extends" => StmtKind::Extends,
            "class" => StmtKind::Class,
            "func" if self.tokens.get(k + 1).is_some_and(|t| t.kind == Kind::Ident) => StmtKind::Func,
            "signal" => StmtKind::Signal,
            "enum" => StmtKind::Enum,
            "const" => StmtKind::Const,
            "var" => StmtKind::Var,
            "pass" => StmtKind::Pass,
            "return" => StmtKind::Return,
            "if" => StmtKind::If,
            "elif" => StmtKind::Elif,
            "else" => StmtKind::Else,
            "for" => StmtKind::For,
            "while" => StmtKind::While,
            "match" => StmtKind::Match,
            _ => StmtKind::Other,
        }
    }
}

#[cfg(test)]
mod tests;
