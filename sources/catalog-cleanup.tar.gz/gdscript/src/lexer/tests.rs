use super::*;

/// The tokens as text, with `NL`, `IN` and `DE` for the layout tokens.
fn toks(source: &str) -> Vec<String> {
    lex(source)
        .tokens
        .iter()
        .map(|t| match t.kind {
            Kind::Newline => "NL".to_owned(),
            Kind::Indent => "IN".to_owned(),
            Kind::Dedent => "DE".to_owned(),
            _ => t.text(source).to_owned(),
        })
        .collect()
}

fn kinds(source: &str) -> Vec<Kind> {
    lex(source).tokens.iter().map(|t| t.kind).collect()
}

fn error(source: &str) -> Option<ErrorKind> {
    lex(source).error.map(|e| e.kind)
}

#[test]
fn lines_indents_and_dedents() {
    assert_eq!(
        toks("if a:\n\tb()\n\tif c:\n\t\td\ne\n"),
        [
            "if", "a", ":", "NL", "IN", "b", "(", ")", "NL", "if", "c", ":", "NL", "IN", "d", "NL", "DE", "DE", "e",
            "NL"
        ]
    );
    // Blank and comment-only lines open nothing, and the last line needs no line break.
    assert_eq!(toks("a\n\n    # c\n  \nb"), ["a", "NL", "b", "NL"]);
    assert_eq!(toks("a\r\n\tb\r\n"), ["a", "NL", "IN", "b", "NL", "DE"]);
    assert_eq!(toks("\u{feff}a\n"), ["a", "NL"]);
    assert_eq!(toks(""), Vec::<String>::new());
}

#[test]
fn brackets_and_backslashes_continue_a_line() {
    assert_eq!(
        toks("x = [\n  1,\n\t2\n]\ny = a + \\\n  b\n"),
        ["x", "=", "[", "1", ",", "2", "]", "NL", "y", "=", "a", "+", "b", "NL"]
    );
    assert_eq!(error("x = (1,\n"), Some(ErrorKind::UnclosedBracket));
    assert_eq!(error("x = (1]\n"), Some(ErrorKind::UnmatchedBracket));
    assert_eq!(error("x = 1)\n"), Some(ErrorKind::UnmatchedBracket));
    assert_eq!(error("x = 1 \\ y\n"), Some(ErrorKind::UnexpectedChar));
}

#[test]
fn strings_keep_comment_signs_and_span_lines() {
    let source = "a = \"x # y\" # real\nb = '''p  \nq # r\n'''\nc = r\"\\\" \" \"\"\n";
    let lexed = lex(source);
    assert!(lexed.error.is_none());
    assert_eq!(lexed.comments.len(), 1);
    assert_eq!(
        &source[lexed.comments[0].start as usize..lexed.comments[0].end as usize],
        "# real"
    );
    assert_eq!(lexed.multiline_strings.len(), 1);
    let strings: Vec<&str> = lexed
        .tokens
        .iter()
        .filter(|t| t.kind == Kind::Str)
        .map(|t| t.text(source))
        .collect();
    assert_eq!(strings, ["\"x # y\"", "'''p  \nq # r\n'''", "r\"\\\" \"", "\"\""]);
    assert_eq!(kinds("&\"a\" ^\"b\"\n")[..2], [Kind::Str, Kind::Str]);
    // A line break is allowed in any string; an unterminated one runs to the end of the file.
    let broken = lex("a = \"one\ntwo\"\nb = 1 \n");
    assert!(broken.error.is_none());
    assert_eq!(broken.multiline_strings.len(), 1);
    assert_eq!(error("a = \"open\nb\n"), Some(ErrorKind::UnterminatedString));
    assert_eq!(error("a = \"\"\"open\n"), Some(ErrorKind::UnterminatedString));
}

#[test]
fn node_paths_and_unique_names_are_single_tokens() {
    assert_eq!(
        toks("$A/B/c.text = %Name\n"),
        ["$A/B/c", ".", "text", "=", "%Name", "NL"]
    );
    assert_eq!(toks("$\"A B/c\".hide()\n")[0], "$\"A B/c\"");
    assert_eq!(toks("x = $../Up/%Down\n")[2], "$../Up/%Down");
    assert_eq!(kinds("%Name.x\n")[0], Kind::Unique);
    // Modulo where a value comes before it.
    assert_eq!(toks("a = b %c\nd = (1) %e\n")[2..5], ["b", "%", "c"]);
    assert_eq!(toks("return %Box\n")[..2], ["return", "%Box"]);
    assert_eq!(toks("a = 5 % 3\n")[3], "%");
}

#[test]
fn numbers_annotations_and_operators() {
    assert_eq!(
        toks("a = 0xFF_ff + 0b10 + 1_000 + 1.5e-3 + .5 + 1. + 2e3\n"),
        [
            "a", "=", "0xFF_ff", "+", "0b10", "+", "1_000", "+", "1.5e-3", "+", ".5", "+", "1.", "+", "2e3", "NL"
        ]
    );
    assert_eq!(toks("1.to_string()\n")[..3], ["1", ".", "to_string"]);
    assert_eq!(
        toks("@export_range(0, 1) var x := 1 ** 2 >>= 3 -> y\n"),
        [
            "@export_range",
            "(",
            "0",
            ",",
            "1",
            ")",
            "var",
            "x",
            ":=",
            "1",
            "**",
            "2",
            ">>=",
            "3",
            "->",
            "y",
            "NL"
        ]
    );
    assert_eq!(kinds("@tool\n")[0], Kind::Annotation);
    assert_eq!(toks("var \u{53d8}\u{91cf} = 1\n")[1], "\u{53d8}\u{91cf}");
    assert_eq!(error("a = b ? c\n"), Some(ErrorKind::UnexpectedChar));
}

#[test]
fn a_multi_line_lambda_in_brackets_is_read_as_statements() {
    let source = "func f():\n\tfoo(1, func(x):\n\t\t\tprint(x)\n\t\t\treturn x\n\t, 2)\nbar()\n";
    assert_eq!(
        toks(source)[7..],
        [
            "foo", "(", "1", ",", "func", "(", "x", ")", ":", "NL", "IN", "print", "(", "x", ")", "NL", "return", "x",
            "NL", "DE", ",", "2", ")", "NL", "DE", "bar", "(", ")", "NL"
        ]
    );
    // The body ends at a closing line no deeper than the one that began it.
    let closing = "connect(func():\n\tprint(1)\n)\n";
    assert_eq!(
        toks(closing),
        [
            "connect", "(", "func", "(", ")", ":", "NL", "IN", "print", "(", "1", ")", "NL", "DE", ")", "NL"
        ]
    );
    // A one-line lambda opens no context, and a statement lambda is plain blocks.
    assert_eq!(
        toks("f(func(): return 1, 2)\n").iter().filter(|t| *t == "NL").count(),
        1
    );
    assert_eq!(
        toks("var f = func(x):\n\treturn x\n")[..10],
        ["var", "f", "=", "func", "(", "x", ")", ":", "NL", "IN"]
    );
    // Nested lambdas.
    let nested = "a(func():\n\tb(func():\n\t\tc()\n\t)\n)\n";
    let lexed = lex(nested);
    assert!(lexed.error.is_none());
    let layout: Vec<Kind> = lexed.tokens.iter().filter(|t| t.is_layout()).map(|t| t.kind).collect();
    assert_eq!(
        layout,
        [
            Kind::Newline,
            Kind::Indent,
            Kind::Newline,
            Kind::Indent,
            Kind::Newline,
            Kind::Dedent,
            Kind::Newline,
            Kind::Dedent,
            Kind::Newline
        ]
    );
    assert_eq!(error("a(func():\n\tb()\n"), Some(ErrorKind::UnclosedBracket));
    // The last body line may close the brackets around the lambda, and a body
    // line may be shallower than the line the lambda began on.
    let closed = "func f():\n\tg(func():\n\t\t\th())\n\tk()\n";
    assert!(lex(closed).error.is_none());
    let dictionary = "func f():\n\tvar d = {\n\t\t1: func():\n\t\t\t\tg(),\n\t\t2: 3,\n\t}\n";
    assert!(lex(dictionary).error.is_none());
}

#[test]
fn indentation_godot_rejects_is_a_fault_not_an_error() {
    let mixed = lex("if a:\n\t b()\n");
    assert!(mixed.error.is_none());
    assert_eq!(mixed.faults.len(), 1);
    assert_eq!(mixed.faults[0].kind, IndentFault::Mixed);
    let switched = lex("if a:\n\tb()\nif c:\n    d()\n");
    assert_eq!(switched.faults.len(), 1);
    assert_eq!(switched.faults[0].kind, IndentFault::Switched { expected: b'\t' });
    assert_eq!(switched.faults[0].start, 17);
    // Continuation lines, comment-only lines and blank lines are not logical lines.
    assert!(lex("if a:\n\tb(1,\n      2)\n  # c\n\tc()\n").faults.is_empty());
    assert_eq!(error("if a:\n\t\tb()\n\tc()\n"), Some(ErrorKind::BadDedent));
    // A fault already seen keeps a misaligned dedent from also being an error.
    assert_eq!(error("if a:\n\t\tb()\n \tc()\n"), None);
    assert_eq!(error("if a:\n    b()\n  c()\n"), Some(ErrorKind::BadDedent));
}

#[test]
fn hostile_nesting_is_refused_not_followed() {
    let brackets = "(".repeat(5_000);
    assert_eq!(error(&brackets), Some(ErrorKind::TooLarge));
    let mut deep = String::new();
    for level in 0..300 {
        deep.push_str(&" ".repeat(level));
        deep.push_str("if a:\n");
    }
    assert_eq!(error(&deep), Some(ErrorKind::TooLarge));
    let tokens = "a,".repeat(MAX_TOKENS);
    assert_eq!(error(&tokens), Some(ErrorKind::TooLarge));
}
