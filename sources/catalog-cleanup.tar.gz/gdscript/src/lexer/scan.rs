//! The scanners of the lexer's tokens proper: strings, numbers, annotations,
//! node paths, names and operators.
use super::{ErrorKind, Kind, Lambda, Lexer};

/// Keywords after which an operand, not an operator, comes.
fn expects_operand(word: &str) -> bool {
    matches!(
        word,
        "and"
            | "or"
            | "not"
            | "in"
            | "is"
            | "as"
            | "return"
            | "if"
            | "elif"
            | "else"
            | "while"
            | "match"
            | "when"
            | "await"
            | "assert"
            | "for"
    )
}

const PUNCT3: [&[u8; 3]; 3] = [b"**=", b"<<=", b">>="];
const PUNCT2: [&[u8; 2]; 17] = [
    b"->", b":=", b"==", b"!=", b"<=", b">=", b"&&", b"||", b"+=", b"-=", b"*=", b"/=", b"%=", b"&=", b"|=", b"^=",
    b"**",
];
const SHIFTS: [&[u8; 2]; 2] = [b"<<", b">>"];

pub(super) fn is_quote(b: u8) -> bool {
    b == b'"' || b == b'\''
}

fn is_word_byte(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'_'
}

impl Lexer<'_> {
    // --- tokens ---

    /// Strings: `start` is where the token (with its prefix) begins, `quote`
    /// the opening quote.
    pub(super) fn string(&mut self, start: usize, quote: usize) {
        let q = self.bytes[quote];
        let triple = self.bytes.get(quote + 1) == Some(&q) && self.bytes.get(quote + 2) == Some(&q);
        let mut i = quote + if triple { 3 } else { 1 };
        let mut multiline = false;
        loop {
            let Some(&b) = self.bytes.get(i) else {
                return self.fail(start, ErrorKind::UnterminatedString);
            };
            if b == b'\\' {
                let crlf = self.bytes.get(i + 1) == Some(&b'\r') && self.bytes.get(i + 2) == Some(&b'\n');
                multiline |= crlf || self.bytes.get(i + 1) == Some(&b'\n');
                i += if crlf { 3 } else { 2 };
            } else if b == q && (!triple || (self.bytes.get(i + 1) == Some(&q) && self.bytes.get(i + 2) == Some(&q))) {
                i += if triple { 3 } else { 1 };
                break;
            } else if b == b'\n' {
                // A line break is allowed inside any string.
                multiline = true;
                i += 1;
            } else {
                i += 1;
            }
        }
        self.finish_string(Kind::Str, start, i, multiline);
    }

    fn finish_string(&mut self, kind: Kind, start: usize, end: usize, multiline: bool) {
        if multiline {
            self.out.multiline_strings.push(start as u32..end as u32);
        }
        self.push(kind, start, end);
        self.pos = end;
    }

    pub(super) fn number(&mut self) {
        let start = self.pos;
        let mut i = start;
        let digits = |i: &mut usize, accept: fn(u8) -> bool, bytes: &[u8]| {
            while bytes.get(*i).is_some_and(|&b| accept(b) || b == b'_') {
                *i += 1;
            }
        };
        let prefix = (self.bytes[i] == b'0').then(|| self.peek(1).to_ascii_lowercase());
        if prefix == Some(b'x') {
            i += 2;
            digits(&mut i, |b| b.is_ascii_hexdigit(), self.bytes);
        } else if prefix == Some(b'b') {
            i += 2;
            digits(&mut i, |b| b == b'0' || b == b'1', self.bytes);
        } else {
            digits(&mut i, |b| b.is_ascii_digit(), self.bytes);
            if self.bytes.get(i) == Some(&b'.') {
                let after = self.bytes.get(i + 1).copied().unwrap_or(0);
                if after.is_ascii_digit() {
                    i += 1;
                    digits(&mut i, |b| b.is_ascii_digit(), self.bytes);
                } else if after != b'.' && !after.is_ascii_alphabetic() && after != b'_' && after < 0x80 {
                    i += 1;
                }
            }
            if matches!(self.bytes.get(i), Some(b'e' | b'E')) {
                let mut j = i + 1;
                if matches!(self.bytes.get(j), Some(b'+' | b'-')) {
                    j += 1;
                }
                if self.bytes.get(j).is_some_and(u8::is_ascii_digit) {
                    digits(&mut j, |b| b.is_ascii_digit(), self.bytes);
                    i = j;
                }
            }
        }
        self.push(Kind::Number, start, i);
        self.pos = i;
    }

    pub(super) fn annotation(&mut self) {
        let start = self.pos;
        let mut i = start + 1;
        while self.bytes.get(i).is_some_and(|&b| is_word_byte(b)) {
            i += 1;
        }
        let kind = if i > start + 1 { Kind::Annotation } else { Kind::Punct };
        self.push(kind, start, i);
        self.pos = i;
    }

    /// `$Node/path`, `$%Unique/child`, `$"Quoted/path"`: one token. A `.` ends
    /// it, since `$Label.text` is a property of the node.
    pub(super) fn node_path(&mut self) {
        let start = self.pos;
        if is_quote(self.peek(1)) {
            let before = self.out.tokens.len();
            self.string(start, start + 1);
            if let Some(token) = self.out.tokens.get_mut(before) {
                token.kind = Kind::NodePath;
            }
            return;
        }
        let mut i = start + 1;
        loop {
            if self.bytes.get(i) == Some(&b'%') {
                i += 1;
            }
            if self.bytes[i..].starts_with(b"..") && self.bytes.get(i + 2) == Some(&b'/') {
                i += 2;
            } else {
                let from = i;
                i += word_length(&self.source[i..]);
                if i == from {
                    break;
                }
            }
            if self.bytes.get(i) == Some(&b'/') {
                i += 1;
            } else {
                break;
            }
        }
        let kind = if i > start + 1 { Kind::NodePath } else { Kind::Punct };
        self.push(kind, start, i);
        self.pos = i;
    }

    /// Whether a `%` here begins a `%Unique` node name, not a modulo: it
    /// does where an operand belongs and a name or quote follows.
    pub(super) fn unique_follows(&self) -> bool {
        let next = self.peek(1);
        if !(is_word_byte(next) || is_quote(next) || next >= 0x80) || next.is_ascii_digit() {
            return false;
        }
        let Some(previous) = self.out.tokens.last() else {
            return true;
        };
        let value_ends = match previous.kind {
            Kind::Number | Kind::Str | Kind::NodePath | Kind::Unique => true,
            Kind::Ident => !expects_operand(previous.text(self.source)),
            Kind::Punct => matches!(previous.text(self.source), ")" | "]" | "}"),
            _ => false,
        };
        !value_ends
    }

    pub(super) fn unique(&mut self) {
        let start = self.pos;
        if is_quote(self.peek(1)) {
            let before = self.out.tokens.len();
            self.string(start, start + 1);
            if let Some(token) = self.out.tokens.get_mut(before) {
                token.kind = Kind::Unique;
            }
            return;
        }
        let end = start + 1 + word_length(&self.source[start + 1..]);
        self.push(Kind::Unique, start, end);
        self.pos = end;
    }

    pub(super) fn word_or_punct(&mut self) {
        let start = self.pos;
        let first = self.source[start..].chars().next().unwrap_or('\0');
        if first == '_' || first.is_alphabetic() {
            let end = start + word_length(&self.source[start..]);
            self.push(Kind::Ident, start, end);
            self.pos = end;
            if &self.source[start..end] == "func" && !self.brackets.is_empty() {
                self.lambdas.push(Lambda {
                    depth: self.brackets.len(),
                    params_closed: false,
                });
            }
            return;
        }
        let rest = &self.bytes[start..];
        let len = if PUNCT3.iter().any(|p| rest.starts_with(*p)) {
            3
        } else if PUNCT2.iter().chain(&SHIFTS).any(|p| rest.starts_with(*p)) {
            2
        } else if b"+-*/%=<>!&|^~.,:;".contains(&rest[0]) {
            1
        } else {
            return self.fail(start, ErrorKind::UnexpectedChar);
        };
        self.push(Kind::Punct, start, start + len);
        self.pos = start + len;
        if len == 1 && rest[0] == b':' {
            self.colon();
        }
    }
}

/// The byte length of the identifier characters at the start of `text`.
fn word_length(text: &str) -> usize {
    text.char_indices()
        .find(|&(_, c)| !(c == '_' || c.is_alphanumeric()))
        .map_or(text.len(), |(i, _)| i)
}
