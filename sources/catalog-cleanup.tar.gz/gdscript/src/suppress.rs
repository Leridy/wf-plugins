//! Suppression comments, written as gdtoolkit's `gdlint` reads them:
//!
//! - `# gdlint: ignore=rule-a,rule-b` alone on a line covers the next line; at
//!   the end of a code line it covers that line.
//! - `# gdlint: disable=rule-a` covers the lines up to the `# gdlint: enable=rule-a`
//!   that follows (to the end of the file without one).
//!
//! A rule may be written with or without the `gdscript/` prefix; unknown
//! names never match anything.
use crate::lines::Lines;
use std::{
    collections::BTreeMap,
    ops::{Range, RangeInclusive},
};

const PREFIX: &str = "gdscript/";

#[derive(Debug, Default)]
pub struct Suppressions {
    covered: BTreeMap<String, Vec<RangeInclusive<usize>>>,
}

enum Directive {
    Ignore,
    Disable,
    Enable,
}

impl Suppressions {
    pub fn covers(&self, rule: &str, line: usize) -> bool {
        self.covered
            .get(rule)
            .is_some_and(|ranges| ranges.iter().any(|range| range.contains(&line)))
    }
}

/// The suppressions of the comments (byte ranges) of `source`, in order.
pub fn read(source: &str, comments: &[Range<u32>], lines: &Lines) -> Suppressions {
    let mut found = Suppressions::default();
    let mut open: BTreeMap<String, usize> = BTreeMap::new();
    for comment in comments {
        let Some((directive, rules)) = directive(&source[comment.start as usize..comment.end as usize]) else {
            continue;
        };
        let line = lines.line_of(comment.start);
        let line_start = lines.around(comment.start).start;
        let alone = source[line_start..comment.start as usize].trim().is_empty();
        for rule in rules {
            match directive {
                Directive::Ignore => {
                    let target = if alone { line + 1 } else { line };
                    found.covered.entry(rule).or_default().push(target..=target);
                }
                Directive::Disable => {
                    open.entry(rule).or_insert(if alone { line + 1 } else { line });
                }
                Directive::Enable => {
                    if let Some(from) = open.remove(&rule)
                        && from < line
                    {
                        found.covered.entry(rule).or_default().push(from..=line - 1);
                    }
                }
            }
        }
    }
    for (rule, from) in open {
        found.covered.entry(rule).or_default().push(from..=usize::MAX);
    }
    found
}

/// `# gdlint: ignore=a, b` as the directive and the rule names.
fn directive(comment: &str) -> Option<(Directive, Vec<String>)> {
    let text = comment.trim_start_matches('#').trim_start().strip_prefix("gdlint:")?;
    let (word, list) = text.trim_start().split_once('=')?;
    let directive = match word.trim() {
        "ignore" => Directive::Ignore,
        "disable" => Directive::Disable,
        "enable" => Directive::Enable,
        _ => return None,
    };
    let rules = list
        .split(',')
        .filter_map(|item| item.split_whitespace().next())
        .map(|name| name.strip_prefix(PREFIX).unwrap_or(name).to_owned())
        .collect();
    Some((directive, rules))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{lexer::lex, lines::Lines};

    fn read_text(source: &str) -> Suppressions {
        read(source, &lex(source).comments, &Lines::new(source))
    }

    #[test]
    fn ignore_covers_the_next_line_or_its_own() {
        let s = read_text("# gdlint: ignore=a,gdscript/b\nx = 1\ny = 2 # gdlint:ignore=c\nz = 3\n");
        assert!(s.covers("a", 2) && s.covers("b", 2));
        assert!(!s.covers("a", 1) && !s.covers("a", 3));
        assert!(s.covers("c", 3) && !s.covers("c", 4));
    }

    #[test]
    fn disable_runs_until_enable_or_the_end() {
        let s = read_text("a\n# gdlint: disable=x, y\nb\n# gdlint: enable=x\nc\n");
        assert!(!s.covers("x", 2) && s.covers("x", 3) && !s.covers("x", 4) && !s.covers("x", 5));
        assert!(s.covers("y", 5) && s.covers("y", 999));
    }

    #[test]
    fn other_comments_and_strings_do_nothing() {
        let s = read_text("x = \"# gdlint: ignore=a\"\n# gdlint: nonsense=a\n# note gdlint: ignore=a\ny = 1\n");
        assert!(!s.covers("a", 1) && !s.covers("a", 3) && !s.covers("a", 4));
    }
}
