//! Finds the scripts and option files, reads them one at a time, runs the
//! rules and drops what the file's suppression comments cover. A script uses
//! the nearest `gdscript-lint.toml` above it; one that does not parse is
//! reported and the defaults apply.
use crate::{
    config::{self, CONFIG_FILE, ConfigError, Options},
    lexer::lex,
    lines::Lines,
    rules::{self, Checked},
    suppress,
};
use plugin_guest::Host;
use plugin_protocols::lint::{Diagnostic, LintInput, LintOutput, Severity, Span};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::Path,
};

/// Most diagnostics one run reports; a hostile file could hold millions.
const MAX_DIAGNOSTICS: usize = 5_000;
pub const INVALID_CONFIG: &str = "invalid-config";

pub fn lint(host: &dyn Host, input: &LintInput) -> LintOutput {
    let scope = Scope::new(&input.paths);
    let scripts = listed(host, scope.script_globs(), |path| {
        is_script(path) && scope.contains(path)
    });
    let configs = listed(host, vec![format!("**/{CONFIG_FILE}")], |_| true);
    let mut loaded = Configs::new(host, &configs);
    let mut output = LintOutput::default();
    for script in &scripts {
        if output.diagnostics.len() >= MAX_DIAGNOSTICS {
            host.warn(&format!(
                "The run stopped after {MAX_DIAGNOSTICS} diagnostics; fix those and run it again to see the rest."
            ));
            break;
        }
        let Ok(bytes) = host.read(script) else {
            continue;
        };
        let Ok(source) = String::from_utf8(bytes) else {
            host.warn(&format!("{script} is not valid UTF-8; it was not checked."));
            continue;
        };
        let options = loaded.options_for(script);
        let diagnostics = check_script(script, &source, &options, MAX_DIAGNOSTICS - output.diagnostics.len());
        output.diagnostics.extend(diagnostics);
        output.checked.push(script.clone());
    }
    for config in loaded.reports(&scope) {
        output.checked.push(config.file.clone());
        output.diagnostics.extend(config.error);
    }
    output
        .diagnostics
        .sort_by(|a, b| (&a.file, a.span.map(|s| s.start), &a.rule).cmp(&(&b.file, b.span.map(|s| s.start), &b.rule)));
    output
}

/// The diagnostics of one script's text that its suppression comments leave.
pub fn check_script(file: &str, source: &str, options: &Options, limit: usize) -> Vec<Diagnostic> {
    let lexed = lex(source);
    let lines = Lines::new(source);
    let checked = Checked {
        file,
        source,
        options,
        lexed: &lexed,
        lines: &lines,
    };
    let suppressed = suppress::read(source, &lexed.comments, &lines);
    let mut diagnostics = rules::check(&checked, limit);
    diagnostics.retain(|d| {
        d.span
            .is_none_or(|span| !suppressed.covers(&d.rule, lines.line_of(span.start)))
    });
    diagnostics
}

/// The files `globs` list that `keep` accepts, sorted and unique.
fn listed(host: &dyn Host, globs: Vec<String>, keep: impl Fn(&str) -> bool) -> BTreeSet<String> {
    let mut found = BTreeSet::new();
    for glob in globs {
        let paths = host.list(&glob);
        if paths.len() >= host.list_limit() {
            host.warn(&format!(
                "The listing of {glob} is as long as the host allows, so some files may not be checked. Check one directory at a time by passing it as a path."
            ));
        }
        found.extend(paths.into_iter().filter(|path| keep(path)));
    }
    found
}

/// The option files, read at most once each.
struct Configs<'a> {
    host: &'a dyn Host,
    files: &'a BTreeSet<String>,
    read: BTreeMap<String, Result<Options, ConfigError>>,
}

/// An option file's report: the file, and `invalid-config` if it is invalid.
struct Report {
    file: String,
    error: Option<Diagnostic>,
}

impl<'a> Configs<'a> {
    fn new(host: &'a dyn Host, files: &'a BTreeSet<String>) -> Self {
        Self {
            host,
            files,
            read: BTreeMap::new(),
        }
    }

    fn load(&mut self, file: &str) -> &Result<Options, ConfigError> {
        let host = self.host;
        self.read.entry(file.to_owned()).or_insert_with(|| {
            let text = host
                .read(file)
                .map_err(|e| e.message)
                .and_then(|bytes| String::from_utf8(bytes).map_err(|_| "it is not valid UTF-8".to_owned()));
            match text {
                Ok(text) => config::parse(&text),
                Err(message) => Err(ConfigError { message, span: None }),
            }
        })
    }

    /// The options for a script; the defaults when its file is invalid.
    fn options_for(&mut self, script: &str) -> Options {
        let Some(file) = config::nearest(self.files, script).map(str::to_owned) else {
            return Options::default();
        };
        match self.load(&file) {
            Ok(options) => *options,
            Err(_) => Options::default(),
        }
    }

    /// The option files in scope, which were read for a script or are checked
    /// themselves, with `invalid-config` for each that is invalid. An invalid
    /// file outside the requested paths is told on stderr instead.
    fn reports(&mut self, scope: &Scope) -> Vec<Report> {
        let used: Vec<String> = self.read.keys().cloned().collect();
        let mut reports = Vec::new();
        for file in self.files.clone() {
            let in_scope = scope.contains(&file);
            if !in_scope && !used.contains(&file) {
                continue;
            }
            let Err(error) = self.load(&file).clone() else {
                if in_scope {
                    reports.push(Report { file, error: None });
                }
                continue;
            };
            if in_scope {
                let diagnostic = invalid(&file, &error);
                reports.push(Report {
                    file,
                    error: Some(diagnostic),
                });
            } else {
                self.host.warn(&format!(
                    "{file} is invalid ({}); the default options are used below it.",
                    error.message
                ));
            }
        }
        reports
    }
}

fn invalid(file: &str, error: &ConfigError) -> Diagnostic {
    Diagnostic {
        rule: INVALID_CONFIG.to_owned(),
        severity: Severity::Error,
        message: format!(
            "{CONFIG_FILE} is invalid: {}. The default options are used below it.",
            plugin_guest::quoted(&error.message, 200)
        ),
        file: file.to_owned(),
        span: error.span.as_ref().map(|span| Span {
            start: span.start as u32,
            end: span.end as u32,
        }),
        fix: None,
    }
}

/// The requested files and directories; empty means the whole project.
struct Scope {
    paths: Vec<String>,
}

impl Scope {
    fn new(paths: &[String]) -> Self {
        Self {
            paths: paths
                .iter()
                .map(|p| p.trim_start_matches("./").trim_end_matches('/').to_owned())
                .filter(|p| !p.is_empty() && p != ".")
                .collect(),
        }
    }

    fn contains(&self, file: &str) -> bool {
        self.paths.is_empty()
            || self
                .paths
                .iter()
                .any(|p| file == p || file.strip_prefix(p.as_str()).is_some_and(|rest| rest.starts_with('/')))
    }

    /// The listings that cover the scope: scripts below a directory (or the
    /// project), and a script by its name.
    fn script_globs(&self) -> Vec<String> {
        if self.paths.is_empty() {
            return vec!["**/*.gd".to_owned()];
        }
        self.paths
            .iter()
            .filter(|path| !path.contains('\\'))
            .map(|path| {
                let path = escaped(path);
                if is_script(&path) {
                    path
                } else {
                    format!("{path}/**/*.gd")
                }
            })
            .collect()
    }
}

fn is_script(path: &str) -> bool {
    Path::new(path).extension().is_some_and(|extension| extension == "gd")
}

/// `path` as a glob that matches only itself.
fn escaped(path: &str) -> String {
    path.chars()
        .map(|c| {
            if matches!(c, '*' | '?' | '[' | ']' | '{' | '}') {
                format!("[{c}]")
            } else {
                c.to_string()
            }
        })
        .collect()
}

#[cfg(test)]
mod tests;
