//! `wf-plugin.toml`: who the plugin is, where its component is, what it may
//! read and run, and the data it contributes to official protocols.
use crate::ui::Ui;
use crate::{
    API, API_0_1_0, API_0_1_1, API_0_1_2, APIS, ConfigField, Process, Protocol, ToolDecl, check_fields, process,
};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize, de::DeserializeOwned};
use std::{
    collections::BTreeSet,
    fmt,
    path::{Component, Path},
};

pub const MANIFEST_FILE: &str = "wf-plugin.toml";
/// Most bytes one skill topic may have.
pub const SKILL_TOPIC_LIMIT: usize = 16 << 10;

/// The `wf-plugin.toml` file.
#[derive(Clone, Debug, Deserialize, JsonSchema, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Manifest {
    pub plugin: PluginInfo,
    #[serde(default)]
    pub permissions: Permissions,
    /// Guidance for Agents, shown by `wf skill show` as `<plugin>/<topic>`.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub skills: Vec<SkillTopic>,
    /// The plugin's settings, set per project and read with `host.config`.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub config: Vec<ConfigField>,
    /// Required external programs of the whole plugin, matching `permissions.exec`.
    /// All must be configured and satisfy their version rules before any operation.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub tools: Vec<ToolDecl>,
    /// Data the plugin contributes to official protocols; the runtime runs
    /// it itself, without the plugin's component.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub contributes: Vec<Contribution>,
    /// What the plugin adds to the client: actions and result views, as data.
    #[serde(default, skip_serializing_if = "Ui::is_empty")]
    pub ui: Ui,
    /// A native program run as a stdio MCP server instead of a component.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub process: Option<Process>,
}

/// One `[[contributes]]` entry: a directory of data in a protocol's shape.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[cfg_attr(feature = "ts", derive(ts_rs::TS), ts(rename = "PluginContribution"))]
#[serde(deny_unknown_fields)]
pub struct Contribution {
    /// A protocol contributed as data: `wf.template/1`.
    pub protocol: Protocol,
    /// A directory inside the plugin, `/`-separated. Its last segment names
    /// the contribution; a template becomes the capability of that name.
    pub data: String,
}

impl Contribution {
    /// The last segment of `data`: a template's name and op.
    pub fn name(&self) -> &str {
        self.data.rsplit('/').next().unwrap_or_default()
    }
}

/// A Markdown topic a plugin adds to `wf skill show`. It is plugin text: it
/// is marked as such, and it can never replace a built-in topic.
#[derive(Clone, Debug, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct SkillTopic {
    /// Lowercase words joined by `-`, unique within the plugin; read as `<plugin>/<topic>`.
    pub topic: String,
    /// A `.md` file inside the plugin directory, at most 16 KiB.
    pub path: String,
}

#[derive(Clone, Debug, Deserialize, JsonSchema, Serialize)]
#[serde(deny_unknown_fields)]
pub struct PluginInfo {
    /// The command name, `wf <name> <op>`: lowercase letters, digits and `-`,
    /// starting with a letter; it cannot be a built-in command.
    pub name: String,
    /// Human-readable label; the command and package identity remain `name`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub display_name: Option<String>,
    pub version: String,
    /// One line saying what the plugin is for; shown in listings.
    pub summary: String,
    /// The WIT package the component targets, e.g. `wf:plugin@0.1.0`.
    pub api: String,
    /// The component, relative to the manifest's directory. Absent for a
    /// data-only plugin, which only contributes data (`[[contributes]]`).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub component: Option<String>,
    /// A square PNG (128 or 256 px, at most 64 KiB) shown beside the name,
    /// relative to the manifest's directory.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub icon: Option<String>,
    /// The wf versions the plugin works with, a semver range such as
    /// `>=0.3.0`; every version when left out. An index lists it beside the
    /// version so a wf outside it never installs the package.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cli: Option<String>,
}

/// What a plugin may reach beyond its own memory; the user grants it once.
#[derive(Clone, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Permissions {
    /// Project-relative globs `read-file` and `list-files` may see; none may
    /// start with `/` or contain `..`. `*` and `**` never match a segment
    /// starting with `.`; a glob segment that starts with `.` itself
    /// (`.gdlintrc`, `.godot/**`) reaches one. `.git`, `.env`, `.env.*`, the
    /// mirror, `wf.toml` and wf's own files stay unreadable whatever the grant.
    #[serde(default)]
    pub read: Vec<String>,
    /// `read` lets `host.call` reach the platform's read methods (the local
    /// mirror: nodes, cards, export locks); `none` by default. Needs API 0.1.1 or later.
    #[serde(default, skip_serializing_if = "PlatformAccess::is_none")]
    pub platform: PlatformAccess,
    /// Plugins whose capabilities `host.call-plugin` may run (by name). Each
    /// runs with its own grants and must be installed and trusted in the
    /// project; its effects come back to this plugin. Needs API 0.1.2 or later.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub calls: Vec<String>,
    /// External programs `effect.exec` may run, by their `[[tools]]` name. A
    /// run that executes one is high-risk; the program runs without a shell,
    /// from the path the person confirmed in the runtime's tool table.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub exec: Vec<String>,
}

/// How far `host.call` reaches into the platform.
#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, JsonSchema, PartialEq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum PlatformAccess {
    #[default]
    None,
    Read,
}

impl PlatformAccess {
    pub const fn is_none(&self) -> bool {
        matches!(self, Self::None)
    }
}

/// The confirmation target of `platform = "read"`.
pub const PLATFORM_READ_TARGET: &str = "read the local WeaveForge mirror";

impl Permissions {
    pub fn is_empty(&self) -> bool {
        self.read.is_empty() && self.platform.is_none() && self.calls.is_empty() && self.exec.is_empty()
    }
    /// Each permission as the user is asked to grant it.
    pub fn targets(&self) -> Vec<String> {
        let reads = self.read.iter().map(|glob| format!("read {glob}"));
        let platform = (self.platform == PlatformAccess::Read).then(|| PLATFORM_READ_TARGET.to_owned());
        let calls = self.calls.iter().map(|plugin| call_target(plugin));
        let exec = self.exec.iter().map(|tool| exec_target(tool));
        reads.chain(platform).chain(calls).chain(exec).collect()
    }
}

/// The confirmation target of `exec = ["<tool>"]`.
pub fn exec_target(tool: &str) -> String {
    format!("run the external program {tool}")
}

/// The confirmation target of `calls = ["<plugin>"]`.
pub fn call_target(plugin: &str) -> String {
    format!("run plugin {plugin} with its own permissions")
}

/// Why a manifest cannot be used, phrased for the plugin author.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ManifestError(pub String);

impl fmt::Display for ManifestError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

impl Manifest {
    pub fn parse(text: &str) -> Result<Self, ManifestError> {
        let manifest: Self = toml_from_str(text)?;
        manifest.check()?;
        Ok(manifest)
    }

    fn check(&self) -> Result<(), ManifestError> {
        let info = &self.plugin;
        if !is_name(&info.name) {
            return Err(ManifestError(format!(
                "plugin.name `{}` must be lowercase letters, digits and `-`, starting with a letter.",
                info.name
            )));
        }
        if info.display_name.as_ref().is_some_and(|name| {
            name.trim().is_empty() || name.chars().count() > 80 || name.chars().any(char::is_control)
        }) {
            return Err(ManifestError("plugin.display_name must be a nonempty single line of at most 80 characters.".into()));
        }
        if let Some(cli) = &info.cli
            && semver::VersionReq::parse(cli).is_err()
        {
            return Err(ManifestError(format!(
                "plugin.cli `{cli}` must be a semver range such as `>=0.3.0`."
            )));
        }
        if !APIS.contains(&info.api.as_str()) {
            return Err(ManifestError(format!(
                "plugin.api `{}` is not supported; this wf runs `{}`.",
                info.api,
                APIS.join("` and `")
            )));
        }
        if !self.permissions.platform.is_none() && info.api == API_0_1_0 {
            return Err(ManifestError(format!(
                "permissions.platform needs `host.call`, which `{API_0_1_0}` lacks: set plugin.api to `{API}` and rebuild against its WIT."
            )));
        }
        if !self.permissions.calls.is_empty() && [API_0_1_0, API_0_1_1].contains(&info.api.as_str()) {
            return Err(ManifestError(format!(
                "permissions.calls needs `host.call-plugin`, which `{}` lacks: set plugin.api to `{API}` and rebuild against its WIT.",
                info.api
            )));
        }
        if !self.config.is_empty() && [API_0_1_0, API_0_1_1, API_0_1_2].contains(&info.api.as_str()) {
            return Err(ManifestError(format!(
                "config needs `host.config`, which `{}` lacks: set plugin.api to `{API}` and rebuild against its WIT.",
                info.api
            )));
        }
        check_fields(&self.config).map_err(|error| {
            ManifestError(if error.key.is_empty() {
                format!("config {}.", error.message)
            } else {
                format!("config `{}` {}.", error.key, error.message)
            })
        })?;
        let mut called = BTreeSet::new();
        for plugin in &self.permissions.calls {
            if !is_name(plugin) || *plugin == info.name || !called.insert(plugin.as_str()) {
                return Err(ManifestError(format!(
                    "permissions.calls `{plugin}` must name another plugin, once: lowercase letters, digits and `-`, starting with a letter."
                )));
            }
        }
        process::check(self)?;
        match &info.component {
            Some(component) if !inside(component) => {
                return Err(ManifestError(format!(
                    "plugin.component `{component}` must be a relative path inside the plugin directory."
                )));
            }
            Some(_) => {}
            None if self.process.is_some() => {}
            None => self.check_data_only()?,
        }
        self.check_tools()?;
        self.check_contributions()?;
        self.ui.check()?;
        if let Some(icon) = &info.icon
            && (!inside(icon)
                || !Path::new(icon)
                    .extension()
                    .is_some_and(|e| e.eq_ignore_ascii_case("png")))
        {
            return Err(ManifestError(format!(
                "plugin.icon `{icon}` must be a relative .png path inside the plugin directory."
            )));
        }
        if let Some(glob) = self
            .permissions
            .read
            .iter()
            .find(|g| g.starts_with('/') || g.split('/').any(|p| p == ".."))
        {
            return Err(ManifestError(format!(
                "permissions.read `{glob}` must stay inside the project."
            )));
        }
        let mut seen = BTreeSet::new();
        for skill in &self.skills {
            if !is_name(&skill.topic) {
                return Err(ManifestError(format!(
                    "skills.topic `{}` must be lowercase letters, digits and `-`, starting with a letter.",
                    skill.topic
                )));
            }
            if !seen.insert(skill.topic.as_str()) {
                return Err(ManifestError(format!(
                    "skills.topic `{}` is declared twice.",
                    skill.topic
                )));
            }
            if !inside(&skill.path)
                || !Path::new(&skill.path)
                    .extension()
                    .is_some_and(|e| e.eq_ignore_ascii_case("md"))
            {
                return Err(ManifestError(format!(
                    "skills.path `{}` must be a relative .md path inside the plugin directory.",
                    skill.path
                )));
            }
        }
        Ok(())
    }

    /// A plugin without a component has nothing that reads files, the
    /// platform, other plugins or settings: only contributions and the tools
    /// they run.
    fn check_data_only(&self) -> Result<(), ManifestError> {
        if self.contributes.is_empty() {
            return Err(ManifestError(
                "plugin.component is required unless the plugin contributes data under [[contributes]].".into(),
            ));
        }
        let permissions = &self.permissions;
        let unused = [
            (!permissions.read.is_empty(), "permissions.read"),
            (!permissions.platform.is_none(), "permissions.platform"),
            (!permissions.calls.is_empty(), "permissions.calls"),
            (!self.config.is_empty(), "config"),
        ];
        match unused.into_iter().find(|(set, _)| *set) {
            Some((_, key)) => Err(ManifestError(format!(
                "{key} is for a component; a plugin without plugin.component cannot use it."
            ))),
            None => Ok(()),
        }
    }

    /// `exec` and `[[tools]]` name the same programs, each once.
    fn check_tools(&self) -> Result<(), ManifestError> {
        let mut declared = BTreeSet::new();
        for tool in &self.tools {
            if !is_name(&tool.name) || !declared.insert(tool.name.as_str()) {
                return Err(ManifestError(format!(
                    "tools.name `{}` must be declared once: lowercase letters, digits and `-`, starting with a letter.",
                    tool.name
                )));
            }
            if tool.summary.trim().is_empty() {
                return Err(ManifestError(format!("tools `{}` needs a summary.", tool.name)));
            }
            if !self.permissions.exec.contains(&tool.name) {
                return Err(ManifestError(format!(
                    "tools `{}` is not in permissions.exec; declare only the programs the plugin runs.",
                    tool.name
                )));
            }
            tool.detect
                .check()
                .map_err(|reason| ManifestError(format!("tools `{}` {reason}", tool.name)))?;
            if let Some(version) = &tool.version {
                version
                    .check()
                    .map_err(|reason| ManifestError(format!("tools `{}` {reason}", tool.name)))?;
            }
        }
        let mut granted = BTreeSet::new();
        for tool in &self.permissions.exec {
            if !granted.insert(tool.as_str()) {
                return Err(ManifestError(format!("permissions.exec `{tool}` is listed twice.")));
            }
            if !declared.contains(tool.as_str()) {
                return Err(ManifestError(format!(
                    "permissions.exec `{tool}` needs a [[tools]] entry with name = \"{tool}\"."
                )));
            }
        }
        Ok(())
    }

    /// Each contribution is a data protocol, in its own directory inside the
    /// plugin, under a name no other contribution has.
    fn check_contributions(&self) -> Result<(), ManifestError> {
        let mut names = BTreeSet::new();
        for contribution in &self.contributes {
            let protocol = contribution.protocol.id();
            if !contribution.protocol.is_data() {
                return Err(ManifestError(format!(
                    "contributes protocol `{protocol}` is implemented by a capability, not contributed as data."
                )));
            }
            if !inside(&contribution.data) || contribution.data.contains('\\') {
                return Err(ManifestError(format!(
                    "contributes data `{}` must be a relative `/`-separated directory inside the plugin.",
                    contribution.data
                )));
            }
            let name = contribution.name();
            if !is_name(name) || name == "help" {
                return Err(ManifestError(format!(
                    "contributes data `{}` must end in a name of lowercase words joined by `-`, not `help`.",
                    contribution.data
                )));
            }
            if !names.insert(name) {
                return Err(ManifestError(format!(
                    "contributes name `{name}` is used twice; the last segment of data names the contribution."
                )));
            }
        }
        Ok(())
    }
}

/// A non-empty relative path that never leaves its directory.
pub(crate) fn inside(path: &str) -> bool {
    !path.is_empty() && Path::new(path).components().all(|c| matches!(c, Component::Normal(_)))
}

/// Lowercase words joined by `-`, starting with a letter: plugin names and ops.
pub fn is_name(value: &str) -> bool {
    value.starts_with(|c: char| c.is_ascii_lowercase())
        && !value.ends_with('-')
        && !value.contains("--")
        && value
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-')
}

fn toml_from_str<T: DeserializeOwned>(text: &str) -> Result<T, ManifestError> {
    toml::from_str(text).map_err(|error| ManifestError(format!("{MANIFEST_FILE}: {}", error.message())))
}

#[cfg(test)]
mod tests {
    use super::Manifest;

    fn manifest(extra: &str) -> String {
        format!(
            "[plugin]\nname = \"demo\"\nversion = \"0.1.0\"\nsummary = \"s\"\napi = \"{}\"\ncomponent = \"demo.wasm\"\n{extra}",
            crate::API
        )
    }

    #[test]
    fn display_names_are_optional_and_do_not_change_command_identity() {
        let legacy = manifest("");
        assert_eq!(Manifest::parse(&legacy).unwrap().plugin.display_name, None);
        let named = legacy.replace("name = \"demo\"", "name = \"demo\"\ndisplay_name = \"Godot Project Checker\"");
        let info = Manifest::parse(&named).unwrap().plugin;
        assert_eq!(info.name, "demo");
        assert_eq!(info.display_name.as_deref(), Some("Godot Project Checker"));
        assert!(Manifest::parse(&named.replace("Godot Project Checker", " ")).is_err());
    }

    #[test]
    fn skill_topics_are_named_unique_markdown_inside_the_plugin() {
        let ok = Manifest::parse(&manifest("[[skills]]\ntopic = \"usage\"\npath = \"docs/usage.md\"\n")).unwrap();
        assert_eq!(ok.skills[0].topic, "usage");
        for (extra, fragment) in [
            ("[[skills]]\ntopic = \"Bad\"\npath = \"a.md\"\n", "skills.topic `Bad`"),
            (
                "[[skills]]\ntopic = \"a\"\npath = \"a.md\"\n[[skills]]\ntopic = \"a\"\npath = \"b.md\"\n",
                "declared twice",
            ),
            ("[[skills]]\ntopic = \"a\"\npath = \"../a.md\"\n", "skills.path"),
            ("[[skills]]\ntopic = \"a\"\npath = \"/etc/a.md\"\n", "skills.path"),
            ("[[skills]]\ntopic = \"a\"\npath = \"notes.txt\"\n", "skills.path"),
            (
                "[[skills]]\ntopic = \"a\"\npath = \"a.md\"\ntitle = \"x\"\n",
                "unknown field",
            ),
        ] {
            let error = Manifest::parse(&manifest(extra)).unwrap_err().to_string();
            assert!(error.contains(fragment), "{extra}: {error}");
        }
    }

    #[test]
    fn every_0_1_api_loads_and_only_0_1_1_on_may_ask_for_the_platform() {
        let parse = |api: &str, extra: &str| {
            Manifest::parse(&manifest(extra).replace(crate::API, api)).map(|m| m.permissions.targets())
        };
        assert_eq!(parse(crate::API_0_1_0, ""), Ok(Vec::new()));
        assert_eq!(
            parse(crate::API, "[permissions]\nread = [\"src/**\"]\nplatform = \"read\"\n"),
            Ok(vec!["read src/**".to_owned(), super::PLATFORM_READ_TARGET.to_owned()])
        );
        let error = parse(crate::API_0_1_0, "[permissions]\nplatform = \"read\"\n").unwrap_err();
        assert!(error.to_string().contains("host.call"), "{error}");
        assert!(
            parse("wf:plugin@0.2.0", "")
                .unwrap_err()
                .to_string()
                .contains("not supported")
        );
        assert!(parse(crate::API, "[permissions]\nplatform = \"write\"\n").is_err());
    }

    #[test]
    fn calls_name_other_plugins_once_and_need_0_1_2() {
        let parse = |api: &str, calls: &str| {
            Manifest::parse(&manifest(&format!("[permissions]\ncalls = [{calls}]\n")).replace(crate::API, api))
                .map(|m| m.permissions.targets())
        };
        assert_eq!(
            parse(crate::API, "\"gdscript\""),
            Ok(vec![super::call_target("gdscript")])
        );
        for calls in ["\"demo\"", "\"Bad\"", "\"a\", \"a\""] {
            let error = parse(crate::API, calls).unwrap_err().to_string();
            assert!(error.contains("permissions.calls"), "{calls}: {error}");
        }
        let error = parse(crate::API_0_1_1, "\"gdscript\"").unwrap_err().to_string();
        assert!(error.contains("call-plugin"), "{error}");
    }

    #[test]
    fn config_fields_are_checked_with_their_defaults_and_need_0_1_3() {
        let field = |kind: &str, default: &str| {
            format!("[[config]]\nkey = \"limit\"\nlabel = \"Limit\"\nkind = {kind}\n{default}")
        };
        let ok = Manifest::parse(&manifest(&field(
            "{ type = \"number\", min = 1, max = 400, integer = true }",
            "default = 100\n",
        )))
        .unwrap();
        assert_eq!(ok.config[0].default, Some(crate::ConfigValue::Number(100.0)));
        for (extra, fragment) in [
            (
                field("{ type = \"number\", max = 10 }", "default = 11\n"),
                "default must be at most 10",
            ),
            (
                field("{ type = \"number\", min = 2, max = 1 }", ""),
                "min must not exceed max",
            ),
            (field("{ type = \"choice\", options = [] }", ""), "needs options"),
            (
                field("{ type = \"bool\" }", "default = \"yes\"\n"),
                "default must be true or false",
            ),
            (field("{ type = \"text\", max_len = 0 }", ""), "max_len"),
            (
                field("{ type = \"project_path\", glob = \"../x\" }", ""),
                "inside the project",
            ),
            (field("{ type = \"colour\" }", ""), "unknown variant"),
            (
                field("{ type = \"bool\" }", "").replace("limit", "Limit"),
                "config `Limit`",
            ),
            (
                format!(
                    "{}{}",
                    field("{ type = \"bool\" }", ""),
                    field("{ type = \"bool\" }", "")
                ),
                "declared twice",
            ),
        ] {
            let error = Manifest::parse(&manifest(&extra)).unwrap_err().to_string();
            assert!(error.contains(fragment), "{extra}: {error}");
        }
        let old = manifest(&field("{ type = \"bool\" }", "")).replace(crate::API, crate::API_0_1_2);
        let error = Manifest::parse(&old).unwrap_err().to_string();
        assert!(error.contains("host.config"), "{error}");
    }

    #[test]
    fn the_cli_range_is_part_of_the_manifest() {
        let parse =
            |cli: &str| Manifest::parse(&manifest("").replace("[plugin]\n", &format!("[plugin]\ncli = \"{cli}\"\n")));
        assert_eq!(parse(">=0.3.0").unwrap().plugin.cli.as_deref(), Some(">=0.3.0"));
        let error = parse("soon").unwrap_err().to_string();
        assert!(error.contains("plugin.cli"), "{error}");
    }

    #[test]
    fn the_icon_is_a_png_inside_the_plugin() {
        let parse = |icon: &str| {
            Manifest::parse(&manifest("").replace("[plugin]\n", &format!("[plugin]\nicon = \"{icon}\"\n")))
        };
        assert_eq!(
            parse("assets/icon.PNG").unwrap().plugin.icon.as_deref(),
            Some("assets/icon.PNG")
        );
        for icon in ["icon.svg", "../icon.png", "/icon.png", ""] {
            let error = parse(icon).unwrap_err().to_string();
            assert!(error.contains("plugin.icon"), "{icon}: {error}");
        }
    }

    const GODOT: &str = "[[tools]]\nname = \"godot\"\nsummary = \"Godot editor\"\ndetect.path = [\"godot\"]\n";
    const TEMPLATE: &str = "[[contributes]]\nprotocol = \"wf.template/1\"\ndata = \"templates/platformer\"\n";

    fn data_only(extra: &str) -> String {
        manifest(extra).replace("component = \"demo.wasm\"\n", "")
    }

    #[test]
    fn a_data_only_plugin_contributes_templates_that_run_declared_tools() {
        let text = data_only(&format!("[permissions]\nexec = [\"godot\"]\n{GODOT}{TEMPLATE}"));
        let parsed = Manifest::parse(&text).unwrap();
        assert_eq!(parsed.plugin.component, None);
        assert_eq!(parsed.contributes[0].protocol, crate::Protocol::Template);
        assert_eq!(parsed.contributes[0].name(), "platformer");
        assert_eq!(parsed.permissions.targets(), [super::exec_target("godot")]);
        assert_eq!(parsed.tools[0].detect.path, ["godot"]);
        for (extra, fragment) in [
            (String::new(), "plugin.component is required"),
            (
                format!("[permissions]\nread = [\"**\"]\n{TEMPLATE}"),
                "permissions.read is for a component",
            ),
            (
                format!("[[config]]\nkey = \"a\"\nlabel = \"A\"\nkind = {{ type = \"bool\" }}\n{TEMPLATE}"),
                "config is for a component",
            ),
        ] {
            let error = Manifest::parse(&data_only(&extra)).unwrap_err().to_string();
            assert!(error.contains(fragment), "{extra}: {error}");
        }
    }

    #[test]
    fn exec_and_tools_name_the_same_programs_once() {
        let exec = |names: &str| format!("[permissions]\nexec = [{names}]\n");
        for (extra, fragment) in [
            (exec("\"godot\""), "needs a [[tools]] entry"),
            (format!("{}{GODOT}", exec("\"godot\", \"godot\"")), "listed twice"),
            (GODOT.to_owned(), "not in permissions.exec"),
            (format!("{}{GODOT}{GODOT}", exec("\"godot\"")), "declared once"),
            (
                format!("{}{}", exec("\"godot\""), GODOT.replace("Godot editor", " ")),
                "needs a summary",
            ),
            (
                format!(
                    "{}{}",
                    exec("\"godot\""),
                    GODOT.replace("[\"godot\"]", "[\"godot; rm\"]")
                ),
                "detect.path",
            ),
            (
                format!("{}{GODOT}detect.macos = [\"/Applications/$(id)\"]\n", exec("\"godot\"")),
                "detect.macos",
            ),
        ] {
            let error = Manifest::parse(&manifest(&extra)).unwrap_err().to_string();
            assert!(error.contains(fragment), "{extra}: {error}");
        }
    }

    #[test]
    fn contributions_are_named_data_directories_of_data_protocols() {
        let contribution =
            |protocol: &str, data: &str| format!("[[contributes]]\nprotocol = \"{protocol}\"\ndata = \"{data}\"\n");
        let ok = Manifest::parse(&manifest(&contribution("wf.template/1", "starter"))).unwrap();
        assert_eq!(ok.contributes[0].name(), "starter");
        for (extra, fragment) in [
            (contribution("wf.lint/1", "lints/a"), "implemented by a capability"),
            (contribution("wf.scene/1", "a"), "unknown variant"),
            (contribution("wf.template/1", "../a"), "inside the plugin"),
            (contribution("wf.template/1", "/a"), "inside the plugin"),
            (contribution("wf.template/1", "templates\\\\a"), "inside the plugin"),
            (contribution("wf.template/1", "templates/Big"), "must end in a name"),
            (contribution("wf.template/1", "templates/help"), "must end in a name"),
            (
                format!(
                    "{}{}",
                    contribution("wf.template/1", "a/x"),
                    contribution("wf.template/1", "b/x")
                ),
                "used twice",
            ),
        ] {
            let error = Manifest::parse(&manifest(&extra)).unwrap_err().to_string();
            assert!(error.contains(fragment), "{extra}: {error}");
        }
    }

    #[test]
    fn a_misspelled_manifest_key_is_an_error() {
        let error = Manifest::parse(&manifest("[permisions]\nread = []\n")).unwrap_err();
        assert!(error.to_string().contains("permisions"), "{error}");
    }
}
