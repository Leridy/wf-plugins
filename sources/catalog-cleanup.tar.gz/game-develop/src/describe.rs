//! What `describe()` returns: `new` and the `wf.lint/1` provider `lint`.
use crate::scaffold::{NewInput, NewOutput};
use schemars::{JsonSchema, schema_for};
use serde_json::Value;
use wf_game_kit::{
    Capability, Description, Example, LintInput, LintOutput, Risk, lint::LINT, protocol::PROTOCOL, scaffold::NEW,
};

pub fn description() -> Description {
    Description {
        capabilities: vec![
            Capability {
                op: NEW.into(),
                summary: "Create a general Godot 4 game project".into(),
                when: "Start a Godot game with a title screen, gameplay, pause, results, seeded randomness, \
                       JSON saves, headless tests, balance bots, and a Web export preset. It creates files \
                       without replacing existing ones. Read game-develop/guide before extending it."
                    .into(),
                risk: Risk::Write,
                input: schema::<NewInput>(),
                output: Some(schema::<NewOutput>()),
                examples: vec![
                    Example {
                        args: "new".into(),
                        note: "create the project in game/".into(),
                    },
                    Example {
                        args: "new --dir games/castle --name Castle".into(),
                        note: "choose the directory and the game's name".into(),
                    },
                ],
                implements: None,
            },
            Capability {
                op: LINT.into(),
                summary: "Check common Godot gameplay, save, UI, and Web export pitfalls".into(),
                when: "Check pause timers, unsafe saves, shared resource mutation, pointer feedback, \
                       threaded Web exports, and accidentally packaged build output. Genre-specific checks \
                       belong to their template plugins. Run wf lint to combine installed checkers."
                    .into(),
                risk: Risk::Read,
                input: schema::<LintInput>(),
                output: Some(schema::<LintOutput>()),
                examples: vec![
                    Example {
                        args: "lint".into(),
                        note: "check every script, scene and export preset".into(),
                    },
                    Example {
                        args: "lint --paths game".into(),
                        note: "check one Godot project".into(),
                    },
                ],
                implements: Some(PROTOCOL.into()),
            },
        ],
    }
}

fn schema<T: JsonSchema>() -> Value {
    schema_for!(T).into()
}
