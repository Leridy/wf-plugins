//! `new`: the starter project, embedded from `template/starter` at build time.
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use wf_game_kit::{
    FileWrite,
    scaffold::{self, InputError, Templates},
};

static TEMPLATES: Templates = include!(concat!(env!("OUT_DIR"), "/templates.rs"));

const STARTER: &str = "starter";

/// Input of `new`.
#[derive(Debug, Deserialize, JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct NewInput {
    /// Project-relative directory to create the Godot project in (default
    /// `game`); it must not hold any of the starter's files yet.
    #[serde(default = "default_dir")]
    pub dir: String,
    /// The game's name, written to project.godot (`config/name`).
    #[serde(default)]
    pub name: Option<String>,
}

fn default_dir() -> String {
    "game".into()
}

/// Output of `new`.
#[derive(Debug, Serialize, JsonSchema)]
pub struct NewOutput {
    /// The Godot project directory, project-relative.
    pub dir: String,
    /// Its project file: open it with Godot 4.
    pub project: String,
    /// The scene the game starts in.
    pub main_scene: String,
    /// The headless rule tests; run with `godot --headless --path <dir> <tests>`.
    pub tests: String,
    /// The balance bots; run the same way.
    pub bots: String,
    /// How many files are created.
    pub files: usize,
}

/// The starter's files under `input.dir`.
pub fn plan(input: &NewInput) -> Result<(NewOutput, Vec<FileWrite>), InputError> {
    let dir = scaffold::directory(&input.dir)?;
    let name = input.name.as_deref().map(scaffold::game_name).transpose()?;
    let writes = scaffold::writes(&dir, starter(), name.as_deref());
    let output = NewOutput {
        project: scaffold::join(&dir, "project.godot"),
        main_scene: "res://main.tscn".into(),
        tests: "tests/run_tests.tscn".into(),
        bots: "tests/bots.tscn".into(),
        files: writes.len(),
        dir,
    };
    Ok((output, writes))
}

fn starter() -> &'static [scaffold::File] {
    scaffold::template(TEMPLATES, STARTER)
}

#[cfg(test)]
mod tests {
    use super::*;
    use wf_game_kit::lint::Source;

    #[test]
    fn the_starter_is_a_godot_project_without_hidden_files() {
        let paths: Vec<&str> = starter().iter().map(|(path, _)| *path).collect();
        for required in [
            "project.godot",
            "main.tscn",
            "scripts/game.gd",
            "tests/run_tests.tscn",
            "tests/bots.tscn",
            "LICENSE",
        ] {
            assert!(paths.contains(&required), "{required}");
        }
        assert!(paths.iter().all(|path| !path.split('/').any(|s| s.starts_with('.'))));
    }

    #[test]
    fn the_starter_passes_its_own_lint() {
        let sources: Vec<Source> = starter()
            .iter()
            .map(|(path, bytes)| Source {
                file: (*path).into(),
                text: String::from_utf8_lossy(bytes).into_owned(),
            })
            .filter(|source| source.is_script() || source.is_scene() || source.is_presets())
            .collect();
        assert!(sources.len() > 5);
        let diagnostics = crate::rules::check(&sources);
        assert!(diagnostics.is_empty(), "{diagnostics:#?}");
    }

    #[test]
    fn the_default_directory_is_game() {
        let input: NewInput = serde_json::from_str("{}").unwrap();
        let (output, writes) = plan(&input).unwrap();
        assert_eq!(output.project, "game/project.godot");
        assert_eq!(output.files, writes.len());
        assert!(writes.iter().all(|w| w.path.starts_with("game/")));
    }
}
