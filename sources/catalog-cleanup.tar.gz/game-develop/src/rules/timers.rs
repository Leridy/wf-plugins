//! `timer-runs-while-paused`.
use super::TIMER_RUNS_WHILE_PAUSED;
use wf_game_kit::{
    Diagnostic, Fix, Severity, TextEdit,
    gdscript::{argument_count, calls, closing_paren},
    span,
};

/// `SceneTree.create_timer(time)` leaves `process_always` at its default,
/// `true`: the timer keeps counting while the tree is paused, so cooldowns,
/// spawn gaps and countdowns run out behind a pause menu or a choice screen.
/// An explicit second argument is a decision and is left alone.
pub fn running_while_paused(file: &str, code: &str) -> Vec<Diagnostic> {
    const NAME: &str = "create_timer";
    let mut diagnostics = Vec::new();
    for (at, _, _) in calls(code, &[NAME], Some(true)) {
        let open = at + NAME.len() + code[at + NAME.len()..].find('(').unwrap_or(0);
        let Some(close) = closing_paren(code, open) else {
            continue;
        };
        if argument_count(code, open, close) != 1 {
            continue;
        }
        // After the argument's last code byte, before any trailing comma or space.
        let last = code[..close].trim_end().trim_end_matches(',').trim_end().len();
        diagnostics.push(Diagnostic {
            rule: TIMER_RUNS_WHILE_PAUSED.into(),
            severity: Severity::Warning,
            message: "create_timer() keeps counting while the game is paused (process_always defaults to true), so \
                      cooldowns, spawn gaps and countdowns run out behind a pause menu or a choice screen. Pass \
                      false as the second argument; pass true only for a delay that must run while paused."
                .into(),
            file: file.into(),
            span: Some(span(at, close + 1)),
            fix: Some(Fix {
                summary: "Stop the timer while paused".into(),
                edits: vec![TextEdit {
                    file: file.into(),
                    span: span(last, last),
                    text: ", false".into(),
                }],
            }),
        });
    }
    diagnostics
}
