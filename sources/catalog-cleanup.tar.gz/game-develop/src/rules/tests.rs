use super::*;
use wf_game_kit::TextEdit;

fn source(file: &str, text: &str) -> Source {
    Source {
        file: file.into(),
        text: text.into(),
    }
}

/// The rules over one file.
fn one(file: &str, text: &str) -> Vec<Diagnostic> {
    check(&[source(file, text)])
}

fn rules(diagnostics: &[Diagnostic]) -> Vec<&str> {
    diagnostics.iter().map(|d| d.rule.as_str()).collect()
}

fn spanned<'a>(text: &'a str, diagnostic: &Diagnostic) -> &'a str {
    let span = diagnostic.span.unwrap();
    &text[span.start as usize..span.end as usize]
}

/// `text` with every fix applied, edits from the end so offsets stay valid.
fn fixed(text: &str, diagnostics: &[Diagnostic]) -> String {
    let mut edits: Vec<&TextEdit> = diagnostics
        .iter()
        .filter_map(|d| d.fix.as_ref())
        .flat_map(|f| &f.edits)
        .collect();
    edits.sort_by_key(|e| std::cmp::Reverse(e.span.start));
    let mut out = text.to_owned();
    for edit in edits {
        out.replace_range(edit.span.start as usize..edit.span.end as usize, &edit.text);
    }
    out
}

#[test]
fn a_one_argument_timer_gets_false_and_explicit_ones_are_left_alone() {
    let text = "func spawn():\n\tawait get_tree().create_timer(gaps[i]).timeout\n\
                \tawait get_tree().create_timer(1.0, true).timeout\n\
                \tawait get_tree().create_timer(0.5, false).timeout\n\
                \t# get_tree().create_timer(9)\n\tprint(\"x.create_timer(2)\")\n\
                \tget_tree().create_timer(\n\t\tdelay,\n\t)\n";
    let diagnostics = one("w.gd", text);
    assert_eq!(rules(&diagnostics), [TIMER_RUNS_WHILE_PAUSED, TIMER_RUNS_WHILE_PAUSED]);
    let after = fixed(text, &diagnostics);
    assert!(after.contains("create_timer(gaps[i], false)"));
    assert!(after.contains("create_timer(\n\t\tdelay, false,\n\t)"));
    assert!(one("w.gd", &after).is_empty());
    assert!(one("a.gd", "func create_timer(t):\n\tpass\nvar x = my_create_timer(1)\n").is_empty());
}

#[test]
fn a_threaded_web_preset_is_reported_unless_the_pwa_isolates_it() {
    let text = "[preset.0]\nname=\"Web\"\nplatform=\"Web\"\n\n[preset.0.options]\nvariant/thread_support=true\n\n\
                [preset.1]\nplatform=\"Windows Desktop\"\n\n[preset.1.options]\nvariant/thread_support=true\n\n\
                [preset.2]\nplatform=\"Web\"\n\n[preset.2.options]\nvariant/thread_support=true\n\
                progressive_web_app/enabled=true\n\n\
                [preset.3]\nplatform=\"Web\"\n\n[preset.3.options]\nvariant/thread_support=false\n\n\
                [preset.4]\nplatform=\"Web\"\n\n[preset.4.options]\nvariant/thread_support=true\r\n\
                progressive_web_app/enabled=true\nprogressive_web_app/ensure_cross_origin_isolation_headers=false\n";
    let diagnostics = one("export_presets.cfg", text);
    assert_eq!(
        rules(&diagnostics),
        [WEB_THREADS_NEED_ISOLATION, WEB_THREADS_NEED_ISOLATION]
    );
    for diagnostic in &diagnostics {
        assert_eq!(spanned(text, diagnostic), "variant/thread_support=true");
        assert!(diagnostic.fix.is_none());
    }
}

#[test]
fn an_export_into_the_project_must_exclude_its_directory() {
    let text = "[preset.0]\nplatform=\"Web\"\nexclude_filter=\"tests/*\"\nexport_path=\"build/web/index.html\"\n\n\
                [preset.1]\nplatform=\"Linux\"\nexclude_filter=\"\"\nexport_path=\"out/game.x86_64\"\n\n\
                [preset.2]\nplatform=\"Web\"\nexclude_filter=\"tests/*, build/*\"\nexport_path=\"build/web/index.html\"\n\n\
                [preset.3]\nplatform=\"Web\"\nexclude_filter=\"\"\nexport_path=\"../site/index.html\"\n\n\
                [preset.4]\nplatform=\"Web\"\nexclude_filter=\"\"\nexport_path=\"\"\n";
    let diagnostics = one("game/export_presets.cfg", text);
    assert_eq!(
        rules(&diagnostics),
        [EXPORT_PACKS_BUILD_OUTPUT, EXPORT_PACKS_BUILD_OUTPUT]
    );
    assert_eq!(spanned(text, &diagnostics[0]), "export_path=\"build/web/index.html\"");
    let after = fixed(text, &diagnostics);
    assert!(after.contains("exclude_filter=\"tests/*, build/*\"\nexport_path=\"build/web"));
    assert!(after.contains("exclude_filter=\"out/*\"\nexport_path=\"out/"));
    assert!(one("game/export_presets.cfg", &after).is_empty());
}

#[test]
fn saves_read_as_resources_or_objects_are_reported() {
    let text = "const SAVE := \"user://inventory.tres\"\nconst SETTINGS = \"user://settings.json\"\n\
                func restore():\n\tvar inv = ResourceLoader.load(SAVE) as Inventory\n\
                \tvar other = load(\"user://slot_1.res\")\n\tvar art = load(\"res://art.tres\")\n\
                \tvar cfg = load(SETTINGS)\n\tvar data = file.get_var(true)\n\tvar plain = file.get_var()\n\
                \tvar obj = bytes_to_var_with_objects(bytes)\n";
    let diagnostics = one("save.gd", text);
    assert_eq!(rules(&diagnostics), [SAVE_CAN_RUN_CODE; 4]);
    let named: Vec<&str> = diagnostics.iter().map(|d| spanned(text, d)).collect();
    assert_eq!(
        named,
        [
            "load(SAVE)",
            "load(\"user://slot_1.res\")",
            "get_var(true)",
            "bytes_to_var_with_objects"
        ]
    );
}

#[test]
fn a_shared_resource_changed_at_runtime_is_reported() {
    let stats = "class_name Stats\nextends Resource\n@export var hp := 10\n";
    let enemy = "extends Node2D\n@export var stats: Stats\nvar label: Label\nfunc _init():\n\tstats.hp = 5\n\
                 func hit(amount):\n\tlabel.text = \"x\"\n\tstats.hp -= amount\n\tif stats.hp == 0:\n\t\tpass\n";
    let diagnostics = check(&[source("stats.gd", stats), source("enemy.gd", enemy)]);
    assert_eq!(rules(&diagnostics), [SHARED_RESOURCE_MUTATED]);
    assert_eq!(spanned(enemy, &diagnostics[0]), "stats");
    assert!(enemy[diagnostics[0].span.unwrap().start as usize..].starts_with("stats.hp -="));
    let unique = format!("{enemy}func _ready():\n\tstats = stats.duplicate()\n");
    assert!(check(&[source("stats.gd", stats), source("enemy.gd", &unique)]).is_empty());
    let loaded = "var data = preload(\"res://slime.tres\")\nfunc hurt():\n\tdata.hp -= 1\n";
    assert_eq!(rules(&one("slime.gd", loaded)), [SHARED_RESOURCE_MUTATED]);
    let made = "var view := preload(\"res://view.gd\").new()\nfunc _ready():\n\tview.position = Vector2.ONE\n";
    assert!(
        one("main.gd", made).is_empty(),
        "an object made from a script is not shared"
    );
    let one_line = "class_name Gear extends Resource\n";
    assert!(resources::Project::of(&[one_line]).resources.contains("Gear"));
}

#[test]
fn clickable_scene_nodes_without_a_cursor_get_the_pointing_hand() {
    let text = "[gd_scene format=3]\n\n[node name=\"Hud\" type=\"Control\"]\nmouse_filter = 2\n\n\
                [node name=\"Play\" type=\"Button\" parent=\".\"]\ntext = \"Play\"\n\n\
                [node name=\"Quit\" type=\"Button\" parent=\".\"]\nmouse_default_cursor_shape = 2\n\n\
                [node name=\"Volume\" type=\"HSlider\" parent=\".\"]\r\n\r\n\
                [node name=\"Shop\" parent=\".\" instance=ExtResource(\"2\")]\n\n\
                [node name=\"Last\" type=\"TextureButton\" parent=\".\"]";
    let diagnostics = one("ui/hud.tscn", text);
    assert_eq!(rules(&diagnostics), [CONTROL_CURSOR_UNSET; 3]);
    assert_eq!(
        spanned(text, &diagnostics[0]),
        "[node name=\"Play\" type=\"Button\" parent=\".\"]"
    );
    let after = fixed(text, &diagnostics);
    assert!(after.contains("parent=\".\"]\nmouse_default_cursor_shape = 2\ntext = \"Play\""));
    assert!(after.contains("type=\"HSlider\" parent=\".\"]\r\nmouse_default_cursor_shape = 2\r\n"));
    assert!(after.ends_with("type=\"TextureButton\" parent=\".\"]\nmouse_default_cursor_shape = 2"));
    assert!(one("ui/hud.tscn", &after).is_empty());
}

#[test]
fn buttons_made_in_code_need_a_cursor_before_they_are_shown() {
    let text = "func offer(options):\n\tfor option in options:\n\t\tvar button := Button.new()\n\
                \t\tbutton.text = option\n\t\tvar box = CheckBox.new()\n\t\tbox.mouse_default_cursor_shape = 2\n\
                \t\tvar label := Label.new()\n\t\tvar check: CheckBox = CheckBox.new()\n";
    let diagnostics = one("main.gd", text);
    assert_eq!(rules(&diagnostics), [CONTROL_CURSOR_UNSET; 2]);
    assert_eq!(spanned(text, &diagnostics[0]), "var button := Button.new()");
    let after = fixed(text, &diagnostics);
    assert!(after.contains(
        "\t\tvar button := Button.new()\n\t\tbutton.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND\n"
    ));
    assert!(after.ends_with("CheckBox.new()\n\t\tcheck.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND\n"));
    assert!(one("main.gd", &after).is_empty());
}

#[test]
fn a_script_level_control_is_reported_unless_a_helper_sets_cursors() {
    let alone = "var volume := HSlider.new()\nfunc _ready():\n\tadd_child(volume)\n";
    let diagnostics = one("hud.gd", alone);
    assert_eq!(rules(&diagnostics), [CONTROL_CURSOR_UNSET]);
    assert!(
        diagnostics[0].fix.is_none(),
        "a script-level var takes no statement after it"
    );
    let helper = "var volume := HSlider.new()\nfunc _ready():\n\t_slider(volume)\n\
                  func _slider(slider):\n\tslider.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND\n";
    assert!(one("hud.gd", helper).is_empty());
}
