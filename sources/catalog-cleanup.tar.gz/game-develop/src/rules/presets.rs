//! The export preset rules: `web-threads-need-isolation` and
//! `export-packs-build-output`.
use super::{EXPORT_PACKS_BUILD_OUTPUT, WEB_THREADS_NEED_ISOLATION};
use wf_game_kit::{Diagnostic, Fix, Severity, TextEdit, span};

/// One `[preset.N]` with its `[preset.N.options]`: the values the rules read,
/// and where each key's line is.
#[derive(Default)]
struct Preset<'a> {
    id: &'a str,
    /// `key=value` lines: key, raw value, and the line's span without its ending.
    values: Vec<(&'a str, &'a str, usize, usize)>,
}

impl<'a> Preset<'a> {
    fn get(&self, key: &str) -> Option<(&'a str, usize, usize)> {
        self.values
            .iter()
            .find(|(k, _, _, _)| *k == key)
            .map(|(_, value, start, end)| (*value, *start, *end))
    }

    /// A string value without its quotes.
    fn string(&self, key: &str) -> Option<&'a str> {
        let (value, _, _) = self.get(key)?;
        value.strip_prefix('"')?.strip_suffix('"')
    }

    fn is(&self, key: &str, value: &str) -> bool {
        self.get(key).is_some_and(|(v, _, _)| v == value)
    }
}

fn presets(text: &str) -> Vec<Preset<'_>> {
    let mut presets: Vec<Preset> = Vec::new();
    let mut current: Option<usize> = None;
    let mut offset = 0;
    for line in text.split_inclusive('\n') {
        let start = offset;
        offset += line.len();
        let content = line.trim_end_matches(['\r', '\n']);
        if let Some(section) = content.strip_prefix('[').and_then(|rest| rest.strip_suffix(']')) {
            let id = section
                .strip_prefix("preset.")
                .map(|rest| rest.strip_suffix(".options").unwrap_or(rest));
            current = id.map(|id| {
                presets.iter().position(|p| p.id == id).unwrap_or_else(|| {
                    presets.push(Preset {
                        id,
                        ..Preset::default()
                    });
                    presets.len() - 1
                })
            });
            continue;
        }
        if let (Some(index), Some((key, value))) = (current, content.split_once('=')) {
            presets[index]
                .values
                .push((key.trim(), value.trim(), start, start + content.len()));
        }
    }
    presets
}

/// A Web preset exported with thread support only starts on a page served
/// with `Cross-Origin-Opener-Policy` and `Cross-Origin-Embedder-Policy`
/// headers. Static hosting, object storage and most game portals send
/// neither, and the game never gets past its loading screen. Godot's PWA
/// option with `ensure_cross_origin_isolation_headers` adds them through a
/// service worker, so that combination is left alone.
pub fn threads_needing_isolation(file: &str, text: &str) -> Vec<Diagnostic> {
    presets(text)
        .iter()
        .filter(|preset| preset.string("platform") == Some("Web"))
        .filter(|preset| {
            let pwa = preset.is("progressive_web_app/enabled", "true");
            let isolates = !preset.is("progressive_web_app/ensure_cross_origin_isolation_headers", "false");
            !(pwa && isolates)
        })
        .filter_map(|preset| preset.get("variant/thread_support").filter(|(v, _, _)| *v == "true"))
        .map(|(_, start, end)| Diagnostic {
            rule: WEB_THREADS_NEED_ISOLATION.into(),
            severity: Severity::Warning,
            message: "This Web preset exports with thread support, which only starts on a page served with \
                      Cross-Origin-Opener-Policy and Cross-Origin-Embedder-Policy headers; static hosting, object \
                      storage and most game portals send neither, so the game hangs on its loading screen. Set \
                      variant/thread_support=false unless your server sends both headers, or enable the \
                      progressive web app with ensure_cross_origin_isolation_headers."
                .into(),
            file: file.into(),
            span: Some(span(start, end)),
            fix: None,
        })
        .collect()
}

/// A preset that exports into the project (`export_path="build/web/…"`)
/// without excluding that directory: Godot imports the previous build's
/// files (its icons, its HTML) as project files, and the next export packs
/// them into the game. The fix adds the export's top directory to
/// `exclude_filter`.
pub fn build_output_packed(file: &str, text: &str) -> Vec<Diagnostic> {
    let mut diagnostics = Vec::new();
    for preset in presets(text) {
        let Some(path) = preset.string("export_path") else {
            continue;
        };
        let Some(top) = inside_project(path) else {
            continue;
        };
        let (filter, start, end) = preset.get("exclude_filter").unwrap_or(("\"\"", 0, 0));
        let filter = filter.trim_matches('"');
        if excludes(filter, top) {
            continue;
        }
        let pattern = format!("{top}/*");
        let fix = (end > 0).then(|| {
            let joined = if filter.trim().is_empty() {
                pattern.clone()
            } else {
                format!("{filter}, {pattern}")
            };
            Fix {
                summary: format!("Exclude {pattern} from the export"),
                edits: vec![TextEdit {
                    file: file.into(),
                    span: span(start, end),
                    text: format!("exclude_filter=\"{joined}\""),
                }],
            }
        });
        let (at, to) = preset.get("export_path").map(|(_, s, e)| (s, e)).unwrap_or_default();
        diagnostics.push(Diagnostic {
            rule: EXPORT_PACKS_BUILD_OUTPUT.into(),
            severity: Severity::Warning,
            message: format!(
                "This preset exports into the project ({path}) but its exclude_filter does not leave out {top}/: \
                 Godot imports the previous build's files as project files and the next export packs them into \
                 the game. Add \"{pattern}\" to exclude_filter (or put an empty .gdignore file in {top}/)."
            ),
            file: file.into(),
            span: Some(span(at, to)),
            fix,
        });
    }
    diagnostics
}

/// The top directory of an export path inside the project, if it is one:
/// `build/web/index.html` → `build`. Absolute paths, `res://`, `..` and a
/// file at the project root are outside any directory the export could pack.
fn inside_project(path: &str) -> Option<&str> {
    let path = path.strip_prefix("res://").unwrap_or(path).trim_start_matches("./");
    if path.starts_with('/') || path.starts_with("..") || path.contains(':') || path.contains('\\') {
        return None;
    }
    let (top, _) = path.split_once('/')?;
    (!top.is_empty() && top != ".").then_some(top)
}

/// Whether a comma-separated filter leaves out everything under `top/`.
fn excludes(filter: &str, top: &str) -> bool {
    filter.split(',').map(str::trim).any(|pattern| {
        let pattern = pattern.trim_start_matches("res://").trim_start_matches("./");
        pattern == "*"
            || pattern
                .strip_prefix(top)
                .is_some_and(|rest| matches!(rest, "/*" | "/**" | "/**/*"))
    })
}
