//! `control-cursor-unset`: a control the player clicks keeps Godot's arrow,
//! so it looks the same as everything that cannot be clicked.
use super::CONTROL_CURSOR_UNSET;
use wf_game_kit::{Diagnostic, Fix, Severity, TextEdit, gdscript::is_identifier_byte, scene, span};

/// Controls a player clicks or drags: the button family and sliders.
const CLICKABLE: [&str; 10] = [
    "Button",
    "TextureButton",
    "CheckBox",
    "CheckButton",
    "OptionButton",
    "MenuButton",
    "LinkButton",
    "ColorPickerButton",
    "HSlider",
    "VSlider",
];

const KEY: &str = "mouse_default_cursor_shape";
/// `Control.CURSOR_POINTING_HAND` as a scene stores it.
const POINTING_HAND: &str = "mouse_default_cursor_shape = 2";

const MESSAGE: &str = "Players can click this control, but it keeps Godot's arrow cursor, so it looks the same as \
                       text and panels they cannot click. Set mouse_default_cursor_shape to \
                       Control.CURSOR_POINTING_HAND (2 in a scene); where the code disables it, switch to \
                       CURSOR_FORBIDDEN at the same place, since Godot keeps the shape of a disabled control.";

/// Clickable nodes in a text scene that set no cursor shape.
pub fn scene(file: &str, text: &str) -> Vec<Diagnostic> {
    scene::nodes(text)
        .into_iter()
        .filter(|node| node.kind.is_some_and(|kind| CLICKABLE.contains(&kind)) && !node.sets(KEY))
        .map(|node| {
            let (at, line) = node.insert_under_header(POINTING_HAND);
            Diagnostic {
                rule: CONTROL_CURSOR_UNSET.into(),
                severity: Severity::Warning,
                message: MESSAGE.into(),
                file: file.into(),
                span: Some(span(node.start, node.start + node.header.len())),
                fix: Some(Fix {
                    summary: "Show a pointing hand over it".into(),
                    edits: vec![TextEdit {
                        file: file.into(),
                        span: span(at, at),
                        text: line,
                    }],
                }),
            }
        })
        .collect()
}

/// `var name := Button.new()` (or `= Button.new()`, typed or not) where the
/// script never sets `name.mouse_default_cursor_shape`. A script-level one is
/// left alone when the script sets a cursor shape on anything, since such
/// controls are usually configured by a helper under another name.
pub fn script(file: &str, code: &str) -> Vec<Diagnostic> {
    let mut diagnostics = Vec::new();
    let mut offset = 0;
    for line in code.split_inclusive('\n') {
        let start = offset;
        offset += line.len();
        let Some((name, kind)) = created_control(line) else {
            continue;
        };
        let indent = &line[..line.len() - line.trim_start().len()];
        // A script-level control is often set up by a helper it is passed to
        // (`_slider(_volume)`); when the script sets a cursor shape anywhere,
        // trust that rather than report a control that has one.
        let helper_sets_it = indent.is_empty() && code.contains(&format!(".{KEY}"));
        if !CLICKABLE.contains(&kind) || sets_cursor(code, name) || helper_sets_it {
            continue;
        }
        let content = line.trim_end_matches(['\r', '\n']);
        let ending = &line[content.len()..];
        let ending = if ending.is_empty() { "\n" } else { ending };
        let (at, text) = if line.len() == content.len() {
            (
                start + content.len(),
                format!("{ending}{indent}{name}.{KEY} = Control.CURSOR_POINTING_HAND"),
            )
        } else {
            (
                start + line.len(),
                format!("{indent}{name}.{KEY} = Control.CURSOR_POINTING_HAND{ending}"),
            )
        };
        let declared = start + indent.len();
        // A script-level `var` takes no statement after it; set it in _ready() by hand.
        let fix = (!indent.is_empty()).then(|| Fix {
            summary: "Show a pointing hand over it".into(),
            edits: vec![TextEdit {
                file: file.into(),
                span: span(at, at),
                text,
            }],
        });
        diagnostics.push(Diagnostic {
            rule: CONTROL_CURSOR_UNSET.into(),
            severity: Severity::Warning,
            message: MESSAGE.into(),
            file: file.into(),
            span: Some(span(declared, start + content.len())),
            fix,
        });
    }
    diagnostics
}

/// `var name[: Type] [:]= Kind.new()` on one line: (name, Kind).
fn created_control(line: &str) -> Option<(&str, &str)> {
    let rest = line.trim_start().strip_prefix("var ")?.trim_start();
    let name_len = rest.bytes().take_while(|&b| is_identifier_byte(b)).count();
    let (name, rest) = rest.split_at(name_len);
    let value = rest.split_once('=')?.1.trim();
    let kind = value.strip_suffix(".new()")?;
    (!name.is_empty() && kind.bytes().all(is_identifier_byte)).then_some((name, kind))
}

/// Whether `code` assigns `name.mouse_default_cursor_shape` anywhere.
fn sets_cursor(code: &str, name: &str) -> bool {
    let pattern = format!("{name}.{KEY}");
    code.match_indices(&pattern).any(|(at, _)| {
        let before = code[..at].bytes().next_back();
        let after = code[at + pattern.len()..].trim_start();
        before.is_none_or(|b| !is_identifier_byte(b) && b != b'.') && after.starts_with('=') && !after.starts_with("==")
    })
}
