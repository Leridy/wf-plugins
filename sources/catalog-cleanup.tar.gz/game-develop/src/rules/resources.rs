//! `save-can-run-code` and `shared-resource-mutated`: saves read as objects,
//! and Resources changed at runtime that every user of the file shares.
use super::{SAVE_CAN_RUN_CODE, SHARED_RESOURCE_MUTATED};
use std::collections::{BTreeMap, BTreeSet};
use wf_game_kit::{
    Diagnostic, Severity,
    gdscript::{calls, class_name, closing_paren, code_only, extends, functions, is_identifier_byte, strings},
    span,
};

/// Resource files `load()` reads as objects.
const RESOURCE_FILES: [&str; 4] = [".tres", ".res", ".tscn", ".scn"];

/// What the rules know about the checked scripts as a whole.
#[derive(Clone, Debug, Default)]
pub struct Project {
    /// `class_name`s of scripts that extend Resource directly.
    pub resources: BTreeSet<String>,
}

impl Project {
    pub fn of(texts: &[&str]) -> Self {
        let mut project = Self::default();
        for text in texts {
            let code = code_only(text);
            if let Some(name) = class_name(&code, text)
                && extends(&code) == Some("Resource")
            {
                project.resources.insert(name);
            }
        }
        project
    }
}

/// Loading a save as a Resource (`load("user://save.tres")`) runs any script
/// embedded in the file, and so does `get_var(true)` or
/// `bytes_to_var_with_objects()` on file data. Players share and edit save
/// files, so a save is untrusted input.
pub fn saves_that_run_code(file: &str, text: &str, code: &str) -> Vec<Diagnostic> {
    let constants = user_resource_constants(text, code);
    let mut diagnostics = Vec::new();
    let mut report = |start: usize, end: usize, what: String| {
        diagnostics.push(Diagnostic {
            rule: SAVE_CAN_RUN_CODE.into(),
            severity: Severity::Warning,
            message: format!(
                "{what} A save file is something players share and edit, and a Resource or object read from it can \
                 carry a script that runs when it loads. Store saves as data: JSON (FileAccess + JSON), or \
                 store_var()/get_var() without objects, and rebuild objects from that data."
            ),
            file: file.into(),
            span: Some(span(start, end)),
            fix: None,
        });
    };
    for (at, name, _) in calls(code, &["load", "load_threaded_request"], None) {
        let open = at + name.len() + code[at + name.len()..].find('(').unwrap_or(0);
        let Some(close) = closing_paren(code, open) else {
            continue;
        };
        let argument = text[open + 1..close].split(',').next().unwrap_or("").trim();
        let path = argument
            .strip_prefix('"')
            .and_then(|a| a.strip_suffix('"'))
            .map(str::to_owned)
            .or_else(|| constants.get(argument).cloned());
        if let Some(path) = path.filter(|p| is_user_resource(p)) {
            report(
                at,
                close + 1,
                format!("{name}() reads {path:?} from user:// as a Resource."),
            );
        }
    }
    for (at, name, _) in calls(code, &["get_var"], Some(true)) {
        let open = at + name.len() + code[at + name.len()..].find('(').unwrap_or(0);
        if let Some(close) = closing_paren(code, open)
            && code[open + 1..close].trim() == "true"
        {
            report(at, close + 1, "get_var(true) decodes objects from the file.".into());
        }
    }
    for (at, name, _) in calls(code, &["bytes_to_var_with_objects"], None) {
        report(
            at,
            at + name.len(),
            "bytes_to_var_with_objects() decodes objects from the data.".into(),
        );
    }
    diagnostics
}

fn is_user_resource(path: &str) -> bool {
    path.starts_with("user://") && RESOURCE_FILES.iter().any(|extension| path.ends_with(extension))
}

/// `const NAME := "user://…tres"` (or `var`) in the script: name -> path.
fn user_resource_constants(text: &str, code: &str) -> BTreeMap<String, String> {
    let mut constants = BTreeMap::new();
    for (start, _, inner) in strings(text) {
        if !is_user_resource(inner) {
            continue;
        }
        let line_start = code[..start].rfind('\n').map_or(0, |n| n + 1);
        let before = code[line_start..start].trim();
        let Some(declaration) = before.strip_suffix('=').map(|b| b.trim_end_matches(':').trim()) else {
            continue;
        };
        let declaration = declaration.split(':').next().unwrap_or("").trim();
        for keyword in ["const ", "var ", "static var "] {
            if let Some(name) = declaration.strip_prefix(keyword) {
                constants.insert(name.trim().to_owned(), inner.to_owned());
            }
        }
    }
    constants
}

/// A Resource loaded from a file is cached: every node that loads (or
/// exports) the same `.tres` holds the same object. Changing a field of it at
/// runtime (`stats.hp -= 3`) changes it for every enemy that uses the file,
/// and for the editor's copy until the game restarts.
pub fn shared_resources(file: &str, code: &str, project: &Project) -> Vec<Diagnostic> {
    let mut diagnostics = Vec::new();
    for (name, kind) in resource_variables(code, project) {
        let made_unique = code.contains(&format!("{name}.duplicate(")) || code.contains("resource_local_to_scene");
        if made_unique {
            continue;
        }
        let Some(at) = first_mutation(code, &name) else {
            continue;
        };
        diagnostics.push(Diagnostic {
            rule: SHARED_RESOURCE_MUTATED.into(),
            severity: Severity::Warning,
            message: format!(
                "{name} is a {kind} Resource and this changes it at runtime. Godot loads a resource file once, so \
                 every node using the same file shares this one object: hurting one enemy hurts them all. Call \
                 `{name} = {name}.duplicate()` in _ready(), turn on resource_local_to_scene, or keep the \
                 changing values (current HP) on the node."
            ),
            file: file.into(),
            span: Some(span(at, at + name.len())),
            fix: None,
        });
    }
    diagnostics
}

/// Script variables holding a Resource: typed with a project Resource class
/// (`@export var stats: Stats`), or set from a resource file
/// (`var stats = preload("res://slime.tres")`). Returns (name, kind).
fn resource_variables(code: &str, project: &Project) -> Vec<(String, String)> {
    let mut found = Vec::new();
    for line in code.lines() {
        let trimmed = line.trim_start();
        // Only script-level variables: function bodies are indented.
        if trimmed.len() != line.len() {
            continue;
        }
        let Some(rest) = trimmed
            .strip_prefix("@export ")
            .or(Some(trimmed))
            .map(str::trim_start)
            .and_then(|r| r.strip_prefix("var "))
        else {
            continue;
        };
        let name: String = rest
            .bytes()
            .take_while(|&b| is_identifier_byte(b))
            .map(char::from)
            .collect();
        let after = rest[name.len()..].trim_start();
        let typed = after.strip_prefix(':').map(|t| {
            t.trim_start()
                .bytes()
                .take_while(|&b| is_identifier_byte(b))
                .map(char::from)
                .collect::<String>()
        });
        if let Some(kind) = typed.filter(|t| project.resources.contains(t)) {
            found.push((name, kind));
        } else if loads_shared_resource(after) {
            found.push((name, "loaded".into()));
        }
    }
    found
}

/// Whether a declaration's value is a resource as loaded (`load(…)`,
/// `preload(…)`), not a fresh object made from it with `.new()`,
/// `.instantiate()` or `.duplicate()`.
fn loads_shared_resource(value: &str) -> bool {
    value.find("load(").is_some_and(|at| {
        ![".new(", ".instantiate(", ".duplicate("]
            .iter()
            .any(|made| value[at..].contains(made))
    })
}

/// The offset of the first `name.field = ...` or `name.field op= ...` inside
/// a function other than `_init`.
fn first_mutation(code: &str, name: &str) -> Option<usize> {
    let pattern = format!("{name}.");
    for (start, end) in functions(code) {
        let header = code[start..end].lines().next().unwrap_or_default();
        if header.contains("_init(") {
            continue;
        }
        for (offset, _) in code[start..end].match_indices(&pattern) {
            let at = start + offset;
            if at > 0 && (is_identifier_byte(code.as_bytes()[at - 1]) || code.as_bytes()[at - 1] == b'.') {
                continue;
            }
            let rest = &code[at + pattern.len()..];
            let field_len = rest.bytes().take_while(|&b| is_identifier_byte(b)).count();
            let after = rest[field_len..].trim_start();
            let assigns = ["+=", "-=", "*=", "/=", "%="].iter().any(|op| after.starts_with(op))
                || after.starts_with('=') && !after.starts_with("==");
            if field_len > 0 && assigns {
                return Some(at);
            }
        }
    }
    None
}
