//! `game-develop`: a wf plugin for Godot 4 games of any genre.
//!
//! - `new` writes a small playable project with the structure every game
//!   needs (rules apart from the screen, seeded randomness, JSON saves,
//!   headless tests and bots, a Web export that runs on static hosting).
//! - `lint` implements `wf.lint/1` with checks that hold for every game.
//!
//! Genre plugins (`tower-develop`, `rpg-develop`, …) build on `wf-game-kit`
//! (`kit/`) and leave these checks to this plugin.

mod describe;
mod rules;
mod scaffold;

use wf_game_kit::{
    CallError, Description, Hint, Host, Plugin, Reply,
    lint::{self, GODOT_KINDS, LINT},
    plugin::parse,
    scaffold::NEW,
};

pub use rules::check;
pub use scaffold::{NewInput, NewOutput, plan};

/// The plugin.
pub struct GameDevelop;

impl Plugin for GameDevelop {
    const NAME: &'static str = "game-develop";

    fn description() -> Description {
        describe::description()
    }

    fn call(op: &str, input: &[u8], host: &dyn Host) -> Result<Reply, CallError> {
        match op {
            NEW => {
                let (output, writes) = plan(&parse(input)?)?;
                let hints = vec![
                    Hint::skill("game-develop/guide", "how to grow the starter into your game"),
                    Hint::skill(
                        "game-develop/assets",
                        "which UI kits, word art, icons and art to ask the platform for, and how to wire them in",
                    ),
                    Hint::lint(Self::NAME, &output.dir),
                ];
                Ok(Reply::json(&output).with_writes(writes).with_hints(hints))
            }
            LINT => Ok(Reply::json(&lint::run(host, &parse(input)?, &GODOT_KINDS, check))),
            _ => Err(CallError::unknown_op(op, &[NEW, LINT])),
        }
    }
}

wf_game_kit::export_plugin!(GameDevelop);
