//! The checks that hold for every Godot game, whatever its genre. Genre
//! plugins leave these to `game-develop` and keep only their own.
//!
//! Spans are UTF-8 byte offsets into the checked file; the lint driver skips
//! files too large for them before any rule runs.
use wf_game_kit::{Diagnostic, lint::Source};

mod cursor;
mod presets;
mod resources;
mod timers;

pub const TIMER_RUNS_WHILE_PAUSED: &str = "timer-runs-while-paused";
pub const WEB_THREADS_NEED_ISOLATION: &str = "web-threads-need-isolation";
pub const EXPORT_PACKS_BUILD_OUTPUT: &str = "export-packs-build-output";
pub const SAVE_CAN_RUN_CODE: &str = "save-can-run-code";
pub const SHARED_RESOURCE_MUTATED: &str = "shared-resource-mutated";
pub const CONTROL_CURSOR_UNSET: &str = "control-cursor-unset";

/// Every rule over the checked files.
pub fn check(sources: &[Source]) -> Vec<Diagnostic> {
    let scripts: Vec<&Source> = sources.iter().filter(|s| s.is_script()).collect();
    let project = resources::Project::of(&scripts.iter().map(|s| s.text.as_str()).collect::<Vec<_>>());
    let mut diagnostics = Vec::new();
    for source in sources {
        let (file, text) = (source.file.as_str(), source.text.as_str());
        if source.is_script() {
            let code = wf_game_kit::gdscript::code_only(text);
            diagnostics.extend(timers::running_while_paused(file, &code));
            diagnostics.extend(resources::saves_that_run_code(file, text, &code));
            diagnostics.extend(resources::shared_resources(file, &code, &project));
            diagnostics.extend(cursor::script(file, &code));
        } else if source.is_scene() {
            diagnostics.extend(cursor::scene(file, text));
        } else if source.is_presets() {
            diagnostics.extend(presets::threads_needing_isolation(file, text));
            diagnostics.extend(presets::build_output_packed(file, text));
        }
    }
    diagnostics
}

#[cfg(test)]
mod tests;
