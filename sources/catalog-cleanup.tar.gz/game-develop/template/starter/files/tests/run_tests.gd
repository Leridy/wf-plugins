# Rule tests: the round's rules, the save and the screens.
#
#   godot --headless --path . --editor --import --quit   # once, on a fresh clone
#   godot --headless --fixed-fps 60 --path . tests/run_tests.tscn
#
# Prints one line per failed check and "TESTS: PASS" or "TESTS: FAIL" last;
# the exit code is 0 or 1. Test what the rules promise (a coin counts once,
# the same seed plays the same round), not today's numbers.
extends Node

const TEST_SAVE := "user://test_save.json"

var _failures: Array[String] = []
var _script_errors := preload("res://tests/script_errors.gd").new()
var _checks := 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	OS.add_logger(_script_errors)
	_run.call_deferred()


func _run() -> void:
	SaveGame.path = TEST_SAVE
	SaveGame.delete()
	_check_same_seed_same_round()
	_check_coins_count_once()
	_check_hits_and_invulnerability()
	_check_round_ends_once()
	_check_losing()
	_check_save_round_trip_and_bad_files()
	await _check_screens()
	SaveGame.delete()

	_script_errors.report(_failures)
	for failure in _failures:
		print("FAIL " + failure)
	print("%d checks, %d failed" % [_checks, _failures.size()])
	print("TESTS: %s" % ("PASS" if _failures.is_empty() else "FAIL"))
	get_tree().quit(0 if _failures.is_empty() else 1)


func _expect(condition: bool, what: String) -> void:
	_checks += 1
	if not condition:
		_failures.append(what)


## A round with no hazards, for checks about coins and time.
func _calm(seed_value: int) -> Game:
	var game := Game.new(GameRng.new(seed_value))
	game.hazards.clear()
	return game


func _check_same_seed_same_round() -> void:
	var a := Game.new(GameRng.new(42))
	var b := Game.new(GameRng.new(42))
	for frame in 1200:
		var direction := Vector2.from_angle(frame * 0.05)
		a.step(1.0 / 60.0, direction)
		b.step(1.0 / 60.0, direction)
	_expect(a.player == b.player and a.coins == b.coins and a.hearts == b.hearts, "the same seed and moves play the same round")
	_expect(a.coins_on_field == b.coins_on_field and a.hazards == b.hazards, "the same seed places the same coins and hazards")
	_expect(Game.new(GameRng.new(43)).coins_on_field != Game.new(GameRng.new(42)).coins_on_field, "another seed places other coins")


func _check_coins_count_once() -> void:
	var game := _calm(1)
	var counted: Array[int] = []
	game.coin_collected.connect(func(total: int) -> void: counted.append(total))
	game.player = game.coins_on_field[0]
	game.step(0.0, Vector2.ZERO)
	game.step(0.0, Vector2.ZERO)
	_expect(game.coins == 1 and counted == [1], "standing on a coin counts it once (got %d)" % game.coins)
	_expect(game.coins_on_field.size() == Content.COINS_ON_FIELD, "a collected coin is replaced")
	_expect(game.coins_on_field[0].distance_to(game.player) >= Content.COIN_MIN_DISTANCE, "a new coin does not appear under the player")


func _check_hits_and_invulnerability() -> void:
	var game := _calm(2)
	game.hazards.append({"position": game.player, "velocity": Vector2.ZERO})
	game.step(0.0, Vector2.ZERO)
	_expect(game.hearts == Content.HEARTS - 1, "touching a hazard costs one heart")
	game.step(Content.INVULNERABLE * 0.5, Vector2.ZERO)
	_expect(game.hearts == Content.HEARTS - 1, "no second hit while invulnerable")
	game.step(Content.INVULNERABLE * 0.6, Vector2.ZERO)
	_expect(game.hearts == Content.HEARTS - 2, "a hit lands again once invulnerability ends")


func _check_round_ends_once() -> void:
	var game := _calm(3)
	var ends: Array[bool] = []
	game.ended.connect(func(won: bool) -> void: ends.append(won))
	game.coins = Content.COIN_TARGET - 1
	game.player = game.coins_on_field[0]
	game.step(0.1, Vector2.ZERO)
	var time_at_end := game.time_left
	game.step(1.0, Vector2.RIGHT)
	_expect(game.over and game.won and ends == [true], "reaching the coin target wins once")
	_expect(game.time_left == time_at_end, "nothing changes after the round is over")


func _check_losing() -> void:
	var slow := _calm(4)
	slow.step(Content.TIME_LIMIT + 1.0, Vector2.ZERO)
	_expect(slow.over and not slow.won, "running out of time loses")
	var hurt := _calm(5)
	hurt.hazards.append({"position": hurt.player, "velocity": Vector2.ZERO})
	for i in Content.HEARTS:
		hurt.step(Content.INVULNERABLE + 0.01, Vector2.ZERO)
	_expect(hurt.over and not hurt.won and hurt.hearts == 0, "losing every heart loses")


func _check_save_round_trip_and_bad_files() -> void:
	SaveGame.delete()
	var fresh := SaveGame.load_or_new()
	_expect(fresh.best_coins == 0 and fresh.rounds == 0, "no save file gives a fresh save")
	fresh.record(7, true)
	fresh.record(4, false)
	var loaded := SaveGame.load_or_new()
	_expect(loaded.best_coins == 7 and loaded.wins == 1 and loaded.rounds == 2, "a save reads back what was recorded")
	for bad in ["{not json", "[1, 2]", "{\"best_coins\": \"lots\", \"wins\": -3}"]:
		var file := FileAccess.open(SaveGame.path, FileAccess.WRITE)
		file.store_string(bad)
		file.close()
		var damaged := SaveGame.load_or_new()
		_expect(damaged.best_coins == 0 and damaged.wins == 0, "a damaged save (%s) gives a fresh one" % bad)


func _check_screens() -> void:
	var main: Node = load("res://main.tscn").instantiate()
	add_child(main)
	await get_tree().process_frame
	for button: BaseButton in main.find_children("*", "BaseButton", true, false):
		_expect(button.mouse_default_cursor_shape == Control.CURSOR_POINTING_HAND, "%s shows a pointing hand" % button.name)
	for container: Control in main.find_children("*", "CenterContainer", true, false):
		_expect(container.mouse_filter == Control.MOUSE_FILTER_IGNORE, "full-screen containers let the mouse through")
	main.start(9)
	await get_tree().physics_frame
	await get_tree().physics_frame
	var running: float = main.game.time_left
	_expect(running < Content.TIME_LIMIT, "time runs while playing")
	main._show(main.Screen.PAUSED)
	for i in 5:
		await get_tree().physics_frame
	_expect(get_tree().paused and main.game.time_left == running, "time stops while paused")
	main._show(main.Screen.PLAYING)
	main.game._end(false)
	_expect(main.screen == main.Screen.RESULT and SaveGame.load_or_new().rounds == 1, "the end of a round shows the result and saves it")
	get_tree().paused = false
	main.queue_free()
	await get_tree().process_frame
