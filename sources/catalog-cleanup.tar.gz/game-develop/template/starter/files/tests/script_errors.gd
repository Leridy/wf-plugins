## Counts GDScript runtime errors while the tests or bots run.
##
## A check that calls a method on null, indexes past an array and so on stops
## at that line, but the runner carries on, so without this count the run
## still ends with PASS and exit code 0. push_error() and engine errors (a bad
## JSON file the tests feed in on purpose) are not counted.
extends Logger

var count := 0


func _log_error(_function: String, _file: String, _line: int, _code: String, _rationale: String, _editor_notify: bool, error_type: int, _script_backtraces: Array[ScriptBacktrace]) -> void:
	if error_type == ERROR_TYPE_SCRIPT:
		count += 1


## Adds one failure when any script error happened.
func report(failures: Array[String]) -> void:
	if count > 0:
		failures.append("%d script error(s), printed above as SCRIPT ERROR: a check or bot stopped part-way" % count)
