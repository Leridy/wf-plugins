# Balance bots: whole rounds, headless, several seeds each.
#
#   godot --headless --fixed-fps 60 --path . tests/bots.tscn
#   godot --headless --fixed-fps 60 --path . tests/bots.tscn -- careful
#
# idle     never moves: the floor every design must stay above.
# greedy   runs straight at the nearest coin and ignores hazards.
# careful  goes for the nearest coin but steps around hazards it sees coming.
# Each decides every REACTION seconds, like a person, not every frame.
#
# Expectations (exit 1 and "BOTS: FAIL" when one breaks): idle never wins;
# careful wins most seeds and collects at least as much as greedy, so care
# pays; careful does not win every seed with time to spare, so the round is
# not a formality. Change the expectations with the design, never just to pass.
extends Node

const SEEDS := [1, 2, 3, 4, 5, 6, 7, 8]
const STEP := 1.0 / 60.0
## Seconds between decisions: about a person's reaction time.
const REACTION := 0.25
## How far ahead `careful` looks for hazards, in seconds.
const LOOKAHEAD := 0.4

var _failures: Array[String] = []
var _script_errors := preload("res://tests/script_errors.gd").new()


func _ready() -> void:
	OS.add_logger(_script_errors)
	_run.call_deferred()


func _run() -> void:
	var wanted := Array(OS.get_cmdline_user_args())
	var scores := {}
	for strategy in ["idle", "greedy", "careful"]:
		if wanted.is_empty() or wanted.has(strategy):
			var results: Array[Dictionary] = []
			for seed_value in SEEDS:
				results.append(_play(strategy, seed_value))
			scores[strategy] = _report(strategy, results)
	if scores.has("idle") and scores.idle.wins > 0:
		_failures.append("standing still wins %d seeds: the round plays itself" % scores.idle.wins)
	if scores.has("careful"):
		if scores.careful.wins * 2 <= SEEDS.size():
			_failures.append("careful should win most seeds (%d of %d did)" % [scores.careful.wins, SEEDS.size()])
		if scores.careful.easy_wins == SEEDS.size():
			_failures.append("careful wins every seed with half the time left: the round is a formality")
		if scores.has("greedy") and scores.careful.coins < scores.greedy.coins:
			_failures.append("care should pay: careful averages %.1f coins < greedy %.1f" % [scores.careful.coins, scores.greedy.coins])
	_script_errors.report(_failures)
	print("BOTS: %s" % ("PASS" if _failures.is_empty() else "FAIL"))
	for failure in _failures:
		print("  - " + failure)
	get_tree().quit(0 if _failures.is_empty() else 1)


func _play(strategy: String, seed_value: int) -> Dictionary:
	var game := Game.new(GameRng.new(seed_value))
	var direction := Vector2.ZERO
	var next_decision := 0.0
	var elapsed := 0.0
	while not game.over:
		if elapsed >= next_decision:
			direction = _decide(strategy, game)
			next_decision += REACTION
		game.step(STEP, direction)
		elapsed += STEP
	return {"won": game.won, "coins": game.coins, "hearts": game.hearts, "time_left": game.time_left}


func _decide(strategy: String, game: Game) -> Vector2:
	if strategy == "idle":
		return Vector2.ZERO
	var target: Vector2 = game.coins_on_field[0]
	for coin in game.coins_on_field:
		if game.player.distance_to(coin) < game.player.distance_to(target):
			target = coin
	var direction := game.player.direction_to(target)
	if strategy == "careful":
		var away := Vector2.ZERO
		for hazard in game.hazards:
			var ahead: Vector2 = hazard.position + hazard.velocity * LOOKAHEAD
			var gap := game.player.distance_to(ahead)
			if gap < 56.0:
				away += ahead.direction_to(game.player) * (56.0 - gap) / 56.0 * 2.0
		direction = (direction + away).normalized()
	return direction


func _report(strategy: String, results: Array[Dictionary]) -> Dictionary:
	var wins := 0
	var easy_wins := 0
	var coins := 0.0
	var line := ""
	for result in results:
		wins += 1 if result.won else 0
		easy_wins += 1 if result.won and result.time_left > Content.TIME_LIMIT / 2.0 else 0
		coins += result.coins
		line += " %s%d" % ["W" if result.won else "L", result.coins]
	coins /= results.size()
	print("%-8s wins %d/%d, %.1f coins on average:%s" % [strategy, wins, results.size(), coins, line])
	return {"wins": wins, "easy_wins": easy_wins, "coins": coins}
