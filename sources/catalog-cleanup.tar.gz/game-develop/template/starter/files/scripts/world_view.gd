## Draws the round: the field, the coins, the hazards and the player. It only
## reads `game`; swap these shapes for the platform's art (see WEAVEFORGE.md)
## without touching the rules.
extends Node2D

var game: Game


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	if game == null:
		return
	draw_rect(Rect2(Vector2.ZERO, Content.FIELD), Color(0.11, 0.12, 0.15))
	for coin in game.coins_on_field:
		draw_circle(coin, Content.COIN_RADIUS, Color(1.0, 0.82, 0.25))
	for hazard in game.hazards:
		draw_circle(hazard.position, Content.HAZARD_RADIUS, Color(0.9, 0.3, 0.3))
	# Blink while invulnerable after a hit.
	var visible_now := game.invulnerable <= 0.0 or int(game.invulnerable * 10.0) % 2 == 0
	if visible_now:
		draw_circle(game.player, Content.PLAYER_RADIUS, Color(0.45, 0.8, 1.0))
