## One seed per round, split into named streams.
##
## Each system rolls on its own stream ("coins", "hazards", later "loot",
## "map", "waves"…), seeded from the round's seed and the stream's name. A
## system that rolls more or less often then leaves every other system's
## sequence alone, so the same seed keeps giving the same round: a bug report
## with its seed can be replayed, and the bots compare designs on equal
## footing. Cosmetic randomness (shake, particles) may use the global RNG;
## anything that changes the game state must use a stream.
class_name GameRng
extends RefCounted

var run_seed: int
var _streams := {}


func _init(seed_value: int = 0) -> void:
	if seed_value == 0:
		seed_value = GameRng.command_line_seed()
	if seed_value == 0:
		# A short positive seed is easier to read out, type and share than a
		# 64-bit one.
		var picker := RandomNumberGenerator.new()
		picker.randomize()
		seed_value = picker.randi_range(1, 999_999_999)
	run_seed = seed_value


## The stream called `stream_name`, created on first use.
func stream(stream_name: String) -> RandomNumberGenerator:
	if not _streams.has(stream_name):
		var rng := RandomNumberGenerator.new()
		rng.seed = hash([run_seed, stream_name])
		_streams[stream_name] = rng
	return _streams[stream_name]


## Every stream's state, for a save. RNG states are 64-bit and JSON keeps
## only 53 bits of a number, so they are strings.
func save_data() -> Dictionary:
	var states := {}
	for stream_name in _streams:
		states[stream_name] = str(_streams[stream_name].state)
	return {"seed": str(run_seed), "states": states}


static func from_save(data: Dictionary) -> GameRng:
	var run := GameRng.new(int(data["seed"]))
	for stream_name in data["states"]:
		run.stream(stream_name).state = int(data["states"][stream_name])
	return run


## `--seed=N` after `--` on the command line, or 0.
static func command_line_seed() -> int:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--seed="):
			return int(argument.trim_prefix("--seed="))
	return 0


## A weighted pick: `weights` maps keys to positive weights.
static func pick_weighted(rng: RandomNumberGenerator, weights: Dictionary) -> Variant:
	var total := 0.0
	for weight in weights.values():
		total += weight
	var roll := rng.randf() * total
	for key in weights:
		roll -= weights[key]
		if roll < 0.0:
			return key
	return weights.keys().back()
