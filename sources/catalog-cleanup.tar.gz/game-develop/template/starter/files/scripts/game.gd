## The rules of one round, apart from the screen. A plain object that the
## scene, the tests and the bots all drive the same way: nothing here reads
## input, draws or waits on a timer. `step()` takes the elapsed time and the
## direction the player is pushing, so pausing is simply not stepping.
##
## Grow your game here (or in more objects like this one), not in main.gd:
## the tests and bots only see what the rules do.
class_name Game
extends RefCounted

signal coin_collected(total: int)
signal hurt(hearts: int)
signal ended(won: bool)

var rng: GameRng
var player := Content.FIELD / 2.0
var hearts := Content.HEARTS
var coins := 0
var time_left := Content.TIME_LIMIT
var invulnerable := 0.0
var coins_on_field: Array[Vector2] = []
## Each hazard: {"position": Vector2, "velocity": Vector2}.
var hazards: Array[Dictionary] = []
var over := false
var won := false


func _init(game_rng: GameRng) -> void:
	rng = game_rng
	for i in Content.COINS_ON_FIELD:
		coins_on_field.append(_coin_spot())
	var stream := rng.stream("hazards")
	for i in Content.HAZARDS:
		var position := _spot(stream, Content.HAZARD_RADIUS, Content.HAZARD_MIN_DISTANCE)
		var speed := stream.randf_range(Content.HAZARD_SPEED_MIN, Content.HAZARD_SPEED_MAX)
		hazards.append({"position": position, "velocity": Vector2.from_angle(stream.randf() * TAU) * speed})


## Advances the round by `delta` seconds while the player pushes along
## `direction` (longer than 1 is cut to 1). Does nothing once the round is over.
func step(delta: float, direction: Vector2) -> void:
	if over:
		return
	time_left = maxf(time_left - delta, 0.0)
	invulnerable = maxf(invulnerable - delta, 0.0)
	var margin := Vector2.ONE * Content.PLAYER_RADIUS
	player = (player + direction.limit_length(1.0) * Content.PLAYER_SPEED * delta).clamp(margin, Content.FIELD - margin)
	_move_hazards(delta)
	_collect_coins()
	_touch_hazards()
	if coins >= Content.COIN_TARGET:
		_end(true)
	elif hearts <= 0 or time_left <= 0.0:
		_end(false)


func _move_hazards(delta: float) -> void:
	for hazard in hazards:
		var position: Vector2 = hazard.position + hazard.velocity * delta
		var velocity: Vector2 = hazard.velocity
		for axis in 2:
			if position[axis] < Content.HAZARD_RADIUS or position[axis] > Content.FIELD[axis] - Content.HAZARD_RADIUS:
				velocity[axis] = -velocity[axis]
				position[axis] = clampf(position[axis], Content.HAZARD_RADIUS, Content.FIELD[axis] - Content.HAZARD_RADIUS)
		hazard.position = position
		hazard.velocity = velocity


func _collect_coins() -> void:
	for i in coins_on_field.size():
		if player.distance_to(coins_on_field[i]) <= Content.PLAYER_RADIUS + Content.COIN_RADIUS:
			coins += 1
			coins_on_field[i] = _coin_spot()
			coin_collected.emit(coins)


func _touch_hazards() -> void:
	if invulnerable > 0.0:
		return
	for hazard in hazards:
		if player.distance_to(hazard.position) <= Content.PLAYER_RADIUS + Content.HAZARD_RADIUS:
			hearts -= 1
			invulnerable = Content.INVULNERABLE
			hurt.emit(hearts)
			return


## Ends the round once; later calls change nothing.
func _end(win: bool) -> void:
	if over:
		return
	over = true
	won = win
	ended.emit(win)


func _coin_spot() -> Vector2:
	return _spot(rng.stream("coins"), Content.COIN_RADIUS, Content.COIN_MIN_DISTANCE)


## A random point inside the field at least `away` from the player; after
## 32 tries it takes the last one rather than looping forever.
func _spot(stream: RandomNumberGenerator, radius: float, away: float) -> Vector2:
	var spot := Vector2.ZERO
	for attempt in 32:
		spot = Vector2(stream.randf_range(radius, Content.FIELD.x - radius), stream.randf_range(radius, Content.FIELD.y - radius))
		if spot.distance_to(player) >= away:
			break
	return spot
