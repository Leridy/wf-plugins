## What survives between rounds, saved as JSON in user://.
##
## Never save a Resource or an object (`ResourceSaver`, `store_var(x, true)`):
## a save is a file players share and edit, and loading an object from it can
## run a script inside it. Store plain data and rebuild from it. A missing,
## damaged or hand-edited file gives a fresh save instead of an error.
class_name SaveGame
extends RefCounted

## Tests and bots point this elsewhere so they never touch the player's save.
static var path := "user://save.json"

var best_coins := 0
var wins := 0
var rounds := 0


static func load_or_new() -> SaveGame:
	var save := SaveGame.new()
	if not FileAccess.file_exists(path):
		return save
	var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if data is Dictionary:
		save.best_coins = maxi(_whole(data.get("best_coins")), 0)
		save.wins = maxi(_whole(data.get("wins")), 0)
		save.rounds = maxi(_whole(data.get("rounds")), save.wins)
	return save


## Records a finished round and writes the file.
func record(coins: int, won: bool) -> void:
	rounds += 1
	wins += 1 if won else 0
	best_coins = maxi(best_coins, coins)
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		push_warning("could not write %s: %s" % [path, error_string(FileAccess.get_open_error())])
		return
	file.store_string(JSON.stringify({"best_coins": best_coins, "wins": wins, "rounds": rounds}))


static func delete() -> void:
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(path)


## A JSON number as an int; anything else is 0.
static func _whole(value: Variant) -> int:
	return int(value) if value is float or value is int else 0
