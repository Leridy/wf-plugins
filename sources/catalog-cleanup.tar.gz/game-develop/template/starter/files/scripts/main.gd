## The screens around the rules: title, playing (with the HUD), paused and
## the result. It turns input into `game.step()` calls and shows what the
## rules report; it decides nothing about the game itself.
##
## Every button goes through `_button()`, which gives it the pointing-hand
## cursor. The HUD and the full-screen containers ignore the mouse, so they
## never hide a button or swallow a click.
extends Node

enum Screen { TITLE, PLAYING, PAUSED, RESULT }

## The Theme `godot-export` made from the platform's UI kit; every screen uses it.
@export var ui_theme: Theme

var game: Game
var save := SaveGame.load_or_new()
var screen := Screen.TITLE

var _world := preload("res://scripts/world_view.gd").new()
var _ui := Control.new()
var _hud := Label.new()
var _pause_button: Button
var _title: Control
var _paused: Control
var _result: Control
var _result_text := Label.new()


func _ready() -> void:
	# The screens keep working while the tree is paused; the world stops.
	process_mode = Node.PROCESS_MODE_ALWAYS
	_world.process_mode = Node.PROCESS_MODE_PAUSABLE
	_world.position = Vector2(0, 32)
	add_child(_world)
	_build_ui()
	_show(Screen.TITLE)


func _physics_process(delta: float) -> void:
	if screen != Screen.PLAYING:
		return
	game.step(delta, Input.get_vector("move_left", "move_right", "move_up", "move_down"))
	_update_hud()


func _unhandled_input(event: InputEvent) -> void:
	if not event.is_action_pressed("pause"):
		return
	if screen == Screen.PLAYING:
		_show(Screen.PAUSED)
	elif screen == Screen.PAUSED:
		_show(Screen.PLAYING)
	get_viewport().set_input_as_handled()


## Starts a round. A `seed_value` of 0 takes `--seed=N` from the command line,
## or else a new random seed.
func start(seed_value := 0) -> void:
	game = Game.new(GameRng.new(seed_value))
	game.ended.connect(_on_ended)
	_world.game = game
	_show(Screen.PLAYING)
	_update_hud()


func _on_ended(won: bool) -> void:
	save.record(game.coins, won)
	var why := "You win!" if won else ("Out of hearts" if game.hearts <= 0 else "Out of time")
	_result_text.text = "%s\n%d of %d coins, best %d\nRound seed %d" % [
		why, game.coins, Content.COIN_TARGET, save.best_coins, game.rng.run_seed,
	]
	_show(Screen.RESULT)


func _update_hud() -> void:
	_hud.text = "%s   Coins %d/%d   Time %d" % [
		"♥".repeat(maxi(game.hearts, 0)) + "♡".repeat(maxi(Content.HEARTS - game.hearts, 0)),
		game.coins, Content.COIN_TARGET, ceili(game.time_left),
	]


func _show(next: Screen) -> void:
	screen = next
	get_tree().paused = next == Screen.PAUSED
	_world.visible = game != null and next != Screen.TITLE
	_hud.visible = next == Screen.PLAYING or next == Screen.PAUSED
	_pause_button.visible = next == Screen.PLAYING
	for menu: Control in [_title, _paused, _result]:
		menu.visible = false
	var shown: Control = {Screen.TITLE: _title, Screen.PAUSED: _paused, Screen.RESULT: _result}.get(next)
	if shown:
		shown.visible = true
		# Keyboard and gamepad players start on the first button.
		var first := shown.find_children("*", "BaseButton", true, false).filter(func(b: BaseButton) -> bool: return b.visible)
		if not first.is_empty():
			(first[0] as Control).grab_focus.call_deferred()


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	_ui.theme = ui_theme
	_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_ui)
	_hud.position = Vector2(8, 6)
	_ui.add_child(_hud)
	_pause_button = _button("Pause", _show.bind(Screen.PAUSED))
	_pause_button.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 4)
	_ui.add_child(_pause_button)
	var title := Label.new()
	title.text = ProjectSettings.get_setting("application/config/name")
	var quit := _button("Quit", get_tree().quit)
	# A browser tab cannot be closed by the game.
	quit.visible = not OS.has_feature("web")
	_title = _menu([title, _button("Play", start), quit])
	var paused := Label.new()
	paused.text = "Paused"
	_paused = _menu([paused, _button("Resume", _show.bind(Screen.PLAYING)), _button("Restart", start), _button("Title", _show.bind(Screen.TITLE))])
	_result = _menu([_result_text, _button("Play again", start), _button("Title", _show.bind(Screen.TITLE))])


## A centred panel holding `items` in a column.
func _menu(items: Array) -> Control:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var panel := PanelContainer.new()
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	for item: Control in items:
		if item is Label:
			item.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		column.add_child(item)
	panel.add_child(column)
	center.add_child(panel)
	_ui.add_child(center)
	return center


## A button with the pointing-hand cursor that calls `action` when pressed.
func _button(text: String, action: Callable) -> Button:
	var button := Button.new()
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	button.text = text
	button.pressed.connect(func() -> void: action.call())
	return button
