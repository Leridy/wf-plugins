# 通用骨架（game-develop/starter）

> **素材**：画面是 `_draw()` 画的圆和方框，界面是 Godot 默认主题，都是占位。做成自己的游戏前，先读 `wf skill show game-develop/assets`：按画面向平台要 UI 组件、艺术字、图标和动画，用官方插件 `godot-export` 接进来，不要自己拼界面、用系统字体写标题。

原创（MIT，见 `LICENSE`）。Godot 4.7.1，入口 `main.tscn`。占位玩法是一局 45 秒的收集：WASD 或方向键移动，收集 20 枚金币获胜，碰到障碍掉一颗心，Esc 或 P 暂停。

## 改动入口

| 要改什么 | 入口 |
| --- | --- |
| 所有数值 | `data/content.gd` |
| 规则：一局里发生什么、怎么赢怎么输 | `scripts/game.gd`（纯逻辑：不读输入、不画画，`step(delta, 方向)` 推进） |
| 标题、HUD、暂停、结算，按键翻译成调用 | `scripts/main.gd`；按钮都经 `_button()` 建，自带手形指针 |
| 画面 | `scripts/world_view.gd`（只读 `game`） |
| 存档（最高分、胜场） | `scripts/save_game.gd`（`user://save.json`，坏文件读成新档） |
| 种子与随机流 | `scripts/game_rng.gd`；`--seed=N` 指定种子，结算画面显示本局种子 |
| UI 主题 | `main.tscn` 根节点的 `ui_theme`，设成 `godot-export` 生成的 Theme |

把占位玩法换成你的游戏时，规则写进 `game.gd`（大了就拆成几个同样不碰节点的对象），然后改测试守住新规则的承诺，改机器人的打法和预期。

## 测试与机器人

```sh
godot --headless --path . --editor --import --quit
godot --headless --fixed-fps 60 --path . tests/run_tests.tscn   # 末行 TESTS: PASS
godot --headless --fixed-fps 60 --path . tests/bots.tscn        # 末行 BOTS: PASS；-- idle / greedy / careful
```

规则测试：同一种子和操作打出同一局，金币只算一次且不会刷在玩家脚下，受击后有无敌时间，达成目标只结束一次、结束后不再变化，超时和掉光心都判负，存档往返、坏存档读成新档，每个按钮是手形、全屏容器不挡鼠标、暂停时时间不走、结束时显示结算并存档。测试里故意喂坏存档，会打印一条 `Parse JSON failed` 引擎错误，这是预期的。

机器人每 0.25 秒决策一次：`idle` 不动（0/8），`greedy` 直奔最近的金币（6/8），`careful` 绕开迎面来的障碍（6/8，平均金币略多）。预期是不动的赢不了、谨慎的赢多数局且不比贪心差、不是每局都能剩一半时间轻松赢；改了数值先看数字再决定改不改预期。

## Web 导出

`export_presets.cfg` 的「Web」预设不开多线程，导出到 `build/web/index.html`，排除 `tests/` 和 `build/`。网页上隐藏“退出”按钮。
