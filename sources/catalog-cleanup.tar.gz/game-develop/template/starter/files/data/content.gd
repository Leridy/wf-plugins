## Every number a designer tunes, in one place. The rules read these; the
## tests and bots read them too, so a change here is checked everywhere.
class_name Content
extends RefCounted

## The play field, in pixels; the view is 640×360 with a 32 px HUD strip on top.
const FIELD := Vector2(640, 328)
const PLAYER_SPEED := 150.0
const PLAYER_RADIUS := 8.0
const HEARTS := 3
## Seconds after a hit during which another hit does nothing.
const INVULNERABLE := 1.0
## Seconds a round lasts; reaching COIN_TARGET first wins.
const TIME_LIMIT := 45.0
const COIN_TARGET := 20
const COINS_ON_FIELD := 3
const COIN_RADIUS := 6.0
## A new coin never appears closer than this to the player.
const COIN_MIN_DISTANCE := 64.0
const HAZARDS := 5
const HAZARD_RADIUS := 10.0
const HAZARD_SPEED_MIN := 70.0
const HAZARD_SPEED_MAX := 120.0
## Hazards start at least this far from the player.
const HAZARD_MIN_DISTANCE := 120.0
