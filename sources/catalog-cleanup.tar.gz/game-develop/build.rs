//! Embeds `template/starter` into the component: `wf game-develop new` writes
//! these files, and a plugin has no file access of its own to read them.
fn main() {
    wf_game_kit::build::embed("template");
}
