//! What `lint` asks of its host, as a trait: the WIT imports in the component,
//! an in-memory project in tests.

/// Most paths one `list-files` call returns; a listing this long may be cut short.
pub const LIST_LIMIT: usize = 10_000;

/// A refused read, with the host's message.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HostError(pub String);

pub trait Host {
    /// Readable project-relative files matching `glob`, at most [`LIST_LIMIT`].
    fn list(&self, glob: &str) -> Vec<String>;
    /// A readable project-relative file.
    fn read(&self, path: &str) -> Result<Vec<u8>, HostError>;
    /// A message for the person running the command.
    fn warn(&self, message: &str);
}
