//! Just enough GDScript lexing for the rules: the code with every string
//! literal and comment blanked out, byte for byte, so a search in it never
//! matches text inside a string or a comment and its offsets are the source's.

/// `text` with string and comment bytes replaced by spaces (newlines kept).
/// Blanking whole multi-byte characters keeps the result valid UTF-8.
///
/// # Panics
///
/// Never: only whole UTF-8 sequences are blanked.
pub fn code_only(text: &str) -> String {
    let bytes = text.as_bytes();
    let mut out = bytes.to_vec();
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'#' => {
                let end = memchr(b'\n', &bytes[i..]).map_or(bytes.len(), |n| i + n);
                blank(&mut out, i, end);
                i = end;
            }
            quote @ (b'"' | b'\'') => {
                let triple = bytes[i..].starts_with(&[quote; 3]);
                let end = string_end(bytes, i, quote, triple);
                blank(&mut out, i, end);
                i = end;
            }
            _ => i += 1,
        }
    }
    String::from_utf8(out).expect("only whole UTF-8 sequences are blanked")
}

/// Every string literal outside comments: the offset of its opening quote,
/// the offset just past its closing quote, and its text between the quotes
/// (escapes left as written). Triple-quoted strings are included.
pub fn strings(text: &str) -> Vec<(usize, usize, &str)> {
    let bytes = text.as_bytes();
    let mut found = Vec::new();
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'#' => i = memchr(b'\n', &bytes[i..]).map_or(bytes.len(), |n| i + n),
            quote @ (b'"' | b'\'') => {
                let triple = bytes[i..].starts_with(&[quote; 3]);
                let end = string_end(bytes, i, quote, triple);
                let width = if triple { 3 } else { 1 };
                let inner_end = end.saturating_sub(width).max(i + width);
                if end > i + width && end - i >= 2 * width {
                    found.push((i, end, &text[i + width..inner_end]));
                }
                i = end;
            }
            _ => i += 1,
        }
    }
    found
}

/// The offset just past the string literal opening at `start`. A backslash
/// keeps the next byte inside the string, raw strings included (a raw string
/// cannot end on `\"` either). An unterminated string runs to the end.
fn string_end(bytes: &[u8], start: usize, quote: u8, triple: bool) -> usize {
    let mut i = start + if triple { 3 } else { 1 };
    while i < bytes.len() {
        match bytes[i] {
            b'\\' => i += 2,
            b'\n' if !triple => return i,
            b if b == quote && (!triple || bytes[i..].starts_with(&[quote; 3])) => {
                return i + if triple { 3 } else { 1 };
            }
            _ => i += 1,
        }
    }
    bytes.len()
}

fn blank(out: &mut [u8], start: usize, end: usize) {
    let end = end.min(out.len());
    for byte in &mut out[start..end] {
        if *byte != b'\n' {
            *byte = b' ';
        }
    }
}

fn memchr(needle: u8, haystack: &[u8]) -> Option<usize> {
    haystack.iter().position(|&b| b == needle)
}

/// The offset of the `)` closing the `(` at `open`, skipping nested brackets.
pub fn closing_paren(code: &str, open: usize) -> Option<usize> {
    let mut depth = 0usize;
    for (i, b) in code.bytes().enumerate().skip(open) {
        match b {
            b'(' | b'[' | b'{' => depth += 1,
            b')' | b']' | b'}' => {
                depth = depth.checked_sub(1)?;
                if depth == 0 {
                    return (b == b')').then_some(i);
                }
            }
            _ => {}
        }
    }
    None
}

pub fn is_identifier_byte(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'_' || b >= 0x80
}

/// How many arguments the call between `open` (`(`) and `close` (`)`) passes.
pub fn argument_count(code: &str, open: usize, close: usize) -> usize {
    let inner = &code[open + 1..close];
    if inner.trim().is_empty() {
        return 0;
    }
    let mut depth = 0usize;
    let mut count = 1;
    let mut trailing_comma = false;
    for b in inner.bytes() {
        match b {
            b'(' | b'[' | b'{' => depth += 1,
            b')' | b']' | b'}' => depth = depth.saturating_sub(1),
            b',' if depth == 0 => {
                count += 1;
                trailing_comma = true;
                continue;
            }
            b if b.is_ascii_whitespace() => continue,
            _ => {}
        }
        trailing_comma = false;
    }
    // `f(a,)` passes one argument.
    if trailing_comma { count - 1 } else { count }
}

/// Calls of the named functions: their offset, name, and whether they are a
/// method call (`x.name(`). `method` keeps only method calls (true), only
/// bare calls (false) or both (None); a `func name(` definition is never a
/// call.
pub fn calls<'a>(code: &str, names: &[&'a str], method: Option<bool>) -> Vec<(usize, &'a str, bool)> {
    let bytes = code.as_bytes();
    let mut found = Vec::new();
    for name in names {
        for (at, _) in code.match_indices(name) {
            let end = at + name.len();
            let starts_word = at == 0 || !is_identifier_byte(bytes[at - 1]);
            let ends_word = bytes.get(end).is_none_or(|&b| !is_identifier_byte(b));
            if !starts_word || !ends_word {
                continue;
            }
            let before = code[..at].trim_end();
            let is_method = before.ends_with('.');
            let is_definition = before.ends_with("func");
            let opens = code[end..].trim_start().starts_with('(');
            if opens && !is_definition && method.is_none_or(|m| m == is_method) {
                found.push((at, *name, is_method));
            }
        }
    }
    found.sort_unstable();
    found
}

/// The byte ranges of the functions in `code`: from a line starting with
/// `func` (or `static func`) to the next such line.
pub fn functions(code: &str) -> Vec<(usize, usize)> {
    let mut starts = Vec::new();
    let mut offset = 0;
    for line in code.split_inclusive('\n') {
        let trimmed = line.trim_start();
        let trimmed = trimmed.strip_prefix("static").map_or(trimmed, str::trim_start);
        if trimmed
            .strip_prefix("func")
            .is_some_and(|rest| rest.starts_with([' ', '\t']))
        {
            starts.push(offset);
        }
        offset += line.len();
    }
    let ends = starts.iter().skip(1).copied().chain([code.len()]);
    starts.iter().copied().zip(ends).collect()
}

/// `class_name X` in the script.
pub fn class_name(code: &str, text: &str) -> Option<String> {
    let at = code
        .lines()
        .position(|line| line.trim_start().starts_with("class_name "))?;
    let line = text.lines().nth(at)?;
    let name: String = line
        .trim_start()
        .trim_start_matches("class_name ")
        .bytes()
        .take_while(|&b| is_identifier_byte(b))
        .map(char::from)
        .collect();
    (!name.is_empty()).then_some(name)
}

/// The class named by `extends X` in the script, on its own line or after
/// `class_name Y`.
pub fn extends(code: &str) -> Option<&str> {
    code.lines().find_map(|line| {
        let line = line.trim_start();
        let rest = line.strip_prefix("extends ").or_else(|| {
            line.strip_prefix("class_name ")?
                .split_once(" extends ")
                .map(|(_, r)| r.trim_start())
        })?;
        let end = rest.bytes().take_while(|&b| is_identifier_byte(b)).count();
        Some(&rest[..end])
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strings_and_comments_are_blanked_in_place() {
        let text = "var a = \"x # y\" # create_timer(1)\nvar b = '''q\n\"z\"''' + r\"\\\"\"\nf(é)";
        let code = code_only(text);
        assert_eq!(code.len(), text.len());
        assert!(!code.contains("create_timer"));
        assert!(!code.contains('q'));
        assert!(code.contains("var b ="));
        assert!(code.ends_with("f(é)"));
        assert_eq!(code.matches('\n').count(), text.matches('\n').count());
    }

    #[test]
    fn string_literals_are_listed_with_their_text() {
        let text = "f(\"a\", 'b') # \"c\"\nvar d = \"\"\"e\"\"\" + \"\"";
        let found: Vec<&str> = strings(text).iter().map(|(_, _, inner)| *inner).collect();
        assert_eq!(found, ["a", "b", "e", ""]);
        let (start, end, _) = strings(text)[0];
        assert_eq!(&text[start..end], "\"a\"");
    }

    #[test]
    fn closing_parens_skip_nested_brackets() {
        let code = "f(a, g(b, c), [d, e],)";
        assert_eq!(closing_paren(code, 1), Some(code.len() - 1));
        assert_eq!(closing_paren("f(a]", 1), None);
    }

    #[test]
    fn arguments_are_counted_at_the_top_level() {
        let code = "f(a, g(b, c), [d, e],)";
        let close = closing_paren(code, 1).unwrap();
        assert_eq!(argument_count(code, 1, close), 3);
        assert_eq!(argument_count("f( )", 1, 3), 0);
        assert_eq!(argument_count("f(x)", 1, 3), 1);
    }

    #[test]
    fn calls_skip_definitions_and_split_methods_from_bare_calls() {
        let code = "func load(p):\n\tload(p)\n\tx.load(p)\n\tunload(p)\n";
        let found: Vec<bool> = calls(code, &["load"], None).iter().map(|c| c.2).collect();
        assert_eq!(found, [false, true]);
        assert_eq!(calls(code, &["load"], Some(true)).len(), 1);
    }

    #[test]
    fn functions_classes_and_bases_are_found() {
        let code = "class_name Stats extends Resource\nvar a\nfunc f():\n\tpass\nstatic func g():\n\tpass\n";
        assert_eq!(functions(code).len(), 2);
        assert_eq!(class_name(code, code).as_deref(), Some("Stats"));
        assert_eq!(extends(code), Some("Resource"));
        assert_eq!(extends("extends Node2D\n"), Some("Node2D"));
    }
}
