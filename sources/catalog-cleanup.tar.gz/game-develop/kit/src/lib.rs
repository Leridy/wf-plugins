//! `wf-game-kit`: what every wf game development plugin shares.
//!
//! A game plugin (`game-develop`, `tower-develop`, …) is a WebAssembly
//! component with a `new` that writes a Godot project from embedded templates
//! and a `lint` that implements `wf.lint/1`. This crate holds everything that
//! is the same between them, so a plugin keeps only its rules, its templates
//! and its skills:
//!
//! - [`Plugin`] and [`export_plugin!`]: the plugin's operations as plain Rust;
//!   the macro turns them into the component's WIT exports.
//! - [`lint`]: lists and reads the files a plugin checks and hands them to its rules.
//! - [`gdscript`] and [`scene`]: just enough of GDScript and text scenes for rules.
//! - [`scaffold`]: the checks and file plan behind every `new`.
//! - [`build`]: embeds `template/<name>/` directories into the component at build time.
//!
//! Everything except [`component`] is plain Rust, so `cargo test` runs it on the host.
#![cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "the component glue that calls into these is wasm-only")
)]

pub mod build;
pub mod description;
pub mod gdscript;
pub mod host;
pub mod lint;
pub mod plugin;
pub mod protocol;
pub mod scaffold;
pub mod scene;

pub use description::{Capability, Description, Example, Risk};
pub use host::{Host, HostError};
pub use plugin::{CallError, Failure, FileWrite, Hint, Plugin, Reply};
pub use protocol::{Diagnostic, Fix, LintInput, LintOutput, Severity, Span, TextEdit};

#[cfg(target_arch = "wasm32")]
#[doc(hidden)]
#[allow(unsafe_code, clippy::pedantic, reason = "wit-bindgen's generated glue")]
pub mod component;

/// A span from byte offsets.
///
/// # Panics
///
/// When an offset does not fit `u32`; the lint driver skips files that large
/// before any rule runs.
pub fn span(start: usize, end: usize) -> Span {
    Span {
        start: u32::try_from(start).expect("a checked file size"),
        end: u32::try_from(end).expect("a checked file size"),
    }
}
