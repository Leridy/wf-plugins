//! Embeds templates into the component at build time: a plugin has no file
//! access of its own to read them when `new` runs. A plugin's `build.rs`
//! main is one line:
//!
//! ```ignore
//! wf_game_kit::build::embed("template");
//! ```
//!
//! and its `scaffold.rs`:
//!
//! ```ignore
//! static TEMPLATES: wf_game_kit::scaffold::Templates =
//!     include!(concat!(env!("OUT_DIR"), "/templates.rs"));
//! ```
//!
//! Every directory directly under `template/` becomes one template, named
//! after the directory, with its visible files (hidden entries such as
//! `.godot/` caches stay out) sorted by path.
use std::{
    env,
    fmt::Write as _,
    fs,
    path::{Path, PathBuf},
};

/// Writes `$OUT_DIR/templates.rs`: an expression of type
/// [`crate::scaffold::Templates`] holding every directory under `root`
/// (relative to the crate's manifest directory).
///
/// # Panics
///
/// When run outside a build script, or when `root` cannot be read: a build
/// that cannot embed its templates must fail.
pub fn embed(root: &str) {
    let manifest = env::var("CARGO_MANIFEST_DIR").expect("cargo sets CARGO_MANIFEST_DIR for build scripts");
    let base = Path::new(&manifest).join(root);
    println!("cargo:rerun-if-changed={root}");
    let mut names: Vec<(String, PathBuf)> = fs::read_dir(&base)
        .unwrap_or_else(|error| panic!("read {}: {error}", base.display()))
        .map(|entry| entry.expect("a directory entry").path())
        .filter(|path| path.is_dir() && !hidden(path))
        .map(|path| (file_name(&path).to_owned(), path))
        .collect();
    names.sort();
    let mut source = String::from("&[\n");
    for (name, dir) in &names {
        let mut files = Vec::new();
        // A data contribution and the legacy `new` command share one file tree.
        let data = dir.join("files");
        let content = if dir.join("template.toml").is_file() { &data } else { dir };
        walk(content, content, &mut files);
        files.sort();
        writeln!(source, "    ({name:?}, &[").expect("writing to a String");
        for (relative, absolute) in &files {
            writeln!(
                source,
                "        ({relative:?}, include_bytes!({:?})),",
                absolute.display().to_string()
            )
            .expect("writing to a String");
        }
        source.push_str("    ]),\n");
    }
    source.push(']');
    let out = PathBuf::from(env::var("OUT_DIR").expect("cargo sets OUT_DIR")).join("templates.rs");
    fs::write(out, source).expect("write the template index");
}

/// Every visible file under `dir`, as (path relative to `root`, absolute path).
fn walk(root: &Path, dir: &Path, files: &mut Vec<(String, PathBuf)>) {
    for entry in fs::read_dir(dir).expect("read the template directory") {
        let path = entry.expect("a directory entry").path();
        if hidden(&path) {
            continue;
        }
        if path.is_dir() {
            walk(root, &path, files);
        } else {
            let relative = path.strip_prefix(root).expect("under the root");
            let relative = relative
                .components()
                .map(|part| part.as_os_str().to_str().expect("a UTF-8 path"))
                .collect::<Vec<_>>()
                .join("/");
            files.push((relative, path));
        }
    }
}

fn hidden(path: &Path) -> bool {
    file_name(path).starts_with('.')
}

fn file_name(path: &Path) -> &str {
    path.file_name()
        .and_then(|name| name.to_str())
        .expect("a UTF-8 file name")
}
