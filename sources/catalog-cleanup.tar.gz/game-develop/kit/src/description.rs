//! What `describe()` returns: one entry per capability, enough to build its
//! command, `--help` and confirmation without running it. The types are the
//! contract: unknown fields are errors, and `schema()` publishes it as JSON Schema.
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

/// How far a command reaches: reading, changing local state, or a change the
/// user must approve first (`--yes`).
#[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, JsonSchema, Ord, PartialEq, PartialOrd, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum Risk {
    /// Changes nothing.
    Read,
    /// Creates files or edits them in place.
    Write,
    /// Overwrites or deletes files; stops until the user confirms.
    HighRisk,
}

impl Risk {
    pub const fn name(self) -> &'static str {
        match self {
            Self::Read => "read",
            Self::Write => "write",
            Self::HighRisk => "high-risk",
        }
    }
}

/// What `describe()` returns, as JSON.
#[derive(Clone, Debug, Default, Deserialize, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Description {
    pub capabilities: Vec<Capability>,
}

impl Description {
    /// Distinct protocol ids in stable order for listings and package indexes.
    pub fn protocols(&self) -> Vec<String> {
        let mut protocols: Vec<_> = self.capabilities.iter().filter_map(|c| c.implements.clone()).collect();
        protocols.sort();
        protocols.dedup();
        protocols
    }

    pub fn capability(&self, op: &str) -> Option<&Capability> {
        self.capabilities.iter().find(|c| c.op == op)
    }
}

/// One operation, run as `wf <plugin> <op>`.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Capability {
    /// Lowercase words joined by `-`, not `help`; unique within the plugin.
    pub op: String,
    /// One line saying what the operation does; shown in listings and `--help`.
    pub summary: String,
    /// When an Agent should pick this capability instead of another command.
    pub when: String,
    /// The lower bound; the host raises it from the effects a call returns.
    #[serde(default = "read")]
    pub risk: Risk,
    /// JSON Schema of the input object. Top-level scalar properties become
    /// flags; anything else is passed with `--data`.
    #[serde(default = "empty_object")]
    #[schemars(with = "Map<String, Value>")]
    pub input: Value,
    /// JSON Schema of `outcome.output`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    #[schemars(with = "Option<Map<String, Value>>")]
    pub output: Option<Value>,
    /// Runnable calls for `--help`.
    #[serde(default)]
    pub examples: Vec<Example>,
    /// The official protocol this capability implements (`wf.lint/1`): it then
    /// takes and returns that protocol's types, and the protocol's command
    /// (`lint`) calls it alongside the other implementations.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub implements: Option<String>,
}

/// One way to call a capability.
#[derive(Clone, Debug, Deserialize, JsonSchema, PartialEq, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Example {
    /// The arguments after `wf <plugin>`, e.g. `greet --name Ada`; never `--yes`.
    pub args: String,
    /// What this call shows.
    pub note: String,
}

const fn read() -> Risk {
    Risk::Read
}

fn empty_object() -> Value {
    let mut schema = Map::new();
    schema.insert("type".into(), Value::String("object".into()));
    Value::Object(schema)
}

#[cfg(test)]
mod tests {
    use super::{Capability, Description, Risk, empty_object};

    #[test]
    fn protocols_are_sorted_unique_and_ignore_plain_capabilities() {
        let capability = |implements: Option<&str>| Capability {
            op: "inspect".into(),
            summary: "Inspect files".into(),
            when: "Check files".into(),
            risk: Risk::Read,
            input: empty_object(),
            output: None,
            examples: Vec::new(),
            implements: implements.map(str::to_owned),
        };
        let description = Description {
            capabilities: [Some("z/1"), None, Some("a/1"), Some("z/1")].map(capability).into(),
        };
        assert_eq!(description.protocols(), ["a/1", "z/1"]);
        assert!(Description::default().protocols().is_empty());
    }

    #[test]
    fn a_misspelled_field_is_an_error_naming_it() {
        for (text, field) in [
            (r#"{"capabilities": [], "capabilites": []}"#, "capabilites"),
            (
                r#"{"capabilities": [{"op": "a", "summary": "s", "when": "w", "risk": "read", "exmples": []}]}"#,
                "exmples",
            ),
            (
                r#"{"capabilities": [{"op": "a", "summary": "s", "when": "w", "examples": [{"args": "a", "notes": "n"}]}]}"#,
                "notes",
            ),
        ] {
            let error = serde_json::from_str::<Description>(text).unwrap_err().to_string();
            assert!(error.contains(field), "{error}");
        }
    }

    #[test]
    fn optional_fields_take_their_defaults() {
        let description: Description =
            serde_json::from_str(r#"{"capabilities": [{"op": "a", "summary": "s", "when": "w"}]}"#).unwrap();
        let capability = description.capability("a").unwrap();
        assert_eq!(capability.risk, super::Risk::Read);
        assert_eq!(capability.input["type"], "object");
        assert!(capability.examples.is_empty());
    }
}
