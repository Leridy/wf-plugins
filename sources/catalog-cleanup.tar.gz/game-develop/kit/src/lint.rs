//! The `wf.lint/1` driver every game plugin shares: it lists only the kinds
//! of file a plugin checks, narrowed to the requested paths (one listing per
//! kind and path, so a large project stays cheap), reads them as UTF-8 and
//! hands them all to the plugin's rules at once, so a rule can know about the
//! whole project (its Resource classes, whether it seeds its generators).
use crate::{
    host::{Host, LIST_LIMIT},
    protocol::{Diagnostic, LintInput, LintOutput},
};
use std::collections::BTreeSet;

/// The op name of a `wf.lint/1` provider.
pub const LINT: &str = "lint";

/// The kinds of file Godot rules usually read: scripts, text scenes and the
/// export presets. Each is the end of a listing glob.
pub const GODOT_KINDS: [&str; 3] = ["*.gd", "*.tscn", "export_presets.cfg"];

/// One file a rule reads.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Source {
    /// Project-relative path.
    pub file: String,
    pub text: String,
}

#[allow(
    clippy::case_sensitive_file_extension_comparisons,
    reason = "Godot writes these extensions in lower case, and the listing globs are case-exact"
)]
impl Source {
    pub fn is_script(&self) -> bool {
        self.file.ends_with(".gd")
    }

    pub fn is_scene(&self) -> bool {
        self.file.ends_with(".tscn")
    }

    pub fn is_presets(&self) -> bool {
        self.file == "export_presets.cfg" || self.file.ends_with("/export_presets.cfg")
    }
}

/// Runs `rules` over the files of `kinds` under `input.paths` (the whole
/// project when empty). Unreadable, non-UTF-8 and oversized files are skipped
/// with a warning. Diagnostics come back sorted by file and offset.
pub fn run(
    host: &dyn Host,
    input: &LintInput,
    kinds: &[&str],
    rules: impl FnOnce(&[Source]) -> Vec<Diagnostic>,
) -> LintOutput {
    let sources = read(host, &input.paths, kinds);
    let mut diagnostics = rules(&sources);
    diagnostics.sort_by(|a, b| (&a.file, a.span.map(|s| s.start)).cmp(&(&b.file, b.span.map(|s| s.start))));
    LintOutput {
        checked: sources.into_iter().map(|source| source.file).collect(),
        diagnostics,
    }
}

/// The files of `kinds` under `paths`, read, sorted by path.
pub fn read(host: &dyn Host, paths: &[String], kinds: &[&str]) -> Vec<Source> {
    let mut sources = Vec::new();
    for file in files(host, paths, kinds) {
        let bytes = match host.read(&file) {
            Ok(bytes) => bytes,
            Err(error) => {
                host.warn(&format!("skipped {file}: {}", error.0));
                continue;
            }
        };
        let Ok(text) = String::from_utf8(bytes) else {
            host.warn(&format!("skipped {file}: not UTF-8 text"));
            continue;
        };
        if u32::try_from(text.len()).is_err() {
            host.warn(&format!("skipped {file}: too large for lint spans"));
            continue;
        }
        sources.push(Source { file, text });
    }
    sources
}

/// The files of `kinds` under `paths` (the whole project when empty), sorted.
fn files(host: &dyn Host, paths: &[String], kinds: &[&str]) -> BTreeSet<String> {
    let mut globs = Vec::new();
    let roots: Vec<&str> = paths
        .iter()
        .map(|path| path.trim_start_matches("./").trim_end_matches('/'))
        .collect();
    if roots.is_empty() || roots.iter().any(|root| root.is_empty() || *root == ".") {
        globs.extend(kinds.iter().map(|kind| format!("**/{kind}")));
    } else {
        for root in roots {
            if kinds.iter().any(|kind| root.ends_with(kind.trim_start_matches('*'))) {
                globs.push(root.to_owned());
            } else {
                globs.extend(kinds.iter().map(|kind| format!("{root}/**/{kind}")));
            }
        }
    }
    let mut files = BTreeSet::new();
    for glob in globs {
        let listed = host.list(&glob);
        if listed.len() >= LIST_LIMIT {
            host.warn(&format!(
                "{glob} matched {LIST_LIMIT} files, the most one listing returns; lint fewer paths at a time"
            ));
        }
        files.extend(listed);
    }
    files
}

/// An in-memory project for tests of the driver and of plugins' lint ops.
#[cfg(any(test, feature = "testing"))]
pub mod testing {
    use crate::host::{Host, HostError};
    use std::{cell::RefCell, collections::BTreeMap};

    /// Files by path; `list` understands `**/*.ext`, `dir/**/name` and exact paths.
    #[derive(Default)]
    pub struct MemoryProject {
        pub files: BTreeMap<String, String>,
        pub globs: RefCell<Vec<String>>,
        pub warnings: RefCell<Vec<String>>,
    }

    impl MemoryProject {
        pub fn new(files: &[(&str, &str)]) -> Self {
            Self {
                files: files.iter().map(|(p, t)| ((*p).to_owned(), (*t).to_owned())).collect(),
                ..Self::default()
            }
        }
    }

    impl Host for MemoryProject {
        fn list(&self, glob: &str) -> Vec<String> {
            self.globs.borrow_mut().push(glob.to_owned());
            let (prefix, name) = glob.split_once("**/").unwrap_or((glob, ""));
            let suffix = name.trim_start_matches('*');
            self.files
                .keys()
                .filter(|f| {
                    if name.is_empty() {
                        *f == glob
                    } else if suffix.len() < name.len() {
                        f.starts_with(prefix) && f.ends_with(suffix)
                    } else {
                        f.starts_with(prefix) && (**f == format!("{prefix}{name}") || f.ends_with(&format!("/{name}")))
                    }
                })
                .cloned()
                .collect()
        }

        fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
            self.files
                .get(path)
                .map(|t| t.as_bytes().to_vec())
                .ok_or_else(|| HostError("not found".into()))
        }

        fn warn(&self, message: &str) {
            self.warnings.borrow_mut().push(message.to_owned());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{testing::MemoryProject, *};

    fn project() -> MemoryProject {
        MemoryProject::new(&[
            ("enemies/enemy.tscn", "[node name=\"E\" type=\"Node2D\"]\n"),
            ("waves/wave.gd", "func go():\n\tpass\n"),
            ("notes.txt", "x"),
            ("export_presets.cfg", "[preset.0]\n"),
        ])
    }

    #[test]
    fn checks_every_kind_of_the_whole_project() {
        let output = run(&project(), &LintInput::default(), &GODOT_KINDS, |sources| {
            assert!(sources[1].is_presets() && sources[2].is_script() && sources[0].is_scene());
            Vec::new()
        });
        assert_eq!(
            output.checked,
            ["enemies/enemy.tscn", "export_presets.cfg", "waves/wave.gd"]
        );
    }

    #[test]
    fn requested_paths_narrow_the_listing() {
        let project = project();
        let input = LintInput {
            paths: vec!["waves/".into()],
        };
        let output = run(&project, &input, &GODOT_KINDS, |_| Vec::new());
        assert_eq!(output.checked, ["waves/wave.gd"]);
        assert_eq!(
            *project.globs.borrow(),
            ["waves/**/*.gd", "waves/**/*.tscn", "waves/**/export_presets.cfg"]
        );
        let input = LintInput {
            paths: vec!["./enemies/enemy.tscn".into()],
        };
        assert_eq!(
            run(&project, &input, &GODOT_KINDS, |_| Vec::new()).checked,
            ["enemies/enemy.tscn"]
        );
    }

    #[test]
    fn unreadable_files_are_skipped_with_a_warning() {
        let mut project = project();
        project.files.insert("bad.gd".into(), String::new());
        let host = BadRead(project);
        let output = run(&host, &LintInput::default(), &["*.gd"], |_| Vec::new());
        assert_eq!(output.checked, ["waves/wave.gd"]);
        assert_eq!(*host.0.warnings.borrow(), ["skipped bad.gd: denied"]);
    }

    struct BadRead(MemoryProject);

    impl Host for BadRead {
        fn list(&self, glob: &str) -> Vec<String> {
            self.0.list(glob)
        }

        fn read(&self, path: &str) -> Result<Vec<u8>, crate::host::HostError> {
            if path == "bad.gd" {
                Err(crate::host::HostError("denied".into()))
            } else {
                self.0.read(path)
            }
        }

        fn warn(&self, message: &str) {
            self.0.warn(message);
        }
    }
}
