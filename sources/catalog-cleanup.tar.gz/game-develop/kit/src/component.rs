//! The WIT glue every game plugin shares: the bindings, the host imports
//! behind [`Host`] and the two exports. A plugin reaches it through
//! [`crate::export_plugin!`].
use crate::{
    host::{Host, HostError},
    plugin::{CallError, Failure, Plugin, Reply},
};

pub mod bindings {
    wit_bindgen::generate!({
        path: "wit",
        world: "provider",
        pub_export_macro: true,
        export_macro_name: "export_provider",
        default_bindings_module: "wf_game_kit::component::bindings",
    });
}

use bindings::{
    Error, Outcome,
    wf::plugin::{
        host as imports,
        types::{self, Effect, Level, Verdict},
    },
};

/// The host's imports.
pub struct Wit;

impl Host for Wit {
    fn list(&self, glob: &str) -> Vec<String> {
        imports::list_files(glob)
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        imports::read_file(path).map_err(|error| HostError(error.message))
    }

    fn warn(&self, message: &str) {
        imports::log(Level::Warn, message);
    }
}

/// The `describe` export.
///
/// # Panics
///
/// Never: a description always serializes.
pub fn describe<P: Plugin>() -> Vec<u8> {
    serde_json::to_vec(&P::description()).expect("a description serializes")
}

/// The `call` export. Lint findings stay `ok`: `wf lint` applies the
/// project's rule levels and decides the exit status itself.
pub fn call<P: Plugin>(op: &str, input: &[u8]) -> Result<Outcome, Error> {
    P::call(op, input, &Wit).map(outcome).map_err(error)
}

fn outcome(reply: Reply) -> Outcome {
    Outcome {
        output: reply.output,
        effects: reply
            .writes
            .into_iter()
            .map(|write| {
                Effect::WriteFile(types::FileWrite {
                    path: write.path,
                    bytes: write.bytes,
                    overwrite: write.overwrite,
                })
            })
            .collect(),
        verdict: Verdict::Ok,
        hints: reply
            .hints
            .into_iter()
            .map(|hint| types::Hint {
                args: hint.args,
                reason: hint.reason,
            })
            .collect(),
    }
}

fn error(error: CallError) -> Error {
    Error {
        kind: match error.kind {
            Failure::InvalidInput => types::Failure::InvalidInput,
            Failure::NotFound => types::Failure::NotFound,
            Failure::Unsupported => types::Failure::Unsupported,
            Failure::Internal => types::Failure::Internal,
        },
        message: error.message,
        param: error.param,
    }
}
