//! What every `new` shares: checking `--dir` and `--name`, and planning the
//! embedded template files into the project. The plugin only plans the
//! files; wf previews them and creates them, refusing to replace any.
use crate::plugin::FileWrite;
use std::fmt::Write as _;

/// The op name of the scaffold.
pub const NEW: &str = "new";

/// A file of an embedded template: its path inside the project and its bytes.
pub type File = (&'static str, &'static [u8]);

/// The templates [`crate::build::embed`] embedded, by name.
pub type Templates = &'static [(&'static str, &'static [File])];

const PROJECT_FILE: &str = "project.godot";
const NAME_KEY: &str = "config/name=";

/// A refused input: what is wrong, and which field.
#[derive(Debug, Eq, PartialEq)]
pub struct InputError {
    pub message: String,
    pub param: &'static str,
}

/// The files of the template called `name`.
///
/// # Panics
///
/// When no template has that name: a plugin asks only for directories its
/// build script embeds, so this is a build mistake, caught by its tests.
pub fn template(templates: Templates, name: &str) -> &'static [File] {
    templates
        .iter()
        .find(|(template, _)| *template == name)
        .map_or_else(|| panic!("build.rs embeds no template/{name}"), |(_, files)| *files)
}

/// `files` planned under `dir`, with `project.godot`'s `config/name` set to
/// `name` when one is given. Every write refuses to replace an existing file.
pub fn writes<'a>(dir: &str, files: impl IntoIterator<Item = &'a File>, name: Option<&str>) -> Vec<FileWrite> {
    files
        .into_iter()
        .map(|(path, bytes)| FileWrite {
            path: join(dir, path),
            bytes: match name {
                Some(name) if *path == PROJECT_FILE => renamed(bytes, name),
                _ => bytes.to_vec(),
            },
            overwrite: false,
        })
        .collect()
}

/// A normalized project-relative directory: `/`-separated, no empty, `.`,
/// `..` or hidden segments. `.` alone means the project root (`""`).
pub fn directory(dir: &str) -> Result<String, InputError> {
    let refuse = |why: &str| InputError {
        message: format!("--dir {dir:?} {why}"),
        param: "dir",
    };
    let trimmed = dir.trim_start_matches("./").trim_end_matches('/');
    if trimmed.is_empty() || trimmed == "." {
        return Ok(String::new());
    }
    if dir.starts_with('/') || dir.contains('\\') || dir.contains(':') {
        return Err(refuse("must be a project-relative path with / separators"));
    }
    if trimmed.chars().any(char::is_control) {
        return Err(refuse("contains control characters"));
    }
    for segment in trimmed.split('/') {
        if segment.is_empty() || segment == "." || segment == ".." {
            return Err(refuse("must not contain empty, . or .. segments"));
        }
        if segment.starts_with('.') {
            return Err(refuse("must not name a hidden directory"));
        }
    }
    Ok(trimmed.to_owned())
}

/// The game's name, trimmed: 1 to 100 characters without control characters.
pub fn game_name(name: &str) -> Result<String, InputError> {
    let name = name.trim();
    if name.is_empty() || name.chars().any(char::is_control) || name.chars().count() > 100 {
        return Err(InputError {
            message: "--name must be 1 to 100 characters without control characters".into(),
            param: "name",
        });
    }
    Ok(name.to_owned())
}

/// `path` inside `dir` (`""` is the project root).
pub fn join(dir: &str, path: &str) -> String {
    if dir.is_empty() {
        path.to_owned()
    } else {
        format!("{dir}/{path}")
    }
}

/// project.godot with its `config/name=` line set to `name`, as a Godot
/// string literal, keeping the line ending.
fn renamed(bytes: &[u8], name: &str) -> Vec<u8> {
    let text = String::from_utf8_lossy(bytes);
    let quoted = name.replace('\\', "\\\\").replace('"', "\\\"");
    let mut out = String::with_capacity(text.len() + name.len());
    for line in text.split_inclusive('\n') {
        if line.starts_with(NAME_KEY) {
            let ending = &line[line.trim_end_matches(['\r', '\n']).len()..];
            write!(out, "{NAME_KEY}\"{quoted}\"{ending}").expect("writing to a String");
        } else {
            out.push_str(line);
        }
    }
    out.into_bytes()
}

#[cfg(test)]
mod tests {
    use super::*;

    const FILES: &[File] = &[
        (
            "project.godot",
            b"[application]\r\nconfig/name=\"Old\"\r\nrun/main_scene=\"res://main.tscn\"\r\n",
        ),
        ("main.gd", b"extends Node\n"),
    ];

    #[test]
    fn files_go_under_the_directory_and_the_name_is_quoted() {
        let dir = directory("./games/td/").unwrap();
        let planned = writes(&dir, FILES, Some(r#"Sky "Keep" \ 1"#));
        assert_eq!(planned[0].path, "games/td/project.godot");
        assert_eq!(planned[1].path, "games/td/main.gd");
        assert!(planned.iter().all(|write| !write.overwrite));
        assert_eq!(
            String::from_utf8_lossy(&planned[0].bytes),
            "[application]\r\nconfig/name=\"Sky \\\"Keep\\\" \\\\ 1\"\r\nrun/main_scene=\"res://main.tscn\"\r\n"
        );
        assert_eq!(writes("", FILES, None)[0].bytes, FILES[0].1);
        assert_eq!(directory(".").unwrap(), "");
    }

    #[test]
    fn unsafe_directories_and_names_are_refused() {
        for dir in ["/abs", "a/../b", ".hidden/td", "a//b", "c:\\td"] {
            assert_eq!(directory(dir).err().map(|e| e.param), Some("dir"), "{dir}");
        }
        assert_eq!(game_name("a\nb").err().map(|e| e.param), Some("name"));
        assert_eq!(game_name("  Keep ").unwrap(), "Keep");
    }

    #[test]
    #[should_panic(expected = "build.rs embeds no template/missing")]
    fn a_template_that_was_not_embedded_is_a_build_mistake() {
        let templates: Templates = &[("one", FILES)];
        assert_eq!(template(templates, "one").len(), 2);
        let _ = template(templates, "missing");
    }
}
