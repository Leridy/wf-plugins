//! Just enough of Godot's text scenes (`.tscn`) for rules: each `[node …]`
//! section, its type and the property keys it sets, with offsets into the text.

/// One `[node …]` section of a text scene.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SceneNode<'a> {
    /// The offset of the `[node` header.
    pub start: usize,
    /// The header without its line ending.
    pub header: &'a str,
    /// The header's line ending (`\n`, `\r\n`, or empty at the end of the file).
    pub ending: &'a str,
    /// `name="…"` from the header.
    pub name: Option<&'a str>,
    /// `type="…"` from the header; absent for an instanced scene.
    pub kind: Option<&'a str>,
    /// Property keys set in the section, in order (`loop`, `mouse_filter`, …).
    pub keys: Vec<&'a str>,
}

impl SceneNode<'_> {
    /// Whether the section sets `key`.
    pub fn sets(&self, key: &str) -> bool {
        self.keys.contains(&key)
    }

    /// Where to insert a `key = value` line right under the header, and the
    /// text to insert there, keeping the file's line endings.
    pub fn insert_under_header(&self, line: &str) -> (usize, String) {
        let end = self.start + self.header.len();
        if self.ending.is_empty() {
            (end, format!("\n{line}"))
        } else {
            (end + self.ending.len(), format!("{line}{}", self.ending))
        }
    }
}

/// Every `[node …]` section of `text`, in order.
pub fn nodes(text: &str) -> Vec<SceneNode<'_>> {
    let mut nodes: Vec<SceneNode> = Vec::new();
    let mut in_node = false;
    let mut offset = 0;
    for line in text.split_inclusive('\n') {
        let start = offset;
        offset += line.len();
        let content = line.trim_end_matches(['\r', '\n']);
        if content.starts_with('[') {
            in_node = content.starts_with("[node ");
            if in_node {
                nodes.push(SceneNode {
                    start,
                    header: content,
                    ending: &line[content.len()..],
                    name: attribute(content, "name"),
                    kind: attribute(content, "type"),
                    keys: Vec::new(),
                });
            }
            continue;
        }
        if in_node
            && let Some((key, _)) = content.split_once('=')
            && let Some(node) = nodes.last_mut()
        {
            let key = key.trim();
            if !key.is_empty() {
                node.keys.push(key);
            }
        }
    }
    nodes
}

/// `key="value"` in a section header.
fn attribute<'a>(header: &'a str, key: &str) -> Option<&'a str> {
    let pattern = format!(" {key}=\"");
    let at = header.find(&pattern)? + pattern.len();
    let end = header[at..].find('"')?;
    Some(&header[at..at + end])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn nodes_carry_their_type_name_and_keys() {
        let text = "[gd_scene format=3]\n\n[ext_resource path=\"res://a.gd\" id=\"1\"]\n\n\
                    [node name=\"Root\" type=\"Control\"]\nmouse_filter = 2\n\n\
                    [node name=\"Play\" type=\"Button\" parent=\".\"]\ntext = \"Play\"\nflat = true\n\n\
                    [node name=\"Hud\" parent=\".\" instance=ExtResource(\"2\")]\n\n\
                    [connection signal=\"pressed\" from=\"Play\" to=\".\" method=\"_on_play\"]\n";
        let found = nodes(text);
        assert_eq!(found.len(), 3);
        assert_eq!((found[0].name, found[0].kind), (Some("Root"), Some("Control")));
        assert!(found[0].sets("mouse_filter"));
        assert_eq!(found[1].keys, ["text", "flat"]);
        assert_eq!(found[2].kind, None);
        assert!(found[2].keys.is_empty());
    }

    #[test]
    fn a_line_goes_under_the_header_with_the_file_s_line_ending() {
        let crlf = "[node name=\"B\" type=\"Button\"]\r\ntext = \"x\"\r\n";
        let node = &nodes(crlf)[0];
        assert_eq!(node.insert_under_header("a = 1"), (31, "a = 1\r\n".into()));
        let last = "[node name=\"B\" type=\"Button\"]";
        assert_eq!(
            nodes(last)[0].insert_under_header("a = 1"),
            (last.len(), "\na = 1".into())
        );
    }
}
