//! A plugin's operations as plain Rust. [`export_plugin!`](crate::export_plugin) turns a
//! [`Plugin`] into the component's WIT exports; tests call it directly.
use crate::{description::Description, host::Host, scaffold::InputError};
use serde::{Deserialize, Serialize};

/// What a game plugin is: its name, what `describe()` returns and how it runs an op.
pub trait Plugin {
    /// The name in `wf-plugin.toml`: `wf <name> <op>`.
    const NAME: &'static str;

    fn description() -> Description;

    /// Runs `op` on its JSON `input`. Return [`CallError::unknown_op`] for an
    /// op the description does not list.
    fn call(op: &str, input: &[u8], host: &dyn Host) -> Result<Reply, CallError>;
}

/// What an op returns: its JSON output, the files to write and follow-up commands.
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct Reply {
    pub output: Vec<u8>,
    /// Files the host previews and writes; a plugin never writes one itself.
    pub writes: Vec<FileWrite>,
    pub hints: Vec<Hint>,
}

impl Reply {
    /// A reply carrying `output` as JSON.
    ///
    /// # Panics
    ///
    /// When `output` does not serialize, which a derived output type never does.
    pub fn json(output: &impl Serialize) -> Self {
        Self {
            output: serde_json::to_vec(output).expect("an output serializes"),
            ..Self::default()
        }
    }

    #[must_use]
    pub fn with_writes(mut self, writes: Vec<FileWrite>) -> Self {
        self.writes = writes;
        self
    }

    #[must_use]
    pub fn with_hints(mut self, hints: Vec<Hint>) -> Self {
        self.hints = hints;
        self
    }
}

/// A file to create, or to replace when `overwrite` is set (the host then asks first).
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FileWrite {
    pub path: String,
    pub bytes: Vec<u8>,
    pub overwrite: bool,
}

/// A follow-up command: the arguments after `wf`, and why to run it.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Hint {
    pub args: Vec<String>,
    pub reason: String,
}

impl Hint {
    /// `wf skill show <topic>`.
    pub fn skill(topic: &str, reason: &str) -> Self {
        Self {
            args: vec!["skill".into(), "show".into(), topic.into()],
            reason: reason.into(),
        }
    }

    /// `wf <plugin> lint [--paths <dir>]`: check what `new` just wrote.
    pub fn lint(plugin: &str, dir: &str) -> Self {
        let mut args = vec![plugin.to_owned(), crate::lint::LINT.to_owned()];
        if !dir.is_empty() {
            args.extend(["--paths".to_owned(), dir.to_owned()]);
        }
        Self {
            args,
            reason: "check the project after changing it".into(),
        }
    }

    /// `wf plugin install <plugin> --save`.
    pub fn install(plugin: &str, reason: &str) -> Self {
        Self {
            args: vec!["plugin".into(), "install".into(), plugin.into(), "--save".into()],
            reason: reason.into(),
        }
    }
}

/// Why an op failed.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Failure {
    InvalidInput,
    NotFound,
    Unsupported,
    Internal,
}

/// A failed op: the kind, a message for the person and the input field at fault.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CallError {
    pub kind: Failure,
    pub message: String,
    pub param: Option<String>,
}

impl CallError {
    /// An op this plugin does not have; `ops` are the ones it has.
    pub fn unknown_op(op: &str, ops: &[&str]) -> Self {
        let have = ops.iter().map(|op| format!("`{op}`")).collect::<Vec<_>>().join(", ");
        Self {
            kind: Failure::NotFound,
            message: format!("unknown op `{}`; this plugin has {have}", op.escape_debug()),
            param: None,
        }
    }
}

impl From<InputError> for CallError {
    fn from(error: InputError) -> Self {
        Self {
            kind: Failure::InvalidInput,
            message: error.message,
            param: Some(error.param.into()),
        }
    }
}

/// An op's JSON input as `T`.
pub fn parse<T: for<'de> Deserialize<'de>>(input: &[u8]) -> Result<T, CallError> {
    serde_json::from_slice(input).map_err(|error| CallError {
        kind: Failure::InvalidInput,
        message: error.to_string(),
        param: None,
    })
}

/// Makes `$plugin` (a type implementing [`Plugin`]) this component's
/// `describe` and `call` exports. Put it once in the plugin's `lib.rs`; it
/// expands to nothing outside WebAssembly, so host tests ignore it.
#[macro_export]
macro_rules! export_plugin {
    ($plugin:ty) => {
        #[cfg(target_arch = "wasm32")]
        const _: () = {
            struct Component;

            impl $crate::component::bindings::Guest for Component {
                fn describe() -> ::std::vec::Vec<u8> {
                    $crate::component::describe::<$plugin>()
                }

                fn call(
                    op: ::std::string::String,
                    input: ::std::vec::Vec<u8>,
                ) -> ::core::result::Result<$crate::component::bindings::Outcome, $crate::component::bindings::Error>
                {
                    $crate::component::call::<$plugin>(&op, &input)
                }
            }

    $crate::component::bindings::export_provider!(Component with_types_in $crate::component::bindings);
        };
    };
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn an_unknown_op_names_the_ones_there_are() {
        let error = CallError::unknown_op("lnt", &["new", "lint"]);
        assert_eq!(error.kind, Failure::NotFound);
        assert_eq!(error.message, "unknown op `lnt`; this plugin has `new`, `lint`");
    }

    #[test]
    fn the_lint_hint_narrows_to_the_new_directory() {
        assert_eq!(Hint::lint("game-develop", "").args, ["game-develop", "lint"]);
        assert_eq!(
            Hint::lint("game-develop", "games/a").args,
            ["game-develop", "lint", "--paths", "games/a"]
        );
    }
}
