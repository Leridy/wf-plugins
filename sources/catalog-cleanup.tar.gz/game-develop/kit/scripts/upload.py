#!/usr/bin/env python3
"""Upload dist/site to the public `ugc` plugin index on S3-compatible storage.

Usage: scripts/upload.py [--env-file PATH] [SITE_DIR]   (SITE_DIR defaults to ./dist/site)

The index lives on the company's Tencent COS bucket ai996cs-1329868075
(ap-shanghai) under wf-plugins/ugc/, outside the dev/ and pre/ prefixes the
weaveForge environments use. Its credentials are the STORAGE_* lines of the
deploy repository's config/dev.env.

Configuration (from the environment, or the `STORAGE_*` lines of --env-file):
STORAGE_ENDPOINT, STORAGE_REGION, STORAGE_BUCKET, STORAGE_ACCESS_KEY_ID,
STORAGE_SECRET_ACCESS_KEY, optional STORAGE_PATH_STYLE; WF_INDEX_PREFIX
(default wf-plugins/ugc) and WF_INDEX_PUBLIC_BASE, the public URL of the
bucket (default: derived from the endpoint). STORAGE_KEY_PREFIX is ignored.

Each uploaded object gets its own `public-read` ACL; the bucket policy and
other prefixes are not touched. Packages are create-only: an existing one with
the same bytes is skipped, different bytes stop the upload (a published version
never changes). index.json and its signature go last and are replaced.
Standard library only; the key pair stays in this process and is never printed.
"""
import base64
import datetime
import hashlib
import hmac
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

SETTINGS = (
    "STORAGE_ENDPOINT",
    "STORAGE_REGION",
    "STORAGE_BUCKET",
    "STORAGE_ACCESS_KEY_ID",
    "STORAGE_SECRET_ACCESS_KEY",
    "STORAGE_PATH_STYLE",
    "WF_INDEX_PREFIX",
    "WF_INDEX_PUBLIC_BASE",
)


def quote(value, safe="-_.~"):
    return urllib.parse.quote(value, safe=safe)


def settings(env_file):
    """The environment, with STORAGE_* / WF_INDEX_* lines of env_file filling gaps."""
    values = {name: os.environ[name] for name in SETTINGS if os.environ.get(name)}
    if env_file:
        for line in Path(env_file).read_text().splitlines():
            name, sep, value = line.strip().partition("=")
            if sep and name in SETTINGS and name not in values:
                values[name] = value.strip().strip("'\"")
    missing = [name for name in SETTINGS[:5] if not values.get(name)]
    if missing:
        raise SystemExit(f"missing {', '.join(missing)}")
    return values


class Storage:
    def __init__(self, values):
        self.access = values["STORAGE_ACCESS_KEY_ID"]
        self.secret = values["STORAGE_SECRET_ACCESS_KEY"]
        self.bucket = values["STORAGE_BUCKET"]
        self.region = values["STORAGE_REGION"]
        endpoint = urllib.parse.urlsplit(values["STORAGE_ENDPOINT"])
        if endpoint.scheme != "https" or not re.fullmatch(r"[a-z0-9.-]+", endpoint.netloc):
            raise SystemExit("STORAGE_ENDPOINT must be an https host")
        if not re.fullmatch(r"[a-z0-9][a-z0-9.-]+", self.bucket) or not re.fullmatch(r"[a-z0-9-]+", self.region):
            raise SystemExit("invalid bucket or region")
        self.path_style = values.get("STORAGE_PATH_STYLE", "false").lower() == "true"
        self.host = endpoint.netloc if self.path_style else f"{self.bucket}.{endpoint.netloc}"
        # The address anyone can read the bucket at: the endpoint itself, which
        # for Tencent COS is https://<bucket>.cos.<region>.myqcloud.com.
        self.public_base = values.get("WF_INDEX_PUBLIC_BASE") or (
            f"https://{endpoint.netloc}/{self.bucket}" if self.path_style else f"https://{self.host}"
        )

    def path(self, key):
        key = quote(key, safe="/-_.~")
        return f"/{self.bucket}/{key}" if self.path_style else f"/{key}"

    def request(self, method, key, body=b"", headers=None):
        """A SigV4 header-signed request; returns (status, response headers)."""
        headers = {name.lower(): value for name, value in (headers or {}).items()}
        now = datetime.datetime.now(datetime.timezone.utc)
        stamp = now.strftime("%Y%m%dT%H%M%SZ")
        day = now.strftime("%Y%m%d")
        scope = f"{day}/{self.region}/s3/aws4_request"
        path = self.path(key)
        headers.update(
            {
                "host": self.host,
                "x-amz-date": stamp,
                "x-amz-content-sha256": hashlib.sha256(body).hexdigest(),
            }
        )
        signed = sorted(headers)
        canonical_headers = "".join(f"{name}:{str(headers[name]).strip()}\n" for name in signed)
        signed_names = ";".join(signed)
        canonical = f"{method}\n{path}\n\n{canonical_headers}\n{signed_names}\n{headers['x-amz-content-sha256']}"
        to_sign = f"AWS4-HMAC-SHA256\n{stamp}\n{scope}\n{hashlib.sha256(canonical.encode()).hexdigest()}"
        signing = f"AWS4{self.secret}".encode()
        for part in (day, self.region, "s3", "aws4_request"):
            signing = hmac.new(signing, part.encode(), hashlib.sha256).digest()
        signature = hmac.new(signing, to_sign.encode(), hashlib.sha256).hexdigest()
        headers["authorization"] = (
            f"AWS4-HMAC-SHA256 Credential={self.access}/{scope}, SignedHeaders={signed_names}, Signature={signature}"
        )
        del headers["host"]
        request = urllib.request.Request(
            f"https://{self.host}{path}", data=body if method == "PUT" else None, method=method, headers=headers
        )
        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                return response.status, response.headers
        except urllib.error.HTTPError as error:
            return error.code, error.headers

    def public_url(self, key):
        return f"{self.public_base.rstrip('/')}/{quote(key, safe='/-_.~')}"

    def put(self, key, body, content_type, cache_control):
        status, _ = self.request(
            "PUT",
            key,
            body,
            {
                "content-type": content_type,
                "content-md5": base64.b64encode(hashlib.md5(body).digest()).decode(),
                "cache-control": cache_control,
                "x-amz-acl": "public-read",
            },
        )
        if status != 200:
            raise SystemExit(f"PUT {key} returned HTTP {status}")
        print(f"uploaded  {self.public_url(key)}")


def main():
    args = sys.argv[1:]
    env_file = None
    if args[:1] == ["--env-file"]:
        if len(args) < 2:
            raise SystemExit(__doc__)
        env_file, args = args[1], args[2:]
    # A plugin's scripts/upload.py runs this one from the plugin's directory.
    site = Path(args[0] if args else Path.cwd() / "dist" / "site")
    files = sorted(path for path in site.rglob("*") if path.is_file())
    names = {path.relative_to(site).as_posix() for path in files}
    if not {"index.json", "index.json.sig"} <= names:
        raise SystemExit(f"{site} has no index.json and index.json.sig: run scripts/release.sh first")
    values = settings(env_file)
    prefix = values.get("WF_INDEX_PREFIX", "wf-plugins/ugc").strip("/")
    storage = Storage(values)
    for path in files:
        if path.name in ("index.json", "index.json.sig"):
            continue
        key = f"{prefix}/{path.relative_to(site).as_posix()}"
        body = path.read_bytes()
        status, headers = storage.request("HEAD", key)
        if status == 200:
            if headers.get("ETag", "").strip('"').lower() == hashlib.md5(body).hexdigest():
                print(f"unchanged {storage.public_url(key)}")
                continue
            raise SystemExit(f"{key} is already published with other bytes: bump the plugin version")
        if status != 404:
            raise SystemExit(f"HEAD {key} returned HTTP {status}")
        storage.put(key, body, "application/octet-stream", "public, max-age=31536000, immutable")
    for name in ("index.json", "index.json.sig"):
        storage.put(f"{prefix}/{name}", (site / name).read_bytes(), "application/json", "no-cache")
    print(f"index: {storage.public_url(prefix + '/index.json')}")


if __name__ == "__main__":
    main()
