#!/bin/sh
# Build, pack and sign a game plugin, and add it to the `ugc` plugin index.
# Every game plugin runs this one script: `scripts/release.sh` in a plugin
# calls it with the plugin's directory (the current directory by default).
#
#   WF_INDEX_URL=https://<host>/<dir>/index.json \
#   WF_INDEX_KEY=~/.config/wf-plugins/996-ugc-index.pem \
#   PLUGIN_PUBLISH=~/workspace/weaveForge/target/debug/plugin-publish \
#   scripts/release.sh            # in the plugin's directory
#
# `wf` (the client's own, which needs no pairing) tests, packs and signs;
# `plugin-publish` (built from the weaveForge repository with
# `cargo build -p plugin-publish`) builds the index, which `wf` no longer does.
#
# Writes dist/site/: index.json, index.json.sig and <plugin name>/<package>(.sig).
# Upload everything in dist/site/ into the directory that holds index.json,
# adding files only: the index lists other plugins' packages too.
#
# The index extends the published one (fetched from WF_INDEX_URL and verified
# against the same key), so earlier versions stay installable. A published
# version never changes: bump `version` in wf-plugin.toml before releasing
# changed code. Without a published index (HTTP 404) the index starts empty.
set -eu

WF=${WF:-wf}
PLUGIN_PUBLISH=${PLUGIN_PUBLISH:-plugin-publish}
INDEX_NAME=ugc
: "${WF_INDEX_URL:?set WF_INDEX_URL to the public URL of index.json}"
: "${WF_INDEX_KEY:?set WF_INDEX_KEY to the index signing key (Ed25519 PKCS#8 PEM)}"

root=$(cd "${1:-.}" && pwd)
dist="$root/dist"
name=$(sed -n 's/^name = "\(.*\)"$/\1/p' "$root/wf-plugin.toml" | head -n 1)
version=$(sed -n 's/^version = "\(.*\)"$/\1/p' "$root/wf-plugin.toml" | head -n 1)
package="$name-$version.wfplugin"

rm -rf "$dist"
mkdir -p "$dist/build" "$dist/previous" "$dist/site/$name"

cd "$root"
cargo build --release --locked --target wasm32-wasip2
"$WF" plugin test .
"$WF" plugin pack . --quiet
mv "$package" "$dist/build/"
"$WF" plugin sign "$dist/build/$package" --key "$WF_INDEX_KEY" --quiet

previous=
status=$(curl -sS -o "$dist/previous/index.json" -w '%{http_code}' "$WF_INDEX_URL")
case "$status" in
    200)
        curl -fsS -o "$dist/previous/index.json.sig" "$WF_INDEX_URL.sig"
        previous="--previous $dist/previous/index.json"
        ;;
    *)
        # A private bucket answers 403 for a missing object, so only the
        # publisher can say this is the first release.
        if [ "${WF_INDEX_NEW:-}" != 1 ]; then
            echo "Fetching $WF_INDEX_URL returned HTTP $status; refusing to drop published versions." >&2
            echo "For the index's first release only, rerun with WF_INDEX_NEW=1." >&2
            exit 1
        fi
        echo "Starting a new index (WF_INDEX_NEW=1)."
        ;;
esac

# shellcheck disable=SC2086 # $previous is empty or two words
"$PLUGIN_PUBLISH" index-build "$dist/build" --name "$INDEX_NAME" --key "$WF_INDEX_KEY" $previous

mv "$dist/build/index.json" "$dist/build/index.json.sig" "$dist/site/"
mv "$dist/build/$package" "$dist/build/$package.sig" "$dist/site/$name/"
echo "Ready to upload: $dist/site"
find "$dist/site" -type f | sort
