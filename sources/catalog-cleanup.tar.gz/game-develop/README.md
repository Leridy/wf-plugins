# game-develop

所有 Godot 4 游戏通用的 `wf` 插件（WebAssembly 组件，`wf:plugin@0.1.3`），以及各游戏类型插件共用的 Rust 库 `wf-game-kit`（`kit/`）。

| 命令 | 风险 | 做什么 |
| --- | --- | --- |
| `wf game-develop new [--dir 目录] [--name 名字]` | write | 生成能玩的通用骨架：标题 → 游玩（可暂停）→ 结算 → 重开，规则与画面分开、种子随机流、JSON 存档、无头规则测试与平衡机器人、不开多线程的 Web 预设，按钮都配好指针 |
| `wf game-develop lint [--paths 路径]` | read | 实现 `wf.lint/1`，检查 `.gd`、`.tscn`、`export_presets.cfg` 里所有游戏都会犯的错；`wf lint` 会和类型插件的规则一起运行 |
| `wf skill show game-develop/guide` | read | 选起点（类型插件还是通用骨架）、每个游戏都要守的结构、检查步骤、Web 导出 |
| `wf skill show game-develop/assets` | read | 向平台要 UI、艺术字、图标、动画、地图和声音，`godot-export` 接进 Godot，鼠标指针，接完验收 |
| `wf skill show game-develop/genre-plugin` | read | 用 `wf-game-kit` 派生一个新的游戏类型插件 |

类型插件（`tower-develop`、`roguelike-develop`、`rpg-develop`、`shooter-develop`）只管本类型的模板和规则；下面这些检查只在本插件里，所以和任何类型插件一起装。

## lint 规则

| 规则 | 发现什么 | 自动修复 |
| --- | --- | --- |
| `timer-runs-while-paused` | `create_timer(t)` 只传一个参数：`process_always` 默认为 true，暂停时冷却、出怪间隔和倒计时照样流逝 | 补第二个参数 `false` |
| `save-can-run-code` | 从 `user://` 用 `load()` 读 `.tres`、`.res`，或 `get_var(true)`、`bytes_to_var_with_objects()`：存档里夹带的脚本会在读档时执行 | 无 |
| `shared-resource-mutated` | 运行时改导出的或加载来的 Resource：用同一文件的所有节点共享这一个对象 | 无 |
| `control-cursor-unset` | 按钮、勾选框、滑条等可点控件没设 `mouse_default_cursor_shape`，鼠标移上去还是箭头 | 场景里插入 `mouse_default_cursor_shape = 2`；函数里 `X.new()` 的下一行补设 |
| `web-threads-need-isolation` | Web 预设开了 `variant/thread_support`：没有 COOP/COEP 响应头的托管上停在加载页（启用 PWA 隔离头的除外） | 无 |
| `export-packs-build-output` | 预设导出到工程里却没在 `exclude_filter` 排除那个目录：上一次的产物会被导入并打进下一次的包 | 把目录加进 `exclude_filter` |

都是 warning。项目里可在 `wf-plugins.toml` 的 `[lint.rules]` 调整，例如 `"game-develop/control-cursor-unset" = "off"`。
lint 只申请读取 `**/*.gd`、`**/*.tscn` 与 `**/export_presets.cfg`；`new` 不读文件，只返回新建文件，由 `wf` 预览后写入，已有同名文件时整体拒绝。

以前这些规则分散在类型插件里，类型插件 0.4.0（`shooter-develop` 0.3.0）起只在本插件：`tower-develop/timer-runs-while-paused`、`tower-develop/web-threads-need-isolation`、`roguelike-develop/timer-runs-while-paused`、`rpg-develop/save-can-run-code`、`rpg-develop/shared-resource-mutated` 在 `wf-plugins.toml` 里的级别设置改写成 `game-develop/…`。

## 安装

插件发布在 996-ugc 自建的 `ugc` 插件索引里，登记方法见任一类型插件的 README。在游戏项目根目录：

```sh
wf plugin install game-develop --save
```

确认显示的版本、签名者和读取权限后加 `--yes` 重跑，再把 `wf-plugins.toml` 和 `wf-plugins.lock` 提交到游戏仓库。装好后：

```sh
wf game-develop new --dir game --name 我的游戏 --dry-run   # 先看要建哪些文件
wf game-develop new --dir game --name 我的游戏
godot --editor --path game                               # Godot 4.7.1，F5 运行
wf lint game
godot --headless --path game --editor --import --quit
godot --headless --fixed-fps 60 --path game tests/run_tests.tscn   # 末行 TESTS: PASS
godot --headless --fixed-fps 60 --path game tests/bots.tscn        # 末行 BOTS: PASS
wf skill show game-develop/guide
```

## wf-game-kit

`kit/` 是各游戏插件共用的 Rust 库，类型插件用路径依赖引用它（`wf-game-kit = { path = "../game-develop/kit" }`），所以本仓库要和类型插件放在同一个目录下。

| 模块 | 内容 |
| --- | --- |
| `plugin` | `Plugin` trait（名字、描述、`call`），`Reply`、`FileWrite`、`Hint`、`CallError`，`export_plugin!` 把插件变成组件的 `describe`/`call` 导出 |
| `lint` | `wf.lint/1` 驱动：按文件种类和路径列出、读取、交给规则；`testing::MemoryProject` 供测试 |
| `gdscript`、`scene` | 抹掉字符串和注释的 GDScript 扫描、调用与函数范围、类名；`.tscn` 的节点与属性 |
| `scaffold`、`build` | `--dir`/`--name` 校验与写文件计划；`build.rs` 里把 `template/<名字>/files/` 内嵌进组件 |
| `protocol`、`description`、`host`、`component` | wf 宿主契约与 WIT 胶水（`wit/plugin.wit`、`schemas/` 来自 `wf plugin new`，不要手改） |
| `scripts/` | 所有游戏插件共用的 `release.sh`、`upload.py`；类型插件的同名脚本只是调用它们 |

kit 改了之后，用到它的插件都要重新构建、跑测试，有行为变化就升版本再发布。升级 `wf` 后，用新版 `wf plugin new x --template lint` 生成一份，替换 `kit/src/description.rs`、`kit/src/protocol.rs`、`kit/wit/`、`kit/schemas/`。

## 开发

```sh
cargo test --workspace                         # kit、规则与骨架规划在宿主上测试
cargo clippy --workspace --all-targets
cargo build --release --target wasm32-wasip2   # rust-toolchain.toml 会装好目标
wf plugin test .                               # 校验清单、描述，并 dry-run 每个示例
```

改了 `template/starter/files/` 后，在它的副本里导入并跑测试和机器人（不要把 `.godot/` 留在仓库）；`cargo test` 里的 `the_starter_passes_its_own_lint` 保证骨架通过本插件的 lint。

## 发布新版本

已发布：0.1.0（2026-11-09）；0.1.1（2026-11-13，补充 3D 光照排查、GPU 特效与真实渲染验收规则，以及验收资料的导出隔离；权限和运行逻辑不变）。

和类型插件同一份索引、同一把私钥、同一套步骤（见 `tower-develop` 的 README“发布新版本”），在本仓库根目录运行：

```sh
WF=~/.local/bin/wf \
PLUGIN_PUBLISH=~/workspace/weaveForge/target/debug/plugin-publish \
WF_INDEX_URL=https://ai996cs-1329868075.cos.ap-shanghai.myqcloud.com/wf-plugins/ugc/index.json \
WF_INDEX_KEY=~/.config/wf-plugins/996-ugc-index.pem \
kit/scripts/release.sh
kit/scripts/upload.py --env-file <部署仓库>/config/dev.env
```

## 目录

```text
wf-plugin.toml          清单：权限与技能页
src/lib.rs              插件：new 与 lint
src/describe.rs         两个能力的描述
src/scaffold.rs         new：通用骨架 → 新建文件计划
src/rules.rs, src/rules/  六条通用规则与测试
template/starter/       new 写出的通用骨架，build.rs 编译时嵌入
skills/                 guide、assets、genre-plugin
kit/                    wf-game-kit：各游戏插件共用的库与发布脚本
```

## 来源与许可

- `template/starter/`：原创，MIT（`LICENSE`）；`icon.svg` 是 Godot 的默认图标。
- `kit/`：协议、描述、host 与 WIT 来自 `wf plugin new` 生成的插件骨架；其余从 `tower-develop`、`roguelike-develop`、`rpg-develop`、`shooter-develop` 中重复的代码合并而来。

## Unified template entry

Install this plugin, then open **Plugins → Templates**. Each project template appears
with the other game templates and uses the shared directory selection and preview flow.
The existing `new` and `lint` commands remain compatible. Template project files now live
under `template/<name>/files/`; `template.toml` describes the entry shown by the client.
Both the native CLI scaffolder and the data contribution use this same file tree.
No engine process runs while creating these templates; open the generated project in Godot.
