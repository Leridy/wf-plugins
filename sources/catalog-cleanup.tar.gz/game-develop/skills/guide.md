# 游戏开发通用指南

用于任何 Godot 4 游戏：类型还没定、不属于现有类型插件，或者已经用了类型插件、要查所有游戏都会踩的坑。类型插件（塔防、肉鸽、RPG、射击）管本类型的模板和规则；暂停计时、存档、共享 Resource、导出预设、鼠标指针这些所有游戏共有的检查只在本插件里。

## 先选起点

| 要做的游戏 | 用哪个插件 | 起点 |
| --- | --- | --- |
| 塔防 | `tower-develop` | 固定路线、造塔格、波次、升级出售 |
| 肉鸽、肉鸽 lite | `roguelike-develop` | 回合制地牢、幸存者式、房间式动作 |
| RPG | `rpg-develop` | 回合制队伍、格子战棋、俯视角动作 |
| 第一、第三人称射击 | `shooter-develop` | FPS、TPS 竞技场 |
| 类型还没定，或都不像 | `game-develop` | 本插件的通用骨架（下面） |

无论用哪个类型插件，都把本插件一起装上：

```sh
wf plugin install game-develop --save            # 第一次会停下来让你确认权限，看清后加 --yes
wf plugin install <类型>-develop --save          # 类型确定时
wf lint                                          # 两个插件的规则一起跑
```

类型插件的模板已经守住了下面的结构。只是类型定下来之后，不要把已经开工的通用骨架硬改成类型模板；读那个类型插件的 `guide`，按它的坑去改现有工程就行，它的 lint 对任何工程都有效。

## 插件命令

| 命令 | 做什么 |
| --- | --- |
| `wf game-develop new [--dir 目录] [--name 名字]` | 生成能玩的通用骨架（默认 `game/`）。只新建文件，目录里已有同名文件时整体不写；先加 `--dry-run` 给用户看文件清单 |
| `wf game-develop lint [--paths 路径]` | 查 `.gd`、`.tscn`、`export_presets.cfg` 里所有游戏都会犯的错；`wf lint` 会和其他 linter 一起跑，`wf lint --fix --dry-run` 预览修复 |

lint 规则（都是 warning，可在 `wf-plugins.toml` 的 `[lint.rules]` 里改级别或关掉，例如 `"game-develop/control-cursor-unset" = "off"`）：

| 规则 | 抓什么 | 自动修复 |
| --- | --- | --- |
| `timer-runs-while-paused` | `create_timer(t)` 只传一个参数：暂停时冷却、出怪间隔和倒计时照样流逝 | 补第二个参数 `false` |
| `save-can-run-code` | 从 `user://` 用 `load()` 读 `.tres`、`.res`，或 `get_var(true)`、`bytes_to_var_with_objects()`：存档里夹带的脚本会在读档时执行 | 无 |
| `shared-resource-mutated` | 运行时改导出的或加载来的 Resource（`stats.hp -= 1`）：用同一文件的所有节点共享这一个对象 | 无 |
| `control-cursor-unset` | 按钮、勾选框、滑条等可点控件没设 `mouse_default_cursor_shape`：鼠标移上去还是箭头 | 场景里插入手形；函数里 `X.new()` 的下一行补设 |
| `web-threads-need-isolation` | Web 预设开了多线程：没有 COOP/COEP 响应头的托管上停在加载页 | 无 |
| `export-packs-build-output` | 预设导出到工程里（`build/web/…`）却没在 `exclude_filter` 排除这个目录：上一次的产物会被导入并打进下一次的包 | 加进 `exclude_filter` |

## 通用骨架

`wf game-develop new` 生成一个 45 秒的收集小游戏：WASD 或方向键移动，收集金币、躲开障碍，Esc 暂停。玩法只是占位，结构才是要留下的东西。Godot 4.7.1，入口 `main.tscn`。

| 要改什么 | 入口 |
| --- | --- |
| 所有数值 | `data/content.gd` |
| 规则：一局里发生什么、怎么赢怎么输 | `scripts/game.gd`（纯逻辑，不读输入、不画画） |
| 标题、HUD、暂停、结算画面，按键翻译成调用 | `scripts/main.gd` |
| 画面 | `scripts/world_view.gd`（只读 `game`，换美术不碰规则） |
| 存档 | `scripts/save_game.gd`（`user://save.json`） |
| 种子与随机流 | `scripts/game_rng.gd` |
| 规则测试、平衡机器人 | `tests/run_tests.gd`、`tests/bots.gd` |
| 网页导出 | `export_presets.cfg` 的「Web」预设 |

把占位玩法换成你的：在 `game.gd` 里写规则（大了就拆成几个同样不碰节点的对象），`main.gd` 只负责显示和把输入翻译成调用；然后改测试守住新规则的承诺，改机器人的打法和预期。

## 每个游戏都要守的结构

1. **数字集中在 `data/`。** 调数值只改这里，规则代码里不出现魔法数。
2. **规则在纯逻辑对象里**，不依赖节点和画面；`main.gd` 只画和翻译输入。这样测试和机器人能不开窗口地跑整局。
3. **机器人和测试调用和玩家同一组函数。** 屏幕能做的事机器人也只能这样做，不要给它开后门，否则它的结论对玩家不成立。
4. **每个随机系统一条随机流。** `GameRng.stream("coins")` 由本局种子和名字派生；改变状态的随机都走流，只有抖动、粒子这类表现可以用全局随机。存档时把流的状态一起存（存成字符串，JSON 只保留 53 位）。
5. **存档是 JSON 数据。** 不存 Resource、不存对象；坏文件、手改过的文件读成新档而不是报错。存档会长大时加版本号，先写临时文件再改名，上一份留作 `.bak`。
6. **暂停就是不推进规则。** 规则按传进来的时间走，画面节点设 `PROCESS_MODE_PAUSABLE`，菜单设 `PROCESS_MODE_ALWAYS`；`create_timer` 显式传 `false`（lint 会查）。
7. **界面能点的都有手形指针。** 见 `wf skill show game-develop/assets` 的“鼠标指针”。

## 视觉效果与 GPU

用于大量粒子、碎片、植被摆动、溶解等持续视觉效果。这里是实现与实机验收规则，现有 lint 不会自动证明它们满足要求。

- **规则和画面各管自己的时间。** 伤害、弹道碰撞、无敌、生成与释放由规则更新决定；画面只接收事件和参数。关闭装饰特效不改变命中、奖励或对象容量，视觉随机也不消耗玩法的随机流。
- **可并行的纯视觉计算优先交给 GPU。** 使用 Shader（显卡上的计算程序）、GPU 粒子或引擎动画；脚本负责触发、起止时间、强度、变换等少量参数。检查运动实际发生在哪里：用了 MultiMesh 或 Shader，但每帧仍逐粒子、逐顶点计算并上传，不代表完成 GPU 化。静态网格和纹理离线或初始化生成并缓存；避免在持续动画中反复建网格、纹理、复制材质或回读 GPU。少量镜头、角色动画不需要强行改写成 GPU 程序。
- **共享资源，保留实例差异。** 网格和材质尽量共享，差异用实例参数表达；GPU 位移需要扩展可见包围盒，避免对象仍在屏幕里却被裁掉。若目标渲染器不支持所需能力，采用明确的降级或有实测成本的 CPU 实现，不把预览环境的效果当成跨平台保证。
- **暂停要覆盖着色器和粒子。** Godot 的 Shader 内置 `TIME` 不随游戏暂停停止；需要暂停的效果使用可暂停视觉时钟，粒子模拟也同步暂停。仅停止发射不等于冻结已有粒子。复用时重置旧状态，切关或回滚时清理旧效果。[Shader 时间说明](https://docs.godotengine.org/en/stable/tutorials/shaders/shader_reference/spatial_shader.html#global-built-ins)
- **修改效果后做真实渲染验收。** 检查暂停、恢复、连续触发、实例复用和卸载；对照同硬件、分辨率、渲染器及相同场景负载的帧耗时、CPU/GPU 时间、绘制调用与显存。大量效果或性能优化同时记录 p95/p99（较慢的那部分帧耗时）；拿不到的指标写 `unavailable`，不要用渲染 CPU 时间代替 GPU 时间。无头测试不能证明 GPU 正确，静态截图不能证明战斗性能。

3D 光照检查见 `wf skill show game-develop/assets` 的“3D 光照”；射击游戏的枪口与特效用途见 `wf skill show shooter-develop/systems`。

## 改完要做的检查

```sh
wf lint <目录>
godot --headless --path <目录> --editor --import --quit                  # 新克隆或新增资源后
godot --headless --fixed-fps 60 --path <目录> tests/run_tests.tscn       # 末行 TESTS: PASS
godot --headless --fixed-fps 60 --path <目录> tests/bots.tscn            # 末行 BOTS: PASS
```

1. **规则测试测承诺，不测今天的数字**：同一种子打出同一局、奖励只发一次、结束只结束一次、存档往返、坏存档不崩、暂停时时间不走、每个按钮是手形。
2. **`tests/script_errors.gd` 必须接上。** 检查函数中途报运行时错误（对 null 调方法）时，Godot 只中止这一个函数，后面照常跑完，测试还是 PASS；它统计 `SCRIPT ERROR`，有一次就判失败。新加的测试入口也要接。
3. **机器人至少两种打法对照**（偷懒和认真），每 0.25 秒左右决策一次（人的反应时间），多个种子。先看数字有没有往你想要的方向变，再决定改不改文件开头的预期；不要为了通过改预期。
4. **真的打开窗口玩一遍。** `godot --path <目录>`：从标题开始一局、暂停、继续、输、赢、再来一局；鼠标挨个移过按钮和能点的东西，看指针。只在无头模式下跑过，证明不了玩家玩得通。

## Web 导出

模板的 Web 预设关闭多线程（`variant/thread_support=false`），不需要服务器发 COOP/COEP 头；`exclude_filter` 排除 `tests/*` 和 `build/*`。导出需要装同版本的导出模板：

```sh
godot --headless --path <目录> --export-release Web build/web/index.html
```

浏览器里关不掉标签页，模板在网页上隐藏“退出”按钮。网页上指针图不要超过 128×128。

画面对照截图、性能报告等验收资料也要与运行素材分开：放在工程外，或在专用目录加 `.gdignore` 并核对导出过滤。检查实际导出包，避免图片被自动导入后混进游戏；不要对仍被游戏引用的素材目录加忽略标记。

## 不要做的事

- 不要用 `draw_rect` 和系统字体拼界面、写标题：向平台要 UI 组件和艺术字（`game-develop/assets`）。也不要自己写脚本裁帧动画，用 `godot-export`。
- 不要在 `main.gd` 的按钮回调里写规则（比如直接扣血）：测试和机器人看不到这部分。
- 不要用 `randi()` 之类的全局随机改变游戏状态：同一种子就打不出同一局，读档后也对不上。
- 不要用 Resource 存档，也不要在运行时改共享的 Resource（lint 会报）。
- 不要只用一种打法的机器人判断平衡。
