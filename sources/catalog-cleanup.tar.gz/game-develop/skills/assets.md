# 素材：向平台要什么、怎么要、怎么接进 Godot

模板里的美术和界面都是占位。做成自己的游戏时，美术、界面和文字都从 WeaveForge 工作区来。**开工前先列清单**，按清单一次向平台 Agent 要齐，再用现成的工具接进 Godot。界面不要自己用 `draw_rect` 拼，标题不要用系统字体写，帧动画不要自己写脚本裁：平台给的组件带状态、九宫格边距和文字安全区，玩家一眼就看得出差别。

类型插件的 `assets` 只列本类型的清单和特别接法；要法、接法、鼠标指针和验收都以本文为准。

## 1. 先列清单

按游戏的每个画面列，每个控件写上要哪些状态。下表是几乎每个游戏都有的部分，再加上本类型自己的画面：

| 画面或用途 | 节点类型 | 要什么 |
| --- | --- | --- |
| 标题画面 | `word_art` + `ui` | 游戏名 logo（整句）；开始、继续、设置、退出按钮（普通 / 悬停 / 按下 / 不可用），标题底板 |
| 游戏中 HUD | `ui` | 生命条、资源栏（金钱、弹药、能量）、计时或波次牌、暂停按钮 |
| 暂停与设置 | `ui` | 九宫格窗口、按钮、滑条、勾选框、页签 |
| 结算 | `word_art` + `ui` | “胜利”“失败”横幅；分数和伤害数字用 `digits` 加 `symbols` 字形组；再来一局、回标题按钮 |
| 道具、技能、状态 | `icon` | 每个一个图标，逐个点名 |
| 角色、敌人 | `frame_animation`（2D）或 `model_3d`（3D） | 待机、移动（四向或左右）、攻击、受击、死亡 |
| 物件 | `prop` | 每个状态一张，带锚点和碰撞 |
| 地图 | `tilemap`、`whole_map` 或 `scene3d_map` | 按格子走的要瓦片地图；一整张画好的场景要整图；3D 关卡要 3D 场景 |
| 效果 | `character_effect` 或 `particle_effect` | 命中、爆炸、拾取、升级 |
| 鼠标指针（可选） | `icon` | 普通、可点、不可用，射击游戏菜单用的一套；见第 4 节 |
| 声音 | `music`、`sound_effect` | 每个场景的音乐；确认、取消、拾取、受击、胜负音效 |

先用 `wf ls`、`wf find` 看工作区里已经有什么，只要缺的。生成要花钱，清单给用户过目再发。

## 2. 怎么要：`wf agent send`

平台 Agent 看不到你的工程和对话，需求要写全。每条需求只做一件事：**一套 UI 只对应一个画面**，另一个画面是另一套。所有 UI、艺术字、图标的风格用**同一段话**，从游戏的美术设定里抄出来（有设定文档就写进需求，说“按《视觉风格》”）。画面方向和操作方式照实写：PC 横屏写“横屏，键盘鼠标操作”。

照下面填空，一条一条发（`--wait` 等它做完）：

```sh
wf agent send "在「05_界面」下新建一套 UI 组件，名字「界面_<画面>」：<游戏名>（<类型>）的<画面>，横屏、键盘鼠标操作。要这些控件：<按第 1 节逐个点名，带状态>。风格：<同一段风格描述>。" --wait
wf agent send "在「05_界面」下新建艺术字，名字「艺术字_标题」：标题 \"<游戏名>\"，用于标题画面。风格：<同一段风格描述>，<字的材质、描边>。" --wait
wf agent send "在「05_界面」下新建艺术字，名字「艺术字_结算」：横幅 \"胜利\" 和 \"失败\"，并要数字和符号字形组，用于<分数、伤害、金钱>。风格：<同一段风格描述>。" --wait
wf agent send "在「07_图标」下新建一套图标，名字「图标_<用途>」：<名字1>、<名字2>、…，用于<哪个界面>。风格：<同一段风格描述>。" --wait
```

- 艺术字只画引号里的字，引号里的字要和游戏里显示的一字不差。会变的数字和字母要字形组（数字、符号、大写、小写），不要为每个数字单独要整句图。
- 平台 Agent 问问题时（退出码 11）把问题原样转给用户，不要替用户回答。
- 做完 `wf pull`，再 `wf use <路径>` 看它给了哪些控件、状态、字形和缺字：缺的要说出来、补要一次，不要拿别的控件凑。

## 3. 怎么接进 Godot

官方插件 `godot-export` 把导出转成 Godot 资源，先装好：

```sh
wf plugin install godot-export --save        # 第一次会停下来让你确认，看清后加 --yes
wf export '<UI 或帧动画路径>' --out assets/wf  # 推荐形态；导出目录要在 Godot 工程里面
wf export '<艺术字路径>' --as bmfont --out assets/wf  # 字形组；整句标题用 --as pieces
wf godot-export sync --dry-run
wf godot-export sync
```

| 素材 | 接法 |
| --- | --- |
| `ui` | 推荐形态 `pieces`，`godot-export` 生成 `<名字>.theme.tres`。给界面根节点设 `theme`（通用骨架是 `main.tscn` 上的 `ui_theme`），每个控件设 `theme_type_variation` 为输出里列出的变体名；按钮用 `Button`，条用 `ProgressBar`（填充从右边裁，不要拉伸填充图），面板用 `PanelContainer`；文字放进 `text_safe` 给出的内容区，不要另加边距 |
| `word_art` 整句 | `--as pieces`，`texts.json` 给出每句的文件、尺寸和中心点；`TextureRect` 原样显示，只用于它写的那句字 |
| `word_art` 字形组 | `--as bmfont`，Godot 直接导入 `.fnt`，给 `Label` 设 `theme_override_fonts/font`；先核对要显示的每个字符（含空格、标点）都在 `use` 报告里 |
| `icon` | 每个图标一张 PNG，`TextureRect`，按 `use` 给的 ID 引用 |
| `frame_animation` | `godot-export` 生成 `<名字>.sprite_frames.tres` 和 `<名字>.tscn`（`AnimatedSprite2D`）；动画名是 `动作_方向`，时长和循环照导出 |
| `prop` | `use` 选 `pieces`：每个状态一张 PNG 加 `props.json` 的锚点和碰撞多边形；按锚点摆放，多个多边形分开放 |
| `tilemap` | `wf export` 会多写一份 `tilemap.json`，`godot-export`（0.2.0 起）生成 `<名字>.tileset.tres` 和 `<名字>.tscn`：`Ground<N>` 是地形 `TileMapLayer`，`Scene` 是按 y 排序的物件节点（人物加进去，房子和树会挡住人），`Collision` 是平台算好的碰撞，`Spawn` 是出生点。直接实例化这个场景，不要从预览图里抠图块，也不要自己标墙。TileSet 的 `metadata/wf_terrains` 按四角掩码（NW/NE/SE/SW = 1/2/4/8）列出每种地形的图块，程序生成地图时用它按角铺地形 |
| `whole_map` | 地面和物件分层用，碰撞和遮挡用平台测好的数据，读法见 `wf skill show nodes/whole_map`；不要拿拍平的预览图当背景再凭眼睛摆碰撞 |
| `model_3d` | 导出 GLB，Godot 直接导入；碰撞体保持规则用的形状，不要拿模型网格当碰撞。读 `wf skill show nodes/model_3d` |
| `scene3d_map` | 导入 `engine-scene.glb`；出生点、门、可交互物从根节点 extras 的 `roles` 读，碰撞看网格 extras 的 `weaveforge.collision`。读 `wf skill show nodes/scene3d_map` |
| `particle_effect` | 读 `wf skill show nodes/particle_effect` 的导出说明 |

换成平台组件时，把占位画面改成 `Control`（`Button`、`ProgressBar`、`PanelContainer`、`Label`、`TextureRect`）挂上主题，规则代码不用动。

## 4. 鼠标指针：移上去就知道能不能点

Godot 里所有控件默认都是箭头，按钮、背包格、地图上能点的东西看起来都一样，玩家只能点了才知道。HUD 和界面里每个能用鼠标操作的东西都要配好指针：

| 鼠标下面是什么 | 指针 | 怎么设 |
| --- | --- | --- |
| 能点的按钮、页签、卡片、列表项、勾选框、滑条 | 手形 | `mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND`（`.tscn` 里写 `mouse_default_cursor_shape = 2`） |
| 暂时点不了的（钱不够、未解锁、冷却中） | 禁止 | 在设 `disabled` 的同一处改成 `CURSOR_FORBIDDEN`，恢复时改回手形。Godot 不会因为 `disabled` 自动换指针 |
| 输入框 | 竖线 | `LineEdit`、`TextEdit` 默认就是，不用改 |
| 拖动中的物品 | `CURSOR_DRAG`；能放下的位置 `CURSOR_CAN_DROP`，放不下 `CURSOR_FORBIDDEN` | 在 `_can_drop_data` 里按结果设 |
| 纯展示的面板底、文字、图标、血条、金钱栏 | 箭头 | 不改；不需要接收鼠标的设 `mouse_filter = Control.MOUSE_FILTER_IGNORE`（`.tscn` 里写 `2`） |

- 指针取鼠标下最上层**会接收鼠标**的控件。铺满全屏的 HUD 根节点和装饰层要设 `MOUSE_FILTER_IGNORE`，否则它盖在按钮和游戏画面上面，到哪都是箭头，还会吞掉点击。
- 游戏画面里能点的东西不是 `Control`：鼠标移上去时调 `Input.set_default_cursor_shape(Input.CURSOR_POINTING_HAND)`，移开、点完或取消后改回 `Input.CURSOR_ARROW`。
- 鼠标被捕获的游戏（第一人称射击）战斗中不显示系统指针，瞄准只靠 HUD 准星；切回菜单（`MOUSE_MODE_VISIBLE`）后照上表。
- 换成平台给的 UI 主题时节点不变，指针设置还在；新加的控件要同时设好指针。lint 的 `control-cursor-unset` 会找出漏设的按钮和滑条，但查不出禁用时没换指针、也查不出游戏画面里的可点物，这两样要自己看。
- 想让指针图和美术风格一致，就在第 1 节的清单里加一套 `icon`，用 `Input.set_custom_mouse_cursor(图, 形状, 热点)` 给每种形状各挂一张，热点设在指尖或准心。图不要超过 128×128，网页上浏览器会忽略更大的指针图。

## 5. 接完要看

打开窗口把每个画面过一遍：按钮的普通、悬停、按下、不可用都对，九宫格放大后四角不变形，进度条填充方向对，文字不出框、不压在一起，标题和横幅是艺术字，人物和物件站在锚点上、不穿墙。鼠标挨个移过按钮、格子和画面里能点的东西：能点的是手形，点不了的是禁止，纯展示的是箭头。截图给用户看。

### 3D 光照：先找过亮来源，再调画面

适用于导入 3D 场景、模型后发现发白、过曝或暗部看不清的情况；不是所有游戏都要增加后处理。

1. **先锁定对照条件。** 保留改前配置，固定机位、时刻、分辨率、渲染器和画质档；检查受光墙面、阴影中的敌人及高光材质。若有自动曝光，先固定曝光排查，再验收亮暗场景切换。
2. **检查实际生效的光源与材质。** 分清太阳直射、天空补光、环境颜色、雾和自发光；同时检查贴图导入、金属度与粗糙度，避免用全局调暗掩盖单个材质错误。Godot 的天空参与比例 `ambient_light_sky_contribution = 1` 时，环境颜色和能量不参与补光；只改这两个数不会解决天空补光过强。先核对 `ambient_light_source` 及实际比例。[Environment 参考](https://docs.godotengine.org/en/stable/classes/class_environment.html#class-environment-property-ambient-light-sky-contribution)
3. **先曝光和高光压缩，再微调对比度。** 色调映射把场景亮度压进屏幕可显示范围；检查当前算法的白点等参数是否适用，别直接照抄别的算法。Godot 在色调映射后应用对比度，过度提高会再次丢失亮部或暗部细节。自定义后处理还要核对颜色空间，避免重复做显示颜色转换。[Environment 处理顺序](https://docs.godotengine.org/en/stable/classes/class_environment.html#description)
4. **按症状做最小修改。** 参考游戏的曝光与高光处理思路，不必连软阴影、体积光、环境遮蔽或自动曝光一起移植。参数以当前场景为准；室外日光的一组数值不能直接推广到室内、雪地或其他画质档。
5. **比较细节与可读性。** 固定机位前后截图，确认亮墙仍有纹理、暗处仍能识别敌人与路径；局部亮度统计可辅助定位，不能独自决定好看与否。Web 项目要检查实际浏览器；Forward+ 与 Compatibility 分别验收，缺少目标环境时明确写“未验证”。
