# 派生一个新的游戏类型插件

用于给一个新的游戏类型（比如卡牌、平台跳跃、模拟经营）做 wf 插件。类型插件只写三样本类型特有的东西：**模板、规则、技能文档**。插件协议、lint 驱动、GDScript 和场景解析、脚手架、WIT 胶水、构建时内嵌模板、发布脚本都在 `wf-game-kit`（game-develop 仓库的 `kit/`）里，不要再复制一份。所有游戏共有的检查和文档只在 game-develop 里，类型插件引用它们。

## 先判断值不值得做

- 先用 `wf game-develop new` 的通用骨架做出一个能玩的版本。只有当这个类型有**通用骨架装不下的结构**（固定路线和造塔格、回合与地图生成、射击的视角与弹道），并且有**只在这个类型里出现、试玩又难发现的错误**可以写成规则时，才单独做插件。
- 只是换个题材、换套数值的，写进通用骨架的游戏里就行，不要做插件。

## 仓库结构

新仓库和 `game-develop` 放在同一个目录下（`~/workspace/<类型>-develop` 和 `~/workspace/game-develop`），通过路径依赖引用 kit：

```
<类型>-develop/
  Cargo.toml          # [lib] crate-type = ["cdylib", "rlib"]；依赖见下
  build.rs            # wf_game_kit::build::embed("template");
  wf-plugin.toml      # #:schema ../game-develop/kit/schemas/wf-plugin.schema.json
  rust-toolchain.toml rustfmt.toml .gitignore   # 照 game-develop 抄
  src/lib.rs          # 插件：实现 wf_game_kit::Plugin，末尾 export_plugin!
  src/describe.rs     # describe() 的能力说明：new 和 lint
  src/scaffold.rs     # new 的输入输出；Template 枚举对应 template/ 下的目录
  src/rules.rs        # 本类型的规则；src/rules/tests.rs 放测试
  template/<名字>/template.toml  # wf.template/1 入口
  template/<名字>/files/         # 游戏文件，构建时内嵌
  skills/             # guide.md、assets.md，再加本类型的方法篇
  scripts/release.sh scripts/upload.py   # 两行包装，调 kit/scripts 里的同名脚本
```

`Cargo.toml` 的依赖：

```toml
[dependencies]
schemars = "1"
serde = { version = "1", features = ["derive"] }
serde_json = "1"
wf-game-kit = { path = "../game-develop/kit" }

[build-dependencies]
wf-game-kit = { path = "../game-develop/kit" }

[dev-dependencies]
wf-game-kit = { path = "../game-develop/kit", features = ["testing"] }

[workspace]
```

`lints`、`profile.release` 照 game-develop 的 `Cargo.toml` 抄。`api` 写 kit 的 `wit/plugin.wit` 的版本（现在是 `wf:plugin@0.1.3`）。

## 代码怎么写

照 `tower-develop`（一个模板）或 `roguelike-develop`（`--template` 选模板）抄，改名字即可：

- `lib.rs`：`impl Plugin for X { const NAME; fn description(); fn call(op, input, host) }`。`new` 用 `scaffold::plan` 得到输出和要写的文件，回复里带三条提示：本插件的 `guide`、`assets`，和 `Hint::install("game-develop", …)`。`lint` 就是 `lint::run(host, &parse(input)?, &KINDS, check)`。未知 op 回 `CallError::unknown_op`。最后一行 `wf_game_kit::export_plugin!(X);`。
- `scaffold.rs`：`static TEMPLATES: Templates = include!(concat!(env!("OUT_DIR"), "/templates.rs"));`，`scaffold::template(TEMPLATES, 名字)` 取文件，`scaffold::directory`、`game_name`、`writes` 处理 `--dir`、`--name` 和写文件。
- `rules.rs`：`pub fn check(sources: &[Source]) -> Vec<Diagnostic>`。需要整个工程的信息（类名、旗标、有没有自己的随机数生成器）时，先扫一遍 `sources` 再逐个检查。用 kit 的 `gdscript::{code_only, calls, functions, strings, class_name, extends}` 和 `scene::nodes`，先把字符串和注释抹掉再找代码，偏移量用 `span()`。

## 规则怎么定

- **只收本类型的规则。** 暂停时计时器照走、存档能执行代码、共享 Resource 被改、导出预设、鼠标指针已经在 game-develop 里；对所有游戏都成立的新检查也加到 game-develop，不要放进类型插件，否则两个插件一起装时会重复报。
- 一条规则只抓一种错，消息说清**会怎样坏**和**怎么改**。能安全地自动改才给 `fix`，拿不准就只报不改。
- 宁可漏报，也不要在正常写法上误报：规则测试里要有“看着像但不该报”的写法。
- 把 `KINDS` 收窄到规则真要读的文件，`wf-plugin.toml` 的 `read` 和它一致。

## 模板要满足

- 能直接运行，规则在纯逻辑对象里，`tests/run_tests.tscn` 和 `tests/bots.tscn` 都接上 `tests/script_errors.gd`，末行打印 `TESTS: PASS` / `BOTS: PASS`。
- Web 预设关闭多线程，`exclude_filter` 排除 `tests/*` 和 `build/*`。
- 每个按钮和滑条设好手形指针，全屏容器设 `MOUSE_FILTER_IGNORE`。
- **game-develop 的 lint 和本插件的 lint 在模板上都不报**，写一条 Rust 测试守住（参考 game-develop 的 `the_starter_passes_its_own_lint`）。
- 写清来源和许可证（`LICENSE`、README 的来源一节）。

## 技能文档

- `guide`：选模板、改动入口、本类型的坑和规则表、检查步骤。通用的结构、检查、Web 导出和不要做的事写一句“见 `game-develop/guide`”，不要重抄。
- `assets`：只写本类型的清单（第 1 节）和特别接法，要法、通用接法、鼠标指针和验收引用 `game-develop/assets`；鼠标指针只补本类型画面里特有的可点物。
- 其余按本类型需要拆篇（平衡、系统、来源），每篇不超过 16 KiB。

## 验证和发布

```sh
cargo test && cargo clippy --all-targets
cargo build --release --target wasm32-wasip2
wf plugin test .
godot --headless --path template/<名字>/files --editor --import --quit   # 在模板的副本里跑，别把 .godot 留在仓库
godot --headless --fixed-fps 60 --path <副本> tests/run_tests.tscn
godot --headless --fixed-fps 60 --path <副本> tests/bots.tscn
scripts/release.sh                                                 # 设好 WF_INDEX_URL、WF_INDEX_KEY、PLUGIN_PUBLISH
```

发布前改 `wf-plugin.toml` 和 `Cargo.toml` 的版本号；已发布的版本不能改内容。kit 改了之后，用到它的插件都要重新构建、跑测试、升版本再发布。
