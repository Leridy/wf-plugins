//! Ensures syncing 30,000 animation frames fits the WebAssembly component memory budget.
mod common;

use common::{Fake, fake_png, make_lock, make_node};
use plugin_api::platform::LocksOutput;
use wf_phaser_export::{Input, sync};

#[test]
fn thirty_thousand_frames_fit_the_component_budget() {
    let mut host = Fake::default();
    host.files.insert("package.json".into(), b"{}".to_vec());
    host.files.insert("assets/wf/hero/atlas.png".into(), fake_png(256, 32));

    let mut images = serde_json::Map::new();
    for i in 0..16 {
        images.insert(
            format!("f{i}"),
            serde_json::json!({
                "type": "atlas",
                "path": "atlas.png",
                "frame": { "x": i * 16, "y": 0, "w": 16, "h": 16 }
            }),
        );
    }
    let frames: Vec<_> = (0..30_000).map(|i| format!("f{}", i % 16)).collect();
    let durs: Vec<_> = (0..30_000).map(|_| 50.0).collect();
    let json = serde_json::json!({
        "images": images,
        "clips": [{
            "actionId": "run",
            "direction": "south",
            "loop": true,
            "anchor": { "x": 8, "y": 16 },
            "files": frames,
            "durationsMs": durs,
        }]
    });
    host.files.insert(
        "assets/wf/hero/animation.json".into(),
        serde_json::to_vec(&json).unwrap(),
    );

    let id = "11111111-1111-4111-8111-111111111111";
    host.locks = Some(LocksOutput {
        directory: "assets/wf".into(),
        lock: "assets/wf/wf.lock.json".into(),
        nodes: vec![make_lock(
            id,
            1,
            "Hero",
            "frames",
            vec!["hero/animation.json", "hero/atlas.png"],
        )],
    });
    host.nodes = vec![make_node(id, 1, "Hero", "frame_animation")];
    let plan = sync(&host, &Input::default()).unwrap();
    assert!(!plan.effects.is_empty());
}
