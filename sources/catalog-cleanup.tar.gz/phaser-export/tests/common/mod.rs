//! In-memory integration test host with typed mirror answers and fixture loader.
#![allow(dead_code, reason = "shared integration test host helpers")]
use globset::Glob;
use plugin_api::{
    Effect, Failure,
    platform::{Head, LockedRow, LocksOutput, NodeInput, NodeOutput, NodeRow, NodeState},
};
use plugin_guest::{Host, HostError, Platform};
use std::{collections::BTreeMap, fs, path::Path};

#[derive(Default)]
pub struct Fake {
    pub files: BTreeMap<String, Vec<u8>>,
    pub locks: Option<LocksOutput>,
    pub nodes: Vec<NodeOutput>,
}

impl Fake {
    pub fn apply(&mut self, effects: Vec<Effect>) {
        for effect in effects {
            match effect {
                Effect::WriteFile { path, bytes, .. } => {
                    self.files.insert(path, bytes);
                }
                Effect::DeleteFile { path } => {
                    self.files.remove(&path);
                }
                _ => unreachable!("only writes and deletes"),
            }
        }
    }

    pub fn case(name: &str) -> Self {
        let path = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/cases").join(name);
        Self {
            files: files(&path.join("project")),
            locks: Some(serde_json::from_slice(&fs::read(path.join("locks.json")).unwrap()).unwrap()),
            nodes: serde_json::from_slice(&fs::read(path.join("nodes.json")).unwrap()).unwrap(),
        }
    }
}

pub fn fake_png(w: u32, h: u32) -> Vec<u8> {
    let mut bytes = Vec::from(&b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR"[..]);
    bytes.extend_from_slice(&w.to_be_bytes());
    bytes.extend_from_slice(&h.to_be_bytes());
    bytes.extend_from_slice(&[8, 6, 0, 0, 0, 0, 0, 0, 0]);
    bytes
}

pub fn make_node(id: &str, number: u64, path: &str, node_type: &str) -> NodeOutput {
    NodeOutput {
        node: NodeRow {
            id: id.to_owned(),
            number,
            path: path.to_owned(),
            node_type: node_type.to_owned(),
            version: Some(1),
            state: NodeState::Current,
        },
        summary: String::new(),
        description: None,
        usage: String::new(),
        tags: Vec::new(),
        author: None,
        updated: "2026-11-16T00:00:00Z".into(),
        parts: Vec::new(),
        files: Vec::new(),
        unavailable: Vec::new(),
    }
}

pub fn make_lock(id: &str, number: u64, path: &str, form: &str, files: Vec<&str>) -> LockedRow {
    LockedRow {
        id: id.to_owned(),
        number,
        path: path.to_owned(),
        version: 1,
        form: form.to_owned(),
        files: files.into_iter().map(str::to_owned).collect(),
        head: Head::Current,
        head_version: Some(1),
    }
}

impl Host for Fake {
    fn list(&self, glob: &str) -> Vec<String> {
        let matcher = Glob::new(glob).unwrap().compile_matcher();
        self.files.keys().filter(|p| matcher.is_match(p)).cloned().collect()
    }

    fn read(&self, path: &str) -> Result<Vec<u8>, HostError> {
        self.files
            .get(path)
            .cloned()
            .ok_or_else(|| HostError::new(Failure::NotFound, path))
    }

    fn warn(&self, _: &str) {}
}

impl Platform for Fake {
    fn call(&self, method: &str, input: &[u8]) -> Result<Vec<u8>, HostError> {
        match method {
            "wf.mirror.locks" => self
                .locks
                .as_ref()
                .map(|locks| serde_json::to_vec(locks).unwrap())
                .ok_or_else(|| HostError::new(Failure::NotFound, "no export lock")),
            "wf.mirror.node" => {
                let query: NodeInput = serde_json::from_slice(input).unwrap();
                let node = self
                    .nodes
                    .iter()
                    .find(|n| {
                        query.address == format!("wf://{}", n.node.id)
                            || query.address == format!("#{}", n.node.number)
                            || query.address == n.node.path
                    })
                    .ok_or_else(|| HostError::new(Failure::NotFound, "node"))?;
                Ok(serde_json::to_vec(node).unwrap())
            }
            _ => unreachable!("only mirror reads"),
        }
    }
}

pub fn files(root: &Path) -> BTreeMap<String, Vec<u8>> {
    fn walk(root: &Path, dir: &Path, output: &mut BTreeMap<String, Vec<u8>>) {
        for item in fs::read_dir(dir).unwrap() {
            let path = item.unwrap().path();
            if path.is_dir() {
                walk(root, &path, output);
            } else {
                output.insert(
                    path.strip_prefix(root).unwrap().to_str().unwrap().replace('\\', "/"),
                    fs::read(path).unwrap(),
                );
            }
        }
    }
    let mut output = BTreeMap::new();
    walk(root, root, &mut output);
    output
}
