//! Corpus tests covering all 11 Web node types, partial-sync preservation,
//! edit protection, `--force` overwrite, and leftover cleanup.
mod common;

use common::{Fake, fake_png, make_lock, make_node};
use plugin_api::platform::LocksOutput;
use serde_json::{Value, json};
use wf_phaser_export::{Input, Status, sync};

fn verify_manifest(files: &std::collections::BTreeMap<String, Vec<u8>>) {
    let raw = files.get("assets/wf/wf-assets.json").expect("wf-assets.json missing");
    let v: Value = serde_json::from_slice(raw).expect("valid wf-assets.json");
    assert_eq!(v.get("schema").and_then(Value::as_str), Some("wf-web-assets/1"));
    assert!(!v["entries"].as_object().unwrap().is_empty());

    let ts = std::str::from_utf8(files.get("assets/wf/wf-assets.ts").expect("wf-assets.ts missing")).unwrap();
    assert!(ts.starts_with("// wf phaser-export manifest v1 sha256="));
    assert!(ts.contains("export const WF_ASSETS: WfAssetsMap"));

    for runtime in [
        "assets/wf/wf-runtime/wf-types.ts",
        "assets/wf/wf-runtime/wf-simulation.ts",
        "assets/wf/wf-runtime/wf-whole-map.ts",
        "assets/wf/wf-runtime/wf-parallax.ts",
        "assets/wf/wf-runtime/wf-phaser.ts",
    ] {
        let content = std::str::from_utf8(files.get(runtime).unwrap_or_else(|| panic!("{runtime} missing"))).unwrap();
        assert!(content.starts_with("// wf phaser-export runtime v1 sha256="));
    }
}

#[test]
fn all_fourteen_2d_fixtures_export_valid_manifest_and_rerun_unchanged() {
    for case in [
        "real-frames",
        "real-source",
        "animation-strips",
        "animation-atlas",
        "real-ui-pieces",
        "ui-pieces",
        "ui-atlas",
        "ui-naming",
        "tilemap",
        "real-particles",
        "particle-builtin",
        "prop",
        "whole-map",
        "scrolling-scene",
    ] {
        let mut host = Fake::case(case);
        let plan = sync(&host, &Input::default()).unwrap_or_else(|e| panic!("{case}: {e:?}"));
        assert!(!plan.effects.is_empty(), "{case}: expected writes");
        assert!(
            plan.output.warnings.is_empty(),
            "{case}: unexpected warnings {:?}",
            plan.output.warnings
        );
        host.apply(plan.effects);
        verify_manifest(&host.files);

        let rerun = sync(&host, &Input::default()).unwrap();
        assert!(rerun.effects.is_empty(), "{case}: rerun must be empty");
        assert!(rerun.output.nodes.iter().all(|n| n.status == Status::Unchanged));
    }
}

#[test]
fn word_art_bmfont_pieces_icon_and_table_nodes_sync_cleanly() {
    let mut host = Fake::default();
    host.files.insert("package.json".into(), b"{}".to_vec());
    host.files.insert("assets/wf/title/font.png".into(), fake_png(128, 128));
    host.files.insert(
        "assets/wf/title/font.fnt".into(),
        b"info face=\"GoldTitle\" size=48\ncommon lineHeight=52 base=40\npage id=0 file=\"font.png\"\nchar id=65 x=0 y=0 width=24 height=32 xoffset=0 yoffset=4 xadvance=25 page=0\n"
            .to_vec(),
    );
    host.files.insert("assets/wf/icons/sheet.png".into(), fake_png(64, 64));
    host.files.insert(
        "assets/wf/icons/icons.json".into(),
        serde_json::to_vec(&json!({
            "images": { "sword": { "type": "atlas", "path": "sheet.png", "frame": { "x": 0, "y": 0, "w": 32, "h": 32 } } },
            "elements": [{
                "name": "Sword",
                "kind": "states",
                "widget": { "type": "states" },
                "size": { "width": 32, "height": 32 },
                "states": [{ "name": "rest", "role": "rest", "file": "sword" }]
            }]
        }))
        .unwrap(),
    );
    host.files.insert(
        "assets/wf/items/items.csv".into(),
        b"id,name,cost\n1,\"Potion, Red\",50\n".to_vec(),
    );

    let id_wa = "aaaa0001-0000-4000-8000-000000000001";
    let id_ic = "aaaa0002-0000-4000-8000-000000000002";
    let id_tb = "aaaa0003-0000-4000-8000-000000000003";
    host.locks = Some(LocksOutput {
        directory: "assets/wf".into(),
        lock: "assets/wf/wf.lock.json".into(),
        nodes: vec![
            make_lock(id_wa, 1, "UI/Title", "bmfont", vec!["title/font.fnt", "title/font.png"]),
            make_lock(
                id_ic,
                2,
                "UI/Icons",
                "slices",
                vec!["icons/icons.json", "icons/sheet.png"],
            ),
            make_lock(id_tb, 3, "Data/Items", "csv", vec!["items/items.csv"]),
        ],
    });
    host.nodes = vec![
        make_node(id_wa, 1, "UI/Title", "word_art"),
        make_node(id_ic, 2, "UI/Icons", "icon"),
        make_node(id_tb, 3, "Data/Items", "table"),
    ];

    let plan = sync(&host, &Input::default()).unwrap();
    host.apply(plan.effects);
    verify_manifest(&host.files);

    let manifest: Value = serde_json::from_slice(&host.files["assets/wf/wf-assets.json"]).unwrap();
    assert_eq!(manifest["entries"]["UI/Title"]["mode"], "bmfont");
    assert_eq!(manifest["entries"]["UI/Title"]["font"]["chars"][0]["id"], 65);
    assert_eq!(manifest["entries"]["UI/Icons"]["icons"][0]["name"], "Sword");
    assert_eq!(manifest["entries"]["Data/Items"]["rows"][0]["name"], "Potion, Red");

    // Partial sync for #1 must preserve UI/Icons and Data/Items entries inside wf-assets.json.
    host.files.insert(
        "assets/wf/items/items.csv".into(),
        b"id,name,cost\n1,\"Potion, Blue\",75\n".to_vec(),
    );
    let partial = sync(
        &host,
        &Input {
            nodes: vec!["#1".into()],
            ..Input::default()
        },
    )
    .unwrap();
    host.apply(partial.effects);
    let after_partial: Value = serde_json::from_slice(&host.files["assets/wf/wf-assets.json"]).unwrap();
    assert!(after_partial["entries"]["UI/Title"].is_object());
    assert_eq!(after_partial["entries"]["Data/Items"]["rows"][0]["name"], "Potion, Red");
}

#[test]
fn local_edits_kept_until_force_and_leftovers_cleaned() {
    let mut host = Fake::case("tilemap");
    let first = sync(&host, &Input::default()).unwrap();
    host.apply(first.effects);

    host.files.insert(
        "assets/wf/wf-assets.ts".into(),
        b"// user customization\nexport const X = 1;\n".to_vec(),
    );
    host.files
        .insert("assets/wf/wf-runtime/wf-phaser.ts".into(), b"// user tweak\n".to_vec());

    let kept = sync(&host, &Input::default()).unwrap();
    assert!(kept.output.warnings.iter().any(|w| w.contains("wf-assets.ts")));
    assert!(kept.output.warnings.iter().any(|w| w.contains("wf-phaser.ts")));

    let forced = sync(
        &host,
        &Input {
            force: true,
            ..Input::default()
        },
    )
    .unwrap();
    host.apply(forced.effects);
    let ts = std::str::from_utf8(&host.files["assets/wf/wf-assets.ts"]).unwrap();
    assert!(ts.starts_with("// wf phaser-export manifest"));

    // Edit wf-assets.ts, leave wf-runtime untouched, remove locked nodes -> only unedited files deleted.
    host.files
        .insert("assets/wf/wf-assets.ts".into(), b"// keep me\n".to_vec());
    host.locks.as_mut().unwrap().nodes.clear();
    let cleanup = sync(&host, &Input::default()).unwrap();
    host.apply(cleanup.effects);
    assert!(host.files.contains_key("assets/wf/wf-assets.ts"));
    assert!(!host.files.contains_key("assets/wf/wf-assets.json"));
    assert!(!host.files.contains_key("assets/wf/wf-runtime/wf-phaser.ts"));
}

#[test]
fn missing_web_root_or_unsupported_node_behaves_cleanly() {
    let mut missing_root = Fake::case("tilemap");
    missing_root.files.remove("package.json");
    let err = sync(&missing_root, &Input::default())
        .err()
        .expect("missing package.json should fail");
    assert!(err.message.contains("Web project"), "{}", err.message);

    let mut unsupported = Fake::default();
    unsupported.files.insert("package.json".into(), b"{}".to_vec());
    let id = "bbbb0001-0000-4000-8000-000000000001";
    unsupported.locks = Some(LocksOutput {
        directory: "assets/wf".into(),
        lock: "assets/wf/wf.lock.json".into(),
        nodes: vec![make_lock(id, 1, "Hero3D", "glb", vec!["hero/main.glb"])],
    });
    unsupported.nodes = vec![make_node(id, 1, "Hero3D", "model_3d")];
    let plan = sync(&unsupported, &Input::default()).unwrap();
    assert_eq!(plan.output.nodes[0].status, Status::Skipped);
}
