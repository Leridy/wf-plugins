//! Safe file reconciliation via `wf-web.manifest.json` + `.ts` comment stamps.
use crate::types::Status;
use plugin_api::{Effect, Failure};
use plugin_guest::{Host, HostError};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;
use std::fmt::Write;
use std::str::from_utf8;

pub const MANIFEST_NAME: &str = "wf-web.manifest.json";
const MANIFEST_SCHEMA: &str = "wf-web-manifest/1";

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum StampKind {
    None,
    SlashLine,
}

#[derive(Clone, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
pub struct ManifestEntry {
    pub owner: String,
    pub version: u32,
    pub sha256: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct Manifest {
    pub schema: String,
    #[serde(default)]
    pub files: BTreeMap<String, ManifestEntry>,
}

impl Default for Manifest {
    fn default() -> Self {
        Self {
            schema: MANIFEST_SCHEMA.to_owned(),
            files: BTreeMap::new(),
        }
    }
}

impl Manifest {
    pub fn load(host: &dyn Host, manifest_path: &str) -> Self {
        let Ok(bytes) = host.read(manifest_path) else {
            return Self::default();
        };
        let Ok(parsed) = serde_json::from_slice::<Self>(&bytes) else {
            return Self::default();
        };
        if parsed.schema == MANIFEST_SCHEMA {
            parsed
        } else {
            Self::default()
        }
    }

    pub fn to_bytes(&self) -> Vec<u8> {
        let mut s = serde_json::to_string_pretty(self).expect("manifest json serializes");
        s.push('\n');
        s.into_bytes()
    }
}

pub fn sha256_hex(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    let mut hex = String::with_capacity(64);
    for byte in digest {
        write!(hex, "{byte:02x}").expect("hex write");
    }
    hex
}

pub fn prepare_bytes(prefix_tag: &str, owner: &str, version: u32, body: &str, stamp: StampKind) -> Vec<u8> {
    match stamp {
        StampKind::None => body.as_bytes().to_vec(),
        StampKind::SlashLine => {
            let trimmed = body.trim_start_matches('\u{feff}');
            let digest = sha256_hex(trimmed.as_bytes());
            format!("// wf {prefix_tag} {owner} v{version} sha256={digest}\n{trimmed}").into_bytes()
        }
    }
}

pub fn is_unedited(prefix_tag: &str, bytes: &[u8], recorded_sha: Option<&str>) -> bool {
    if let Ok(text) = from_utf8(bytes)
        && let Some(first) = text.lines().next()
        && let Some(rest) = first.strip_prefix(&format!("// wf {prefix_tag} "))
        && let Some((_, hash)) = rest.rsplit_once(" sha256=")
        && hash.len() == 64
        && hash.bytes().all(|b| b.is_ascii_hexdigit())
    {
        let body = text.find('\n').map_or("", |pos| &text[pos + 1..]);
        return sha256_hex(body.as_bytes()) == hash.to_ascii_lowercase();
    }
    recorded_sha.is_some_and(|expected| sha256_hex(bytes) == expected.to_ascii_lowercase())
}

pub fn plan_write(
    host: &dyn Host,
    prefix_tag: &str,
    path: &str,
    bytes: Vec<u8>,
    force: bool,
    recorded_sha: Option<&str>,
    effects: &mut Vec<Effect>,
) -> Result<(Status, String), HostError> {
    let next_sha = sha256_hex(&bytes);
    match host.read(path) {
        Ok(existing) => {
            if existing == bytes {
                return Ok((Status::Unchanged, next_sha));
            }
            if force || is_unedited(prefix_tag, &existing, recorded_sha) {
                effects.push(Effect::WriteFile {
                    path: path.to_owned(),
                    bytes,
                    overwrite: true,
                });
                Ok((Status::Updated, next_sha))
            } else {
                Ok((
                    Status::Kept,
                    recorded_sha.map_or_else(|| sha256_hex(&existing), str::to_owned),
                ))
            }
        }
        Err(error) if error.kind == Failure::NotFound => {
            effects.push(Effect::WriteFile {
                path: path.to_owned(),
                bytes,
                overwrite: false,
            });
            Ok((Status::Written, next_sha))
        }
        Err(error) => Err(error),
    }
}

pub fn plan_delete(
    host: &dyn Host,
    prefix_tag: &str,
    path: &str,
    force: bool,
    recorded_sha: Option<&str>,
    effects: &mut Vec<Effect>,
) -> Result<bool, HostError> {
    match host.read(path) {
        Ok(existing) => {
            if force || is_unedited(prefix_tag, &existing, recorded_sha) {
                effects.push(Effect::DeleteFile { path: path.to_owned() });
                Ok(true)
            } else {
                Ok(false)
            }
        }
        Err(error) if error.kind == Failure::NotFound => Ok(true),
        Err(error) => Err(error),
    }
}
