//! Engine-neutral asset models decoded from WeaveForge ready sidecars.
pub mod parallax;
pub mod particle;
pub mod png;
pub mod prop;
mod report;
pub mod tilemap;
pub mod ui;
pub mod web_extra;
pub mod whole_map;

use crate::paths::{self, invalid};
use plugin_guest::HostError;
use serde::Deserialize;
use std::collections::{BTreeMap, BTreeSet};

pub use parallax::ParallaxMap;
pub use particle::ParticleEffect;
pub use prop::PropSet;
pub use tilemap::TileMap;
pub use ui::Kit;
pub use whole_map::WholeMap;

#[derive(Clone, Copy, Debug, Deserialize, PartialEq)]
pub struct Point {
    pub x: f64,
    pub y: f64,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, serde::Serialize)]
pub struct Rect {
    pub x: f64,
    pub y: f64,
    pub w: f64,
    pub h: f64,
}

#[derive(Clone, Copy, Debug, Default, Deserialize)]
pub struct Margins {
    pub left: f64,
    pub right: f64,
    pub top: f64,
    pub bottom: f64,
}

impl Margins {
    pub fn values(self) -> [f64; 4] {
        [self.left, self.right, self.top, self.bottom]
    }
}

#[derive(Clone, Debug, serde::Serialize)]
pub struct Texture {
    pub path: String,
    pub region: Option<Rect>,
}

#[derive(Debug)]
pub struct Frame {
    pub texture: Texture,
    pub duration_ms: f64,
}

#[derive(Debug)]
pub struct Clip {
    pub name: String,
    pub frames: Vec<Frame>,
    pub looped: bool,
    pub anchor: Point,
}

#[derive(Debug)]
pub struct Animation {
    pub clips: Vec<Clip>,
}

impl Animation {
    pub fn read(bytes: &[u8]) -> Result<Self, HostError> {
        let report: report::Animation = parse(bytes)?;
        if report.clips.is_empty() {
            return Err(invalid("animation.json has no clips"));
        }
        let mut names = BTreeSet::new();
        let mut clips = Vec::new();
        for clip in report.clips {
            let name = if clip.direction == "source" {
                clip.action_id
            } else {
                format!("{}_{}", clip.action_id, clip.direction)
            };
            if name.is_empty() || !names.insert(name.clone()) {
                return Err(invalid("empty or duplicate animation name"));
            }
            if clip.files.is_empty()
                || clip.files.len() != clip.durations_ms.len()
                || !clip.anchor.x.is_finite()
                || !clip.anchor.y.is_finite()
            {
                return Err(invalid("invalid animation clip timing or anchor"));
            }
            let mut frames = Vec::with_capacity(clip.files.len());
            for (file, duration_ms) in clip.files.into_iter().zip(clip.durations_ms) {
                if !duration_ms.is_finite() || duration_ms <= 0.0 {
                    return Err(invalid("invalid animation frame duration"));
                }
                frames.push(Frame {
                    texture: texture(&report.images, &file)?,
                    duration_ms,
                });
            }
            clips.push(Clip {
                name,
                frames,
                looped: clip.looped,
                anchor: clip.anchor,
            });
        }
        Ok(Self { clips })
    }
}

pub(crate) fn parse<T: for<'de> Deserialize<'de>>(bytes: &[u8]) -> Result<T, HostError> {
    serde_json::from_slice(bytes).map_err(|e| {
        invalid(format!(
            "invalid export sidecar for phaser-export {}: {e}; if the CLI is newer than this plugin, \
             check `wf plugin list` and update or relink it",
            env!("CARGO_PKG_VERSION")
        ))
    })
}

pub(crate) fn texture(images: &BTreeMap<String, report::Image>, key: &str) -> Result<Texture, HostError> {
    let image = images
        .get(key)
        .ok_or_else(|| invalid(format!("image key {key:?} is absent from images")))?;
    let (path, region) = match image {
        report::Image::Png { path } => (path, None),
        report::Image::Strip { path, frame } | report::Image::Atlas { path, frame } => (path, Some(*frame)),
    };
    paths::relative(path)?;
    if let Some(r) = region
        && ([r.x, r.y, r.w, r.h].iter().any(|v| !v.is_finite()) || r.x < 0.0 || r.y < 0.0 || r.w <= 0.0 || r.h <= 0.0)
    {
        return Err(invalid("invalid image region"));
    }
    Ok(Texture {
        path: path.clone(),
        region,
    })
}

#[cfg(test)]
mod tests;
