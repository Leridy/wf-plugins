//! Resolve UI state roles and geometry without introducing any engine names.
use super::{
    Margins, Texture, parse,
    report::{self, Role, SliceMode},
    texture,
};
use crate::paths::invalid;
use plugin_guest::HostError;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum WidgetKind {
    Press,
    Flip,
    Bar,
    Slide,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Style {
    Rest,
    Hover,
    Pressed,
    Disabled,
    HoverPressed,
    Track,
    Fill,
    Thumb,
    ThumbHover,
    ThumbDisabled,
}

#[derive(Debug)]
pub struct State {
    pub style: Style,
    pub texture: Texture,
    pub slice: Margins,
}

#[derive(Debug)]
pub struct Widget {
    pub name: String,
    pub kind: WidgetKind,
    pub size: (f64, f64),
    pub states: Vec<State>,
}

#[derive(Debug)]
pub struct Kit {
    pub elements: Vec<String>,
    pub widgets: Vec<Widget>,
    pub extra_textures: Vec<Texture>,
    pub notes: Vec<String>,
}

impl Kit {
    pub fn read(bytes: &[u8]) -> Result<Self, HostError> {
        let report: report::Kit = parse(bytes)?;
        let elements = report.elements.iter().map(|e| e.name.clone()).collect();
        let mut widgets = Vec::new();
        let mut notes = Vec::new();
        for element in report.elements {
            let kind = match &element.widget {
                report::Widget::Press => WidgetKind::Press,
                report::Widget::Flip => WidgetKind::Flip,
                report::Widget::Bar { .. } => WidgetKind::Bar,
                report::Widget::Slide => WidgetKind::Slide,
                skipped => {
                    let name = match skipped {
                        report::Widget::Switch => "switch",
                        report::Widget::Ring => "ring",
                        report::Widget::Stick => "stick",
                        report::Widget::Parts => "parts",
                        _ => "states",
                    };
                    notes.push(format!(
                        "{}: {name} has no Phaser widget builder; use its state textures directly.",
                        element.name
                    ));
                    continue;
                }
            };
            if [element.size.width, element.size.height]
                .iter()
                .any(|v| !v.is_finite() || *v <= 0.0)
            {
                return Err(invalid("invalid UI element size"));
            }
            let mut states = Vec::new();
            for state in &element.states {
                let Some(style) = style(&element.widget, state) else {
                    continue;
                };
                if states.iter().any(|s: &State| s.style == style) {
                    return Err(invalid("duplicate UI state role"));
                }
                let texture = texture(&report.images, &state.file)?;
                let (width, height) = texture
                    .region
                    .map_or((element.size.width, element.size.height), |r| (r.w, r.h));
                let slice = match state.slice.as_ref() {
                    Some(s) if !matches!(s.mode, SliceMode::Fixed) => s.borders,
                    _ => Margins::default(),
                };
                let content = state.text_safe.map(|r| Margins {
                    left: r.x,
                    right: width - r.x - r.w,
                    top: r.y,
                    bottom: height - r.y - r.h,
                });
                if slice
                    .values()
                    .into_iter()
                    .chain(content.iter().flat_map(|m| m.values()))
                    .any(|v| !v.is_finite() || v < 0.0)
                    || slice.left + slice.right > width
                    || slice.top + slice.bottom > height
                {
                    return Err(invalid(format!("{}: invalid slice or text_safe margins", element.name)));
                }
                states.push(State { style, texture, slice });
            }
            if states.is_empty() {
                notes.push(format!(
                    "{}: no mapped state roles; use its textures directly.",
                    element.name
                ));
            } else {
                let _ = element.kind;
                widgets.push(Widget {
                    name: element.name,
                    kind,
                    size: (element.size.width, element.size.height),
                    states,
                });
            }
        }
        let mut extra_textures = Vec::new();
        for key in report.images.keys() {
            extra_textures.push(texture(&report.images, key)?);
        }
        Ok(Self {
            elements,
            widgets,
            extra_textures,
            notes,
        })
    }
}

fn style(widget: &report::Widget, state: &report::State) -> Option<Style> {
    let role = state.role?;
    match (widget, role) {
        (report::Widget::Press, Role::Rest) | (report::Widget::Flip, Role::Off) => Some(Style::Rest),
        (report::Widget::Press, Role::Hover) | (report::Widget::Flip, Role::OffHover) => Some(Style::Hover),
        (report::Widget::Press, Role::Pressed) | (report::Widget::Flip, Role::On) => Some(Style::Pressed),
        (report::Widget::Press, Role::Disabled) | (report::Widget::Flip, Role::OffDisabled) => Some(Style::Disabled),
        (report::Widget::Flip, Role::OnHover) => Some(Style::HoverPressed),
        (report::Widget::Bar { .. } | report::Widget::Slide, Role::Track) => Some(Style::Track),
        (report::Widget::Bar { fills }, Role::Fill)
            if fills
                .iter()
                .max_by(|a, b| a.amount.total_cmp(&b.amount))
                .is_some_and(|f| f.cell.name == state.name) =>
        {
            Some(Style::Fill)
        }
        (report::Widget::Slide, Role::Fill) => Some(Style::Fill),
        (report::Widget::Slide, Role::Thumb) => Some(Style::Thumb),
        (report::Widget::Slide, Role::ThumbHover) => Some(Style::ThumbHover),
        (report::Widget::Slide, Role::ThumbDisabled) => Some(Style::ThumbDisabled),
        _ => None,
    }
}
