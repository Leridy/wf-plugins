//! Readers for `word_art` (`font.fnt` or `texts.json`), `icon` (`icons.json`), and `table` (`.json` / `.csv`).
use super::{Texture, parse, report, texture};
use crate::paths::{self, invalid};
use plugin_guest::HostError;
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value, json};
use std::collections::BTreeMap;
use std::mem::take;
use std::path::Path;
use std::str::from_utf8;

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct FntChar {
    pub id: u32,
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    pub xoffset: i32,
    pub yoffset: i32,
    pub xadvance: i32,
    pub page: u32,
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BmFontDoc {
    pub face: String,
    pub size: i32,
    pub line_height: i32,
    pub base: i32,
    pub pages: Vec<String>,
    pub chars: Vec<FntChar>,
}

#[derive(Clone, Debug)]
pub enum WordArtDoc {
    BmFont { fnt_file: String, font: BmFontDoc },
    Texts { texts: Vec<WordArtEntry> },
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WordArtEntry {
    pub name: String,
    pub texture: Texture,
    pub width: f64,
    pub height: f64,
}

#[derive(Deserialize)]
struct RawTextsReport {
    #[serde(default)]
    images: BTreeMap<String, report::Image>,
    #[serde(default)]
    texts: Vec<report::Element>,
    #[serde(default)]
    elements: Vec<report::Element>,
}

pub fn parse_word_art_fnt(fnt_file: &str, bytes: &[u8]) -> Result<WordArtDoc, HostError> {
    let text = from_utf8(bytes).map_err(|_| invalid("font.fnt is not UTF-8"))?;
    let mut face = String::new();
    let mut size = 32;
    let mut line_height = 32;
    let mut base = 26;
    let mut pages = Vec::new();
    let mut chars = Vec::new();

    for line in text.lines().map(str::trim).filter(|l| !l.is_empty()) {
        if let Some(rest) = line.strip_prefix("info ") {
            for (k, v) in parse_kv(rest) {
                match k {
                    "face" => face = v,
                    "size" => size = v.parse().unwrap_or(size),
                    _ => {}
                }
            }
        } else if let Some(rest) = line.strip_prefix("common ") {
            for (k, v) in parse_kv(rest) {
                match k {
                    "lineHeight" => line_height = v.parse().unwrap_or(line_height),
                    "base" => base = v.parse().unwrap_or(base),
                    _ => {}
                }
            }
        } else if let Some(rest) = line.strip_prefix("page ") {
            for (k, v) in parse_kv(rest) {
                if k == "file" {
                    paths::relative(&v)?;
                    pages.push(v);
                }
            }
        } else if let Some(rest) = line.strip_prefix("char ") {
            let mut ch = FntChar {
                id: 0,
                x: 0,
                y: 0,
                width: 0,
                height: 0,
                xoffset: 0,
                yoffset: 0,
                xadvance: 0,
                page: 0,
            };
            for (k, v) in parse_kv(rest) {
                match k {
                    "id" => ch.id = v.parse().unwrap_or(0),
                    "x" => ch.x = v.parse().unwrap_or(0),
                    "y" => ch.y = v.parse().unwrap_or(0),
                    "width" => ch.width = v.parse().unwrap_or(0),
                    "height" => ch.height = v.parse().unwrap_or(0),
                    "xoffset" => ch.xoffset = v.parse().unwrap_or(0),
                    "yoffset" => ch.yoffset = v.parse().unwrap_or(0),
                    "xadvance" => ch.xadvance = v.parse().unwrap_or(0),
                    "page" => ch.page = v.parse().unwrap_or(0),
                    _ => {}
                }
            }
            chars.push(ch);
        }
    }
    if pages.is_empty() {
        return Err(invalid("font.fnt has no page entries"));
    }
    Ok(WordArtDoc::BmFont {
        fnt_file: fnt_file.to_owned(),
        font: BmFontDoc {
            face,
            size,
            line_height,
            base,
            pages,
            chars,
        },
    })
}

pub fn parse_word_art_texts(bytes: &[u8]) -> Result<WordArtDoc, HostError> {
    let raw: RawTextsReport = parse(bytes)?;
    let list = if raw.texts.is_empty() { raw.elements } else { raw.texts };
    let mut texts = Vec::new();
    for el in list {
        if let Some(st) = el.states.first() {
            let tex = texture(&raw.images, &st.file)?;
            texts.push(WordArtEntry {
                name: el.name,
                texture: tex,
                width: el.size.width,
                height: el.size.height,
            });
        }
    }
    Ok(WordArtDoc::Texts { texts })
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct IconEntry {
    pub name: String,
    pub kind: String,
    pub width: f64,
    pub height: f64,
    pub states: BTreeMap<String, Texture>,
}

pub fn parse_icons(bytes: &[u8]) -> Result<(Vec<IconEntry>, Vec<Texture>), HostError> {
    let report: report::Kit = parse(bytes)?;
    let mut extras = Vec::new();
    for key in report.images.keys() {
        extras.push(texture(&report.images, key)?);
    }
    let mut entries = Vec::with_capacity(report.elements.len());
    for el in report.elements {
        let mut states = BTreeMap::new();
        for st in el.states {
            let role_key = st
                .role
                .map_or_else(|| st.name.clone(), |r| format!("{r:?}").to_ascii_lowercase());
            states.insert(role_key, texture(&report.images, &st.file)?);
        }
        entries.push(IconEntry {
            name: el.name,
            kind: el.kind,
            width: el.size.width,
            height: el.size.height,
            states,
        });
    }
    Ok((entries, extras))
}

#[derive(Clone, Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TableDoc {
    pub files: Vec<String>,
    pub row_count: usize,
    pub rows: Vec<Value>,
}

pub fn parse_table(file_name: &str, bytes: &[u8]) -> Result<TableDoc, HostError> {
    if Path::new(file_name)
        .extension()
        .is_some_and(|ext| ext.eq_ignore_ascii_case("json"))
    {
        let v: Value = parse(bytes)?;
        let rows = if let Some(arr) = v.as_array() {
            arr.clone()
        } else if let Some(arr) = v.get("rows").and_then(Value::as_array) {
            arr.clone()
        } else {
            vec![v]
        };
        return Ok(TableDoc {
            files: vec![file_name.to_owned()],
            row_count: rows.len(),
            rows,
        });
    }
    let text = from_utf8(bytes).map_err(|_| invalid("CSV table is not UTF-8"))?;
    let mut lines = text.lines().filter(|l| !l.trim().is_empty());
    let Some(header_line) = lines.next() else {
        return Ok(TableDoc {
            files: vec![file_name.to_owned()],
            row_count: 0,
            rows: Vec::new(),
        });
    };
    let headers = split_csv_line(header_line);
    let mut rows = Vec::new();
    for line in lines {
        let cols = split_csv_line(line);
        let mut obj = Map::new();
        for (i, h) in headers.iter().enumerate() {
            obj.insert(h.clone(), json!(cols.get(i).cloned().unwrap_or_default()));
        }
        rows.push(Value::Object(obj));
    }
    Ok(TableDoc {
        files: vec![file_name.to_owned()],
        row_count: rows.len(),
        rows,
    })
}

fn parse_kv(input: &str) -> Vec<(&str, String)> {
    let mut out = Vec::new();
    let bytes = input.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        while i < bytes.len() && bytes[i].is_ascii_whitespace() {
            i += 1;
        }
        let k_start = i;
        while i < bytes.len() && bytes[i] != b'=' && !bytes[i].is_ascii_whitespace() {
            i += 1;
        }
        if i >= bytes.len() || bytes[i] != b'=' {
            while i < bytes.len() && !bytes[i].is_ascii_whitespace() {
                i += 1;
            }
            continue;
        }
        let key = &input[k_start..i];
        i += 1;
        let val = if bytes.get(i) == Some(&b'"') {
            i += 1;
            let v_start = i;
            while i < bytes.len() && bytes[i] != b'"' {
                i += 1;
            }
            let s = input[v_start..i].to_owned();
            if i < bytes.len() {
                i += 1;
            }
            s
        } else {
            let v_start = i;
            while i < bytes.len() && !bytes[i].is_ascii_whitespace() {
                i += 1;
            }
            input[v_start..i].to_owned()
        };
        out.push((key, val));
    }
    out
}

fn split_csv_line(line: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut in_quotes = false;
    let chars: Vec<char> = line.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if in_quotes {
            if c == '"' && chars.get(i + 1) == Some(&'"') {
                cur.push('"');
                i += 2;
                continue;
            }
            if c == '"' {
                in_quotes = false;
            } else {
                cur.push(c);
            }
        } else if c == '"' {
            in_quotes = true;
        } else if c == ',' {
            out.push(take(&mut cur));
        } else {
            cur.push(c);
        }
        i += 1;
    }
    out.push(cur);
    out
}
