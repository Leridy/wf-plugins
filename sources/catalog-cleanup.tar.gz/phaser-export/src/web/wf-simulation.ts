// Exact 1:1 TypeScript simulation of WeaveForge packages/editors/src/particle/simulation.ts.
import type { WfParticleEmitter, WfParticleEntry, WfParticleEvent, WfParticleOrientation } from "./wf-types";

export const PARTICLE_STEP = 1 / 60;
const REST = 0.2;

export type Vec3 = [number, number, number];

export interface SimParticle {
  emitter: WfParticleEmitter;
  position: Vec3;
  velocity: Vec3;
  age: number;
  lifetime: number;
  rotation: number;
  flip: boolean;
  scale: number;
  landed: boolean;
}

interface EmitterStream {
  emitter: WfParticleEmitter;
  random: () => number;
  credit: number;
}

interface EventRecord {
  emitter: WfParticleEmitter;
  on: WfParticleEvent;
  position: Vec3;
  velocity: Vec3;
}

export function particleOrientation(emitter: WfParticleEmitter): WfParticleOrientation {
  return emitter.orientation ?? (emitter.sprite ? "upright" : "random");
}

function createRng(seed: number, id: string, randomState?: number): () => number {
  let state = randomState !== undefined ? randomState >>> 0 : seed >>> 0;
  if (randomState === undefined) {
    for (const char of id) {
      state = Math.imul(state ^ char.charCodeAt(0), 16777619);
    }
  }
  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let value = Math.imul(state ^ (state >>> 15), 1 | state);
    value ^= value + Math.imul(value ^ (value >>> 7), 61 | value);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

export function along(keys: readonly number[], progress: number): number {
  const span = keys.length - 1;
  if (span <= 0) return keys[0] ?? 0;
  const at = Math.min(1, Math.max(0, progress)) * span;
  const index = Math.min(Math.floor(at), span - 1);
  return keys[index] + (keys[index + 1] - keys[index]) * (at - index);
}

export function srgbToLinear(c: number): number {
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

export function linearToSrgb(c: number): number {
  const clamped = Math.min(1, Math.max(0, c));
  return clamped <= 0.0031308 ? clamped * 12.92 : 1.055 * Math.pow(clamped, 1 / 2.4) - 0.055;
}

export function parseHexLinear(hex: string): [number, number, number] {
  const clean = hex.startsWith("#") ? hex.slice(1) : hex;
  if (clean.length !== 6) return [1, 1, 1];
  const r = parseInt(clean.slice(0, 2), 16) / 255;
  const g = parseInt(clean.slice(2, 4), 16) / 255;
  const b = parseInt(clean.slice(4, 6), 16) / 255;
  return [srgbToLinear(r), srgbToLinear(g), srgbToLinear(b)];
}

export function sampleLinearColorRgb01(
  linearKeys: readonly [number, number, number][],
  progress: number,
): [number, number, number] {
  if (linearKeys.length === 0) return [1, 1, 1];
  const rs = linearKeys.map((k) => k[0]);
  const gs = linearKeys.map((k) => k[1]);
  const bs = linearKeys.map((k) => k[2]);
  return [linearToSrgb(along(rs, progress)), linearToSrgb(along(gs, progress)), linearToSrgb(along(bs, progress))];
}

export function sampleLinearColorInt24(
  linearKeys: readonly [number, number, number][],
  progress: number,
): number {
  const [r, g, b] = sampleLinearColorRgb01(linearKeys, progress);
  return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
}

export class WfParticleSimulation {
  particles: SimParticle[] = [];
  private tick = 0;
  private remainder = 0;
  private streams: EmitterStream[];
  readonly document: Pick<WfParticleEntry, "seed" | "duration" | "looping" | "space" | "emitters">;

  constructor(doc: Pick<WfParticleEntry, "seed" | "duration" | "looping" | "space" | "emitters">) {
    this.document = doc;
    this.streams = doc.emitters.map((emitter) => ({
      emitter,
      random: createRng(doc.seed, emitter.id, emitter.randomState),
      credit: 0,
    }));
  }

  get time(): number {
    return this.tick * PARTICLE_STEP;
  }

  reset(): void {
    this.particles = [];
    this.tick = 0;
    this.remainder = 0;
    this.streams = this.document.emitters.map((emitter) => ({
      emitter,
      random: createRng(this.document.seed, emitter.id, emitter.randomState),
      credit: 0,
    }));
  }

  advance(seconds: number): void {
    if (!Number.isFinite(seconds) || seconds <= 0) return;
    this.remainder += seconds;
    while (this.remainder + 1e-10 >= PARTICLE_STEP) {
      this.step();
      this.remainder = Math.max(0, this.remainder - PARTICLE_STEP);
    }
  }

  private step(): void {
    const dt = PARTICLE_STEP;
    const planar = this.document.space === "planar";
    const events: EventRecord[] = [];
    this.particles = this.particles.filter((particle) => {
      const e = particle.emitter;
      const pushEvent = (on: WfParticleEvent) => {
        if ((e.triggers ?? []).some((trigger) => trigger.on === on)) {
          events.push({
            emitter: e,
            on,
            position: [...particle.position],
            velocity: [...particle.velocity],
          });
        }
      };
      particle.age += dt;
      if (particle.age >= particle.lifetime) {
        pushEvent("death");
        return false;
      }
      const above = particle.position[1] >= 0;
      const damping = Math.exp(-e.drag * dt);
      for (let axis = 0; axis < 3; axis++) {
        particle.velocity[axis] = (particle.velocity[axis] + e.gravity[axis] * dt) * damping;
        particle.position[axis] += particle.velocity[axis] * dt;
      }
      if (planar) particle.position[2] = 0;
      const ground = e.ground;
      if (ground && above && particle.position[1] < 0) {
        particle.position[1] = 0;
        if (!particle.landed) {
          particle.landed = true;
          pushEvent("land");
        }
        if (ground.kill) {
          pushEvent("death");
          return false;
        }
        const up = -particle.velocity[1] * ground.bounce;
        particle.velocity[1] = up < REST ? 0 : up;
        particle.velocity[0] *= 1 - ground.friction;
        particle.velocity[2] *= 1 - ground.friction;
      }
      return true;
    });

    const start = this.time;
    const end = ++this.tick * dt;
    const { duration, looping } = this.document;
    const alive = (e: WfParticleEmitter) => this.particles.reduce((n, p) => n + (p.emitter === e ? 1 : 0), 0);

    for (const stream of this.streams) {
      const e = stream.emitter;
      if (!e.enabled) continue;
      let count = 0;
      const first = Math.floor(start / duration);
      const last = Math.floor((end - 1e-10) / duration);
      for (let cycle = first; cycle <= last && (looping || cycle === 0); cycle++) {
        const birth = cycle * duration + e.delay;
        if (birth >= start - 1e-10 && birth < end - 1e-10) count += e.burst;
        stream.credit += Math.max(0, Math.min(end, (cycle + 1) * duration) - Math.max(start, birth)) * e.rate;
      }
      const continuous = Math.floor(stream.credit + 1e-10);
      stream.credit -= continuous;
      count += continuous;
      count = Math.min(count, e.maxParticles - alive(e));
      for (let i = 0; i < count; i++) {
        this.particles.push(born(e, stream.random, planar, [0, 0, 0], [0, 0, 0]));
      }
    }

    for (const event of events) {
      for (const trigger of event.emitter.triggers ?? []) {
        if (trigger.on !== event.on) continue;
        const stream = this.streams.find((s) => s.emitter.id === trigger.emitter);
        if (!stream?.emitter.enabled) continue;
        const e = stream.emitter;
        const count = Math.min(trigger.count, e.maxParticles - alive(e));
        const carried: Vec3 = [
          event.velocity[0] * trigger.inherit,
          event.velocity[1] * trigger.inherit,
          event.velocity[2] * trigger.inherit,
        ];
        for (let i = 0; i < count; i++) {
          this.particles.push(born(e, stream.random, planar, event.position, carried));
        }
      }
    }
  }
}

function born(
  e: WfParticleEmitter,
  rand: () => number,
  planar: boolean,
  at: Vec3,
  carried: Vec3,
): SimParticle {
  const position: Vec3 = [0, 0, 0];
  const velocity: Vec3 = [0, 0, 0];
  for (let axis = 0; axis < 3; axis++) {
    position[axis] = at[axis] + e.position[axis] + (rand() * 2 - 1) * e.spread[axis];
    velocity[axis] = carried[axis] + e.velocity[axis] + (rand() * 2 - 1) * e.velocitySpread[axis];
  }
  if (planar) {
    position[2] = 0;
    velocity[2] = 0;
  }
  const lifetime = e.lifetime[0] + rand() * (e.lifetime[1] - e.lifetime[0]);
  const tilt = ((e.tilt ?? 0) * Math.PI) / 180;
  let rotation = 0;
  if (particleOrientation(e) === "random") rotation = rand() * Math.PI * 2;
  else if (tilt > 0) rotation = (rand() * 2 - 1) * tilt;
  const flip = e.flip === true && rand() < 0.5;
  const jitter = e.sizeJitter ?? 0;
  const scale = jitter > 0 ? 1 + (rand() * 2 - 1) * jitter : 1;
  const radial = e.radial;
  if (radial) {
    const cone = (radial.cone * Math.PI) / 180;
    let direction: Vec3;
    if (planar) {
      const angle = (rand() * 2 - 1) * cone;
      direction = [Math.sin(angle), Math.cos(angle), 0];
    } else {
      const height = 1 - rand() * (1 - Math.cos(cone));
      const azimuth = rand() * Math.PI * 2;
      const across = Math.sqrt(Math.max(0, 1 - height * height));
      direction = [across * Math.cos(azimuth), height, across * Math.sin(azimuth)];
    }
    const radius = radial.radius[0] + rand() * (radial.radius[1] - radial.radius[0]);
    const speed = radial.speed[0] + rand() * (radial.speed[1] - radial.speed[0]);
    for (let axis = 0; axis < 3; axis++) {
      position[axis] += direction[axis] * radius;
      velocity[axis] += direction[axis] * speed;
    }
  }
  return {
    emitter: e,
    position,
    velocity,
    age: 0,
    lifetime,
    rotation,
    flip,
    scale,
    landed: false,
  };
}

export interface EvaluatedParticle {
  emitterIndex: number;
  x: number;
  y: number;
  z: number;
  size: number;
  stretchY: number;
  rotation: number;
  colorInt24: number;
  alpha: number;
  flipX: boolean;
}

export function createParticleColorCache(
  emitters: readonly WfParticleEmitter[],
): Map<WfParticleEmitter, [number, number, number][]> {
  const cache = new Map<WfParticleEmitter, [number, number, number][]>();
  for (const em of emitters) {
    cache.set(
      em,
      em.color.map((hex) => parseHexLinear(hex)),
    );
  }
  return cache;
}

/** Evaluate simulation particles into screen-space (`yUp = false`) or 3D-space (`yUp = true`) draw transforms. */
export function evaluateParticles(
  sim: WfParticleSimulation,
  colorCache: ReadonlyMap<WfParticleEmitter, [number, number, number][]>,
  yUp: boolean,
): EvaluatedParticle[] {
  const emitterIndexMap = new Map<WfParticleEmitter, number>();
  sim.document.emitters.forEach((em, idx) => emitterIndexMap.set(em, idx));
  const out: EvaluatedParticle[] = [];
  for (const p of sim.particles) {
    const progress = Math.min(1, p.age / p.lifetime);
    const e = p.emitter;
    const size = along(e.size, progress) * p.scale;
    const stretch = e.stretch ?? 0;
    const orient = particleOrientation(e);
    const vyDraw = yUp ? p.velocity[1] : -p.velocity[1];
    const speed2d = Math.hypot(p.velocity[0], vyDraw);
    const hasMotion = (stretch > 0 || orient === "velocity") && speed2d >= 1e-9;
    const behind = stretch > 0 && hasMotion ? stretch / 2 : 0;
    const motionAngle = hasMotion ? Math.atan2(vyDraw, p.velocity[0]) + (yUp ? Math.PI / 2 : -Math.PI / 2) : 0;
    const spin = stretch > 0 && orient === "random" ? 0 : p.rotation;
    const len = stretch > 0 && hasMotion ? size + speed2d * stretch : size;
    const colors = colorCache.get(e) ?? [];
    out.push({
      emitterIndex: emitterIndexMap.get(e) ?? 0,
      x: p.position[0] - p.velocity[0] * behind,
      y: yUp ? p.position[1] - p.velocity[1] * behind : -(p.position[1] - p.velocity[1] * behind),
      z: p.position[2] - p.velocity[2] * behind,
      size,
      stretchY: size > 1e-6 ? len / size : 1,
      rotation: spin + motionAngle,
      colorInt24: sampleLinearColorInt24(colors, progress),
      alpha: along(e.opacity, progress),
      flipX: p.flip,
    });
  }
  return out;
}
