// Shared scrolling_scene parallax motion solver (drift, bob, sway, repeatSpan).
import type { WfParallaxItem } from "./wf-types";

export interface ParallaxTransform {
  x: number;
  y: number;
  rotationRad: number;
}

export function computeParallaxTransform(
  item: Pick<WfParallaxItem, "x" | "y" | "repeatSpan" | "motion">,
  layerSpeed: number,
  elapsedSec: number,
  cameraX: number,
): ParallaxTransform {
  let x = item.x - cameraX * (1 - layerSpeed) + item.motion.drift * elapsedSec;
  if (item.repeatSpan && item.repeatSpan > 0) {
    const span = item.repeatSpan;
    const rel = ((x - item.x) % span + span) % span;
    x = item.x + rel;
  }
  const bob =
    item.motion.bob.amplitude !== 0 && item.motion.bob.period > 0
      ? Math.sin((elapsedSec / item.motion.bob.period) * Math.PI * 2) * item.motion.bob.amplitude
      : 0;
  const swayRad =
    item.motion.sway.degrees !== 0 && item.motion.sway.period > 0
      ? ((Math.sin((elapsedSec / item.motion.sway.period) * Math.PI * 2) * item.motion.sway.degrees) * Math.PI) / 180
      : 0;
  return { x, y: item.y + bob, rotationRad: swayRad };
}
