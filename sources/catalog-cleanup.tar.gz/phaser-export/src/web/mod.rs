//! Serialize decoded WeaveForge assets into `wf-assets.json`, typed `wf-assets.ts`, and `wf-runtime/*.ts`.
mod world_and_extra;

use crate::model::particle::{Blend, ParticleEffect, Space};
use crate::model::prop::PropSet;
use crate::model::tilemap::{Area, Orientation, TileMap};
use crate::model::ui::{Kit, Style, WidgetKind};
use crate::model::{Animation, Texture};
use crate::paths;
use crate::reconcile::{self, StampKind};
use serde_json::{Map, Value, json};
use std::collections::BTreeMap;
use std::fmt::Write as _;

pub use world_and_extra::{icon_entry, parallax_entry, table_entry, whole_map_entry, word_art_entry};

pub const ASSETS_JSON_NAME: &str = "wf-assets.json";
pub const ASSETS_TS_NAME: &str = "wf-assets.ts";
pub const RUNTIME_DIR: &str = "wf-runtime";
const ASSETS_SCHEMA: &str = "wf-web-assets/1";
pub const PLUGIN_TAG: &str = "phaser-export";

pub const RUNTIME_FILES: &[(&str, &str)] = &[
    ("wf-types.ts", include_str!("wf-types.ts")),
    ("wf-simulation.ts", include_str!("wf-simulation.ts")),
    ("wf-whole-map.ts", include_str!("wf-whole-map.ts")),
    ("wf-parallax.ts", include_str!("wf-parallax.ts")),
    ("wf-phaser.ts", include_str!("wf-phaser.ts")),
];

#[derive(Clone, Copy)]
pub struct NodeMeta<'a> {
    pub id: &'a str,
    pub path: &'a str,
    pub base_dir: &'a str,
}

pub(crate) fn tex_json(tex: &Texture) -> Value {
    json!({
        "path": tex.path,
        "region": tex.region.map(|r| json!({ "x": r.x, "y": r.y, "w": r.w, "h": r.h })),
    })
}

fn area_json(a: Area) -> Value {
    json!({ "x": a.x, "y": a.y, "width": a.width, "height": a.height })
}

pub fn animation_entry(meta: NodeMeta<'_>, node_type: &str, anim: &Animation) -> Value {
    let clips: Vec<Value> = anim
        .clips
        .iter()
        .map(|clip| {
            let frames: Vec<Value> = clip
                .frames
                .iter()
                .map(|f| {
                    json!({
                        "texture": tex_json(&f.texture),
                        "durationMs": f.duration_ms,
                    })
                })
                .collect();
            json!({
                "name": clip.name,
                "looped": clip.looped,
                "anchor": { "x": clip.anchor.x, "y": clip.anchor.y },
                "frames": frames,
            })
        })
        .collect();
    json!({
        "kind": node_type,
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "clips": clips,
    })
}

fn widget_kind_str(kind: WidgetKind) -> &'static str {
    match kind {
        WidgetKind::Press => "press",
        WidgetKind::Flip => "flip",
        WidgetKind::Bar => "bar",
        WidgetKind::Slide => "slide",
    }
}

fn style_str(style: Style) -> &'static str {
    match style {
        Style::Rest => "rest",
        Style::Hover => "hover",
        Style::Pressed => "pressed",
        Style::Disabled => "disabled",
        Style::HoverPressed => "hoverPressed",
        Style::Track => "track",
        Style::Fill => "fill",
        Style::Thumb => "thumb",
        Style::ThumbHover => "thumbHover",
        Style::ThumbDisabled => "thumbDisabled",
    }
}

pub fn ui_entry(meta: NodeMeta<'_>, kit: &Kit) -> Value {
    let widgets: Vec<Value> = kit
        .widgets
        .iter()
        .map(|w| {
            let states: Vec<Value> = w
                .states
                .iter()
                .map(|st| {
                    json!({
                        "role": style_str(st.style),
                        "texture": tex_json(&st.texture),
                        "borders": st.slice.values(),
                    })
                })
                .collect();
            json!({
                "name": w.name,
                "widget": widget_kind_str(w.kind),
                "width": w.size.0,
                "height": w.size.1,
                "states": states,
            })
        })
        .collect();
    json!({
        "kind": "ui",
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "widgets": widgets,
        "elements": kit.elements,
    })
}

pub fn tilemap_entry(meta: NodeMeta<'_>, map: &TileMap) -> Value {
    let orientation = match map.orientation {
        Orientation::Orthogonal => "orthogonal",
        Orientation::Isometric => "isometric",
    };
    let textures: BTreeMap<&str, Value> = map
        .textures
        .iter()
        .map(|(k, v)| {
            (
                k.as_str(),
                json!({ "file": v.file, "width": v.width, "height": v.height }),
            )
        })
        .collect();
    let ground: Vec<Value> = map
        .ground
        .iter()
        .map(|t| {
            let file = map
                .textures
                .get(&t.texture)
                .map_or(t.texture.as_str(), |f| f.file.as_str());
            json!({
                "level": t.level,
                "cell": t.cell,
                "textureKey": t.texture,
                "texture": file,
                "source": area_json(t.source),
                "target": area_json(t.target),
                "opacity": t.opacity,
            })
        })
        .collect();
    let sprites: Vec<Value> = map
        .sprites
        .iter()
        .map(|s| {
            json!({
                "id": s.id,
                "texture": s.texture,
                "position": { "x": s.position.x, "y": s.position.y },
                "rect": area_json(s.rect),
                "source": s.source.map(area_json),
                "rotation": s.rotation,
                "flipX": s.flip_x,
                "opacity": s.opacity,
            })
        })
        .collect();
    let obstacles: Vec<Value> = map
        .obstacles
        .iter()
        .map(|o| json!({ "kind": o.kind, "points": o.points.iter().map(|p| json!({ "x": p.x, "y": p.y })).collect::<Vec<_>>() }))
        .collect();
    let walkable: Vec<Value> = map
        .walkable
        .iter()
        .map(|poly| Value::Array(poly.iter().map(|p| json!({ "x": p.x, "y": p.y })).collect()))
        .collect();
    json!({
        "kind": "tilemap",
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "orientation": orientation,
        "tileWidth": map.tile_width,
        "tileHeight": map.tile_height,
        "textures": textures,
        "ground": ground,
        "sprites": sprites,
        "obstacles": obstacles,
        "walkable": walkable,
        "spawn": map.spawn.map(|p| json!({ "x": p.x, "y": p.y })),
    })
}

pub fn prop_entry(meta: NodeMeta<'_>, props: &PropSet) -> Value {
    let objects: Vec<Value> = props
        .objects
        .iter()
        .map(|obj| {
            let states: Vec<Value> = obj
                .states
                .iter()
                .map(|st| {
                    let polys: Vec<Value> = st
                        .collision
                        .iter()
                        .map(|poly| Value::Array(poly.iter().map(|p| json!({ "x": p.x, "y": p.y })).collect()))
                        .collect();
                    json!({ "id": st.id, "texture": tex_json(&st.texture), "collision": polys })
                })
                .collect();
            let anims: Vec<Value> = obj
                .animations
                .iter()
                .map(|a| {
                    json!({
                        "id": a.id,
                        "looped": a.looped,
                        "durationsMs": a.durations_ms,
                        "textures": a.textures.iter().map(tex_json).collect::<Vec<_>>(),
                    })
                })
                .collect();
            json!({
                "name": obj.name,
                "canvasWidth": obj.canvas_width,
                "canvasHeight": obj.canvas_height,
                "anchor": { "x": obj.anchor.x, "y": obj.anchor.y },
                "pixelsPerTile": obj.pixels_per_tile,
                "states": states,
                "animations": anims,
            })
        })
        .collect();
    json!({
        "kind": "prop",
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "objects": objects,
    })
}

pub fn particle_entry(meta: NodeMeta<'_>, fx: &ParticleEffect) -> Value {
    let space = match fx.space {
        Space::Planar => "planar",
        Space::Spatial => "spatial",
    };
    let emitters: Vec<Value> = fx
        .emitters
        .iter()
        .map(|em| {
            let blend = match em.blend {
                Blend::Normal => "normal",
                Blend::Additive => "additive",
            };
            let triggers: Vec<Value> = em
                .triggers
                .iter()
                .map(|t| {
                    json!({
                        "on": t.on.as_str(),
                        "emitter": t.emitter,
                        "count": t.count,
                        "inherit": t.inherit,
                    })
                })
                .collect();
            json!({
                "id": em.id,
                "randomState": em.random_state,
                "enabled": true,
                "rate": em.rate,
                "burst": em.burst,
                "delay": em.delay,
                "lifetime": em.lifetime,
                "position": em.position,
                "spread": em.spread,
                "velocity": em.velocity,
                "velocitySpread": em.velocity_spread,
                "gravity": em.gravity,
                "drag": em.drag,
                "size": em.size,
                "opacity": em.opacity,
                "color": em.color,
                "blend": blend,
                "picture": em.picture,
                "sprite": em.sprite,
                "orientation": em.orientation.as_str(),
                "tilt": em.tilt,
                "flip": em.flip,
                "sizeJitter": em.size_jitter,
                "stretch": em.stretch,
                "radial": em.radial.as_ref().map(|r| json!({ "speed": r.speed, "radius": r.radius, "cone": r.cone })),
                "ground": em.ground.as_ref().map(|g| json!({ "bounce": g.bounce, "friction": g.friction, "kill": g.kill })),
                "triggers": triggers,
                "maxParticles": em.max_particles,
            })
        })
        .collect();
    json!({
        "kind": "particle_effect",
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "seed": 0,
        "duration": fx.duration,
        "looping": fx.looping,
        "space": space,
        "emitters": emitters,
    })
}

pub fn load_existing_entries(bytes: &[u8]) -> BTreeMap<String, Value> {
    let Ok(val) = serde_json::from_slice::<Value>(bytes) else {
        return BTreeMap::new();
    };
    if val.get("schema").and_then(Value::as_str) != Some(ASSETS_SCHEMA) {
        return BTreeMap::new();
    }
    let Some(obj) = val.get("entries").and_then(Value::as_object) else {
        return BTreeMap::new();
    };
    obj.iter().map(|(k, v)| (k.clone(), v.clone())).collect()
}

fn encode_json(val: &Value) -> String {
    let compact = serde_json::to_string(val).expect("json serializes");
    if compact.len() > 64 * 1024 {
        compact
    } else {
        serde_json::to_string_pretty(val).expect("json serializes")
    }
}

pub fn render_assets_json(entries: &BTreeMap<String, Value>) -> Vec<u8> {
    let mut map = Map::new();
    for (k, v) in entries {
        map.insert(k.clone(), v.clone());
    }
    let root = json!({
        "schema": ASSETS_SCHEMA,
        "entries": Value::Object(map),
    });
    let mut s = encode_json(&root);
    s.push('\n');
    reconcile::prepare_bytes(PLUGIN_TAG, "manifest", 1, &s, StampKind::None)
}

fn ts_type_for_kind(kind: &str) -> &'static str {
    match kind {
        "frame_animation" | "character_effect" => "WfFrameAnimationEntry",
        "ui" => "WfUiKitEntry",
        "tilemap" => "WfTilemapEntry",
        "prop" => "WfPropSetEntry",
        "particle_effect" => "WfParticleEntry",
        "whole_map" => "WfWholeMapEntry",
        "scrolling_scene" => "WfScrollingSceneEntry",
        "word_art" => "WfWordArtEntry",
        "icon" => "WfIconSetEntry",
        "table" => "WfTableEntry",
        _ => "WfAssetEntry",
    }
}

pub fn render_assets_ts(entries: &BTreeMap<String, Value>) -> Vec<u8> {
    let mut body = String::new();
    body.push_str("import type {\n");
    body.push_str("  WfAssetEntry,\n");
    body.push_str("  WfAssetManifest,\n");
    body.push_str("  WfFrameAnimationEntry,\n");
    body.push_str("  WfIconSetEntry,\n");
    body.push_str("  WfParticleEntry,\n");
    body.push_str("  WfPropSetEntry,\n");
    body.push_str("  WfScrollingSceneEntry,\n");
    body.push_str("  WfTableEntry,\n");
    body.push_str("  WfTilemapEntry,\n");
    body.push_str("  WfUiKitEntry,\n");
    body.push_str("  WfWholeMapEntry,\n");
    body.push_str("  WfWordArtEntry,\n");
    body.push_str("} from \"./wf-runtime/wf-types\";\n\n");

    body.push_str("export interface WfAssetsMap {\n");
    for (key, entry) in entries {
        let kind = entry.get("kind").and_then(Value::as_str).unwrap_or("");
        let ts_type = ts_type_for_kind(kind);
        let q = serde_json::to_string(key).expect("key string serializes");
        writeln!(body, "  {q}: {ts_type};").expect("string write");
    }
    body.push_str("}\n\n");

    let mut obj = Map::new();
    for (k, v) in entries {
        obj.insert(k.clone(), v.clone());
    }
    let json_text = encode_json(&Value::Object(obj));
    writeln!(body, "export const WF_ASSETS: WfAssetsMap = {json_text};\n").expect("string write");
    body.push_str("export const WF_MANIFEST: WfAssetManifest = {\n");
    body.push_str("  schema: \"wf-web-assets/1\",\n");
    body.push_str("  entries: { ...WF_ASSETS } as Record<string, WfAssetEntry>,\n");
    body.push_str("};\n\n");
    body.push_str("export type WfAssetKey = keyof WfAssetsMap;\n");
    body.push_str("export const WF_ASSET_KEYS = Object.keys(WF_ASSETS) as WfAssetKey[];\n\n");
    body.push_str("export function getWfAsset<K extends WfAssetKey>(key: K): WfAssetsMap[K] {\n");
    body.push_str("  return WF_ASSETS[key];\n");
    body.push_str("}\n");

    reconcile::prepare_bytes(PLUGIN_TAG, "manifest", 1, &body, StampKind::SlashLine)
}

pub fn runtime_file_path(export_dir: &str, name: &str) -> String {
    paths::join(&paths::join(export_dir, RUNTIME_DIR), name)
}
