//! Entry encoders for `whole_map`, `scrolling_scene`, `word_art`, `icon`, and `table`.
use super::{NodeMeta, tex_json};
use crate::model::parallax::{LayerPlacement, Level, ObjectArt, ParallaxMap};
use crate::model::web_extra::{IconEntry, TableDoc, WordArtDoc};
use crate::model::whole_map::{ConnectionKind, SortMode, WholeMap};
use serde_json::{Map, Value, json};
use std::collections::BTreeMap;

pub fn whole_map_entry(meta: NodeMeta<'_>, wm: &WholeMap) -> Value {
    let tiles = whole_map_tiles(wm);
    let parts = whole_map_parts(wm);
    let (walkable_rects, nav_masks) = whole_map_nav(wm);
    let connections = whole_map_connections(wm);
    let regions: Vec<Value> = wm
        .regions
        .iter()
        .map(|r| {
            let polygon: Vec<Value> = r.polygon.iter().map(|p| json!({ "x": p.x, "y": p.y })).collect();
            json!({ "id": r.id, "polygon": polygon })
        })
        .collect();
    json!({
        "kind": "whole_map",
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "perspective": wm.perspective,
        "tileWidth": wm.tile_width,
        "tileHeight": wm.tile_height,
        "tiles": tiles,
        "parts": parts,
        "walkableRects": walkable_rects,
        "navMasks": nav_masks,
        "connections": connections,
        "regions": regions,
        "character": { "radius": wm.character.radius, "speed": wm.character.speed },
    })
}

fn whole_map_tiles(wm: &WholeMap) -> Vec<Value> {
    wm.tiles
        .iter()
        .map(|t| {
            json!({
                "key": t.key,
                "gridX": t.grid_x,
                "gridY": t.grid_y,
                "x": t.x,
                "y": t.y,
                "width": t.width,
                "height": t.height,
                "baseFile": t.base_file,
                "maskFile": t.mask_file,
            })
        })
        .collect()
}

fn whole_map_parts(wm: &WholeMap) -> Vec<Value> {
    wm.parts
        .iter()
        .map(|p| {
            let sort_mode = match p.sort_mode {
                SortMode::Below => "below",
                SortMode::Sorted => "sorted",
                SortMode::Above => "above",
            };
            let footprints: Vec<Value> = p
                .footprints
                .iter()
                .map(|poly| Value::Array(poly.iter().map(|pt| json!({ "x": pt.x, "y": pt.y })).collect()))
                .collect();
            json!({
                "id": p.id,
                "name": p.name,
                "textureFile": p.texture_file,
                "x": p.x,
                "y": p.y,
                "foot": { "x": p.foot.x, "y": p.foot.y },
                "footprints": footprints,
                "blocking": p.blocking,
                "sortMode": sort_mode,
                "drawOrder": p.draw_order,
                "layerZ": p.layer_z,
            })
        })
        .collect()
}

fn whole_map_nav(wm: &WholeMap) -> (Vec<Value>, Vec<Value>) {
    let mut walkable_rects = Vec::new();
    let mut nav_masks = Vec::new();
    for layer in &wm.nav_layers {
        for r in &layer.walkable_rects {
            walkable_rects.push(json!({ "x": r.x, "y": r.y, "width": r.width, "height": r.height }));
        }
        if let Some(m) = &layer.mask {
            nav_masks.push(json!({
                "offsetX": 0,
                "offsetY": 0,
                "mask": { "x": m.x, "y": m.y, "columns": m.columns, "rows": m.rows, "data": m.data },
            }));
        }
    }
    for part in &wm.parts {
        for r in &part.walkable_rects {
            walkable_rects.push(json!({ "x": r.x, "y": r.y, "width": r.width, "height": r.height }));
        }
        if let Some((ox, oy, m)) = &part.surface_mask {
            nav_masks.push(json!({
                "offsetX": ox,
                "offsetY": oy,
                "mask": { "x": m.x, "y": m.y, "columns": m.columns, "rows": m.rows, "data": m.data },
            }));
        }
    }
    (walkable_rects, nav_masks)
}

fn whole_map_connections(wm: &WholeMap) -> Vec<Value> {
    wm.connections
        .iter()
        .map(|c| {
            let kind = match c.kind {
                ConnectionKind::Stairs => "stairs",
                ConnectionKind::Ramp => "ramp",
            };
            json!({
                "id": c.id,
                "kind": kind,
                "from": c.from,
                "to": c.to,
                "a": { "x": c.a.x, "y": c.a.y },
                "b": { "x": c.b.x, "y": c.b.y },
            })
        })
        .collect()
}

pub fn parallax_entry(meta: NodeMeta<'_>, map: &ParallaxMap) -> Value {
    let sprite_files: BTreeMap<&str, &str> = map.sprites.iter().map(|s| (s.id.as_str(), s.file.as_str())).collect();
    let layers = parallax_layers(map, &sprite_files);
    let level = map.level.as_ref().map(|lvl| parallax_level(map, lvl));
    json!({
        "kind": "scrolling_scene",
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "pixelRatio": map.pixel_ratio,
        "backdrop": {
            "file": map.backdrop.file,
            "width": map.backdrop.width,
            "speed": map.backdrop.speed,
            "drift": map.backdrop.drift,
            "opacity": map.backdrop.opacity,
            "visible": map.backdrop.visible,
        },
        "layers": layers,
        "level": level,
    })
}

fn parallax_layers(map: &ParallaxMap, sprite_files: &BTreeMap<&str, &str>) -> Vec<Value> {
    map.layers
        .iter()
        .map(|l| {
            let placement = match l.placement {
                LayerPlacement::Behind => "behind",
                LayerPlacement::Front => "front",
            };
            let items: Vec<Value> = l
                .items
                .iter()
                .map(|it| {
                    let tex_file = sprite_files.get(it.sprite_id.as_str()).copied().unwrap_or("");
                    json!({
                        "id": it.id,
                        "spriteId": it.sprite_id,
                        "textureFile": tex_file,
                        "x": it.x,
                        "y": it.y,
                        "scale": it.scale,
                        "flipX": it.flip_x,
                        "opacity": it.opacity,
                        "repeatSpan": it.repeat_span,
                        "motion": {
                            "drift": it.motion.drift,
                            "bob": { "amplitude": it.motion.bob.amplitude, "period": it.motion.bob.period },
                            "sway": { "degrees": it.motion.sway.degrees, "period": it.motion.sway.period },
                        },
                    })
                })
                .collect();
            json!({
                "name": l.name,
                "placement": placement,
                "speed": l.speed,
                "opacity": l.opacity,
                "visible": l.visible,
                "items": items,
            })
        })
        .collect()
}

fn parallax_level(map: &ParallaxMap, lvl: &Level) -> Value {
    let mut solids: Vec<Value> = lvl
        .whitebox
        .solids
        .iter()
        .map(|s| json!({ "x": s.x, "y": s.y, "width": s.width, "height": s.height }))
        .collect();
    for r in &lvl.whitebox.rows {
        solids.push(json!({ "x": r.x, "y": r.y, "width": r.resolved_width(), "height": r.height }));
    }
    let slopes: Vec<Value> = lvl
        .whitebox
        .slopes
        .iter()
        .map(|s| json!({ "x": s.x, "y": s.y, "width": s.width, "height": s.height, "direction": s.direction }))
        .collect();
    let hazards: Vec<Value> = lvl
        .whitebox
        .hazards
        .iter()
        .map(|h| json!({ "kind": h.kind, "x": h.x, "y": h.y, "width": h.width, "height": h.height }))
        .collect();
    let climbs: Vec<Value> = lvl
        .whitebox
        .climbs
        .iter()
        .map(|c| json!({ "id": c.id, "x": c.x, "top": c.top, "bottom": c.bottom }))
        .collect();
    let art_groups: Vec<Value> = lvl
        .kit
        .groups
        .iter()
        .filter_map(|g| {
            map.art_files
                .get(&g.file)
                .map(|f| json!({ "file": f, "x": g.image.x, "y": g.image.y }))
        })
        .collect();
    let depths: BTreeMap<&str, &str> = lvl
        .whitebox
        .slot_kinds
        .iter()
        .map(|sk| (sk.id.as_str(), sk.depth.as_str()))
        .collect();
    let obj_by_kind: BTreeMap<&str, &ObjectArt> = lvl.kit.objects.iter().map(|o| (o.kind.as_str(), o)).collect();
    let slots: Vec<Value> = lvl
        .whitebox
        .slots
        .iter()
        .filter_map(|sl| {
            let obj = obj_by_kind.get(sl.kind.as_str())?;
            let file = map.art_files.get(&obj.file)?;
            let depth = depths.get(sl.kind.as_str()).copied().unwrap_or("level");
            Some(json!({
                "kind": sl.kind,
                "x": sl.x,
                "y": sl.y,
                "file": file,
                "anchor": obj.anchor,
                "base": obj.base,
                "depth": depth,
            }))
        })
        .collect();
    json!({
        "solids": solids,
        "slopes": slopes,
        "hazards": hazards,
        "climbs": climbs,
        "markers": {
            "spawn": { "id": lvl.whitebox.markers.spawn.id, "x": lvl.whitebox.markers.spawn.x, "y": lvl.whitebox.markers.spawn.y },
            "exit": { "id": lvl.whitebox.markers.exit.id, "x": lvl.whitebox.markers.exit.x, "y": lvl.whitebox.markers.exit.y },
            "checkpoints": lvl.whitebox.markers.checkpoints.iter().map(|m| json!({ "id": m.id, "x": m.x, "y": m.y })).collect::<Vec<_>>(),
            "collectibles": lvl.whitebox.markers.collectibles.iter().map(|m| json!({ "id": m.id, "x": m.x, "y": m.y })).collect::<Vec<_>>(),
        },
        "artGroups": art_groups,
        "slots": slots,
    })
}

pub fn word_art_entry(meta: NodeMeta<'_>, doc: &WordArtDoc) -> Value {
    match doc {
        WordArtDoc::BmFont { fnt_file, font } => json!({
            "kind": "word_art",
            "id": meta.id,
            "path": meta.path,
            "baseDir": meta.base_dir,
            "mode": "bmfont",
            "fntFile": fnt_file,
            "font": font,
        }),
        WordArtDoc::Texts { texts } => json!({
            "kind": "word_art",
            "id": meta.id,
            "path": meta.path,
            "baseDir": meta.base_dir,
            "mode": "pieces",
            "texts": texts.iter().map(|t| json!({
                "name": t.name,
                "texture": tex_json(&t.texture),
                "width": t.width,
                "height": t.height,
            })).collect::<Vec<_>>(),
        }),
    }
}

pub fn icon_entry(meta: NodeMeta<'_>, icons: &[IconEntry]) -> Value {
    let items: Vec<Value> = icons
        .iter()
        .map(|ic| {
            let mut states = Map::new();
            for (k, v) in &ic.states {
                states.insert(k.clone(), tex_json(v));
            }
            json!({
                "name": ic.name,
                "kind": ic.kind,
                "width": ic.width,
                "height": ic.height,
                "states": Value::Object(states),
            })
        })
        .collect();
    json!({
        "kind": "icon",
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "icons": items,
    })
}

pub fn table_entry(meta: NodeMeta<'_>, table: &TableDoc) -> Value {
    json!({
        "kind": "table",
        "id": meta.id,
        "path": meta.path,
        "baseDir": meta.base_dir,
        "files": table.files,
        "rowCount": table.row_count,
        "rows": table.rows,
    })
}
