// Whole-map tile mask nearest-neighbor + 1px dilation compositor, 8px RLE/bitmap navigation decoder, and depth sorter.
import type { WfPoint, WfWholeMapEntry, WfWholeMapNavMask, WfWholeMapPart } from "./wf-types";

export const WHOLE_MAP_CELL_PX = 8;

const B64_ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

function decodeBase64(b64: string): Uint8Array {
  if (typeof atob === "function") {
    const bin = atob(b64.replace(/\s+/g, ""));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  const clean = b64.replace(/[\s=]+/g, "");
  const out = new Uint8Array(Math.floor((clean.length * 3) / 4));
  let p = 0;
  for (let i = 0; i < clean.length; i += 4) {
    const a = B64_ALPHA.indexOf(clean[i]);
    const b = B64_ALPHA.indexOf(clean[i + 1]);
    const c = i + 2 < clean.length ? B64_ALPHA.indexOf(clean[i + 2]) : -1;
    const d = i + 3 < clean.length ? B64_ALPHA.indexOf(clean[i + 3]) : -1;
    if (a < 0 || b < 0) break;
    out[p++] = (a << 2) | (b >> 4);
    if (c >= 0) out[p++] = ((b & 15) << 4) | (c >> 2);
    if (d >= 0) out[p++] = ((c & 3) << 6) | d;
  }
  return out.subarray(0, p);
}

function decodeLeb128Runs(bytes: Uint8Array): number[] {
  const runs: number[] = [];
  let val = 0;
  let shift = 0;
  for (const b of bytes) {
    val += (b & 0x7f) * Math.pow(2, shift);
    if ((b & 0x80) !== 0) {
      shift += 7;
      continue;
    }
    runs.push(val);
    val = 0;
    shift = 0;
  }
  return runs;
}

/** Decode `r:` (LEB128 RLE) or `b:` (row-major bitmap) 8px navigation mask into a dense 0/1 byte grid. */
export function decodeWholeMapMask(mask: WfWholeMapNavMask): Uint8Array {
  const total = mask.columns * mask.rows;
  const grid = new Uint8Array(total);
  if (total === 0) return grid;

  if (mask.data.startsWith("b:")) {
    const bytes = decodeBase64(mask.data.slice(2));
    for (let idx = 0; idx < total; idx++) {
      if (((bytes[idx >> 3] ?? 0) & (1 << (idx & 7))) !== 0) {
        grid[idx] = 1;
      }
    }
    return grid;
  }

  if (mask.data.startsWith("r:")) {
    const runs = decodeLeb128Runs(decodeBase64(mask.data.slice(2)));
    let pos = 0;
    let value = 0;
    for (const run of runs) {
      const end = Math.min(total, pos + run);
      if (value === 1) {
        grid.fill(1, pos, end);
      }
      pos = end;
      value = 1 - value;
      if (pos >= total) break;
    }
    return grid;
  }

  return grid;
}

/** Exact nearest-neighbor upscaled mask + 1px max-alpha dilation applied over `baseSource`. */
export function composeMaskedTileCanvas(
  baseSource: CanvasImageSource,
  maskSource: CanvasImageSource | null,
  width: number,
  height: number,
): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width));
  canvas.height = Math.max(1, Math.round(height));
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;

  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(baseSource, 0, 0, canvas.width, canvas.height);

  if (!maskSource) return canvas;

  const maskCanvas = document.createElement("canvas");
  maskCanvas.width = canvas.width;
  maskCanvas.height = canvas.height;
  const mctx = maskCanvas.getContext("2d");
  if (!mctx) return canvas;

  mctx.imageSmoothingEnabled = false;
  mctx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
  mctx.drawImage(maskSource, 0, 0, maskCanvas.width, maskCanvas.height);

  const baseData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const maskData = mctx.getImageData(0, 0, canvas.width, canvas.height);
  const w = canvas.width;
  const h = canvas.height;
  const m = maskData.data;
  const b = baseData.data;

  for (let y = 0; y < h; y++) {
    const yUp = Math.max(0, y - 1);
    const yDown = Math.min(h - 1, y + 1);
    for (let x = 0; x < w; x++) {
      const xLeft = Math.max(0, x - 1);
      const xRight = Math.min(w - 1, x + 1);
      let maxAlpha = m[(y * w + x) * 4 + 3];
      for (const ny of [yUp, y, yDown]) {
        for (const nx of [xLeft, x, xRight]) {
          const a = m[(ny * w + nx) * 4 + 3];
          if (a > maxAlpha) maxAlpha = a;
        }
      }
      const p = (y * w + x) * 4 + 3;
      b[p] = Math.round((b[p] * maxAlpha) / 255);
    }
  }

  ctx.putImageData(baseData, 0, 0);
  return canvas;
}

export function sortWholeMapParts(parts: readonly WfWholeMapPart[]): WfWholeMapPart[] {
  const band = (mode: WfWholeMapPart["sortMode"]) => (mode === "below" ? -1 : mode === "sorted" ? 0 : 1);
  return [...parts].sort((a, b) => {
    if (a.layerZ !== b.layerZ) return a.layerZ - b.layerZ;
    const ba = band(a.sortMode);
    const bb = band(b.sortMode);
    if (ba !== bb) return ba - bb;
    if (a.sortMode === "sorted" && a.foot.y !== b.foot.y) return a.foot.y - b.foot.y;
    return a.drawOrder - b.drawOrder;
  });
}

export class WfWholeMapNavRuntime {
  readonly entry: WfWholeMapEntry;

  constructor(entry: WfWholeMapEntry) {
    this.entry = entry;
  }

  isWalkable(px: number, py: number): boolean {
    for (const r of this.entry.walkableRects) {
      if (px >= r.x && px < r.x + r.width && py >= r.y && py < r.y + r.height) {
        return true;
      }
    }
    return false;
  }

  findPath(start: WfPoint, goal: WfPoint): WfPoint[] {
    const rects = this.entry.walkableRects;
    if (rects.length === 0) return [start, goal];
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const r of rects) {
      minX = Math.min(minX, r.x);
      minY = Math.min(minY, r.y);
      maxX = Math.max(maxX, r.x + r.width);
      maxY = Math.max(maxY, r.y + r.height);
    }
    const cols = Math.max(1, Math.ceil((maxX - minX) / WHOLE_MAP_CELL_PX));
    const rows = Math.max(1, Math.ceil((maxY - minY) / WHOLE_MAP_CELL_PX));
    const toCell = (p: WfPoint): [number, number] => [
      Math.max(0, Math.min(cols - 1, Math.floor((p.x - minX) / WHOLE_MAP_CELL_PX))),
      Math.max(0, Math.min(rows - 1, Math.floor((p.y - minY) / WHOLE_MAP_CELL_PX))),
    ];
    const [sx, sy] = toCell(start);
    const [gx, gy] = toCell(goal);
    const startIdx = sy * cols + sx;
    const goalIdx = gy * cols + gx;
    const parent = new Int32Array(cols * rows).fill(-1);
    const visited = new Uint8Array(cols * rows);
    const queue = [startIdx];
    visited[startIdx] = 1;

    let head = 0;
    while (head < queue.length) {
      const cur = queue[head++];
      if (cur === goalIdx) break;
      const cx = cur % cols;
      const cy = Math.floor(cur / cols);
      for (const [dx, dy] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const nx = cx + dx;
        const ny = cy + dy;
        if (nx < 0 || nx >= cols || ny < 0 || ny >= rows) continue;
        const ni = ny * cols + nx;
        if (visited[ni]) continue;
        const wx = minX + (nx + 0.5) * WHOLE_MAP_CELL_PX;
        const wy = minY + (ny + 0.5) * WHOLE_MAP_CELL_PX;
        if (!this.isWalkable(wx, wy) && ni !== goalIdx) continue;
        visited[ni] = 1;
        parent[ni] = cur;
        queue.push(ni);
      }
    }

    if (!visited[goalIdx]) return [];
    const out: WfPoint[] = [];
    for (let cur = goalIdx; cur !== -1; cur = parent[cur]) {
      const cx = cur % cols;
      const cy = Math.floor(cur / cols);
      out.push({
        x: minX + (cx + 0.5) * WHOLE_MAP_CELL_PX,
        y: minY + (cy + 0.5) * WHOLE_MAP_CELL_PX,
      });
    }
    return out.reverse();
  }
}
