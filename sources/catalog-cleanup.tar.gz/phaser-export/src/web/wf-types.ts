// Shared TypeScript interfaces for exported WeaveForge web assets.

export interface WfPoint {
  x: number;
  y: number;
}

export interface WfRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface WfTextureRegion {
  path: string;
  region?: WfRect | null;
}

export interface WfFrame {
  texture: WfTextureRegion;
  durationMs: number;
}

export interface WfClip {
  name: string;
  looped: boolean;
  anchor: WfPoint;
  frames: WfFrame[];
}

export interface WfFrameAnimationEntry {
  kind: "frame_animation" | "character_effect";
  id: string;
  path: string;
  baseDir: string;
  clips: WfClip[];
}

export interface WfUiState {
  role: string;
  texture: WfTextureRegion;
  borders: [number, number, number, number];
}

export interface WfUiWidget {
  name: string;
  widget: "press" | "flip" | "bar" | "slide";
  width: number;
  height: number;
  states: WfUiState[];
}

export interface WfUiKitEntry {
  kind: "ui";
  id: string;
  path: string;
  baseDir: string;
  widgets: WfUiWidget[];
  elements: string[];
}

export interface WfTilemapGroundTile {
  level: number;
  cell: [number, number];
  textureKey: string;
  texture: string;
  source: { x: number; y: number; width: number; height: number };
  target: { x: number; y: number; width: number; height: number };
  opacity: number;
}

export interface WfTilemapSprite {
  id: string;
  texture: string;
  position: WfPoint;
  rect: { x: number; y: number; width: number; height: number };
  source?: { x: number; y: number; width: number; height: number } | null;
  rotation: number;
  flipX: boolean;
  opacity: number;
}

export interface WfTilemapEntry {
  kind: "tilemap";
  id: string;
  path: string;
  baseDir: string;
  orientation: "orthogonal" | "isometric";
  tileWidth: number;
  tileHeight: number;
  textures: Record<string, { file: string; width: number; height: number }>;
  ground: WfTilemapGroundTile[];
  sprites: WfTilemapSprite[];
  obstacles: Array<{ kind: string; points: WfPoint[] }>;
  walkable: WfPoint[][];
  spawn?: WfPoint | null;
}

export interface WfPropState {
  id: string;
  texture: WfTextureRegion;
  collision: WfPoint[][];
}

export interface WfPropTransition {
  id: string;
  looped: boolean;
  durationsMs: number[];
  textures: WfTextureRegion[];
}

export interface WfPropObject {
  name: string;
  canvasWidth: number;
  canvasHeight: number;
  anchor: WfPoint;
  pixelsPerTile: number;
  states: WfPropState[];
  animations: WfPropTransition[];
}

export interface WfPropSetEntry {
  kind: "prop";
  id: string;
  path: string;
  baseDir: string;
  objects: WfPropObject[];
}

export type WfParticleEvent = "land" | "death";
export type WfParticleOrientation = "random" | "upright" | "velocity";

export interface WfParticleEmitter {
  id: string;
  randomState?: number;
  enabled: boolean;
  rate: number;
  burst: number;
  delay: number;
  lifetime: [number, number];
  position: [number, number, number];
  spread: [number, number, number];
  velocity: [number, number, number];
  velocitySpread: [number, number, number];
  gravity: [number, number, number];
  drag: number;
  size: number[];
  opacity: number[];
  color: string[];
  blend: "normal" | "additive";
  picture: string;
  sprite?: boolean;
  orientation?: WfParticleOrientation;
  tilt?: number;
  flip?: boolean;
  sizeJitter?: number;
  stretch?: number;
  radial?: { speed: [number, number]; radius: [number, number]; cone: number };
  ground?: { bounce: number; friction: number; kill: boolean };
  triggers?: Array<{ on: WfParticleEvent; emitter: string; count: number; inherit: number }>;
  maxParticles: number;
}

export interface WfParticleEntry {
  kind: "particle_effect";
  id: string;
  path: string;
  baseDir: string;
  seed: number;
  duration: number;
  looping: boolean;
  space: "planar" | "spatial";
  emitters: WfParticleEmitter[];
}

export interface WfWholeMapTile {
  key: string;
  gridX: number;
  gridY: number;
  x: number;
  y: number;
  width: number;
  height: number;
  baseFile: string;
  maskFile?: string | null;
}

export interface WfWholeMapPart {
  id: string;
  name: string;
  textureFile: string;
  x: number;
  y: number;
  foot: WfPoint;
  footprints: WfPoint[][];
  blocking: boolean;
  sortMode: "below" | "sorted" | "above";
  drawOrder: number;
  layerZ: number;
}

export interface WfWholeMapNavMask {
  x: number;
  y: number;
  columns: number;
  rows: number;
  data: string;
}

export interface WfWholeMapEntry {
  kind: "whole_map";
  id: string;
  path: string;
  baseDir: string;
  perspective: string;
  tileWidth: number;
  tileHeight: number;
  tiles: WfWholeMapTile[];
  parts: WfWholeMapPart[];
  walkableRects: Array<{ x: number; y: number; width: number; height: number }>;
  navMasks: Array<{ offsetX: number; offsetY: number; mask: WfWholeMapNavMask }>;
  connections: Array<{ id: string; kind: "stairs" | "ramp"; from: string; to: string; a: WfPoint; b: WfPoint }>;
  regions: Array<{ id: string; polygon: WfPoint[] }>;
  character: { radius: number; speed: number };
}

export interface WfParallaxItem {
  id: string;
  spriteId: string;
  textureFile: string;
  x: number;
  y: number;
  scale: number;
  flipX: boolean;
  opacity: number;
  repeatSpan?: number | null;
  motion: {
    drift: number;
    bob: { amplitude: number; period: number };
    sway: { degrees: number; period: number };
  };
}

export interface WfParallaxLayer {
  name: string;
  placement: "behind" | "front";
  speed: number;
  opacity: number;
  visible: boolean;
  items: WfParallaxItem[];
}

export interface WfScrollingSceneEntry {
  kind: "scrolling_scene";
  id: string;
  path: string;
  baseDir: string;
  pixelRatio: number;
  backdrop: { file: string; width: number; speed: number; drift: number; opacity: number; visible: boolean };
  layers: WfParallaxLayer[];
  level?: {
    solids: Array<{ x: number; y: number; width: number; height: number }>;
    slopes: Array<{ x: number; y: number; width: number; height: number; direction: string }>;
    hazards: Array<{ kind: string; x: number; y: number; width: number; height: number }>;
    climbs: Array<{ id: string; x: number; top: number; bottom: number }>;
    markers: {
      spawn: { id: string; x: number; y: number };
      exit: { id: string; x: number; y: number };
      checkpoints: Array<{ id: string; x: number; y: number }>;
      collectibles: Array<{ id: string; x: number; y: number }>;
    };
    artGroups: Array<{ file: string; x: number; y: number }>;
    slots: Array<{ kind: string; x: number; y: number; file: string; anchor: number; base: number; depth: string }>;
  } | null;
}

export interface WfWordArtEntry {
  kind: "word_art";
  id: string;
  path: string;
  baseDir: string;
  mode: "bmfont" | "pieces";
  fntFile?: string;
  font?: {
    face: string;
    size: number;
    lineHeight: number;
    base: number;
    pages: string[];
    chars: Array<{
      id: number;
      x: number;
      y: number;
      width: number;
      height: number;
      xoffset: number;
      yoffset: number;
      xadvance: number;
      page: number;
    }>;
  };
  texts?: Array<{ name: string; texture: WfTextureRegion; width: number; height: number }>;
}

export interface WfIconSetEntry {
  kind: "icon";
  id: string;
  path: string;
  baseDir: string;
  icons: Array<{
    name: string;
    kind: string;
    width: number;
    height: number;
    states: Record<string, WfTextureRegion>;
  }>;
}

export interface WfTableEntry {
  kind: "table";
  id: string;
  path: string;
  baseDir: string;
  files: string[];
  rowCount: number;
  rows: Array<Record<string, unknown>>;
}

export interface WfModel3dEntry {
  kind: "model_3d";
  id: string;
  path: string;
  baseDir: string;
  glbFile: string;
  height: number;
  bottom: number;
  collider:
    | { type: "capsule"; radius: number; height: number; center: [number, number, number] }
    | { type: "box"; size: [number, number, number]; center: [number, number, number] };
  bones: Record<string, string>;
  sockets: Array<{ name: string; position: [number, number, number] }>;
  clips: Array<{
    name: string;
    duration: number;
    loops?: boolean;
    travel?: [number, number, number];
    soleLow?: number;
    soleHigh?: number;
    liftoffs?: number;
    checks: string[];
  }>;
}

export interface WfScene3dMapEntry {
  kind: "scene3d_map";
  id: string;
  path: string;
  baseDir: string;
  glbFile: string;
  blockedDoors: string[];
  environment: {
    ambientColor?: [number, number, number] | null;
    ambientIntensity: number;
    fogColor?: [number, number, number] | null;
    fogDensity: number;
    fogNear?: number | null;
    fogFar?: number | null;
  };
  colliders: Array<{ name: string; center: [number, number, number]; size: [number, number, number] }>;
  roles: Array<{
    role: string;
    id?: string | null;
    node?: string | null;
    position: [number, number, number];
    forward: [number, number, number];
    min?: [number, number, number] | null;
    max?: [number, number, number] | null;
    blocked: boolean;
  }>;
}

export type WfAssetEntry =
  | WfFrameAnimationEntry
  | WfUiKitEntry
  | WfTilemapEntry
  | WfPropSetEntry
  | WfParticleEntry
  | WfWholeMapEntry
  | WfScrollingSceneEntry
  | WfWordArtEntry
  | WfIconSetEntry
  | WfTableEntry
  | WfModel3dEntry
  | WfScene3dMapEntry;

export interface WfAssetManifest {
  schema: "wf-web-assets/1";
  entries: Record<string, WfAssetEntry>;
}
