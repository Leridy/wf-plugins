// Phaser 3 adapter for all exported WeaveForge web asset entries (`wf-assets.json`).
import type * as Phaser from "phaser";
import { computeParallaxTransform } from "./wf-parallax";
import { createParticleColorCache, evaluateParticles, WfParticleSimulation } from "./wf-simulation";
import type {
  WfAssetEntry,
  WfAssetManifest,
  WfFrameAnimationEntry,
  WfIconSetEntry,
  WfParticleEntry,
  WfPoint,
  WfPropSetEntry,
  WfScrollingSceneEntry,
  WfTableEntry,
  WfTextureRegion,
  WfTilemapEntry,
  WfUiKitEntry,
  WfUiState,
  WfWholeMapEntry,
  WfWordArtEntry,
} from "./wf-types";
import { composeMaskedTileCanvas, sortWholeMapParts, WfWholeMapNavRuntime } from "./wf-whole-map";

export interface WfPreloadOptions {
  /** URL prefix before `entry.baseDir` (e.g. `"/assets"` or `""`). Default `""`. */
  baseUrl?: string;
}

function joinUrl(baseUrl: string, baseDir: string, file: string): string {
  const cleanBase = baseUrl.replace(/\/+$/, "");
  const cleanDir = baseDir.replace(/^\/+|\/+$/g, "");
  const cleanFile = file.replace(/^\/+/, "");
  return [cleanBase, cleanDir, cleanFile].filter((s) => s.length > 0).join("/");
}

export function wfTextureKey(baseDir: string, file: string): string {
  const norm = baseDir.replace(/^\/+|\/+$/g, "");
  return norm.length > 0 ? `wf:${norm}/${file}` : `wf:${file}`;
}

export function wfWordArtFontKey(entry: Pick<WfWordArtEntry, "id">): string {
  return `wf:bmfont:${entry.id}`;
}

function regionFrameName(tex: WfTextureRegion): string | undefined {
  if (!tex.region) return undefined;
  const r = tex.region;
  return `r:${Math.round(r.x)}:${Math.round(r.y)}:${Math.round(r.w)}:${Math.round(r.h)}`;
}

function ensureRegionFrame(scene: Phaser.Scene, baseDir: string, tex: WfTextureRegion): { key: string; frame?: string } {
  const key = wfTextureKey(baseDir, tex.path);
  const frame = regionFrameName(tex);
  if (frame && tex.region && scene.textures.exists(key)) {
    const phaserTex = scene.textures.get(key);
    if (!phaserTex.has(frame)) {
      phaserTex.add(frame, 0, tex.region.x, tex.region.y, tex.region.w, tex.region.h);
    }
  }
  return { key, frame };
}

function collectEntryImages(entry: WfAssetEntry): string[] {
  const files = new Set<string>();
  switch (entry.kind) {
    case "frame_animation":
    case "character_effect":
      for (const c of entry.clips) {
        for (const f of c.frames) files.add(f.texture.path);
      }
      break;
    case "ui":
      for (const w of entry.widgets) {
        for (const s of w.states) files.add(s.texture.path);
      }
      break;
    case "tilemap":
      for (const tex of Object.values(entry.textures)) files.add(tex.file);
      break;
    case "prop":
      for (const obj of entry.objects) {
        for (const st of obj.states) files.add(st.texture.path);
        for (const anim of obj.animations) {
          for (const tex of anim.textures) files.add(tex.path);
        }
      }
      break;
    case "particle_effect":
      for (const em of entry.emitters) {
        if (em.sprite) files.add(em.picture);
      }
      break;
    case "whole_map":
      for (const tile of entry.tiles) {
        files.add(tile.baseFile);
        if (tile.maskFile) files.add(tile.maskFile);
      }
      for (const part of entry.parts) files.add(part.textureFile);
      break;
    case "scrolling_scene":
      files.add(entry.backdrop.file);
      for (const layer of entry.layers) {
        for (const item of layer.items) files.add(item.textureFile);
      }
      if (entry.level) {
        for (const g of entry.level.artGroups) files.add(g.file);
        for (const s of entry.level.slots) files.add(s.file);
      }
      break;
    case "word_art":
      if (entry.mode === "pieces" && entry.texts) {
        for (const t of entry.texts) files.add(t.texture.path);
      }
      break;
    case "icon":
      for (const icon of entry.icons) {
        for (const tex of Object.values(icon.states)) files.add(tex.path);
      }
      break;
    case "table":
    case "model_3d":
    case "scene3d_map":
      break;
  }
  return [...files];
}

/** Queue all images and BMFont assets for a single exported WeaveForge node in `scene.preload()`. */
export function preloadWfEntry(scene: Phaser.Scene, entry: WfAssetEntry, options?: WfPreloadOptions): void {
  const baseUrl = options?.baseUrl ?? "";
  for (const file of collectEntryImages(entry)) {
    const key = wfTextureKey(entry.baseDir, file);
    if (!scene.textures.exists(key)) {
      scene.load.image(key, joinUrl(baseUrl, entry.baseDir, file));
    }
  }
  if (entry.kind === "word_art" && entry.mode === "bmfont" && entry.fntFile && entry.font?.pages.length) {
    const fontKey = wfWordArtFontKey(entry);
    const pngUrl = joinUrl(baseUrl, entry.baseDir, entry.font.pages[0]);
    const fntUrl = joinUrl(baseUrl, entry.baseDir, entry.fntFile);
    scene.load.bitmapFont(fontKey, pngUrl, fntUrl);
  }
}

/** Queue all entries in `wf-assets.json` during Phaser `Scene.preload()`. */
export function preloadWfManifest(scene: Phaser.Scene, manifest: WfAssetManifest, options?: WfPreloadOptions): void {
  for (const entry of Object.values(manifest.entries)) {
    preloadWfEntry(scene, entry, options);
  }
}

export function registerWfAnimations(scene: Phaser.Scene, entry: WfFrameAnimationEntry): string[] {
  const keys: string[] = [];
  for (const clip of entry.clips) {
    const key = `wf:${entry.id}:${clip.name}`;
    keys.push(key);
    if (scene.anims.exists(key)) continue;
    scene.anims.create({
      key,
      frames: clip.frames.map((frame) => {
        const ref = ensureRegionFrame(scene, entry.baseDir, frame.texture);
        return { key: ref.key, frame: ref.frame, duration: frame.durationMs };
      }),
      frameRate: 1000,
      repeat: clip.looped ? -1 : 0,
    });
  }
  return keys;
}

export function createWfAnimatedSprite(
  scene: Phaser.Scene,
  entry: WfFrameAnimationEntry,
  x: number,
  y: number,
  clipName?: string,
): Phaser.GameObjects.Sprite {
  registerWfAnimations(scene, entry);
  const clip = (clipName ? entry.clips.find((c) => c.name === clipName) : entry.clips[0]) ?? entry.clips[0];
  const first = ensureRegionFrame(scene, entry.baseDir, clip.frames[0].texture);
  const sprite = scene.add.sprite(x, y, first.key, first.frame);
  sprite.setOrigin(clip.anchor.x, clip.anchor.y);
  sprite.play(`wf:${entry.id}:${clip.name}`);
  return sprite;
}

export interface WfUiWidgetHandle {
  root: Phaser.GameObjects.Container;
  setState(role: string): void;
  setValue(norm: number): void;
  getChecked(): boolean;
  setChecked(next: boolean): void;
}

export interface WfUiWidgetOptions {
  onClick?: () => void;
  onToggle?: (checked: boolean) => void;
  onChange?: (value: number) => void;
  initialValue?: number;
  initialChecked?: boolean;
}

function makeUiVisual(
  scene: Phaser.Scene,
  baseDir: string,
  st: WfUiState,
  w: number,
  h: number,
): Phaser.GameObjects.Image | Phaser.GameObjects.NineSlice {
  const ref = ensureRegionFrame(scene, baseDir, st.texture);
  const [left, right, top, bottom] = st.borders;
  if (left > 0 || right > 0 || top > 0 || bottom > 0) {
    return scene.add.nineslice(0, 0, ref.key, ref.frame, w, h, left, right, top, bottom);
  }
  const img = scene.add.image(0, 0, ref.key, ref.frame);
  img.setDisplaySize(w, h);
  return img;
}

function applyUiTexture(
  target: Phaser.GameObjects.Image | Phaser.GameObjects.NineSlice,
  scene: Phaser.Scene,
  baseDir: string,
  st: WfUiState,
): void {
  const ref = ensureRegionFrame(scene, baseDir, st.texture);
  target.setTexture(ref.key, ref.frame);
}

export function createWfUiWidget(
  scene: Phaser.Scene,
  entry: WfUiKitEntry,
  widgetName: string,
  x: number,
  y: number,
  options?: WfUiWidgetOptions,
): WfUiWidgetHandle {
  const spec = entry.widgets.find((w) => w.name === widgetName) ?? entry.widgets[0];
  if (!spec || spec.states.length === 0) {
    throw new Error(`UI widget ${widgetName} not found in ${entry.path}`);
  }
  const findState = (role: string): WfUiState | undefined => spec.states.find((s) => s.role === role);
  const root = scene.add.container(x, y);
  root.setSize(spec.width, spec.height);

  let checked = Boolean(options?.initialChecked);
  let value = Math.max(0, Math.min(1, options?.initialValue ?? 1));

  if (spec.widget === "bar" || spec.widget === "slide") {
    const trackState = findState("track") ?? spec.states[0];
    const fillState = findState("fill");
    const thumbState = findState("thumb");
    const track = makeUiVisual(scene, entry.baseDir, trackState, spec.width, spec.height);
    root.add(track);

    let fill: (Phaser.GameObjects.Image | Phaser.GameObjects.NineSlice) | null = null;
    if (fillState) {
      fill = makeUiVisual(scene, entry.baseDir, fillState, spec.width, spec.height);
      root.add(fill);
    }

    let thumb: (Phaser.GameObjects.Image | Phaser.GameObjects.NineSlice) | null = null;
    if (thumbState && spec.widget === "slide") {
      const thumbSize = Math.min(spec.width, spec.height);
      thumb = makeUiVisual(scene, entry.baseDir, thumbState, thumbSize, thumbSize);
      root.add(thumb);
    }

    const updateBar = (next: number) => {
      value = Math.max(0, Math.min(1, next));
      if (fill) {
        fill.setCrop(0, 0, Math.round(spec.width * value), spec.height);
      }
      if (thumb) {
        thumb.setX((value - 0.5) * spec.width);
      }
    };
    updateBar(value);

    if (spec.widget === "slide") {
      root.setInteractive({ useHandCursor: true, draggable: true });
      const applyPointer = (ptr: Phaser.Input.Pointer) => {
        const localX = ptr.x - root.x;
        const norm = localX / spec.width + 0.5;
        updateBar(norm);
        options?.onChange?.(value);
      };
      root.on("pointerdown", applyPointer);
      root.on("drag", applyPointer);
    }

    return {
      root,
      setState: () => {},
      setValue: updateBar,
      getChecked: () => checked,
      setChecked: () => {},
    };
  }

  const baseState = (checked ? findState("hoverPressed") : findState("rest")) ?? spec.states[0];
  const face = makeUiVisual(scene, entry.baseDir, baseState, spec.width, spec.height);
  root.add(face);
  const setState = (role: string) => {
    const st = findState(role) ?? findState("rest") ?? spec.states[0];
    applyUiTexture(face, scene, entry.baseDir, st);
  };

  root.setInteractive({ useHandCursor: true });
  root.on("pointerover", () => setState(checked ? "hoverPressed" : "hover"));
  root.on("pointerout", () => setState(checked ? "hoverPressed" : "rest"));
  root.on("pointerdown", () => setState("pressed"));
  root.on("pointerup", () => {
    if (spec.widget === "flip") {
      checked = !checked;
      setState(checked ? "hoverPressed" : "rest");
      options?.onToggle?.(checked);
    } else {
      setState("hover");
      options?.onClick?.();
    }
  });

  return {
    root,
    setState,
    setValue: () => {},
    getChecked: () => checked,
    setChecked: (next: boolean) => {
      checked = next;
      setState(checked ? "hoverPressed" : "rest");
    },
  };
}

export interface WfTilemapHandle {
  container: Phaser.GameObjects.Container;
  obstacles: WfTilemapEntry["obstacles"];
  walkable: WfTilemapEntry["walkable"];
  spawn: WfPoint | null;
}

export function createWfTilemap(scene: Phaser.Scene, entry: WfTilemapEntry, x = 0, y = 0): WfTilemapHandle {
  const container = scene.add.container(x, y);
  const sortedGround = [...entry.ground].sort((a, b) => a.level - b.level || a.cell[1] - b.cell[1] || a.cell[0] - b.cell[0]);
  for (const tile of sortedGround) {
    const ref = ensureRegionFrame(scene, entry.baseDir, {
      path: tile.texture,
      region: { x: tile.source.x, y: tile.source.y, w: tile.source.width, h: tile.source.height },
    });
    const img = scene.add.image(tile.target.x, tile.target.y, ref.key, ref.frame);
    img.setOrigin(0, 0);
    img.setDisplaySize(tile.target.width, tile.target.height);
    img.setAlpha(tile.opacity);
    container.add(img);
  }

  const sortedSprites = [...entry.sprites].sort((a, b) => a.position.y - b.position.y);
  for (const sp of sortedSprites) {
    const texFile = entry.textures[sp.texture]?.file ?? sp.texture;
    const ref = ensureRegionFrame(scene, entry.baseDir, {
      path: texFile,
      region: sp.source ? { x: sp.source.x, y: sp.source.y, w: sp.source.width, h: sp.source.height } : null,
    });
    const img = scene.add.image(sp.position.x, sp.position.y, ref.key, ref.frame);
    img.setOrigin(0, 0);
    img.setDisplaySize(sp.rect.width, sp.rect.height);
    img.setRotation(sp.rotation);
    img.setFlipX(sp.flipX);
    img.setAlpha(sp.opacity);
    container.add(img);
  }

  return {
    container,
    obstacles: entry.obstacles,
    walkable: entry.walkable,
    spawn: entry.spawn ?? null,
  };
}

export interface WfPropHandle {
  sprite: Phaser.GameObjects.Sprite;
  setState(stateId: string): void;
  playTransition(animId: string): void;
  getCollisionPolygons(): WfPoint[][];
}

export function createWfProp(
  scene: Phaser.Scene,
  entry: WfPropSetEntry,
  objectName: string,
  x: number,
  y: number,
  initialStateId?: string,
): WfPropHandle {
  const obj = entry.objects.find((o) => o.name === objectName) ?? entry.objects[0];
  if (!obj || obj.states.length === 0) {
    throw new Error(`Prop object ${objectName} not found in ${entry.path}`);
  }
  let current = (initialStateId ? obj.states.find((s) => s.id === initialStateId) : obj.states[0]) ?? obj.states[0];
  const initRef = ensureRegionFrame(scene, entry.baseDir, current.texture);
  const sprite = scene.add.sprite(x, y, initRef.key, initRef.frame);
  sprite.setOrigin(obj.anchor.x / obj.canvasWidth, obj.anchor.y / obj.canvasHeight);

  for (const anim of obj.animations) {
    const key = `wf:prop:${entry.id}:${obj.name}:${anim.id}`;
    if (scene.anims.exists(key)) continue;
    scene.anims.create({
      key,
      frames: anim.textures.map((tex, idx) => {
        const ref = ensureRegionFrame(scene, entry.baseDir, tex);
        return { key: ref.key, frame: ref.frame, duration: anim.durationsMs[idx] ?? 100 };
      }),
      frameRate: 1000,
      repeat: anim.looped ? -1 : 0,
    });
  }

  return {
    sprite,
    setState(stateId: string) {
      const next = obj.states.find((s) => s.id === stateId);
      if (!next) return;
      current = next;
      sprite.stop();
      const ref = ensureRegionFrame(scene, entry.baseDir, current.texture);
      sprite.setTexture(ref.key, ref.frame);
    },
    playTransition(animId: string) {
      const key = `wf:prop:${entry.id}:${obj.name}:${animId}`;
      if (scene.anims.exists(key)) sprite.play(key);
    },
    getCollisionPolygons() {
      return current.collision.map((poly) => poly.map((p) => ({ x: sprite.x + p.x, y: sprite.y + p.y })));
    },
  };
}

function ensureBuiltinParticleTexture(scene: Phaser.Scene, picture: string): string {
  const key = `wf:builtin-particle:${picture}`;
  if (scene.textures.exists(key)) return key;
  const size = 32;
  const tex = scene.textures.createCanvas(key, size, size);
  const ctx = tex?.getContext();
  if (ctx) {
    const half = size / 2;
    const grad = ctx.createRadialGradient(half, half, 0, half, half, half);
    if (picture === "ring") {
      grad.addColorStop(0, "rgba(255,255,255,0)");
      grad.addColorStop(0.55, "rgba(255,255,255,0.2)");
      grad.addColorStop(0.8, "rgba(255,255,255,1)");
      grad.addColorStop(1, "rgba(255,255,255,0)");
    } else if (picture === "spark") {
      grad.addColorStop(0, "rgba(255,255,255,1)");
      grad.addColorStop(0.35, "rgba(255,255,255,0.85)");
      grad.addColorStop(1, "rgba(255,255,255,0)");
    } else {
      grad.addColorStop(0, "rgba(255,255,255,1)");
      grad.addColorStop(0.5, "rgba(255,255,255,0.5)");
      grad.addColorStop(1, "rgba(255,255,255,0)");
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);
    tex?.refresh();
  }
  return key;
}

export class WfPhaserParticleEmitter {
  readonly scene: Phaser.Scene;
  readonly entry: WfParticleEntry;
  readonly sim: WfParticleSimulation;
  readonly container: Phaser.GameObjects.Container;
  private readonly pools: Phaser.GameObjects.Image[][] = [];
  private readonly emitterTex: string[];
  private readonly blendModes: number[];
  private readonly colorCache: ReturnType<typeof createParticleColorCache>;
  private readonly updateListener: ((time: number, delta: number) => void) | null = null;

  constructor(scene: Phaser.Scene, entry: WfParticleEntry, x: number, y: number, manualStep = false) {
    this.scene = scene;
    this.entry = entry;
    this.sim = new WfParticleSimulation(entry);
    this.container = scene.add.container(x, y);
    this.colorCache = createParticleColorCache(entry.emitters);
    this.emitterTex = entry.emitters.map((em) =>
      em.sprite ? wfTextureKey(entry.baseDir, em.picture) : ensureBuiltinParticleTexture(scene, em.picture),
    );
    this.blendModes = entry.emitters.map((em) => (em.blend === "additive" ? 1 : 0));
    for (let i = 0; i < entry.emitters.length; i++) {
      this.pools.push([]);
    }
    this.syncVisuals();
    if (!manualStep) {
      this.updateListener = (_time, deltaMs) => this.step(deltaMs / 1000);
      scene.events.on("update", this.updateListener);
    }
  }

  step(dtSec: number): void {
    this.sim.advance(dtSec);
    this.syncVisuals();
  }

  reset(): void {
    this.sim.reset();
    this.syncVisuals();
  }

  destroy(): void {
    if (this.updateListener) {
      this.scene.events.off("update", this.updateListener);
    }
    this.container.destroy(true);
  }

  private syncVisuals(): void {
    const evaluated = evaluateParticles(this.sim, this.colorCache, false);
    const byEmitter = this.entry.emitters.map(() => [] as typeof evaluated);
    for (const p of evaluated) byEmitter[p.emitterIndex]?.push(p);

    for (let ei = 0; ei < this.entry.emitters.length; ei++) {
      const list = byEmitter[ei];
      const pool = this.pools[ei];
      const texKey = this.emitterTex[ei];
      const blendMode = this.blendModes[ei];

      while (pool.length < list.length) {
        const sprite = this.scene.add.image(0, 0, texKey);
        sprite.setBlendMode(blendMode);
        this.container.add(sprite);
        pool.push(sprite);
      }

      for (let i = 0; i < pool.length; i++) {
        const sprite = pool[i];
        if (i >= list.length) {
          sprite.setVisible(false);
          continue;
        }
        const p = list[i];
        sprite.setVisible(true);
        sprite.setPosition(p.x, p.y);
        sprite.setAlpha(p.alpha);
        sprite.setTint(p.colorInt24);
        const baseScale = Math.max(0.01, p.size / Math.max(1, sprite.width));
        sprite.setScale(baseScale, baseScale * p.stretchY);
        sprite.setRotation(p.rotation);
        sprite.setFlipX(p.flipX);
      }
    }
  }
}

export function createWfParticleEffect(
  scene: Phaser.Scene,
  entry: WfParticleEntry,
  x: number,
  y: number,
  options?: { manualStep?: boolean },
): WfPhaserParticleEmitter {
  return new WfPhaserParticleEmitter(scene, entry, x, y, Boolean(options?.manualStep));
}

export interface WfWholeMapHandle {
  container: Phaser.GameObjects.Container;
  nav: WfWholeMapNavRuntime;
  character: WfWholeMapEntry["character"];
  connections: WfWholeMapEntry["connections"];
  regions: WfWholeMapEntry["regions"];
  updateActorDepth(actor: { setDepth(d: number): unknown }, footY: number, layerZ?: number): void;
}

export function createWfWholeMap(scene: Phaser.Scene, entry: WfWholeMapEntry, x = 0, y = 0): WfWholeMapHandle {
  const container = scene.add.container(x, y);
  for (const tile of entry.tiles) {
    const baseKey = wfTextureKey(entry.baseDir, tile.baseFile);
    const composedKey = `wf:whole-tile:${entry.id}:${tile.key}`;
    if (!scene.textures.exists(composedKey) && scene.textures.exists(baseKey)) {
      const baseSrc = scene.textures.get(baseKey).getSourceImage() as CanvasImageSource;
      const maskSrc =
        tile.maskFile && scene.textures.exists(wfTextureKey(entry.baseDir, tile.maskFile))
          ? (scene.textures.get(wfTextureKey(entry.baseDir, tile.maskFile)).getSourceImage() as CanvasImageSource)
          : null;
      const canvas = composeMaskedTileCanvas(baseSrc, maskSrc, tile.width, tile.height);
      scene.textures.addCanvas(composedKey, canvas);
    }
    const tileImg = scene.add.image(tile.x, tile.y, scene.textures.exists(composedKey) ? composedKey : baseKey);
    tileImg.setOrigin(0, 0);
    tileImg.setDisplaySize(tile.width, tile.height);
    tileImg.setDepth(-100_000);
    container.add(tileImg);
  }

  for (const part of sortWholeMapParts(entry.parts)) {
    const texKey = wfTextureKey(entry.baseDir, part.textureFile);
    const img = scene.add.image(part.x, part.y, texKey);
    img.setOrigin(0, 0);
    const bandOffset = part.sortMode === "below" ? -10_000 : part.sortMode === "sorted" ? part.foot.y : 10_000;
    img.setDepth(part.layerZ * 100_000 + bandOffset + part.drawOrder * 0.001);
    container.add(img);
  }

  return {
    container,
    nav: new WfWholeMapNavRuntime(entry),
    character: entry.character,
    connections: entry.connections,
    regions: entry.regions,
    updateActorDepth(actor, footY, layerZ = 0) {
      actor.setDepth(layerZ * 100_000 + footY);
    },
  };
}

export interface WfScrollingSceneHandle {
  behindContainer: Phaser.GameObjects.Container;
  levelContainer: Phaser.GameObjects.Container;
  frontContainer: Phaser.GameObjects.Container;
  level: WfScrollingSceneEntry["level"];
  update(elapsedSec: number, cameraX: number): void;
  destroy(): void;
}

export function createWfScrollingScene(
  scene: Phaser.Scene,
  entry: WfScrollingSceneEntry,
  options?: { viewportWidth?: number; viewportHeight?: number; autoUpdate?: boolean },
): WfScrollingSceneHandle {
  const behindContainer = scene.add.container(0, 0);
  const levelContainer = scene.add.container(0, 0);
  const frontContainer = scene.add.container(0, 0);
  const viewW = options?.viewportWidth ?? Math.max(entry.backdrop.width, 1280);
  const viewH = options?.viewportHeight ?? 720;

  let backdrop: Phaser.GameObjects.TileSprite | null = null;
  if (entry.backdrop.visible) {
    const key = wfTextureKey(entry.baseDir, entry.backdrop.file);
    backdrop = scene.add.tileSprite(0, 0, viewW, viewH, key);
    backdrop.setOrigin(0, 0);
    backdrop.setScrollFactor(0, 0);
    backdrop.setAlpha(entry.backdrop.opacity);
    behindContainer.add(backdrop);
  }

  const animated: Array<{
    sprite: Phaser.GameObjects.Image;
    item: WfScrollingSceneEntry["layers"][number]["items"][number];
    speed: number;
  }> = [];

  for (const layer of entry.layers) {
    if (!layer.visible) continue;
    const parent = layer.placement === "front" ? frontContainer : behindContainer;
    for (const item of layer.items) {
      const sprite = scene.add.image(item.x, item.y, wfTextureKey(entry.baseDir, item.textureFile));
      sprite.setScale(item.scale);
      sprite.setFlipX(item.flipX);
      sprite.setAlpha(item.opacity * layer.opacity);
      parent.add(sprite);
      animated.push({ sprite, item, speed: layer.speed });
    }
  }

  if (entry.level) {
    for (const group of entry.level.artGroups) {
      const img = scene.add.image(group.x, group.y, wfTextureKey(entry.baseDir, group.file));
      img.setOrigin(0, 0);
      levelContainer.add(img);
    }
    for (const slot of entry.level.slots) {
      const img = scene.add.image(slot.x, slot.y, wfTextureKey(entry.baseDir, slot.file));
      img.setOrigin(slot.anchor, slot.base);
      if (slot.depth === "front") {
        frontContainer.add(img);
      } else {
        levelContainer.add(img);
      }
    }
  }

  const update = (elapsedSec: number, cameraX: number) => {
    if (backdrop) {
      backdrop.setTilePosition(cameraX * entry.backdrop.speed - entry.backdrop.drift * elapsedSec, 0);
    }
    for (const node of animated) {
      const tr = computeParallaxTransform(node.item, node.speed, elapsedSec, cameraX);
      node.sprite.setPosition(tr.x, tr.y);
      node.sprite.setRotation(tr.rotationRad);
    }
  };

  let elapsed = 0;
  const listener =
    options?.autoUpdate === true
      ? (_time: number, deltaMs: number) => {
          elapsed += deltaMs / 1000;
          update(elapsed, scene.cameras.main.scrollX);
        }
      : null;
  if (listener) {
    scene.events.on("update", listener);
  }

  return {
    behindContainer,
    levelContainer,
    frontContainer,
    level: entry.level ?? null,
    update,
    destroy() {
      if (listener) scene.events.off("update", listener);
      behindContainer.destroy(true);
      levelContainer.destroy(true);
      frontContainer.destroy(true);
    },
  };
}

export function createWfWordArt(
  scene: Phaser.Scene,
  entry: WfWordArtEntry,
  x: number,
  y: number,
  value: string,
  size?: number,
): Phaser.GameObjects.BitmapText | Phaser.GameObjects.Image {
  if (entry.mode === "bmfont") {
    return scene.add.bitmapText(x, y, wfWordArtFontKey(entry), value, size ?? entry.font?.size);
  }
  const item = entry.texts?.find((t) => t.name === value) ?? entry.texts?.[0];
  if (!item) {
    throw new Error(`word_art piece ${value} not found in ${entry.path}`);
  }
  const ref = ensureRegionFrame(scene, entry.baseDir, item.texture);
  const img = scene.add.image(x, y, ref.key, ref.frame);
  img.setDisplaySize(item.width, item.height);
  return img;
}

export function createWfIcon(
  scene: Phaser.Scene,
  entry: WfIconSetEntry,
  iconName: string,
  x: number,
  y: number,
  stateRole = "rest",
): Phaser.GameObjects.Image {
  const icon = entry.icons.find((i) => i.name === iconName) ?? entry.icons[0];
  if (!icon) {
    throw new Error(`Icon ${iconName} not found in ${entry.path}`);
  }
  const tex = icon.states[stateRole] ?? Object.values(icon.states)[0];
  if (!tex) {
    throw new Error(`Icon ${icon.name} has no states`);
  }
  const ref = ensureRegionFrame(scene, entry.baseDir, tex);
  const img = scene.add.image(x, y, ref.key, ref.frame);
  img.setDisplaySize(icon.width, icon.height);
  return img;
}

export function getWfTableRows<T extends Record<string, unknown> = Record<string, unknown>>(entry: WfTableEntry): T[] {
  return entry.rows as T[];
}

export function findWfTableRow<T extends Record<string, unknown> = Record<string, unknown>>(
  entry: WfTableEntry,
  field: string,
  value: unknown,
): T | undefined {
  return (entry.rows as T[]).find((row) => row[field] === value);
}
