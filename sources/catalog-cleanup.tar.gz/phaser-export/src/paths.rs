//! Relative path validation and Web game project root resolution.
use plugin_api::Failure;
use plugin_guest::{Host, HostError};

pub fn invalid(message: impl Into<String>) -> HostError {
    HostError::new(Failure::InvalidInput, message)
}

pub fn relative(path: &str) -> Result<(), HostError> {
    if path.is_empty() || path.starts_with('/') || path.contains('\\') {
        return Err(invalid(format!("unsafe relative path {path:?}")));
    }
    for segment in path.split('/') {
        if segment.is_empty()
            || segment == "."
            || segment == ".."
            || matches!(segment, ".git" | "node_modules" | "dist" | "build")
        {
            return Err(invalid(format!("unsafe relative path {path:?}")));
        }
    }
    Ok(())
}

pub fn join(base: &str, child: &str) -> String {
    let base = base.trim_matches('/');
    let child = child.trim_start_matches('/');
    if base.is_empty() {
        child.to_owned()
    } else if child.is_empty() {
        base.to_owned()
    } else {
        format!("{base}/{child}")
    }
}

pub fn root(host: &dyn Host, directory: &str) -> Result<String, HostError> {
    let mut candidate = directory.trim_end_matches('/').to_owned();
    loop {
        if is_web_root(host, &candidate) {
            return Ok(candidate);
        }
        if candidate.is_empty() {
            break;
        }
        candidate = candidate
            .rsplit_once('/')
            .map_or_else(String::new, |(parent, _)| parent.to_owned());
    }
    Err(invalid(
        "directory is not inside a Web project (expected package.json, tsconfig.json, or index.html)",
    ))
}

fn is_web_root(host: &dyn Host, root: &str) -> bool {
    !host.list(&join(root, "package.json")).is_empty()
        || !host.list(&join(root, "tsconfig.json")).is_empty()
        || !host.list(&join(root, "index.html")).is_empty()
}

pub fn asset_path(root: &str, project_path: &str) -> String {
    let root = root.trim_matches('/');
    if root.is_empty() {
        project_path.to_owned()
    } else if let Some(rest) = project_path.strip_prefix(&format!("{root}/")) {
        rest.to_owned()
    } else {
        project_path.to_owned()
    }
}
