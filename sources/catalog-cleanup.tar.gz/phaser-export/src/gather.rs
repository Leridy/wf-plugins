//! Reads WeaveForge mirror locks/sidecars, generates `wf-assets.json`, typed `wf-assets.ts`, and `wf-runtime/*.ts`.
use crate::{
    decode::{decode_basic_node, decode_world_or_extra, find_sidecar},
    paths::{self, invalid},
    reconcile::{self, MANIFEST_NAME, Manifest, ManifestEntry, StampKind},
    types::{File, Input, Node, Output, Plan, Status},
    web::{
        ASSETS_JSON_NAME, ASSETS_TS_NAME, NodeMeta, PLUGIN_TAG, RUNTIME_FILES, load_existing_entries,
        render_assets_json, render_assets_ts, runtime_file_path,
    },
};
use plugin_api::{
    Failure,
    platform::{LockedRow, LocksInput, LocksOutput, Method, NodeInput, NodeOutput},
};
use plugin_guest::{Host, HostError, Platform};
use serde::{Serialize, de::DeserializeOwned};
use serde_json::Value;
use std::collections::{BTreeMap, BTreeSet};

const MAX_SIDECAR: usize = 8 << 20;
const MAX_OUTPUT: usize = 16 << 20;
const SCHEMA_VERSION: u32 = 1;

struct DecodedNode {
    node: Node,
    form: String,
    entry_key: String,
    entry: Value,
}

pub fn sync(host: &dyn Platform, input: &Input) -> Result<Plan, HostError> {
    let mut plan = Plan {
        output: Output::default(),
        effects: Vec::new(),
    };
    let locks: LocksOutput = match answer(
        host,
        Method::MirrorLocks,
        &LocksInput {
            directory: input.directory.clone(),
        },
    ) {
        Ok(locks) => locks,
        Err(error) if error.kind == Failure::NotFound && !input.nodes.is_empty() => {
            selection(host, input, &[], &mut plan.output)?;
            return Ok(plan);
        }
        Err(error) => return Err(error),
    };

    let directory = locks.directory.trim_end_matches('/');
    if directory != "." && !directory.is_empty() {
        paths::relative(directory)?;
    }
    let directory = if directory == "." { "" } else { directory };
    let root = paths::root(host, directory)?;
    let selected = selection(host, input, &locks.nodes, &mut plan.output)?;

    let manifest_path = paths::join(directory, MANIFEST_NAME);
    let prev_manifest = Manifest::load(host, &manifest_path);
    let mut next_manifest = Manifest::default();
    let mut wanted = BTreeSet::new();
    let mut size = 0usize;

    let assets_json_path = paths::join(directory, ASSETS_JSON_NAME);
    let assets_ts_path = paths::join(directory, ASSETS_TS_NAME);
    let prev_entries = host
        .read(&assets_json_path)
        .map(|b| load_existing_entries(&b))
        .unwrap_or_default();

    let locked_ids: BTreeSet<&str> = locks.nodes.iter().map(|n| n.id.as_str()).collect();
    let mut entries = if input.nodes.is_empty() {
        BTreeMap::new()
    } else {
        prev_entries
            .iter()
            .filter(|(_, val)| {
                val.get("id")
                    .and_then(Value::as_str)
                    .is_some_and(|id| locked_ids.contains(id) && !selected.contains(id))
            })
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect()
    };

    let mut decoded_nodes = Vec::new();
    for row in locks.nodes.iter().filter(|r| selected.contains(&r.id)) {
        if let Some(decoded) = decode_node(host, directory, &root, row, &mut plan.output)? {
            entries.insert(decoded.entry_key.clone(), decoded.entry.clone());
            decoded_nodes.push(decoded);
        }
    }

    if !entries.is_empty() {
        emit_outputs(
            host,
            &locks,
            directory,
            &root,
            input.force,
            &assets_json_path,
            &assets_ts_path,
            &prev_entries,
            &entries,
            decoded_nodes,
            &prev_manifest,
            &mut next_manifest,
            &mut wanted,
            &mut size,
            &mut plan,
        )?;
    }

    leftovers(
        host,
        input.force,
        &prev_manifest,
        &mut next_manifest,
        &wanted,
        &mut plan,
    )?;

    if next_manifest != prev_manifest {
        let mbytes = next_manifest.to_bytes();
        let _ = reconcile::plan_write(host, PLUGIN_TAG, &manifest_path, mbytes, true, None, &mut plan.effects)?;
    }

    Ok(plan)
}

#[allow(clippy::too_many_arguments)]
fn emit_outputs(
    host: &dyn Platform,
    locks: &LocksOutput,
    directory: &str,
    root: &str,
    force: bool,
    assets_json_path: &str,
    assets_ts_path: &str,
    prev_entries: &BTreeMap<String, Value>,
    entries: &BTreeMap<String, Value>,
    decoded_nodes: Vec<DecodedNode>,
    prev_manifest: &Manifest,
    next_manifest: &mut Manifest,
    wanted: &mut BTreeSet<String>,
    size: &mut usize,
    plan: &mut Plan,
) -> Result<(), HostError> {
    let json_bytes = render_assets_json(entries);
    let ts_bytes = render_assets_ts(entries);
    let json_status = record_generated_file(
        host,
        locks,
        directory,
        force,
        assets_json_path,
        "shared-manifest-json",
        json_bytes,
        prev_manifest,
        next_manifest,
        wanted,
        size,
        plan,
    )?;
    let ts_status = record_generated_file(
        host,
        locks,
        directory,
        force,
        assets_ts_path,
        "shared-manifest-ts",
        ts_bytes,
        prev_manifest,
        next_manifest,
        wanted,
        size,
        plan,
    )?;

    for &(name, body) in RUNTIME_FILES {
        let path = runtime_file_path(directory, name);
        let bytes = reconcile::prepare_bytes(PLUGIN_TAG, "runtime", SCHEMA_VERSION, body, StampKind::SlashLine);
        let owner = format!("shared-runtime-{name}");
        let st = record_generated_file(
            host,
            locks,
            directory,
            force,
            &path,
            &owner,
            bytes,
            prev_manifest,
            next_manifest,
            wanted,
            size,
            plan,
        )?;
        if st == Status::Kept {
            plan.output.warnings.push(format!(
                "{path}: shared runtime has local edits; use --force to replace it."
            ));
        }
    }

    let json_res = paths::asset_path(root, assets_json_path);
    let ts_res = paths::asset_path(root, assets_ts_path);
    for mut decoded in decoded_nodes {
        let entry_changed = prev_entries.get(&decoded.entry_key) != Some(&decoded.entry);
        decoded.node.status = summarize_node_status(json_status, ts_status, entry_changed);
        decoded.node.main_prefab = Some(format!("{ts_res}#{}", decoded.entry_key));
        decoded.node.files = vec![
            File {
                path: assets_json_path.to_owned(),
                resource: json_res.clone(),
                status: json_status,
            },
            File {
                path: assets_ts_path.to_owned(),
                resource: ts_res.clone(),
                status: ts_status,
            },
        ];
        plan.output.push_node(decoded.node, Some(&decoded.form));
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn record_generated_file(
    host: &dyn Platform,
    locks: &LocksOutput,
    directory: &str,
    force: bool,
    path: &str,
    owner: &str,
    bytes: Vec<u8>,
    prev_manifest: &Manifest,
    next_manifest: &mut Manifest,
    wanted: &mut BTreeSet<String>,
    size: &mut usize,
    plan: &mut Plan,
) -> Result<Status, HostError> {
    if !wanted.insert(path.to_owned()) {
        return Err(invalid(format!("generated paths collide: {path}")));
    }
    ensure_not_locked(locks, directory, path)?;
    *size += bytes.len();
    if *size > MAX_OUTPUT {
        return Err(invalid("generated output exceeds 16 MiB; sync fewer nodes"));
    }
    let recorded = prev_manifest.files.get(path).map(|e| e.sha256.as_str());
    let (st, sha) = reconcile::plan_write(host, PLUGIN_TAG, path, bytes, force, recorded, &mut plan.effects)?;
    if st == Status::Kept && owner.starts_with("shared-manifest") {
        plan.output
            .warnings
            .push(format!("{path}: local edits detected; use --force to replace it."));
    }
    next_manifest.files.insert(
        path.to_owned(),
        ManifestEntry {
            owner: owner.to_owned(),
            version: SCHEMA_VERSION,
            sha256: sha,
        },
    );
    Ok(st)
}

fn summarize_node_status(json_status: Status, ts_status: Status, entry_changed: bool) -> Status {
    if ts_status == Status::Kept || json_status == Status::Kept {
        if entry_changed { Status::Kept } else { Status::Unchanged }
    } else if ts_status == Status::Written || json_status == Status::Written {
        Status::Written
    } else if entry_changed && (ts_status == Status::Updated || json_status == Status::Updated) {
        Status::Updated
    } else {
        Status::Unchanged
    }
}

fn decode_node(
    host: &dyn Platform,
    directory: &str,
    root: &str,
    row: &LockedRow,
    output: &mut Output,
) -> Result<Option<DecodedNode>, HostError> {
    let info: NodeOutput = answer(
        host,
        Method::MirrorNode,
        &NodeInput {
            address: format!("wf://{}", row.id),
        },
    )?;
    let node_type = info.node.node_type.as_str();
    let mut node = Node {
        id: row.id.clone(),
        number: row.number,
        path: row.path.clone(),
        node_type: info.node.node_type.clone(),
        status: Status::Skipped,
        files: Vec::new(),
        main_prefab: None,
        elements: Vec::new(),
        reasons: Vec::new(),
    };
    let Some((prefix, sidecar_name)) = find_sidecar(node_type, row) else {
        node.reasons.push(format!(
            "{}: no supported Web export file for type {node_type}; skipped.",
            row.path
        ));
        output.push_node(node, Some(&row.form));
        return Ok(None);
    };

    let node_dir = paths::join(directory, &prefix);
    let base_dir = paths::asset_path(root, &node_dir);
    let entry_key = info.node.path.trim_matches('/').to_owned();
    let meta = NodeMeta {
        id: &row.id,
        path: &info.node.path,
        base_dir: &base_dir,
    };

    let sidecar_path = paths::join(&node_dir, &sidecar_name);
    let bytes = read_sidecar(host, &sidecar_path)?;
    let locked: BTreeSet<String> = row.files.iter().cloned().collect();

    let (entry, elements, notes) = match node_type {
        "frame_animation" | "character_effect" | "ui" | "tilemap" | "prop" => {
            decode_basic_node(host, row, directory, &prefix, node_type, meta, &entry_key, &bytes)?
        }
        "particle_effect" | "whole_map" | "scrolling_scene" | "scroll_map" | "word_art" | "icon" | "table" => {
            decode_world_or_extra(
                host,
                row,
                directory,
                &prefix,
                node_type,
                &sidecar_name,
                meta,
                &entry_key,
                &bytes,
                &locked,
            )?
        }
        other => {
            node.reasons
                .push(format!("{}: unsupported type {other}; skipped.", row.path));
            output.push_node(node, Some(&row.form));
            return Ok(None);
        }
    };

    node.elements = elements;
    node.reasons = notes;
    Ok(Some(DecodedNode {
        node,
        form: row.form.clone(),
        entry_key,
        entry,
    }))
}

fn read_sidecar(host: &dyn Host, path: &str) -> Result<Vec<u8>, HostError> {
    let bytes = host.read(path)?;
    if bytes.len() > MAX_SIDECAR {
        return Err(invalid(format!("{path} exceeds 8 MiB sidecar limit")));
    }
    Ok(bytes)
}

fn leftovers(
    host: &dyn Platform,
    force: bool,
    prev_manifest: &Manifest,
    next_manifest: &mut Manifest,
    wanted: &BTreeSet<String>,
    plan: &mut Plan,
) -> Result<(), HostError> {
    for (path, entry) in &prev_manifest.files {
        if wanted.contains(path) {
            continue;
        }
        if reconcile::plan_delete(host, PLUGIN_TAG, path, force, Some(&entry.sha256), &mut plan.effects)? {
            plan.output.deleted.push(path.clone());
        } else {
            plan.output.warnings.push(format!(
                "{path}: leftover has local edits; kept (pass force to remove)."
            ));
            next_manifest.files.insert(path.clone(), entry.clone());
        }
    }
    Ok(())
}

fn selection(
    host: &dyn Platform,
    input: &Input,
    nodes: &[LockedRow],
    output: &mut Output,
) -> Result<BTreeSet<String>, HostError> {
    if input.nodes.is_empty() {
        return Ok(nodes.iter().map(|n| n.id.clone()).collect());
    }
    let mut selected = BTreeSet::new();
    for addr in &input.nodes {
        let info: NodeOutput = answer(host, Method::MirrorNode, &NodeInput { address: addr.clone() })?;
        if let Some(row) = nodes.iter().find(|r| r.id == info.node.id) {
            selected.insert(row.id.clone());
        } else {
            output.push_node(
                Node {
                    id: info.node.id.clone(),
                    number: info.node.number,
                    path: info.node.path.clone(),
                    node_type: info.node.node_type.clone(),
                    status: Status::Skipped,
                    files: Vec::new(),
                    main_prefab: None,
                    elements: Vec::new(),
                    reasons: vec![format!("{} has no ready export; run wf export first.", info.node.path)],
                },
                None,
            );
        }
    }
    Ok(selected)
}

fn ensure_not_locked(locks: &LocksOutput, directory: &str, path: &str) -> Result<(), HostError> {
    let conflict = locks
        .nodes
        .iter()
        .flat_map(|n| &n.files)
        .any(|f| paths::join(directory, f) == path);
    if conflict {
        return Err(invalid(format!("refusing to overwrite locked export file {path}")));
    }
    Ok(())
}

fn answer<I: Serialize, O: DeserializeOwned>(host: &dyn Platform, method: Method, input: &I) -> Result<O, HostError> {
    let payload = serde_json::to_vec(input).map_err(|e| invalid(e.to_string()))?;
    let bytes = host.call(method.name(), &payload)?;
    serde_json::from_slice(&bytes).map_err(|e| invalid(e.to_string()))
}
