//! A result row uses the same node status as the structured sync report.
use crate::types::{Node, Output, Status};
use plugin_protocols::ui::{Cell, Status as UiStatus, Tone};

impl Output {
    pub(crate) fn push_node(&mut self, node: Node, form: Option<&str>) {
        let (tone, text) = match (form, node.status) {
            (None, _) => (Tone::Warn, "Run wf export"),
            (_, Status::Written) => (Tone::Ok, "Written"),
            (_, Status::Updated) => (Tone::Ok, "Updated"),
            (_, Status::Unchanged) => (Tone::Neutral, "Unchanged"),
            (_, Status::Skipped) => (Tone::Warn, "Skipped"),
            (_, Status::Kept) => (Tone::Warn, "Edits kept"),
        };
        self.table.rows.push(vec![
            Cell::Node(format!("wf://{}", node.id)),
            Cell::Status(UiStatus {
                tone,
                text: text.into(),
            }),
            Cell::Number(f64::from(
                u32::try_from(node.files.len()).expect("resource count fits u32"),
            )),
            Cell::Path(node.main_prefab.clone().unwrap_or_default()),
        ]);
        self.nodes.push(node);
    }
}
