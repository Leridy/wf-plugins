//! The official `phaser-export` plugin: generates typed `wf-assets.ts` manifests
//! + `wf-assets.json` and plug-and-play Phaser 3 TypeScript loaders, particle simulator
//!   matching `simulation.ts`, whole-map dilated tile composer & pathfinder, and parallax layers.
#![cfg_attr(
    not(target_arch = "wasm32"),
    allow(dead_code, reason = "the component glue that calls into these is wasm-only")
)]

#[cfg(target_arch = "wasm32")]
mod component;
mod decode;
mod describe;
mod gather;
mod model;
mod paths;
mod reconcile;
mod table;
mod types;
mod web;

pub use gather::sync;
pub use types::{Element, File, Input, Node, Output, Plan, Status};
