//! Capability description for `phaser-export`.
use crate::types::{Input, Output};
use plugin_api::{Capability, Description, Example, Risk};
use schemars::schema_for;

pub const OP: &str = "sync";

pub fn description() -> Description {
    Description {
        capabilities: vec![Capability {
            op: OP.into(),
            summary: "Generate typed wf-assets.ts manifests and Phaser 3 TypeScript loaders/players from wf exports".into(),
            when: "The project uses Phaser 3 on Web/MiniGame and exported animations, UI kits, tilemaps, particles, whole_map, scrolling_scene, word_art, icons, or tables need typed TypeScript runtime glue.".into(),
            risk: Risk::Write,
            input: serde_json::to_value(schema_for!(Input)).expect("input schema"),
            output: Some(serde_json::to_value(schema_for!(Output)).expect("output schema")),
            examples: vec![
                Example {
                    args: "sync".into(),
                    note: "Generate wf-assets.json, wf-assets.ts, and wf-runtime/*.ts for all exported nodes.".into(),
                },
                Example {
                    args: "sync --nodes #12 --force".into(),
                    note: "Re-generate node #12 and overwrite locally modified runtime files.".into(),
                },
            ],
            implements: None,
        }],
    }
}
